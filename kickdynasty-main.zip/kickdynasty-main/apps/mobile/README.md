# kickdynasty_mobile

Aplicación móvil de KickDynasty (Android e iOS).

## Flujo jugable (Fase 6)

1. **Menú** — Nueva partida o continuar un guardado.
2. **Nueva partida** — Nombre y semilla del mundo.
3. **Elegir club** — Pestañas por liga; toca un club para empezar.
4. **Hub de campaña** — Plantilla, clasificación, avanzar jornada, guardar.
5. **Resultados** — Marcadores de la jornada (destaca tu club).
6. **Clasificación** — Tabla parcial de tu liga.

## Desarrollo

```bash
# Desde la raíz del monorepo
dart pub get
cd apps/mobile
flutter run
```

APK debug: `flutter build apk --debug` →
`build/app/outputs/flutter-apk/app-debug.apk`.

## Tests

Golden tests del vertical:

```bash
flutter test test/vertical_golden_test.dart
```

Actualizar referencias: añadir `--update-goldens`.
