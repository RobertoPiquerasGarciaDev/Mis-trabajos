import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Plantilla del club del jugador con atributos y condición.
class SquadScreen extends ConsumerWidget {
  /// Crea la pantalla.
  const SquadScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(activeCampaignProvider).value;
    final theme = Theme.of(context);
    if (session == null) {
      return const Scaffold(body: Center(child: Text('Sin partida activa')));
    }

    final club = playerClubOf(session.state);
    if (club == null) {
      return const Scaffold(
        body: Center(child: Text('No hay club del jugador')),
      );
    }

    final players = [...club.squad.players]
      ..sort((a, b) {
        final pos = a.position.group.index.compareTo(b.position.group.index);
        if (pos != 0) return pos;
        return b.overall.compareTo(a.overall);
      });

    return Scaffold(
      appBar: AppBar(title: Text('Plantilla · ${club.club.code.value}')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: players.length,
        separatorBuilder: (_, _) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final player = players[index];
          return Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          player.name.value,
                          style: theme.textTheme.titleSmall,
                        ),
                      ),
                      Text(
                        '${player.overall}',
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: theme.colorScheme.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  Text(
                    '${player.position.label} · ${player.age.years} años · '
                    'Pot ${player.potential.value}',
                    style: theme.textTheme.bodySmall,
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 12,
                    runSpacing: 4,
                    children: [
                      _ConditionChip(
                        label: 'Físico',
                        value: player.fitness.value,
                      ),
                      _ConditionChip(
                        label: 'Moral',
                        value: player.morale.value,
                      ),
                      _ConditionChip(label: 'Forma', value: player.form.value),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class _ConditionChip extends StatelessWidget {
  const _ConditionChip({required this.label, required this.value});

  final String label;
  final int value;

  @override
  Widget build(BuildContext context) {
    return Chip(
      visualDensity: VisualDensity.compact,
      label: Text('$label $value'),
    );
  }
}

extension on Position {
  String get label => name.toUpperCase();
}

extension on Player {
  int get overall {
    final attrs = attributes;
    final fieldAvg =
        (attrs.pace.value +
            attrs.stamina.value +
            attrs.strength.value +
            attrs.passing.value +
            attrs.shooting.value +
            attrs.dribbling.value +
            attrs.tackling.value +
            attrs.positioning.value +
            attrs.vision.value +
            attrs.composure.value) ~/
        10;
    if (position.isGoalkeeper) {
      return ((fieldAvg + attrs.goalkeeping.value * 2) / 3).round();
    }
    return fieldAvg;
  }
}
