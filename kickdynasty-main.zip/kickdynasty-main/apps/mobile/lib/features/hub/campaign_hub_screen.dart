import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_mobile/router/app_router.dart';

/// Centro de mando de la partida en curso.
class CampaignHubScreen extends ConsumerWidget {
  /// Crea la pantalla.
  const CampaignHubScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncSession = ref.watch(activeCampaignProvider);
    final theme = Theme.of(context);

    return asyncSession.when(
      loading: () =>
          const Scaffold(body: Center(child: CircularProgressIndicator())),
      error: (e, _) => Scaffold(body: Center(child: Text('Error: $e'))),
      data: (session) {
        if (session == null) {
          return const Scaffold(
            body: Center(child: Text('Sin partida activa')),
          );
        }
        final club = playerClubOf(session.state);
        final seasonComplete = session.state.isSeasonComplete;

        return Scaffold(
          appBar: AppBar(
            title: Text(session.saveName),
            actions: [
              IconButton(
                tooltip: 'Guardar',
                onPressed: () async {
                  await ref.read(activeCampaignProvider.notifier).save();
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Partida guardada')),
                    );
                  }
                },
                icon: const Icon(Icons.save_outlined),
              ),
              IconButton(
                tooltip: 'Salir al menú',
                onPressed: () {
                  ref.read(activeCampaignProvider.notifier).clear();
                  context.go(AppRoutes.home);
                },
                icon: const Icon(Icons.home_outlined),
              ),
            ],
          ),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (club != null) ...[
                    Text(
                      club.club.name.value,
                      style: theme.textTheme.headlineSmall,
                    ),
                    Text(
                      '${club.club.code.value} · Rep ${club.club.reputation.value}',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                  const SizedBox(height: 8),
                  Text(
                    'Temporada ${session.state.season} · '
                    'Jornada ${seasonComplete ? 'finalizada' : session.state.nextRound}',
                    style: theme.textTheme.titleMedium,
                  ),
                  if (seasonComplete)
                    Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(
                        'Temporada completada. El rollover llegará en una fase posterior.',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.tertiary,
                        ),
                      ),
                    ),
                  const SizedBox(height: 32),
                  _HubButton(
                    icon: Icons.groups_outlined,
                    label: 'Plantilla',
                    onTap: () => context.push(AppRoutes.squad),
                  ),
                  const SizedBox(height: 12),
                  _HubButton(
                    icon: Icons.leaderboard_outlined,
                    label: 'Clasificación',
                    onTap: () => context.push(AppRoutes.table),
                  ),
                  const Spacer(),
                  FilledButton.icon(
                    onPressed: seasonComplete
                        ? null
                        : () async {
                            await ref
                                .read(activeCampaignProvider.notifier)
                                .advanceRound();
                            if (context.mounted) {
                              context.push(AppRoutes.roundResults);
                            }
                          },
                    icon: const Icon(Icons.play_arrow),
                    label: Text(
                      seasonComplete
                          ? 'Temporada terminada'
                          : 'Avanzar jornada ${session.state.nextRound}',
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}

class _HubButton extends StatelessWidget {
  const _HubButton({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton.icon(
      onPressed: onTap,
      icon: Icon(icon),
      label: Align(alignment: Alignment.centerLeft, child: Text(label)),
      style: OutlinedButton.styleFrom(
        minimumSize: const Size.fromHeight(52),
        alignment: Alignment.centerLeft,
      ),
    );
  }
}
