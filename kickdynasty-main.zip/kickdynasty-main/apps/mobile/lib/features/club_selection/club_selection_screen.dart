import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_mobile/features/new_game/new_game_draft.dart';
import 'package:kickdynasty_mobile/router/app_router.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';

/// Pantalla para elegir el club que dirigirá el jugador humano.
class ClubSelectionScreen extends ConsumerStatefulWidget {
  /// Crea la pantalla.
  const ClubSelectionScreen({required this.draft, super.key});

  /// Datos de la partida nueva.
  final NewGameDraft draft;

  @override
  ConsumerState<ClubSelectionScreen> createState() =>
      _ClubSelectionScreenState();
}

class _ClubSelectionScreenState extends ConsumerState<ClubSelectionScreen>
    with SingleTickerProviderStateMixin {
  late final GeneratedWorld _preview;
  late final TabController _tabs;
  var _starting = false;

  @override
  void initState() {
    super.initState();
    _preview = WorldGenerator().generate(seed: widget.draft.seed);
    _tabs = TabController(length: _preview.leagues.length, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  Future<void> _selectClub(GeneratedClub club) async {
    if (_starting) return;
    setState(() => _starting = true);
    await ref
        .read(activeCampaignProvider.notifier)
        .startNew(
          name: widget.draft.name,
          seed: widget.draft.seed,
          playerClubId: club.club.id,
        );
    if (!mounted) return;
    final error = ref.read(activeCampaignProvider).error;
    if (error != null) {
      setState(() => _starting = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('No se pudo crear la partida: $error')),
      );
      return;
    }
    context.go(AppRoutes.campaign);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Elegir club'),
        bottom: TabBar(
          controller: _tabs,
          tabs: [
            for (final league in _preview.leagues)
              Tab(text: league.league.name.value),
          ],
        ),
      ),
      body: _starting
          ? const Center(child: CircularProgressIndicator())
          : TabBarView(
              controller: _tabs,
              children: [
                for (final league in _preview.leagues)
                  ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: league.clubs.length,
                    separatorBuilder: (_, _) => const SizedBox(height: 8),
                    itemBuilder: (context, index) {
                      final generated = league.clubs[index];
                      final club = generated.club;
                      return Card(
                        child: ListTile(
                          leading: CircleAvatar(child: Text(club.code.value)),
                          title: Text(club.name.value),
                          subtitle: Text(
                            '${club.country.value} · Rep ${club.reputation.value} · '
                            '${generated.squad.players.length} jugadores',
                            style: theme.textTheme.bodySmall,
                          ),
                          trailing: const Icon(Icons.arrow_forward),
                          onTap: () => _selectClub(generated),
                        ),
                      );
                    },
                  ),
              ],
            ),
    );
  }
}
