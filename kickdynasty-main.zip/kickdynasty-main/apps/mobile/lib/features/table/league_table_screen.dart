import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart' as engine;

/// Clasificación de la liga del club del jugador.
class LeagueTableScreen extends ConsumerWidget {
  /// Crea la pantalla.
  const LeagueTableScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(activeCampaignProvider).value;
    final table = ref.watch(playerLeagueTableProvider);
    final theme = Theme.of(context);

    if (session == null || table == null) {
      return const Scaffold(body: Center(child: Text('Sin datos de liga')));
    }

    final playerClubId = session.state.playerClubId;

    return Scaffold(
      appBar: AppBar(title: const Text('Clasificación')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: const [
              SizedBox(width: 28, child: Text('#')),
              Expanded(flex: 4, child: Text('Club')),
              Expanded(child: Text('PJ', textAlign: TextAlign.center)),
              Expanded(child: Text('Pts', textAlign: TextAlign.center)),
              Expanded(child: Text('DG', textAlign: TextAlign.center)),
            ],
          ),
          const Divider(height: 24),
          for (var i = 0; i < table.rows.length; i++)
            _TableRowTile(
              position: i + 1,
              clubName: clubNameOf(session.state, table.rows[i].clubId),
              row: table.rows[i],
              highlight: table.rows[i].clubId == playerClubId,
              theme: theme,
            ),
        ],
      ),
    );
  }
}

class _TableRowTile extends StatelessWidget {
  const _TableRowTile({
    required this.position,
    required this.clubName,
    required this.row,
    required this.highlight,
    required this.theme,
  });

  final int position;
  final String clubName;
  final engine.TableRow row;
  final bool highlight;
  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          SizedBox(
            width: 28,
            child: Text(
              '$position',
              style: highlight
                  ? theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.primary,
                    )
                  : null,
            ),
          ),
          Expanded(
            flex: 4,
            child: Text(
              clubName,
              style: highlight
                  ? theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.bold,
                    )
                  : null,
            ),
          ),
          Expanded(child: Text('${row.played}', textAlign: TextAlign.center)),
          Expanded(
            child: Text(
              '${row.points}',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            child: Text(
              '${row.goalDifference >= 0 ? '+' : ''}${row.goalDifference}',
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}
