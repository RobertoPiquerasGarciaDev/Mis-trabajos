import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';
import 'package:kickdynasty_mobile/router/app_router.dart';

/// Pantalla principal: nueva partida o continuar una existente.
class HomeScreen extends ConsumerWidget {
  /// Crea la pantalla.
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final saves = ref.watch(savedGamesProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('KickDynasty')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Simulador de gestión futbolística',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
              const SizedBox(height: 32),
              FilledButton.icon(
                onPressed: () => context.push(AppRoutes.newGame),
                icon: const Icon(Icons.add),
                label: const Text('Nueva partida'),
              ),
              const SizedBox(height: 32),
              Text('Continuar', style: theme.textTheme.titleSmall),
              const SizedBox(height: 12),
              Expanded(
                child: saves.when(
                  loading: () =>
                      const Center(child: CircularProgressIndicator()),
                  error: (e, _) => Center(child: Text('Error: $e')),
                  data: (items) {
                    if (items.isEmpty) {
                      return Center(
                        child: Text(
                          'No hay partidas guardadas',
                          style: theme.textTheme.bodyLarge?.copyWith(
                            color: theme.colorScheme.onSurfaceVariant,
                          ),
                        ),
                      );
                    }
                    return ListView.separated(
                      itemCount: items.length,
                      separatorBuilder: (_, _) => const SizedBox(height: 8),
                      itemBuilder: (context, index) {
                        final save = items[index];
                        return _SaveTile(save: save);
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _SaveTile extends ConsumerWidget {
  const _SaveTile({required this.save});

  final SaveSummary save;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final clubLabel = save.playerClubId?.value ?? 'Espectador';
    return Card(
      child: ListTile(
        title: Text(save.name),
        subtitle: Text('T${save.season} · J${save.nextRound} · $clubLabel'),
        trailing: const Icon(Icons.chevron_right),
        onTap: () async {
          await ref.read(activeCampaignProvider.notifier).load(save);
          if (context.mounted) context.go(AppRoutes.campaign);
        },
      ),
    );
  }
}
