import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';

/// Resultados de la última jornada disputada.
class RoundResultsScreen extends ConsumerWidget {
  /// Crea la pantalla.
  const RoundResultsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(activeCampaignProvider).value;
    final theme = Theme.of(context);
    if (session == null) {
      return const Scaffold(body: Center(child: Text('Sin partida activa')));
    }

    final round = session.lastRound;
    if (round == null) {
      return const Scaffold(
        body: Center(child: Text('Aún no se ha jugado ninguna jornada')),
      );
    }

    final playerClubId = session.state.playerClubId;

    return Scaffold(
      appBar: AppBar(title: Text('Jornada ${round.round}')),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: round.matches.length,
        separatorBuilder: (_, _) => const SizedBox(height: 8),
        itemBuilder: (context, index) {
          final match = round.matches[index];
          final home = clubNameOf(session.state, match.fixture.homeClubId);
          final away = clubNameOf(session.state, match.fixture.awayClubId);
          final result = match.report.result;
          final involved =
              playerClubId != null &&
              (match.fixture.homeClubId == playerClubId ||
                  match.fixture.awayClubId == playerClubId);

          return Card(
            color: involved
                ? theme.colorScheme.primaryContainer.withValues(alpha: 0.35)
                : null,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          home,
                          textAlign: TextAlign.end,
                          style:
                              involved &&
                                  match.fixture.homeClubId == playerClubId
                              ? theme.textTheme.titleSmall?.copyWith(
                                  fontWeight: FontWeight.bold,
                                )
                              : theme.textTheme.bodyLarge,
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Text(
                          '${result.homeGoals} – ${result.awayGoals}',
                          style: theme.textTheme.headlineSmall?.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      Expanded(
                        child: Text(
                          away,
                          style:
                              involved &&
                                  match.fixture.awayClubId == playerClubId
                              ? theme.textTheme.titleSmall?.copyWith(
                                  fontWeight: FontWeight.bold,
                                )
                              : theme.textTheme.bodyLarge,
                        ),
                      ),
                    ],
                  ),
                  if (involved) ...[
                    const SizedBox(height: 8),
                    Text(
                      'Posesión ${match.report.homeStats.possessionPct}% – '
                      '${match.report.awayStats.possessionPct}% · '
                      'Tiros ${match.report.homeStats.shots}–'
                      '${match.report.awayStats.shots}',
                      style: theme.textTheme.bodySmall,
                    ),
                  ],
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
