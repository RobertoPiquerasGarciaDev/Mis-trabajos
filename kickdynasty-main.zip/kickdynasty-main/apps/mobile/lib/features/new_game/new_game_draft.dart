/// Borrador de partida nueva antes de elegir club.
class NewGameDraft {
  /// Crea el borrador.
  const NewGameDraft({required this.name, required this.seed});

  /// Nombre del guardado.
  final String name;

  /// Semilla del mundo.
  final int seed;
}
