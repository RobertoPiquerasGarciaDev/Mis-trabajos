import 'dart:math';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:kickdynasty_mobile/features/new_game/new_game_draft.dart';
import 'package:kickdynasty_mobile/router/app_router.dart';

/// Pantalla para nombrar la partida y elegir semilla.
class NewGameScreen extends StatefulWidget {
  /// Crea la pantalla.
  const NewGameScreen({super.key});

  @override
  State<NewGameScreen> createState() => _NewGameScreenState();
}

class _NewGameScreenState extends State<NewGameScreen> {
  final _nameController = TextEditingController(text: 'Mi carrera');
  final _seedController = TextEditingController(text: '42');
  final _formKey = GlobalKey<FormState>();

  @override
  void dispose() {
    _nameController.dispose();
    _seedController.dispose();
    super.dispose();
  }

  void _randomizeSeed() {
    final seed = Random().nextInt(1 << 30);
    _seedController.text = seed.toString();
  }

  void _continue() {
    if (!_formKey.currentState!.validate()) return;
    final draft = NewGameDraft(
      name: _nameController.text.trim(),
      seed: int.parse(_seedController.text.trim()),
    );
    context.push(AppRoutes.clubSelection, extra: draft);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nueva partida')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nombre del guardado',
                  ),
                  validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Obligatorio' : null,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _seedController,
                  decoration: InputDecoration(
                    labelText: 'Semilla del mundo',
                    suffixIcon: IconButton(
                      onPressed: _randomizeSeed,
                      icon: const Icon(Icons.casino_outlined),
                      tooltip: 'Semilla aleatoria',
                    ),
                  ),
                  keyboardType: TextInputType.number,
                  validator: (v) {
                    if (v == null || int.tryParse(v.trim()) == null) {
                      return 'Introduce un número entero';
                    }
                    return null;
                  },
                ),
                const Spacer(),
                FilledButton(
                  onPressed: _continue,
                  child: const Text('Elegir club'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
