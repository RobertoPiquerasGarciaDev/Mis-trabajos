import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kickdynasty_mobile/router/app_router.dart';
import 'package:kickdynasty_mobile/theme/app_theme.dart';

/// Raíz de la aplicación KickDynasty.
class KickDynastyApp extends ConsumerWidget {
  /// Crea la app.
  const KickDynastyApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final router = ref.watch(appRouterProvider);
    return MaterialApp.router(
      title: 'KickDynasty',
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: ThemeMode.dark,
      routerConfig: router,
    );
  }
}
