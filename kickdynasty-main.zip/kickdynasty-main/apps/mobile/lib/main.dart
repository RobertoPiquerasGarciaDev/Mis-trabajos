import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_mobile/app.dart';
import 'package:kickdynasty_mobile/bootstrap.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final database = await openAppDatabase();
  runApp(
    ProviderScope(
      overrides: [saveDatabaseProvider.overrideWithValue(database)],
      child: const KickDynastyApp(),
    ),
  );
}
