import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_mobile/features/club_selection/club_selection_screen.dart';
import 'package:kickdynasty_mobile/features/new_game/new_game_draft.dart';
import 'package:kickdynasty_mobile/features/home/home_screen.dart';
import 'package:kickdynasty_mobile/features/hub/campaign_hub_screen.dart';
import 'package:kickdynasty_mobile/features/new_game/new_game_screen.dart';
import 'package:kickdynasty_mobile/features/round/round_results_screen.dart';
import 'package:kickdynasty_mobile/features/squad/squad_screen.dart';
import 'package:kickdynasty_mobile/features/table/league_table_screen.dart';

/// Rutas de la aplicación.
abstract final class AppRoutes {
  static const home = '/';
  static const newGame = '/new';
  static const clubSelection = '/new/clubs';
  static const campaign = '/campaign';
  static const squad = '/campaign/squad';
  static const roundResults = '/campaign/round';
  static const table = '/campaign/table';
}

/// Router principal con redirección según sesión activa.
final appRouterProvider = Provider<GoRouter>((ref) {
  final refresh = ValueNotifier(0);
  ref.listen(activeCampaignProvider, (_, _) => refresh.value++);

  return GoRouter(
    initialLocation: AppRoutes.home,
    refreshListenable: refresh,
    redirect: (context, state) {
      final session = ref.read(activeCampaignProvider).value;
      final loc = state.matchedLocation;
      final needsSession = loc.startsWith('/campaign');
      if (needsSession && session == null) return AppRoutes.home;
      return null;
    },
    routes: [
      GoRoute(
        path: AppRoutes.home,
        builder: (context, state) => const HomeScreen(),
      ),
      GoRoute(
        path: AppRoutes.newGame,
        builder: (context, state) => const NewGameScreen(),
      ),
      GoRoute(
        path: AppRoutes.clubSelection,
        builder: (context, state) {
          final extra = state.extra! as NewGameDraft;
          return ClubSelectionScreen(draft: extra);
        },
      ),
      GoRoute(
        path: AppRoutes.campaign,
        builder: (context, state) => const CampaignHubScreen(),
        routes: [
          GoRoute(
            path: 'squad',
            builder: (context, state) => const SquadScreen(),
          ),
          GoRoute(
            path: 'round',
            builder: (context, state) => const RoundResultsScreen(),
          ),
          GoRoute(
            path: 'table',
            builder: (context, state) => const LeagueTableScreen(),
          ),
        ],
      ),
    ],
  );
});
