import 'dart:io';

import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// Abre (o crea) la base de datos de partidas en el directorio de la app.
Future<SaveDatabase> openAppDatabase() async {
  final dir = await getApplicationDocumentsDirectory();
  final path = p.join(dir.path, 'kickdynasty.db');
  return openSaveDatabase(path);
}

/// Ruta de la base de datos (útil en tests de integración).
Future<String> appDatabasePath() async {
  final dir = await getApplicationDocumentsDirectory();
  return p.join(dir.path, 'kickdynasty.db');
}

/// Indica si la plataforma actual es móvil nativa.
bool get isMobilePlatform => Platform.isAndroid || Platform.isIOS;
