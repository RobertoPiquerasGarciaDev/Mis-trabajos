import 'package:flutter_test/flutter_test.dart';
import 'package:kickdynasty_mobile/features/home/home_screen.dart';
import 'package:kickdynasty_mobile/features/hub/campaign_hub_screen.dart';
import 'package:kickdynasty_mobile/features/round/round_results_screen.dart';
import 'package:kickdynasty_mobile/features/squad/squad_screen.dart';
import 'package:kickdynasty_mobile/features/table/league_table_screen.dart';

import 'support/test_app.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('goldens del vertical jugable', () {
    testWidgets('home_screen', (tester) async {
      await tester.pumpWidget(buildTestApp(const HomeScreen()));
      await tester.pumpAndSettle();

      await expectLater(
        find.byType(HomeScreen),
        matchesGoldenFile('goldens/home_screen.png'),
      );
    });

    testWidgets('campaign_hub_screen', (tester) async {
      final session = await goldenSession();
      await tester.pumpWidget(
        buildTestApp(const CampaignHubScreen(), session: session),
      );
      await tester.pumpAndSettle();

      await expectLater(
        find.byType(CampaignHubScreen),
        matchesGoldenFile('goldens/campaign_hub_screen.png'),
      );
    });

    testWidgets('squad_screen', (tester) async {
      final session = await goldenSession();
      await tester.pumpWidget(
        buildTestApp(const SquadScreen(), session: session),
      );
      await tester.pumpAndSettle();

      await expectLater(
        find.byType(SquadScreen),
        matchesGoldenFile('goldens/squad_screen.png'),
      );
    });

    testWidgets('round_results_screen', (tester) async {
      final session = await goldenSession();
      await tester.pumpWidget(
        buildTestApp(const RoundResultsScreen(), session: session),
      );
      await tester.pumpAndSettle();

      await expectLater(
        find.byType(RoundResultsScreen),
        matchesGoldenFile('goldens/round_results_screen.png'),
      );
    });

    testWidgets('league_table_screen', (tester) async {
      final session = await goldenSession();
      await tester.pumpWidget(
        buildTestApp(const LeagueTableScreen(), session: session),
      );
      await tester.pumpAndSettle();

      await expectLater(
        find.byType(LeagueTableScreen),
        matchesGoldenFile('goldens/league_table_screen.png'),
      );
    });
  });
}
