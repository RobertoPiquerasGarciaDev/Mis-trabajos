import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_mobile/theme/app_theme.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';

/// Sesión de campaña fija para pruebas de widget/golden.
class FixedCampaignNotifier extends ActiveCampaignNotifier {
  FixedCampaignNotifier(this.session);

  final CampaignSession session;

  @override
  Future<CampaignSession?> build() async => session;
}

/// Construye un árbol de widgets con Riverpod y tema oscuro.
Widget buildTestApp(
  Widget child, {
  SaveDatabase? database,
  CampaignSession? session,
}) {
  final db = database ?? openSaveDatabaseInMemory();
  return ProviderScope(
    overrides: [
      saveDatabaseProvider.overrideWithValue(db),
      if (session != null)
        activeCampaignProvider.overrideWith(
          () => FixedCampaignNotifier(session),
        ),
    ],
    child: MaterialApp(theme: AppTheme.dark, home: child),
  );
}

/// Crea una sesión real con una jornada ya disputada (semilla fija).
Future<CampaignSession> goldenSession() async {
  final simulator = SeasonSimulator();
  final bootstrap = simulator.bootstrapCampaign(seed: 42);
  final clubId = bootstrap.world.leagues.first.clubs.first.club.id;
  final db = openSaveDatabaseInMemory();
  final saves = SaveRepository(db);
  final start = StartNewCampaign(saves, simulator);
  var session = await start(name: 'Golden FC', seed: 42, playerClubId: clubId);
  session = await AdvanceRound(saves, simulator)(session);
  return session;
}
