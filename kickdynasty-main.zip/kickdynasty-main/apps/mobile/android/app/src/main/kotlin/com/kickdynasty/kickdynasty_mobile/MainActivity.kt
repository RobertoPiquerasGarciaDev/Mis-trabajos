package com.kickdynasty.kickdynasty_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
