/// Serialización de [MatchLineup] para SQLite.
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica [lineup] como JSON compacto.
String encodeLineup(MatchLineup lineup) => jsonEncode({
  'formation': lineup.formation.label,
  'starters': [for (final id in lineup.starters) id.value],
  'bench': [for (final id in lineup.bench) id.value],
  'captain': lineup.captainId.value,
});

/// Decodifica una alineación guardada; `null` si [json] es nulo o vacío.
MatchLineup? decodeLineup(String? json) {
  if (json == null || json.isEmpty) return null;
  final map = jsonDecode(json) as Map<String, dynamic>;
  final label = map['formation'] as String;
  final formation = Formation.standard.firstWhere(
    (f) => f.label == label,
    orElse: () => Formation.f433,
  );
  return MatchLineup(
    formation: formation,
    starters: [
      for (final id in map['starters'] as List<dynamic>) PlayerId(id as String),
    ],
    bench: [
      for (final id in map['bench'] as List<dynamic>) PlayerId(id as String),
    ],
    captainId: PlayerId(map['captain'] as String),
  );
}
