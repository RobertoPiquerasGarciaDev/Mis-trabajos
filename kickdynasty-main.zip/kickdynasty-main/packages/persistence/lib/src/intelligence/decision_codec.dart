/// Serialización JSON de [DecisionState] (PF-10).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [DecisionState] a JSON compacto.
String encodeDecisionState(DecisionState state) => jsonEncode(state.toJson());

/// Decodifica un [DecisionState] desde JSON.
DecisionState decodeDecisionState(String json) =>
    DecisionState.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de estados de decisiones.
String encodeDecisionStateList(List<DecisionState> states) => jsonEncode({
  'v': 1,
  'states': [for (final state in states) state.toJson()],
});

/// Decodifica una lista de estados de decisiones.
List<DecisionState> decodeDecisionStateList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('DecisionStateList JSON v$version no soportada');
  }
  return [
    for (final item in root['states']! as List)
      DecisionState.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
