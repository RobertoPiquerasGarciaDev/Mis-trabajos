/// Serialización JSON de [BeliefState] (PF-7).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [BeliefState] a JSON compacto.
String encodeBeliefState(BeliefState state) => jsonEncode(state.toJson());

/// Decodifica un [BeliefState] desde JSON.
BeliefState decodeBeliefState(String json) =>
    BeliefState.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de estados de creencias.
String encodeBeliefStateList(List<BeliefState> states) => jsonEncode({
  'v': 1,
  'states': [for (final state in states) state.toJson()],
});

/// Decodifica una lista de estados de creencias.
List<BeliefState> decodeBeliefStateList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('BeliefStateList JSON v$version no soportada');
  }
  return [
    for (final item in root['states']! as List)
      BeliefState.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
