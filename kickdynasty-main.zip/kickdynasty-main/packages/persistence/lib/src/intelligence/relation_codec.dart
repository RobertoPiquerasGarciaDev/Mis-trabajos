/// Serialización JSON de [RelationState] (PF-5).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [RelationState] a JSON compacto.
String encodeRelationState(RelationState state) => jsonEncode(state.toJson());

/// Decodifica un [RelationState] desde JSON.
RelationState decodeRelationState(String json) =>
    RelationState.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de estados relacionales.
String encodeRelationStateList(List<RelationState> states) => jsonEncode({
  'v': 1,
  'states': [for (final state in states) state.toJson()],
});

/// Decodifica una lista de estados relacionales.
List<RelationState> decodeRelationStateList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('RelationStateList JSON v$version no soportada');
  }
  return [
    for (final item in root['states']! as List)
      RelationState.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
