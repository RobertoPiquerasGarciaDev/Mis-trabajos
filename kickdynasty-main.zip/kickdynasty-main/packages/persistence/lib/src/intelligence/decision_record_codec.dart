/// Serialización JSON de [DecisionRecord] (PF-10).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [DecisionRecord] a JSON compacto.
String encodeDecisionRecord(DecisionRecord record) =>
    jsonEncode(record.toJson());

/// Decodifica un [DecisionRecord] desde JSON.
DecisionRecord decodeDecisionRecord(String json) =>
    DecisionRecord.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de registros sociales.
String encodeDecisionRecordList(List<DecisionRecord> records) => jsonEncode({
  'v': 1,
  'records': [for (final record in records) record.toJson()],
});

/// Decodifica una lista de registros sociales.
List<DecisionRecord> decodeDecisionRecordList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('DecisionRecordList JSON v$version no soportada');
  }
  return [
    for (final item in root['records']! as List)
      DecisionRecord.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
