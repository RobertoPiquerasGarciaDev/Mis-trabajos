/// Serialización JSON de [PriorityState] (PF-9).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [PriorityState] a JSON compacto.
String encodePriorityState(PriorityState state) => jsonEncode(state.toJson());

/// Decodifica un [PriorityState] desde JSON.
PriorityState decodePriorityState(String json) =>
    PriorityState.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de estados de prioridades.
String encodePriorityStateList(List<PriorityState> states) => jsonEncode({
  'v': 1,
  'states': [for (final state in states) state.toJson()],
});

/// Decodifica una lista de estados de prioridades.
List<PriorityState> decodePriorityStateList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('PriorityStateList JSON v$version no soportada');
  }
  return [
    for (final item in root['states']! as List)
      PriorityState.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
