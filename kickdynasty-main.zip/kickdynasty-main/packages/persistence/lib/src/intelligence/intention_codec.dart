/// Serialización JSON de [IntentionState] (PF-9).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [IntentionState] a JSON compacto.
String encodeIntentionState(IntentionState state) => jsonEncode(state.toJson());

/// Decodifica un [IntentionState] desde JSON.
IntentionState decodeIntentionState(String json) =>
    IntentionState.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de estados de intenciones.
String encodeIntentionStateList(List<IntentionState> states) => jsonEncode({
  'v': 1,
  'states': [for (final state in states) state.toJson()],
});

/// Decodifica una lista de estados de intenciones.
List<IntentionState> decodeIntentionStateList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('IntentionStateList JSON v$version no soportada');
  }
  return [
    for (final item in root['states']! as List)
      IntentionState.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
