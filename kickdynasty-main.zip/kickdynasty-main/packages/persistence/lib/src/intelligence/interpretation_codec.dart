/// Serialización JSON de [InterpretationState] (PF-6).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [InterpretationState] a JSON compacto.
String encodeInterpretationState(InterpretationState state) =>
    jsonEncode(state.toJson());

/// Decodifica un [InterpretationState] desde JSON.
InterpretationState decodeInterpretationState(String json) =>
    InterpretationState.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de estados interpretativos.
String encodeInterpretationStateList(List<InterpretationState> states) =>
    jsonEncode({
      'v': 1,
      'states': [for (final state in states) state.toJson()],
    });

/// Decodifica una lista de estados interpretativos.
List<InterpretationState> decodeInterpretationStateList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException(
      'InterpretationStateList JSON v$version no soportada',
    );
  }
  return [
    for (final item in root['states']! as List)
      InterpretationState.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
