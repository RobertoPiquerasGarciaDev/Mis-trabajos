/// Serialización JSON de [GoalState] (PF-8).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [GoalState] a JSON compacto.
String encodeGoalState(GoalState state) => jsonEncode(state.toJson());

/// Decodifica un [GoalState] desde JSON.
GoalState decodeGoalState(String json) =>
    GoalState.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de estados de objetivos.
String encodeGoalStateList(List<GoalState> states) => jsonEncode({
  'v': 1,
  'states': [for (final state in states) state.toJson()],
});

/// Decodifica una lista de estados de objetivos.
List<GoalState> decodeGoalStateList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('GoalStateList JSON v$version no soportada');
  }
  return [
    for (final item in root['states']! as List)
      GoalState.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
