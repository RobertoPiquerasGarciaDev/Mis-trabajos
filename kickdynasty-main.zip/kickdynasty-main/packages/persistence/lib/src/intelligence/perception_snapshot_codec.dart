/// Serialización JSON de [PerceptionSnapshot] (PF-3).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [PerceptionSnapshot] a JSON compacto.
String encodePerceptionSnapshot(PerceptionSnapshot snapshot) =>
    jsonEncode(snapshot.toJson());

/// Decodifica un [PerceptionSnapshot] desde JSON.
PerceptionSnapshot decodePerceptionSnapshot(String json) =>
    PerceptionSnapshot.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de snapshots.
String encodePerceptionSnapshotList(List<PerceptionSnapshot> snapshots) =>
    jsonEncode({
      'v': 1,
      'snapshots': [for (final snapshot in snapshots) snapshot.toJson()],
    });

/// Decodifica una lista de snapshots.
List<PerceptionSnapshot> decodePerceptionSnapshotList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('PerceptionSnapshotList JSON v$version no soportada');
  }
  return [
    for (final item in root['snapshots']! as List)
      PerceptionSnapshot.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
