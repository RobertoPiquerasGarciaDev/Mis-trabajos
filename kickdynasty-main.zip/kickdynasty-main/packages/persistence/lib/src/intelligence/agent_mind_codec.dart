/// Serialización JSON de [AgentMind] (PF-2).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica un [AgentMind] a JSON compacto.
String encodeAgentMind(AgentMind mind) => jsonEncode(mind.toJson());

/// Decodifica un [AgentMind] desde JSON.
AgentMind decodeAgentMind(String json) =>
    AgentMind.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de mentes.
String encodeAgentMindList(List<AgentMind> minds) => jsonEncode({
  'v': 1,
  'minds': [for (final mind in minds) mind.toJson()],
});

/// Decodifica una lista de mentes.
List<AgentMind> decodeAgentMindList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('AgentMindList JSON v$version no soportada');
  }
  return [
    for (final item in root['minds']! as List)
      AgentMind.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
