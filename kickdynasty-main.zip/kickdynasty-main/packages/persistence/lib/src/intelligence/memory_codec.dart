/// Serialización JSON de [MemoryCollection] (PF-4).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica una [MemoryCollection] a JSON compacto.
String encodeMemoryCollection(MemoryCollection collection) =>
    jsonEncode(collection.toJson());

/// Decodifica una [MemoryCollection] desde JSON.
MemoryCollection decodeMemoryCollection(String json) =>
    MemoryCollection.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de colecciones.
String encodeMemoryCollectionList(List<MemoryCollection> collections) =>
    jsonEncode({
      'v': 1,
      'collections': [
        for (final collection in collections) collection.toJson(),
      ],
    });

/// Decodifica una lista de colecciones.
List<MemoryCollection> decodeMemoryCollectionList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('MemoryCollectionList JSON v$version no soportada');
  }
  return [
    for (final item in root['collections']! as List)
      MemoryCollection.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
