/// Repositorio de personas persistidas (PF-1).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/person/person_codec.dart';

/// Acceso CRUD mínimo a personas de un guardado.
final class PersonRepository {
  /// Crea el repositorio sobre [database].
  const PersonRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene una persona por id en el slot dado.
  Future<Person?> get({
    required int saveId,
    required int slot,
    required PersonId id,
  }) async {
    final row =
        await (database.select(database.personRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(id.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodePerson(row.personJson);
  }

  /// Lista todas las personas del slot, en orden de persistencia.
  Future<List<Person>> list({required int saveId, required int slot}) async {
    final rows =
        await (database.select(database.personRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodePerson(row.personJson)];
  }

  /// Guarda la lista completa de personas del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<Person> persons,
  }) async {
    await (database.delete(
      database.personRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (persons.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final person in persons) {
        batch.insert(
          database.personRows,
          PersonRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: person.id.value,
            personJson: encodePerson(person),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
