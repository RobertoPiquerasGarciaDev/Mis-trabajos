/// Repositorio de InterpretationState persistidos (PF-6).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/interpretation_codec.dart';

/// Acceso CRUD mínimo a interpretaciones de un guardado.
final class InterpretationRepository {
  /// Crea el repositorio sobre [database].
  const InterpretationRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene el estado interpretativo de una persona en el slot dado.
  Future<InterpretationState?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.interpretationRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeInterpretationState(row.interpretationJson);
  }

  /// Lista todos los estados del slot, en orden de persistencia.
  Future<List<InterpretationState>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.interpretationRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [
      for (final row in rows) decodeInterpretationState(row.interpretationJson),
    ];
  }

  /// Guarda la lista completa del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<InterpretationState> states,
  }) async {
    await (database.delete(
      database.interpretationRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (states.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final state in states) {
        final personId = state.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.interpretationRows,
          InterpretationRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            interpretationJson: encodeInterpretationState(state),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
