/// Repositorio de PriorityState persistidos (PF-9).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/priority_codec.dart';

/// Acceso CRUD mínimo a prioridades de un guardado.
final class PriorityRepository {
  /// Crea el repositorio sobre [database].
  const PriorityRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene el estado de prioridades de una persona en el slot dado.
  Future<PriorityState?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.priorityRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodePriorityState(row.priorityJson);
  }

  /// Lista todos los estados del slot, en orden de persistencia.
  Future<List<PriorityState>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.priorityRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodePriorityState(row.priorityJson)];
  }

  /// Guarda la lista completa del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<PriorityState> states,
  }) async {
    await (database.delete(
      database.priorityRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (states.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final state in states) {
        final personId = state.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.priorityRows,
          PriorityRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            priorityJson: encodePriorityState(state),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
