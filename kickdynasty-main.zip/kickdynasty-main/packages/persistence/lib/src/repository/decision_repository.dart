/// Repositorio de DecisionState persistidos (PF-10).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/decision_codec.dart';

/// Acceso CRUD mínimo a decisiones cognitivas de un guardado.
final class DecisionRepository {
  /// Crea el repositorio sobre [database].
  const DecisionRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene el estado de decisiones de una persona en el slot dado.
  Future<DecisionState?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.decisionRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeDecisionState(row.decisionJson);
  }

  /// Lista todos los estados del slot, en orden de persistencia.
  Future<List<DecisionState>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.decisionRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodeDecisionState(row.decisionJson)];
  }

  /// Guarda la lista completa del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<DecisionState> states,
  }) async {
    await (database.delete(
      database.decisionRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (states.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final state in states) {
        final personId = state.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.decisionRows,
          DecisionRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            decisionJson: encodeDecisionState(state),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
