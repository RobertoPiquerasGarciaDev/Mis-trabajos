/// Repositorio de RelationState persistidos (PF-5).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/relation_codec.dart';

/// Acceso CRUD mínimo a relaciones de un guardado.
final class RelationRepository {
  /// Crea el repositorio sobre [database].
  const RelationRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene el grafo relacional de una persona en el slot dado.
  Future<RelationState?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.relationRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeRelationState(row.relationJson);
  }

  /// Lista todos los grafos del slot, en orden de persistencia.
  Future<List<RelationState>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.relationRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodeRelationState(row.relationJson)];
  }

  /// Guarda la lista completa de grafos del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<RelationState> states,
  }) async {
    await (database.delete(
      database.relationRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (states.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final state in states) {
        final personId = state.observerId;
        if (personId == null) continue;
        batch.insert(
          database.relationRows,
          RelationRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            relationJson: encodeRelationState(state),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
