/// Repositorio de GoalState persistidos (PF-8).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/goal_codec.dart';

/// Acceso CRUD mínimo a objetivos de un guardado.
final class GoalRepository {
  /// Crea el repositorio sobre [database].
  const GoalRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene el estado de objetivos de una persona en el slot dado.
  Future<GoalState?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.goalRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeGoalState(row.goalJson);
  }

  /// Lista todos los estados del slot, en orden de persistencia.
  Future<List<GoalState>> list({required int saveId, required int slot}) async {
    final rows =
        await (database.select(database.goalRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodeGoalState(row.goalJson)];
  }

  /// Guarda la lista completa del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<GoalState> states,
  }) async {
    await (database.delete(
      database.goalRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (states.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final state in states) {
        final personId = state.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.goalRows,
          GoalRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            goalJson: encodeGoalState(state),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
