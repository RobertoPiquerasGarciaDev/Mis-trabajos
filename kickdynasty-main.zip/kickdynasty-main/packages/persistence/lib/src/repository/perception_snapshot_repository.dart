/// Repositorio de PerceptionSnapshot persistidos (PF-3).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/perception_snapshot_codec.dart';

/// Acceso CRUD mínimo a fotografías perceptivas de un guardado.
final class PerceptionSnapshotRepository {
  /// Crea el repositorio sobre [database].
  const PerceptionSnapshotRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene un snapshot por observador en el slot dado.
  Future<PerceptionSnapshot?> get({
    required int saveId,
    required int slot,
    required PersonId observerId,
  }) async {
    final row =
        await (database.select(database.perceptionSnapshotRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.observerId.equals(observerId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodePerceptionSnapshot(row.snapshotJson);
  }

  /// Lista todos los snapshots del slot, en orden de persistencia.
  Future<List<PerceptionSnapshot>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.perceptionSnapshotRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodePerceptionSnapshot(row.snapshotJson)];
  }

  /// Guarda la lista completa de snapshots del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<PerceptionSnapshot> snapshots,
  }) async {
    await (database.delete(
      database.perceptionSnapshotRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (snapshots.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final snapshot in snapshots) {
        batch.insert(
          database.perceptionSnapshotRows,
          PerceptionSnapshotRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            observerId: snapshot.observerId.value,
            snapshotJson: encodePerceptionSnapshot(snapshot),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
