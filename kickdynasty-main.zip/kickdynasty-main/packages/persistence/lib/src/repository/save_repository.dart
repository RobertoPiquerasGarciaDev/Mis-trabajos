/// Repositorio de partidas guardadas: guardar/cargar el estado de campaña
/// completo y snapshots por jornada con retención.
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_persistence/src/codec/lineup_codec.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/agent_mind_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/belief_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/decision_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/decision_record_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/goal_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/intention_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/interpretation_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/memory_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/perception_snapshot_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/priority_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/relation_codec.dart';
import 'package:kickdynasty_persistence/src/person/person_codec.dart';
import 'package:meta/meta.dart';

/// Slot reservado para el estado vivo de la partida.
const int liveSlot = 0;

/// Resumen de un guardado para la pantalla de "continuar partida".
@immutable
final class SaveSummary {
  /// Crea el resumen.
  const SaveSummary({
    required this.id,
    required this.name,
    required this.season,
    required this.nextRound,
    required this.playerClubId,
    required this.createdAt,
    required this.updatedAt,
  });

  /// Identificador del guardado.
  final int id;

  /// Nombre visible.
  final String name;

  /// Temporada en curso.
  final int season;

  /// Próxima jornada a disputar.
  final int nextRound;

  /// Club del jugador (`null` = espectador).
  final ClubId? playerClubId;

  /// Momento de creación.
  final DateTime createdAt;

  /// Momento de la última escritura.
  final DateTime updatedAt;
}

/// Un snapshot disponible de un guardado.
@immutable
final class SnapshotInfo {
  /// Crea la ficha.
  const SnapshotInfo({
    required this.slot,
    required this.season,
    required this.round,
    required this.createdAt,
  });

  /// Slot que ocupa (≥ 1).
  final int slot;

  /// Temporada capturada.
  final int season;

  /// Próxima jornada en el momento de la captura.
  final int round;

  /// Momento de la captura.
  final DateTime createdAt;
}

/// Datos cargados de una campaña, incluyendo extras de gestión de club.
@immutable
final class CampaignLoad {
  /// Crea el resultado de carga.
  const CampaignLoad({
    required this.state,
    this.persons = const [],
    this.agentMinds = const [],
    this.perceptionSnapshots = const [],
    this.memoryCollections = const [],
    this.relationStates = const [],
    this.interpretationStates = const [],
    this.beliefStates = const [],
    this.goalStates = const [],
    this.priorityStates = const [],
    this.intentionStates = const [],
    this.decisionStates = const [],
    this.decisionRecords = const [],
    this.marketOverlayJson,
    this.lastFinancesJson,
    this.lastTrainingRound,
    this.managerDecisionsJson,
  });

  /// Estado de campaña reconstruido.
  final CampaignState state;

  /// Personas persistidas del guardado (vacío si aún no migrado).
  final List<Person> persons;

  /// Mentes persistidas del guardado (vacío si aún no migrado a v8).
  final List<AgentMind> agentMinds;

  /// Fotografías perceptivas persistidas (vacío si aún no migrado a v9).
  final List<PerceptionSnapshot> perceptionSnapshots;

  /// Colecciones de memoria persistidas (vacío si aún no migrado a v10).
  final List<MemoryCollection> memoryCollections;

  /// Grafos relacionales persistidos (vacío si aún no migrado a v11).
  final List<RelationState> relationStates;

  /// Estados interpretativos persistidos (vacío si aún no migrado a v12).
  final List<InterpretationState> interpretationStates;

  /// Estados de creencias persistidos (vacío si aún no migrado a v13).
  final List<BeliefState> beliefStates;

  /// Estados de objetivos persistidos (vacío si aún no migrado a v14).
  final List<GoalState> goalStates;

  /// Estados de prioridades persistidos (vacío si aún no migrado a v15).
  final List<PriorityState> priorityStates;

  /// Estados de intenciones persistidos (vacío si aún no migrado a v15).
  final List<IntentionState> intentionStates;

  /// Estados de decisiones cognitivas persistidos (vacío si aún no migrado a v16).
  final List<DecisionState> decisionStates;

  /// Registros sociales append-only (vacío si aún no migrado a v16).
  final List<DecisionRecord> decisionRecords;

  /// Overlay de mercado serializado (`null` en partidas anteriores a v4).
  final String? marketOverlayJson;

  /// Último balance financiero serializado.
  final String? lastFinancesJson;

  /// Última jornada para la que se aplicó entrenamiento (`null` = ninguna).
  final int? lastTrainingRound;

  /// Decisiones del manager serializadas (`null` en partidas anteriores a v6).
  final String? managerDecisionsJson;
}

/// Acceso de alto nivel a las partidas guardadas.
///
/// Toda escritura es transaccional: o se persiste el estado completo o no
/// se persiste nada. Ninguna otra capa ve SQL.
final class SaveRepository {
  /// Crea el repositorio sobre [database]. El [clock] es inyectable para
  /// que los tests controlen los timestamps.
  SaveRepository(this.database, {DateTime Function()? clock})
    : _clock = clock ?? DateTime.now;

  /// Base de datos subyacente.
  final SaveDatabase database;

  final DateTime Function() _clock;

  /// Retención de snapshots por defecto (los más antiguos se podan).
  static const int defaultSnapshotRetention = 10;

  // ── Ciclo de vida del guardado ─────────────────────────────────────────

  /// Crea un guardado con [name] y su estado inicial; devuelve su id.
  Future<int> createSave({required String name, required CampaignState state}) {
    final now = _clock().millisecondsSinceEpoch;
    return database.transaction(() async {
      final saveId = await database
          .into(database.saves)
          .insert(
            SavesCompanion.insert(
              name: name,
              createdAtMs: now,
              updatedAtMs: now,
            ),
          );
      await _writeCampaign(saveId, liveSlot, state);
      return saveId;
    });
  }

  /// Sobrescribe el estado vivo del guardado [saveId].
  Future<void> saveCampaign(
    int saveId,
    CampaignState state, {
    List<Person> persons = const [],
    List<AgentMind> agentMinds = const [],
    List<PerceptionSnapshot> perceptionSnapshots = const [],
    List<MemoryCollection> memoryCollections = const [],
    List<RelationState> relationStates = const [],
    List<InterpretationState> interpretationStates = const [],
    List<BeliefState> beliefStates = const [],
    List<GoalState> goalStates = const [],
    List<PriorityState> priorityStates = const [],
    List<IntentionState> intentionStates = const [],
    List<DecisionState> decisionStates = const [],
    List<DecisionRecord> decisionRecords = const [],
    String? marketOverlayJson,
    String? lastFinancesJson,
    int? lastTrainingRound,
    String? managerDecisionsJson,
  }) {
    return database.transaction(() async {
      await _requireSave(saveId);
      await _deleteSlot(saveId, liveSlot);
      await _writeCampaign(
        saveId,
        liveSlot,
        state,
        persons: persons,
        agentMinds: agentMinds,
        perceptionSnapshots: perceptionSnapshots,
        memoryCollections: memoryCollections,
        relationStates: relationStates,
        interpretationStates: interpretationStates,
        beliefStates: beliefStates,
        goalStates: goalStates,
        priorityStates: priorityStates,
        intentionStates: intentionStates,
        decisionStates: decisionStates,
        decisionRecords: decisionRecords,
        marketOverlayJson: marketOverlayJson,
        lastFinancesJson: lastFinancesJson,
        lastTrainingRound: lastTrainingRound,
        managerDecisionsJson: managerDecisionsJson,
      );
      await (database.update(
        database.saves,
      )..where((s) => s.id.equals(saveId))).write(
        SavesCompanion(updatedAtMs: Value(_clock().millisecondsSinceEpoch)),
      );
    });
  }

  /// Carga el estado vivo del guardado [saveId].
  Future<CampaignLoad> loadCampaign(int saveId) async {
    final data = await _readCampaign(saveId, liveSlot);
    return CampaignLoad(
      state: data.state,
      persons: data.persons,
      agentMinds: data.agentMinds,
      perceptionSnapshots: data.perceptionSnapshots,
      memoryCollections: data.memoryCollections,
      relationStates: data.relationStates,
      interpretationStates: data.interpretationStates,
      beliefStates: data.beliefStates,
      goalStates: data.goalStates,
      priorityStates: data.priorityStates,
      intentionStates: data.intentionStates,
      decisionStates: data.decisionStates,
      decisionRecords: data.decisionRecords,
      marketOverlayJson: data.marketOverlayJson,
      lastFinancesJson: data.lastFinancesJson,
      lastTrainingRound: data.lastTrainingRound,
      managerDecisionsJson: data.managerDecisionsJson,
    );
  }

  /// Carga solo el [CampaignState] (compatibilidad con snapshots).
  Future<CampaignState> loadCampaignState(int saveId) async =>
      (await loadCampaign(saveId)).state;

  /// Lista los guardados existentes, el más reciente primero.
  Future<List<SaveSummary>> listSaves() async {
    final query = database.select(database.saves).join([
      innerJoin(
        database.campaigns,
        database.campaigns.saveId.equalsExp(database.saves.id) &
            database.campaigns.slot.equals(liveSlot),
      ),
    ])..orderBy([OrderingTerm.desc(database.saves.updatedAtMs)]);

    final rows = await query.get();
    return [
      for (final row in rows)
        SaveSummary(
          id: row.readTable(database.saves).id,
          name: row.readTable(database.saves).name,
          season: row.readTable(database.campaigns).season,
          nextRound: row.readTable(database.campaigns).nextRound,
          playerClubId: switch (row
              .readTable(database.campaigns)
              .playerClubId) {
            null => null,
            final id => ClubId(id),
          },
          createdAt: DateTime.fromMillisecondsSinceEpoch(
            row.readTable(database.saves).createdAtMs,
          ),
          updatedAt: DateTime.fromMillisecondsSinceEpoch(
            row.readTable(database.saves).updatedAtMs,
          ),
        ),
    ];
  }

  /// Borra el guardado [saveId] con todos sus slots y snapshots.
  Future<void> deleteSave(int saveId) {
    return database.transaction(() async {
      final slots = await (database.select(
        database.campaigns,
      )..where((c) => c.saveId.equals(saveId))).get();
      for (final campaign in slots) {
        await _deleteSlot(saveId, campaign.slot);
      }
      await (database.delete(
        database.snapshots,
      )..where((s) => s.saveId.equals(saveId))).go();
      await (database.delete(
        database.saves,
      )..where((s) => s.id.equals(saveId))).go();
    });
  }

  // ── Snapshots por jornada ──────────────────────────────────────────────

  /// Captura [state] como snapshot del guardado [saveId] y poda los más
  /// antiguos que excedan [retention].
  Future<SnapshotInfo> writeSnapshot(
    int saveId,
    CampaignState state, {
    int retention = defaultSnapshotRetention,
  }) {
    if (retention < 1) {
      throw ArgumentError.value(retention, 'retention', 'debe ser >= 1');
    }
    return database.transaction(() async {
      await _requireSave(saveId);
      final existing =
          await (database.select(database.snapshots)
                ..where((s) => s.saveId.equals(saveId))
                ..orderBy([(s) => OrderingTerm.desc(s.slot)]))
              .get();

      final slot = existing.isEmpty ? 1 : existing.first.slot + 1;
      final createdAt = _clock().millisecondsSinceEpoch;

      await database
          .into(database.snapshots)
          .insert(
            SnapshotsCompanion.insert(
              saveId: saveId,
              slot: slot,
              season: state.season,
              round: state.nextRound,
              createdAtMs: createdAt,
            ),
          );
      await _writeCampaign(saveId, slot, state);

      // Poda: conserva los `retention` snapshots más recientes.
      final all = [slot, ...existing.map((s) => s.slot)]
        ..sort((a, b) => b.compareTo(a));
      for (final oldSlot in all.skip(retention)) {
        await _deleteSlot(saveId, oldSlot);
        await (database.delete(
          database.snapshots,
        )..where((s) => s.saveId.equals(saveId) & s.slot.equals(oldSlot))).go();
      }

      return SnapshotInfo(
        slot: slot,
        season: state.season,
        round: state.nextRound,
        createdAt: DateTime.fromMillisecondsSinceEpoch(createdAt),
      );
    });
  }

  /// Lista los snapshots del guardado [saveId], el más reciente primero.
  Future<List<SnapshotInfo>> listSnapshots(int saveId) async {
    final rows =
        await (database.select(database.snapshots)
              ..where((s) => s.saveId.equals(saveId))
              ..orderBy([(s) => OrderingTerm.desc(s.slot)]))
            .get();
    return [
      for (final row in rows)
        SnapshotInfo(
          slot: row.slot,
          season: row.season,
          round: row.round,
          createdAt: DateTime.fromMillisecondsSinceEpoch(row.createdAtMs),
        ),
    ];
  }

  /// Carga el estado capturado en el snapshot [slot] del guardado [saveId].
  Future<CampaignState> loadSnapshot(int saveId, int slot) async {
    if (slot == liveSlot) {
      throw ArgumentError.value(slot, 'slot', 'el slot 0 es el estado vivo');
    }
    return (await _readCampaign(saveId, slot)).state;
  }

  // ── Escritura ──────────────────────────────────────────────────────────

  Future<void> _requireSave(int saveId) async {
    final save = await (database.select(
      database.saves,
    )..where((s) => s.id.equals(saveId))).getSingleOrNull();
    if (save == null) {
      throw StateError('No existe el guardado $saveId');
    }
  }

  Future<void> _writeCampaign(
    int saveId,
    int slot,
    CampaignState state, {
    List<Person> persons = const [],
    List<AgentMind> agentMinds = const [],
    List<PerceptionSnapshot> perceptionSnapshots = const [],
    List<MemoryCollection> memoryCollections = const [],
    List<RelationState> relationStates = const [],
    List<InterpretationState> interpretationStates = const [],
    List<BeliefState> beliefStates = const [],
    List<GoalState> goalStates = const [],
    List<PriorityState> priorityStates = const [],
    List<IntentionState> intentionStates = const [],
    List<DecisionState> decisionStates = const [],
    List<DecisionRecord> decisionRecords = const [],
    String? marketOverlayJson,
    String? lastFinancesJson,
    int? lastTrainingRound,
    String? managerDecisionsJson,
  }) async {
    await database
        .into(database.campaigns)
        .insert(
          CampaignsCompanion.insert(
            saveId: saveId,
            slot: slot,
            worldSeed: state.world.seed,
            season: state.season,
            nextRound: state.nextRound,
            playerClubId: Value(state.playerClubId?.value),
            playerLineupJson: Value(
              state.playerLineup == null
                  ? null
                  : encodeLineup(state.playerLineup!),
            ),
            marketOverlayJson: slot == liveSlot
                ? Value(marketOverlayJson)
                : const Value.absent(),
            lastFinancesJson: slot == liveSlot
                ? Value(lastFinancesJson)
                : const Value.absent(),
            lastTrainingRound: slot == liveSlot
                ? Value(lastTrainingRound)
                : const Value.absent(),
            managerDecisionsJson: slot == liveSlot
                ? Value(managerDecisionsJson)
                : const Value.absent(),
          ),
        );

    await database.batch((batch) {
      var leagueOrder = 0;
      for (final league in state.world.leagues) {
        batch.insert(
          database.leagueRows,
          LeagueRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            leagueId: league.league.id.value,
            name: league.league.name.value,
            country: league.league.country.value,
            level: league.level,
            sortOrder: leagueOrder++,
          ),
        );

        var clubOrder = 0;
        for (final generatedClub in league.clubs) {
          final club = generatedClub.club;
          batch.insert(
            database.clubRows,
            ClubRowsCompanion.insert(
              saveId: saveId,
              slot: slot,
              clubId: club.id.value,
              leagueId: league.league.id.value,
              name: club.name.value,
              code: club.code.value,
              country: club.country.value,
              reputation: club.reputation.value,
              stadiumName: club.stadium.name.value,
              stadiumCapacity: club.stadium.capacity,
              balance: club.balance.amount,
              sortOrder: clubOrder++,
            ),
          );

          var playerOrder = 0;
          for (final player in generatedClub.squad.players) {
            batch.insert(
              database.playerRows,
              PlayerRowsCompanion.insert(
                saveId: saveId,
                slot: slot,
                playerId: player.id.value,
                clubId: club.id.value,
                name: player.name.value,
                nationality: player.nationality.value,
                position: player.position.name,
                preferredFoot: player.preferredFoot.name,
                age: player.age.years,
                pace: player.attributes.pace.value,
                stamina: player.attributes.stamina.value,
                strength: player.attributes.strength.value,
                passing: player.attributes.passing.value,
                shooting: player.attributes.shooting.value,
                dribbling: player.attributes.dribbling.value,
                tackling: player.attributes.tackling.value,
                positioning: player.attributes.positioning.value,
                vision: player.attributes.vision.value,
                composure: player.attributes.composure.value,
                goalkeeping: player.attributes.goalkeeping.value,
                potential: player.potential.value,
                fitness: player.fitness.value,
                morale: player.morale.value,
                form: player.form.value,
                personId: Value(player.personId?.value),
                sortOrder: playerOrder++,
              ),
            );
          }

          var contractOrder = 0;
          for (final contract in generatedClub.contracts) {
            batch.insert(
              database.contractRows,
              ContractRowsCompanion.insert(
                saveId: saveId,
                slot: slot,
                contractId: contract.id.value,
                playerId: contract.playerId.value,
                clubId: contract.clubId.value,
                weeklyWage: contract.weeklyWage.amount,
                expirySeason: contract.expiry.season,
                expiryWeek: contract.expiry.week,
                sortOrder: contractOrder++,
              ),
            );
          }
        }
      }

      var personOrder = 0;
      for (final person in persons) {
        batch.insert(
          database.personRows,
          PersonRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: person.id.value,
            personJson: encodePerson(person),
            sortOrder: personOrder++,
          ),
        );
      }

      var agentMindOrder = 0;
      for (final mind in agentMinds) {
        batch.insert(
          database.agentMindRows,
          AgentMindRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: mind.personId.value,
            agentMindJson: encodeAgentMind(mind),
            sortOrder: agentMindOrder++,
          ),
        );
      }

      var perceptionOrder = 0;
      for (final snapshot in perceptionSnapshots) {
        batch.insert(
          database.perceptionSnapshotRows,
          PerceptionSnapshotRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            observerId: snapshot.observerId.value,
            snapshotJson: encodePerceptionSnapshot(snapshot),
            sortOrder: perceptionOrder++,
          ),
        );
      }

      var memoryOrder = 0;
      for (final collection in memoryCollections) {
        final personId = collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.memoryCollectionRows,
          MemoryCollectionRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            memoryJson: encodeMemoryCollection(collection),
            sortOrder: memoryOrder++,
          ),
        );
      }

      var relationOrder = 0;
      for (final relationState in relationStates) {
        final personId = relationState.observerId;
        if (personId == null) continue;
        batch.insert(
          database.relationRows,
          RelationRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            relationJson: encodeRelationState(relationState),
            sortOrder: relationOrder++,
          ),
        );
      }

      var interpretationOrder = 0;
      for (final interpretationState in interpretationStates) {
        final personId = interpretationState.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.interpretationRows,
          InterpretationRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            interpretationJson: encodeInterpretationState(interpretationState),
            sortOrder: interpretationOrder++,
          ),
        );
      }

      var beliefOrder = 0;
      for (final beliefState in beliefStates) {
        final personId = beliefState.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.beliefRows,
          BeliefRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            beliefJson: encodeBeliefState(beliefState),
            sortOrder: beliefOrder++,
          ),
        );
      }

      var goalOrder = 0;
      for (final goalState in goalStates) {
        final personId = goalState.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.goalRows,
          GoalRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            goalJson: encodeGoalState(goalState),
            sortOrder: goalOrder++,
          ),
        );
      }

      var priorityOrder = 0;
      for (final priorityState in priorityStates) {
        final personId = priorityState.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.priorityRows,
          PriorityRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            priorityJson: encodePriorityState(priorityState),
            sortOrder: priorityOrder++,
          ),
        );
      }

      var intentionOrder = 0;
      for (final intentionState in intentionStates) {
        final personId = intentionState.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.intentionRows,
          IntentionRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            intentionJson: encodeIntentionState(intentionState),
            sortOrder: intentionOrder++,
          ),
        );
      }

      var decisionOrder = 0;
      for (final decisionState in decisionStates) {
        final personId = decisionState.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.decisionRows,
          DecisionRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            decisionJson: encodeDecisionState(decisionState),
            sortOrder: decisionOrder++,
          ),
        );
      }

      var decisionRecordOrder = 0;
      for (final record in decisionRecords) {
        batch.insert(
          database.decisionRecordRows,
          DecisionRecordRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            recordId: record.id,
            recordJson: encodeDecisionRecord(record),
            sortOrder: decisionRecordOrder++,
          ),
        );
      }

      var fixtureOrder = 0;
      for (final fixture in state.fixtures) {
        batch.insert(
          database.fixtureRows,
          FixtureRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            fixtureId: fixture.id.value,
            leagueId: fixture.leagueId.value,
            season: fixture.season,
            round: fixture.round,
            homeClubId: fixture.homeClubId.value,
            awayClubId: fixture.awayClubId.value,
            sortOrder: fixtureOrder++,
          ),
        );
      }

      for (final entry in state.results.entries) {
        final result = entry.value;
        batch.insert(
          database.resultRows,
          ResultRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            fixtureId: entry.key.value,
            homeGoals: result.homeGoals,
            awayGoals: result.awayGoals,
          ),
        );
        for (var seq = 0; seq < result.events.length; seq++) {
          batch.insert(
            database.matchEventRows,
            _eventCompanion(saveId, slot, entry.key, seq, result.events[seq]),
          );
        }
      }

      for (final entry in state.stats.entries) {
        final stats = entry.value;
        batch.insert(
          database.playerStatRows,
          PlayerStatRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            playerId: entry.key.value,
            appearances: stats.appearances,
            goals: stats.goals,
            assists: stats.assists,
            yellowCards: stats.yellowCards,
            redCards: stats.redCards,
            averageRating: stats.averageRating,
          ),
        );
      }
    });
  }

  MatchEventRowsCompanion _eventCompanion(
    int saveId,
    int slot,
    FixtureId fixtureId,
    int seq,
    MatchEvent event,
  ) {
    final base = MatchEventRowsCompanion.insert(
      saveId: saveId,
      slot: slot,
      fixtureId: fixtureId.value,
      seq: seq,
      minute: event.minute.value,
      side: event.side.name,
      eventType: switch (event) {
        GoalScored() => 'goal',
        CardIssued() => 'card',
        PlayerInjured() => 'injury',
        Substitution() => 'substitution',
      },
      playerId: switch (event) {
        GoalScored(:final scorerId) => scorerId.value,
        CardIssued(:final playerId) => playerId.value,
        PlayerInjured(:final playerId) => playerId.value,
        Substitution(:final playerOutId) => playerOutId.value,
      },
    );
    return switch (event) {
      GoalScored(:final assistantId, :final ownGoal) => base.copyWith(
        secondPlayerId: Value(assistantId?.value),
        ownGoal: Value(ownGoal),
      ),
      CardIssued(:final cardType) => base.copyWith(
        cardType: Value(cardType.name),
      ),
      Substitution(:final playerInId) => base.copyWith(
        secondPlayerId: Value(playerInId.value),
      ),
      PlayerInjured() => base,
    };
  }

  Future<void> _deleteSlot(int saveId, int slot) async {
    await (database.delete(
      database.campaigns,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.leagueRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.clubRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.playerRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.contractRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.fixtureRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.resultRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.matchEventRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.playerStatRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.personRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.agentMindRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.perceptionSnapshotRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.memoryCollectionRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.relationRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.interpretationRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.beliefRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.goalRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.priorityRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.intentionRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.decisionRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    await (database.delete(
      database.decisionRecordRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
  }

  // ── Lectura ────────────────────────────────────────────────────────────

  Future<
    ({
      CampaignState state,
      List<Person> persons,
      List<AgentMind> agentMinds,
      List<PerceptionSnapshot> perceptionSnapshots,
      List<MemoryCollection> memoryCollections,
      List<RelationState> relationStates,
      List<InterpretationState> interpretationStates,
      List<BeliefState> beliefStates,
      List<GoalState> goalStates,
      List<PriorityState> priorityStates,
      List<IntentionState> intentionStates,
      List<DecisionState> decisionStates,
      List<DecisionRecord> decisionRecords,
      String? marketOverlayJson,
      String? lastFinancesJson,
      int? lastTrainingRound,
      String? managerDecisionsJson,
    })
  >
  _readCampaign(int saveId, int slot) async {
    final campaign =
        await (database.select(database.campaigns)
              ..where((c) => c.saveId.equals(saveId) & c.slot.equals(slot)))
            .getSingleOrNull();
    if (campaign == null) {
      throw StateError(
        'No existe estado de campaña para el guardado $saveId (slot $slot)',
      );
    }

    final leagueRows =
        await (database.select(database.leagueRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final clubRows =
        await (database.select(database.clubRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final playerRows =
        await (database.select(database.playerRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final contractRows =
        await (database.select(database.contractRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final fixtureRows =
        await (database.select(database.fixtureRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final resultRows = await (database.select(
      database.resultRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).get();
    final eventRows =
        await (database.select(database.matchEventRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.seq)]))
            .get();
    final statRows = await (database.select(
      database.playerStatRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).get();
    final personRows =
        await (database.select(database.personRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();

    final persons = [
      for (final row in personRows) decodePerson(row.personJson),
    ];
    final agentMindRows =
        await (database.select(database.agentMindRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final agentMinds = [
      for (final row in agentMindRows) decodeAgentMind(row.agentMindJson),
    ];
    final perceptionSnapshotRows =
        await (database.select(database.perceptionSnapshotRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final perceptionSnapshots = [
      for (final row in perceptionSnapshotRows)
        decodePerceptionSnapshot(row.snapshotJson),
    ];
    final memoryCollectionRows =
        await (database.select(database.memoryCollectionRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final memoryCollections = [
      for (final row in memoryCollectionRows)
        decodeMemoryCollection(row.memoryJson),
    ];
    final relationRows =
        await (database.select(database.relationRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final relationStates = [
      for (final row in relationRows) decodeRelationState(row.relationJson),
    ];
    final interpretationRows =
        await (database.select(database.interpretationRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final interpretationStates = [
      for (final row in interpretationRows)
        decodeInterpretationState(row.interpretationJson),
    ];
    final beliefRows =
        await (database.select(database.beliefRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final beliefStates = [
      for (final row in beliefRows) decodeBeliefState(row.beliefJson),
    ];
    final goalRows =
        await (database.select(database.goalRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final goalStates = [
      for (final row in goalRows) decodeGoalState(row.goalJson),
    ];
    final priorityRows =
        await (database.select(database.priorityRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final priorityStates = [
      for (final row in priorityRows) decodePriorityState(row.priorityJson),
    ];
    final intentionRows =
        await (database.select(database.intentionRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final intentionStates = [
      for (final row in intentionRows) decodeIntentionState(row.intentionJson),
    ];
    final decisionRows =
        await (database.select(database.decisionRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final decisionStates = [
      for (final row in decisionRows) decodeDecisionState(row.decisionJson),
    ];
    final decisionRecordRows =
        await (database.select(database.decisionRecordRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    final decisionRecords = [
      for (final row in decisionRecordRows)
        decodeDecisionRecord(row.recordJson),
    ];

    // Jugadores y contratos agrupados por club, preservando el orden.
    final playersByClub = <String, List<Player>>{};
    for (final row in playerRows) {
      playersByClub.putIfAbsent(row.clubId, () => []).add(_toPlayer(row));
    }
    final contractsByClub = <String, List<Contract>>{};
    for (final row in contractRows) {
      contractsByClub
          .putIfAbsent(row.clubId, () => [])
          .add(
            Contract(
              id: ContractId(row.contractId),
              playerId: PlayerId(row.playerId),
              clubId: ClubId(row.clubId),
              weeklyWage: Money(row.weeklyWage),
              expiry: GameDate(season: row.expirySeason, week: row.expiryWeek),
            ),
          );
    }
    final clubsByLeague = <String, List<GeneratedClub>>{};
    for (final row in clubRows) {
      clubsByLeague
          .putIfAbsent(row.leagueId, () => [])
          .add(
            GeneratedClub(
              club: Club(
                id: ClubId(row.clubId),
                name: DisplayName(row.name),
                code: ClubCode(row.code),
                country: CountryCode(row.country),
                reputation: Rating(row.reputation),
                stadium: Stadium(
                  name: DisplayName(row.stadiumName),
                  capacity: row.stadiumCapacity,
                ),
                balance: Money(row.balance),
              ),
              squad: Squad(
                clubId: ClubId(row.clubId),
                players: playersByClub[row.clubId] ?? const [],
              ),
              contracts: List.unmodifiable(
                contractsByClub[row.clubId] ?? const <Contract>[],
              ),
            ),
          );
    }

    final world = GeneratedWorld(
      seed: campaign.worldSeed,
      leagues: List.unmodifiable([
        for (final row in leagueRows)
          GeneratedLeague(
            league: League(
              id: LeagueId(row.leagueId),
              name: DisplayName(row.name),
              country: CountryCode(row.country),
              clubIds: [
                for (final club
                    in clubsByLeague[row.leagueId] ?? const <GeneratedClub>[])
                  club.club.id,
              ],
            ),
            level: row.level,
            clubs: List.unmodifiable(
              clubsByLeague[row.leagueId] ?? const <GeneratedClub>[],
            ),
          ),
      ]),
    );

    final eventsByFixture = <String, List<MatchEvent>>{};
    for (final row in eventRows) {
      eventsByFixture.putIfAbsent(row.fixtureId, () => []).add(_toEvent(row));
    }

    final results = <FixtureId, MatchResult>{
      for (final row in resultRows)
        FixtureId(row.fixtureId): MatchResult(
          fixtureId: FixtureId(row.fixtureId),
          homeGoals: row.homeGoals,
          awayGoals: row.awayGoals,
          events: eventsByFixture[row.fixtureId] ?? const [],
        ),
    };

    return (
      state: CampaignState(
        world: world,
        season: campaign.season,
        nextRound: campaign.nextRound,
        fixtures: [
          for (final row in fixtureRows)
            Fixture(
              id: FixtureId(row.fixtureId),
              leagueId: LeagueId(row.leagueId),
              season: row.season,
              round: row.round,
              homeClubId: ClubId(row.homeClubId),
              awayClubId: ClubId(row.awayClubId),
            ),
        ],
        results: results,
        stats: {
          for (final row in statRows)
            PlayerId(row.playerId): PlayerSeasonStats(
              playerId: PlayerId(row.playerId),
              appearances: row.appearances,
              goals: row.goals,
              assists: row.assists,
              yellowCards: row.yellowCards,
              redCards: row.redCards,
              averageRating: row.averageRating,
            ),
        },
        playerClubId: switch (campaign.playerClubId) {
          null => null,
          final id => ClubId(id),
        },
        playerLineup: decodeLineup(campaign.playerLineupJson),
      ),
      persons: persons,
      agentMinds: agentMinds,
      perceptionSnapshots: perceptionSnapshots,
      memoryCollections: memoryCollections,
      relationStates: relationStates,
      interpretationStates: interpretationStates,
      beliefStates: beliefStates,
      goalStates: goalStates,
      priorityStates: priorityStates,
      intentionStates: intentionStates,
      decisionStates: decisionStates,
      decisionRecords: decisionRecords,
      marketOverlayJson: campaign.marketOverlayJson,
      lastFinancesJson: campaign.lastFinancesJson,
      lastTrainingRound: campaign.lastTrainingRound,
      managerDecisionsJson: campaign.managerDecisionsJson,
    );
  }

  Player _toPlayer(PlayerRow row) => Player(
    id: PlayerId(row.playerId),
    personId: switch (row.personId) {
      null => null,
      final id => PersonId(id),
    },
    name: DisplayName(row.name),
    nationality: CountryCode(row.nationality),
    position: Position.values.byName(row.position),
    preferredFoot: PreferredFoot.values.byName(row.preferredFoot),
    age: Age(row.age),
    attributes: PlayerAttributes(
      pace: Rating(row.pace),
      stamina: Rating(row.stamina),
      strength: Rating(row.strength),
      passing: Rating(row.passing),
      shooting: Rating(row.shooting),
      dribbling: Rating(row.dribbling),
      tackling: Rating(row.tackling),
      positioning: Rating(row.positioning),
      vision: Rating(row.vision),
      composure: Rating(row.composure),
      goalkeeping: Rating(row.goalkeeping),
    ),
    potential: Rating(row.potential),
    fitness: Fitness(row.fitness),
    morale: Morale(row.morale),
    form: Form(row.form),
  );

  MatchEvent _toEvent(MatchEventRow row) {
    final minute = MatchMinute(row.minute);
    final side = TeamSide.values.byName(row.side);
    return switch (row.eventType) {
      'goal' => GoalScored(
        minute: minute,
        side: side,
        scorerId: PlayerId(row.playerId),
        assistantId: switch (row.secondPlayerId) {
          null => null,
          final id => PlayerId(id),
        },
        ownGoal: row.ownGoal,
      ),
      'card' => CardIssued(
        minute: minute,
        side: side,
        playerId: PlayerId(row.playerId),
        cardType: CardType.values.byName(row.cardType!),
      ),
      'injury' => PlayerInjured(
        minute: minute,
        side: side,
        playerId: PlayerId(row.playerId),
      ),
      'substitution' => Substitution(
        minute: minute,
        side: side,
        playerOutId: PlayerId(row.playerId),
        playerInId: PlayerId(row.secondPlayerId!),
      ),
      final other => throw StateError('Tipo de evento desconocido: $other'),
    };
  }
}
