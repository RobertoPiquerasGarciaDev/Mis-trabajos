/// Repositorio de IntentionState persistidos (PF-9).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/intention_codec.dart';

/// Acceso CRUD mínimo a intenciones de un guardado.
final class IntentionRepository {
  /// Crea el repositorio sobre [database].
  const IntentionRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene el estado de intenciones de una persona en el slot dado.
  Future<IntentionState?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.intentionRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeIntentionState(row.intentionJson);
  }

  /// Lista todos los estados del slot, en orden de persistencia.
  Future<List<IntentionState>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.intentionRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodeIntentionState(row.intentionJson)];
  }

  /// Guarda la lista completa del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<IntentionState> states,
  }) async {
    await (database.delete(
      database.intentionRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (states.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final state in states) {
        final personId = state.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.intentionRows,
          IntentionRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            intentionJson: encodeIntentionState(state),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
