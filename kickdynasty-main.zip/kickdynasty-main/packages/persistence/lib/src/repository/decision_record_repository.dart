/// Repositorio de DecisionRecord persistidos (PF-10).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/decision_record_codec.dart';

/// Acceso CRUD mínimo a registros sociales de un guardado.
final class DecisionRecordRepository {
  /// Crea el repositorio sobre [database].
  const DecisionRecordRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene un registro por id en el slot dado.
  Future<DecisionRecord?> get({
    required int saveId,
    required int slot,
    required String recordId,
  }) async {
    final row =
        await (database.select(database.decisionRecordRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.recordId.equals(recordId),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeDecisionRecord(row.recordJson);
  }

  /// Lista todos los registros del slot, en orden de persistencia.
  Future<List<DecisionRecord>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.decisionRecordRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodeDecisionRecord(row.recordJson)];
  }

  /// Guarda la lista completa del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<DecisionRecord> records,
  }) async {
    await (database.delete(
      database.decisionRecordRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (records.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final record in records) {
        batch.insert(
          database.decisionRecordRows,
          DecisionRecordRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            recordId: record.id,
            recordJson: encodeDecisionRecord(record),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
