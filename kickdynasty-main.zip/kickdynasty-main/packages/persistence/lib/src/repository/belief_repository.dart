/// Repositorio de BeliefState persistidos (PF-7).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/belief_codec.dart';

/// Acceso CRUD mínimo a creencias de un guardado.
final class BeliefRepository {
  /// Crea el repositorio sobre [database].
  const BeliefRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene el estado de creencias de una persona en el slot dado.
  Future<BeliefState?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.beliefRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeBeliefState(row.beliefJson);
  }

  /// Lista todos los estados del slot, en orden de persistencia.
  Future<List<BeliefState>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.beliefRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodeBeliefState(row.beliefJson)];
  }

  /// Guarda la lista completa del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<BeliefState> states,
  }) async {
    await (database.delete(
      database.beliefRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (states.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final state in states) {
        final personId = state.collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.beliefRows,
          BeliefRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            beliefJson: encodeBeliefState(state),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
