/// Repositorio de AgentMind persistidos (PF-2).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/agent_mind_codec.dart';

/// Acceso CRUD mínimo a mentes de un guardado.
final class AgentMindRepository {
  /// Crea el repositorio sobre [database].
  const AgentMindRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene una mente por persona en el slot dado.
  Future<AgentMind?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.agentMindRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeAgentMind(row.agentMindJson);
  }

  /// Lista todas las mentes del slot, en orden de persistencia.
  Future<List<AgentMind>> list({required int saveId, required int slot}) async {
    final rows =
        await (database.select(database.agentMindRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodeAgentMind(row.agentMindJson)];
  }

  /// Guarda la lista completa de mentes del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<AgentMind> minds,
  }) async {
    await (database.delete(
      database.agentMindRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (minds.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final mind in minds) {
        batch.insert(
          database.agentMindRows,
          AgentMindRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: mind.personId.value,
            agentMindJson: encodeAgentMind(mind),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
