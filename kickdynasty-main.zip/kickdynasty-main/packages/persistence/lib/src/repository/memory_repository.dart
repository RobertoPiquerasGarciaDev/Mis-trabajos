/// Repositorio de MemoryCollection persistidas (PF-4).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/memory_codec.dart';

/// Acceso CRUD mínimo a colecciones de memoria de un guardado.
final class MemoryRepository {
  /// Crea el repositorio sobre [database].
  const MemoryRepository(this.database);

  /// Base de datos subyacente.
  final SaveDatabase database;

  /// Obtiene la colección de una persona en el slot dado.
  Future<MemoryCollection?> get({
    required int saveId,
    required int slot,
    required PersonId personId,
  }) async {
    final row =
        await (database.select(database.memoryCollectionRows)..where(
              (r) =>
                  r.saveId.equals(saveId) &
                  r.slot.equals(slot) &
                  r.personId.equals(personId.value),
            ))
            .getSingleOrNull();
    if (row == null) return null;
    return decodeMemoryCollection(row.memoryJson);
  }

  /// Lista todas las colecciones del slot, en orden de persistencia.
  Future<List<MemoryCollection>> list({
    required int saveId,
    required int slot,
  }) async {
    final rows =
        await (database.select(database.memoryCollectionRows)
              ..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))
              ..orderBy([(r) => OrderingTerm.asc(r.sortOrder)]))
            .get();
    return [for (final row in rows) decodeMemoryCollection(row.memoryJson)];
  }

  /// Guarda la lista completa de colecciones del slot (reemplazo total).
  Future<void> saveAll({
    required int saveId,
    required int slot,
    required List<MemoryCollection> collections,
  }) async {
    await (database.delete(
      database.memoryCollectionRows,
    )..where((r) => r.saveId.equals(saveId) & r.slot.equals(slot))).go();
    if (collections.isEmpty) return;
    await database.batch((batch) {
      var order = 0;
      for (final collection in collections) {
        final personId = collection.ownerId;
        if (personId == null) continue;
        batch.insert(
          database.memoryCollectionRows,
          MemoryCollectionRowsCompanion.insert(
            saveId: saveId,
            slot: slot,
            personId: personId.value,
            memoryJson: encodeMemoryCollection(collection),
            sortOrder: order++,
          ),
        );
      }
    });
  }
}
