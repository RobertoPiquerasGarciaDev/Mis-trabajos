/// Serialización JSON de [Person] (PF-1).
library;

import 'dart:convert';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Codifica una [Person] a JSON compacto.
String encodePerson(Person person) => jsonEncode(person.toJson());

/// Decodifica una [Person] desde JSON.
Person decodePerson(String json) =>
    Person.fromJson(jsonDecode(json) as Map<String, Object?>);

/// Codifica una lista de personas.
String encodePersonList(List<Person> persons) => jsonEncode({
  'v': 1,
  'persons': [for (final p in persons) p.toJson()],
});

/// Decodifica una lista de personas.
List<Person> decodePersonList(String? json) {
  if (json == null || json.isEmpty) return const [];
  final root = jsonDecode(json) as Map<String, Object?>;
  final version = root['v'] as int? ?? 1;
  if (version != 1) {
    throw FormatException('PersonList JSON v$version no soportada');
  }
  return [
    for (final item in root['persons']! as List)
      Person.fromJson(Map<String, Object?>.from(item as Map)),
  ];
}
