/// Esquema normalizado de la base de datos de partidas (ADR 0003).
///
/// Convenciones:
/// - Todas las tablas de estado de partida están claveadas por
///   `(saveId, slot)`: el slot 0 es el estado vivo y los slots ≥ 1 son
///   snapshots por jornada. Guardar un snapshot es escribir las mismas
///   filas en otro slot: un único esquema, un único mapeador y las
///   migraciones cubren también el histórico.
/// - Los value objects del dominio se almacenan desenvueltos (ids y nombres
///   como TEXT, escalas como INTEGER); los enums, por su `name`.
/// - Las columnas `sortOrder`/`seq` preservan el orden exacto de las listas
///   del dominio, para que el roundtrip sea sin pérdida también en el orden.
library;

import 'package:drift/drift.dart';

/// Partidas guardadas (una fila por hueco de guardado).
class Saves extends Table {
  /// Identificador autoincremental del guardado.
  IntColumn get id => integer().autoIncrement()();

  /// Nombre visible del guardado.
  TextColumn get name => text().withLength(min: 1, max: 60)();

  /// Momento de creación (epoch ms).
  IntColumn get createdAtMs => integer()();

  /// Momento de la última escritura (epoch ms).
  IntColumn get updatedAtMs => integer()();
}

/// Cabecera del estado de campaña de un slot.
class Campaigns extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot: 0 = estado vivo, ≥ 1 = snapshot.
  IntColumn get slot => integer()();

  /// Semilla con la que se generó el mundo.
  IntColumn get worldSeed => integer()();

  /// Temporada en curso.
  IntColumn get season => integer()();

  /// Próxima jornada a disputar.
  IntColumn get nextRound => integer()();

  /// Club dirigido por el jugador humano (nullable; añadido en v2).
  TextColumn get playerClubId => text().nullable()();

  /// Alineación del jugador serializada (JSON; añadido en v3).
  TextColumn get playerLineupJson => text().nullable()();

  /// Overlay de mercado serializado (JSON; añadido en v4).
  TextColumn get marketOverlayJson => text().nullable()();

  /// Último balance financiero del club del jugador (JSON; añadido en v4).
  TextColumn get lastFinancesJson => text().nullable()();

  /// Jornada entrenada por última vez (añadido en v5).
  IntColumn get lastTrainingRound => integer().nullable()();

  /// Decisiones del manager pendientes (JSON; añadido en v6).
  TextColumn get managerDecisionsJson => text().nullable()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot};
}

/// Índice de snapshots por jornada (los datos viven en las tablas de
/// estado bajo el mismo slot).
class Snapshots extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot que ocupa el snapshot (≥ 1).
  IntColumn get slot => integer()();

  /// Temporada capturada.
  IntColumn get season => integer()();

  /// Jornada capturada (la próxima a disputar en ese momento).
  IntColumn get round => integer()();

  /// Momento de la captura (epoch ms).
  IntColumn get createdAtMs => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot};
}

/// Ligas del mundo.
class LeagueRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Identificador de la liga.
  TextColumn get leagueId => text()();

  /// Nombre de la competición.
  TextColumn get name => text()();

  /// País (ISO 3166-1 alfa-2).
  TextColumn get country => text()();

  /// Nivel de la pirámide (1 = máxima categoría).
  IntColumn get level => integer()();

  /// Posición en la lista de ligas del mundo.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, leagueId};
}

/// Clubes con su estadio y tesorería.
class ClubRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Identificador del club.
  TextColumn get clubId => text()();

  /// Liga en la que milita.
  TextColumn get leagueId => text()();

  /// Nombre completo.
  TextColumn get name => text()();

  /// Código corto para marcadores.
  TextColumn get code => text()();

  /// País (ISO 3166-1 alfa-2).
  TextColumn get country => text()();

  /// Reputación (1–99).
  IntColumn get reputation => integer()();

  /// Nombre del estadio.
  TextColumn get stadiumName => text()();

  /// Aforo del estadio.
  IntColumn get stadiumCapacity => integer()();

  /// Saldo de tesorería (puede ser negativo).
  IntColumn get balance => integer()();

  /// Posición en la lista de clubes de su liga.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, clubId};
}

/// Jugadores con atributos y condición.
class PlayerRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Identificador del jugador.
  TextColumn get playerId => text()();

  /// Club al que pertenece su plantilla.
  TextColumn get clubId => text()();

  /// Nombre visible.
  TextColumn get name => text()();

  /// Nacionalidad (ISO 3166-1 alfa-2).
  TextColumn get nationality => text()();

  /// Posición natural (name del enum `Position`).
  TextColumn get position => text()();

  /// Pie preferido (name del enum `PreferredFoot`).
  TextColumn get preferredFoot => text()();

  /// Edad en años.
  IntColumn get age => integer()();

  /// Atributo: ritmo.
  IntColumn get pace => integer()();

  /// Atributo: resistencia.
  IntColumn get stamina => integer()();

  /// Atributo: fuerza.
  IntColumn get strength => integer()();

  /// Atributo: pase.
  IntColumn get passing => integer()();

  /// Atributo: remate.
  IntColumn get shooting => integer()();

  /// Atributo: regate.
  IntColumn get dribbling => integer()();

  /// Atributo: entrada.
  IntColumn get tackling => integer()();

  /// Atributo: colocación.
  IntColumn get positioning => integer()();

  /// Atributo: visión.
  IntColumn get vision => integer()();

  /// Atributo: temple.
  IntColumn get composure => integer()();

  /// Atributo: portería.
  IntColumn get goalkeeping => integer()();

  /// Potencial (1–99).
  IntColumn get potential => integer()();

  /// Estado físico (0–100).
  IntColumn get fitness => integer()();

  /// Moral (0–100).
  IntColumn get morale => integer()();

  /// Forma (0–100).
  IntColumn get form => integer()();

  /// Persona asociada (`null` en saves anteriores a v7).
  TextColumn get personId => text().nullable()();

  /// Posición en la lista de la plantilla.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, playerId};
}

/// Contratos jugador–club.
class ContractRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Identificador del contrato.
  TextColumn get contractId => text()();

  /// Jugador contratado.
  TextColumn get playerId => text()();

  /// Club contratante.
  TextColumn get clubId => text()();

  /// Salario semanal.
  IntColumn get weeklyWage => integer()();

  /// Temporada de expiración.
  IntColumn get expirySeason => integer()();

  /// Semana de expiración.
  IntColumn get expiryWeek => integer()();

  /// Posición en la lista de contratos del club.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, contractId};
}

/// Calendario de la temporada en curso.
class FixtureRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Identificador del fixture.
  TextColumn get fixtureId => text()();

  /// Liga del fixture.
  TextColumn get leagueId => text()();

  /// Temporada.
  IntColumn get season => integer()();

  /// Jornada.
  IntColumn get round => integer()();

  /// Club local.
  TextColumn get homeClubId => text()();

  /// Club visitante.
  TextColumn get awayClubId => text()();

  /// Posición en la lista del calendario.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, fixtureId};
}

/// Resultados de los fixtures disputados.
class ResultRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Fixture al que corresponde.
  TextColumn get fixtureId => text()();

  /// Goles del local.
  IntColumn get homeGoals => integer()();

  /// Goles del visitante.
  IntColumn get awayGoals => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, fixtureId};
}

/// Eventos de los partidos disputados.
class MatchEventRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Fixture al que corresponde.
  TextColumn get fixtureId => text()();

  /// Orden del evento dentro del partido.
  IntColumn get seq => integer()();

  /// Minuto del evento.
  IntColumn get minute => integer()();

  /// Lado al que se atribuye (name de `TeamSide`).
  TextColumn get side => text()();

  /// Discriminador: `goal`, `card`, `injury` o `substitution`.
  TextColumn get eventType => text()();

  /// Jugador principal (goleador, amonestado, lesionado o sustituido).
  TextColumn get playerId => text()();

  /// Jugador secundario (asistente o el que entra), si aplica.
  TextColumn get secondPlayerId => text().nullable()();

  /// Tipo de tarjeta (name de `CardType`), solo en eventos `card`.
  TextColumn get cardType => text().nullable()();

  /// `true` si el gol fue en propia puerta.
  BoolColumn get ownGoal => boolean().withDefault(const Constant(false))();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, fixtureId, seq};
}

/// Estadísticas de jugador de la temporada en curso.
class PlayerStatRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Jugador.
  TextColumn get playerId => text()();

  /// Partidos jugados.
  IntColumn get appearances => integer()();

  /// Goles.
  IntColumn get goals => integer()();

  /// Asistencias.
  IntColumn get assists => integer()();

  /// Amarillas.
  IntColumn get yellowCards => integer()();

  /// Expulsiones.
  IntColumn get redCards => integer()();

  /// Valoración media.
  RealColumn get averageRating => real()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, playerId};
}

/// Personas People First (PF-1, esquema v7).
class PersonRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Identificador estable de la persona.
  TextColumn get personId => text()();

  /// Persona serializada (PersonCodec v1).
  TextColumn get personJson => text()();

  /// Posición en la lista de personas del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Mentes People First (PF-2, esquema v8).
class AgentMindRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona dueña de la mente.
  TextColumn get personId => text()();

  /// AgentMind serializado (AgentMindCodec v1).
  TextColumn get agentMindJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Fotografías perceptivas People First (PF-3, esquema v9).
class PerceptionSnapshotRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona observadora.
  TextColumn get observerId => text()();

  /// PerceptionSnapshot serializado (PerceptionSnapshotCodec v1).
  TextColumn get snapshotJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, observerId};
}

/// Colecciones de memoria People First (PF-4, esquema v10).
class MemoryCollectionRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona dueña de los recuerdos.
  TextColumn get personId => text()();

  /// MemoryCollection serializado (MemoryCodec v1).
  TextColumn get memoryJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Relaciones People First (PF-5, esquema v11).
class RelationRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona observadora dueña del grafo.
  TextColumn get personId => text()();

  /// RelationState serializado (RelationCodec v1).
  TextColumn get relationJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Interpretaciones People First (PF-6, esquema v12).
class InterpretationRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona observadora dueña de las hipótesis.
  TextColumn get personId => text()();

  /// InterpretationState serializado (InterpretationCodec v1).
  TextColumn get interpretationJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Creencias People First (PF-7, esquema v13).
class BeliefRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona observadora dueña de las creencias.
  TextColumn get personId => text()();

  /// BeliefState serializado (BeliefCodec v2).
  TextColumn get beliefJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Objetivos People First (PF-8, esquema v14).
class GoalRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona observadora dueña de los objetivos.
  TextColumn get personId => text()();

  /// GoalState serializado (GoalCodec v2).
  TextColumn get goalJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Prioridades People First (PF-9, esquema v15).
class PriorityRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona observadora dueña de las prioridades.
  TextColumn get personId => text()();

  /// PriorityState serializado (PriorityCodec v2).
  TextColumn get priorityJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Intenciones People First (PF-9, esquema v15).
class IntentionRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona observadora dueña de las intenciones.
  TextColumn get personId => text()();

  /// IntentionState serializado (IntentionCodec v2).
  TextColumn get intentionJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Filas de decisiones cognitivas People First (PF-10, esquema v16).
class DecisionRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Persona observadora dueña de las decisiones.
  TextColumn get personId => text()();

  /// DecisionState serializado.
  TextColumn get decisionJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, personId};
}

/// Registros sociales append-only People First (PF-10, esquema v16).
class DecisionRecordRows extends Table {
  /// Guardado al que pertenece.
  IntColumn get saveId => integer()();

  /// Slot de estado.
  IntColumn get slot => integer()();

  /// Identificador estable del registro.
  TextColumn get recordId => text()();

  /// DecisionRecord serializado.
  TextColumn get recordJson => text()();

  /// Posición en la lista del slot.
  IntColumn get sortOrder => integer()();

  @override
  Set<Column<Object>> get primaryKey => {saveId, slot, recordId};
}
