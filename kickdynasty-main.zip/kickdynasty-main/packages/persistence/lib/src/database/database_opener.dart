/// Apertura de la base de datos de partidas.
library;

import 'dart:io';

import 'package:drift/native.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';

/// Abre la base de datos sobre el fichero en [path].
SaveDatabase openSaveDatabase(String path) =>
    SaveDatabase(NativeDatabase(File(path)));

/// Abre una base de datos en memoria (tests y desarrollo).
SaveDatabase openSaveDatabaseInMemory() =>
    SaveDatabase(NativeDatabase.memory());
