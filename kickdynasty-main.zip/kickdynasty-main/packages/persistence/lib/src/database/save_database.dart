/// Base de datos de partidas guardadas (Drift/SQLite, ADR 0003).
library;

import 'package:drift/drift.dart';
import 'package:kickdynasty_persistence/src/database/tables.dart';

part 'save_database.g.dart';

/// Base de datos local de KickDynasty.
///
/// Migraciones: el esquema está versionado y cada salto de versión tiene su
/// paso explícito en [migration]. Historia:
/// - v1: esquema inicial (sin `campaigns.player_club_id` ni `snapshots`).
/// - v2: añade `campaigns.player_club_id` (partidas con club dirigido por
///   el jugador) y la tabla `snapshots` (histórico por jornada).
/// - v3: añade `campaigns.player_lineup_json` (alineación del jugador).
/// - v4: añade `campaigns.market_overlay_json` y `campaigns.last_finances_json`.
/// - v5: añade `campaigns.last_training_round`.
/// - v6: añade `campaigns.manager_decisions_json`.
/// - v7: añade `person_rows` y `player_rows.person_id`.
/// - v8: añade `agent_mind_rows`.
/// - v9: añade `perception_snapshot_rows`.
/// - v10: añade `memory_collection_rows`.
/// - v11: añade `relation_rows`.
/// - v12: añade `interpretation_rows`.
/// - v13: añade `belief_rows`.
/// - v14: añade `goal_rows`.
/// - v15: añade `priority_rows` e `intention_rows`.
/// - v16: añade `decision_rows` y `decision_record_rows`.
@DriftDatabase(
  tables: [
    Saves,
    Campaigns,
    Snapshots,
    LeagueRows,
    ClubRows,
    PlayerRows,
    PersonRows,
    AgentMindRows,
    PerceptionSnapshotRows,
    MemoryCollectionRows,
    RelationRows,
    InterpretationRows,
    BeliefRows,
    GoalRows,
    PriorityRows,
    IntentionRows,
    DecisionRows,
    DecisionRecordRows,
    ContractRows,
    FixtureRows,
    ResultRows,
    MatchEventRows,
    PlayerStatRows,
  ],
)
class SaveDatabase extends _$SaveDatabase {
  /// Abre la base de datos sobre el [executor] dado (fichero en producción,
  /// memoria en tests).
  SaveDatabase(super.executor);

  @override
  int get schemaVersion => 16;

  @override
  MigrationStrategy get migration => MigrationStrategy(
    onCreate: (m) => m.createAll(),
    onUpgrade: (m, from, to) async {
      if (from < 2) {
        await m.addColumn(campaigns, campaigns.playerClubId);
        await m.createTable(snapshots);
      }
      if (from < 3) {
        await m.addColumn(campaigns, campaigns.playerLineupJson);
      }
      if (from < 4) {
        await m.addColumn(campaigns, campaigns.marketOverlayJson);
        await m.addColumn(campaigns, campaigns.lastFinancesJson);
      }
      if (from < 5) {
        await m.addColumn(campaigns, campaigns.lastTrainingRound);
      }
      if (from < 6) {
        await m.addColumn(campaigns, campaigns.managerDecisionsJson);
      }
      if (from < 7) {
        await m.createTable(personRows);
        await m.addColumn(playerRows, playerRows.personId);
      }
      if (from < 8) {
        await m.createTable(agentMindRows);
      }
      if (from < 9) {
        await m.createTable(perceptionSnapshotRows);
      }
      if (from < 10) {
        await m.createTable(memoryCollectionRows);
      }
      if (from < 11) {
        await m.createTable(relationRows);
      }
      if (from < 12) {
        await m.createTable(interpretationRows);
      }
      if (from < 13) {
        await m.createTable(beliefRows);
      }
      if (from < 14) {
        await m.createTable(goalRows);
      }
      if (from < 15) {
        await m.createTable(priorityRows);
        await m.createTable(intentionRows);
      }
      if (from < 16) {
        await m.createTable(decisionRows);
        await m.createTable(decisionRecordRows);
      }
    },
  );
}
