/// Persistencia local de KickDynasty sobre Drift/SQLite.
///
/// Estado de partida normalizado en tablas (no blobs JSON), migraciones
/// versionadas y snapshots por jornada (ADR 0003). Implementa las interfaces
/// de repositorio definidas por la capa de aplicación; ninguna otra capa ve
/// SQL.
library;

export 'src/database/database_opener.dart';
export 'src/database/save_database.dart' show SaveDatabase;
export 'src/repository/agent_mind_repository.dart';
export 'src/repository/belief_repository.dart';
export 'src/repository/decision_record_repository.dart';
export 'src/repository/decision_repository.dart';
export 'src/repository/goal_repository.dart';
export 'src/repository/intention_repository.dart';
export 'src/repository/interpretation_repository.dart';
export 'src/repository/memory_repository.dart';
export 'src/repository/perception_snapshot_repository.dart';
export 'src/repository/person_repository.dart';
export 'src/repository/priority_repository.dart';
export 'src/repository/relation_repository.dart';
export 'src/repository/save_repository.dart';
