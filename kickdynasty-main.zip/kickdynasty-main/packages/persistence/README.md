# kickdynasty_persistence

Persistencia local de KickDynasty sobre Drift/SQLite (ADR 0003): estado de
partida normalizado en tablas, migraciones versionadas y snapshots por
jornada.

## Diseño

La unidad de guardado es `CampaignState` (definido en el engine): el mundo
en su estado actual más el progreso de la temporada en curso. Este paquete
lo mapea a un **esquema normalizado** — nada de blobs JSON — y lo
reconstruye sin pérdida, incluido el orden exacto de las listas del dominio
(columnas `sort_order`/`seq`).

### Slots: un esquema para el estado vivo y los snapshots

Todas las tablas de estado están claveadas por `(save_id, slot)`:

- **slot 0**: el estado vivo de la partida.
- **slots ≥ 1**: snapshots por jornada, indexados en la tabla `snapshots`.

Guardar un snapshot es escribir las mismas filas en otro slot. Ventajas: un
único mapeador (el roundtrip testeado cubre ambos caminos), las migraciones
de esquema aplican también al histórico y la retención es borrar slots.

### API

```dart
final database = SaveDatabase(NativeDatabase(file));
final repository = SaveRepository(database);

final saveId = await repository.createSave(name: 'Mi carrera', state: state);
await repository.saveCampaign(saveId, nextState);        // sobrescribe
final loaded = await repository.loadCampaign(saveId);    // roundtrip exacto

await repository.writeSnapshot(saveId, state);           // retención: 10
final snapshots = await repository.listSnapshots(saveId);
final past = await repository.loadSnapshot(saveId, snapshots.first.slot);
```

Toda escritura es transaccional: o se persiste el estado completo o nada.
Ninguna otra capa ve SQL.

### Migraciones

El esquema está versionado (`SaveDatabase.schemaVersion`) y cada salto
tiene su paso explícito en `MigrationStrategy`. La historia vive en el
doc de `SaveDatabase`; cada migración se prueba fabricando una BD real en
el formato antiguo (`test/migration_test.dart`) y verificando que los
datos sobreviven.

## Tests

- `save_repository_test.dart`: roundtrip con igualdad profunda de una
  temporada completa simulada por el motor real, ciclo de vida del
  guardado, aislamiento entre guardados y retención de snapshots.
- `migration_test.dart`: BD v1 real → abre con el esquema actual → migra a
  v2 conservando los datos.
