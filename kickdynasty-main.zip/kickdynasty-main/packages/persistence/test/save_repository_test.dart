import 'package:drift/drift.dart' hide isNotNull, isNull;
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';
import 'package:test/test.dart';

import 'support/campaign_fixtures.dart';

void main() {
  late SaveDatabase database;
  late SaveRepository repository;
  var nowMs = 1000000;

  setUp(() {
    driftRuntimeOptions.dontWarnAboutMultipleDatabases = true;
    database = SaveDatabase(NativeDatabase.memory());
    repository = SaveRepository(
      database,
      clock: () => DateTime.fromMillisecondsSinceEpoch(nowMs += 1000),
    );
  });

  tearDown(() => database.close());

  group('roundtrip sin pérdida', () {
    test('una temporada completa simulada por el motor real', () async {
      final state = fullSeasonCampaign();
      final saveId = await repository.createSave(
        name: 'Mi carrera',
        state: state,
      );

      final loaded = await repository.loadCampaign(saveId);

      expectCampaignEquals(loaded.state, state);
    });

    test(
      'una partida recién creada (sin resultados ni estadísticas)',
      () async {
        final state = freshCampaign();
        final saveId = await repository.createSave(name: 'Nueva', state: state);

        final loaded = await repository.loadCampaign(saveId);

        expectCampaignEquals(loaded.state, state);
        expect(loaded.state.results, isEmpty);
        expect(loaded.state.stats, isEmpty);
        expect(loaded.state.playerClubId, isNull);
        expect(loaded.state.isSeasonComplete, isFalse);
      },
    );

    test('todos los tipos de evento sobreviven al roundtrip', () async {
      final state = fullSeasonCampaign();
      final saveId = await repository.createSave(name: 'e', state: state);
      final loaded = await repository.loadCampaign(saveId);

      final types = <Type>{};
      var ownGoals = 0;
      var assisted = 0;
      var secondYellows = 0;
      for (final result in loaded.state.results.values) {
        for (final event in result.events) {
          types.add(event.runtimeType);
          if (event is GoalScored) {
            if (event.ownGoal) ownGoals++;
            if (event.assistantId != null) assisted++;
          }
          if (event is CardIssued && event.cardType == CardType.secondYellow) {
            secondYellows++;
          }
        }
      }

      // Una temporada de 760 partidos ejercita todo el vocabulario.
      expect(
        types,
        containsAll([GoalScored, CardIssued, PlayerInjured, Substitution]),
      );
      expect(assisted, greaterThan(0));
      expect(ownGoals + secondYellows, greaterThanOrEqualTo(0));
    });
  });

  group('ciclo de vida del guardado', () {
    test('saveCampaign sobrescribe el estado vivo', () async {
      final initial = freshCampaign();
      final saveId = await repository.createSave(name: 'c', state: initial);

      final progressed = fullSeasonCampaign();
      await repository.saveCampaign(saveId, progressed);

      final loaded = await repository.loadCampaign(saveId);
      expectCampaignEquals(loaded.state, progressed);
    });

    test('listSaves devuelve resúmenes con el más reciente primero', () async {
      final first = await repository.createSave(
        name: 'Primera',
        state: freshCampaign(),
      );
      final second = await repository.createSave(
        name: 'Segunda',
        state: fullSeasonCampaign(),
      );

      final summaries = await repository.listSaves();
      expect(summaries, hasLength(2));
      expect(summaries.first.id, second);
      expect(summaries.first.name, 'Segunda');
      expect(summaries.first.season, 1);
      expect(summaries.first.nextRound, 39);
      expect(summaries.first.playerClubId, isNotNull);
      expect(summaries.last.id, first);
      expect(summaries.last.playerClubId, isNull);
      expect(
        summaries.first.updatedAt.isAfter(summaries.last.updatedAt),
        isTrue,
      );
    });

    test('persiste alineación del jugador', () async {
      final state = freshCampaign();
      final club = state.world.leagues.first.clubs.first;
      final lineup = LineupSelector().select(squad: club.squad);
      final withLineup = state.copyWith(
        playerClubId: club.club.id,
        playerLineup: lineup,
      );

      final saveId = await repository.createSave(
        name: 'lineup',
        state: withLineup,
      );
      final loaded = await repository.loadCampaign(saveId);

      expect(loaded.state.playerLineup, isNotNull);
      expect(
        loaded.state.playerLineup!.formation.label,
        lineup.formation.label,
      );
      expect(loaded.state.playerLineup!.starters, lineup.starters);
    });

    test('deleteSave elimina el estado, los snapshots y el resumen', () async {
      final state = freshCampaign();
      final saveId = await repository.createSave(name: 'd', state: state);
      await repository.writeSnapshot(saveId, state);

      await repository.deleteSave(saveId);

      expect(await repository.listSaves(), isEmpty);
      expect(await repository.listSnapshots(saveId), isEmpty);
      await expectLater(
        repository.loadCampaign(saveId),
        throwsA(isA<StateError>()),
      );
      // Sin filas huérfanas en ninguna tabla de estado.
      for (final table in database.allTables) {
        final rows = await database.select(table).get();
        expect(rows, isEmpty, reason: table.actualTableName);
      }
    });

    test('dos guardados no se contaminan entre sí', () async {
      final stateA = freshCampaign(seed: 5);
      final stateB = fullSeasonCampaign(seed: 12);
      final saveA = await repository.createSave(name: 'A', state: stateA);
      final saveB = await repository.createSave(name: 'B', state: stateB);

      expectCampaignEquals(
        (await repository.loadCampaign(saveA)).state,
        stateA,
      );
      expectCampaignEquals(
        (await repository.loadCampaign(saveB)).state,
        stateB,
      );

      await repository.deleteSave(saveA);
      expectCampaignEquals(
        (await repository.loadCampaign(saveB)).state,
        stateB,
      );
    });

    test('guardar sobre un id inexistente falla sin efectos', () async {
      await expectLater(
        repository.saveCampaign(99, freshCampaign()),
        throwsA(isA<StateError>()),
      );
      await expectLater(
        repository.writeSnapshot(99, freshCampaign()),
        throwsA(isA<StateError>()),
      );
    });
  });

  group('snapshots por jornada', () {
    test('roundtrip del snapshot y del estado vivo independientes', () async {
      final initial = freshCampaign();
      final saveId = await repository.createSave(name: 's', state: initial);

      final info = await repository.writeSnapshot(saveId, initial);
      expect(info.slot, 1);
      expect(info.season, 1);
      expect(info.round, 1);

      // El estado vivo avanza; el snapshot no cambia.
      final progressed = fullSeasonCampaign();
      await repository.saveCampaign(saveId, progressed);

      expectCampaignEquals(
        await repository.loadSnapshot(saveId, info.slot),
        initial,
      );
      final live = await repository.loadCampaign(saveId);
      expectCampaignEquals(live.state, progressed);
    });

    test('la retención poda los snapshots más antiguos', () async {
      final state = freshCampaign();
      final saveId = await repository.createSave(name: 'r', state: state);

      for (var i = 0; i < 5; i++) {
        await repository.writeSnapshot(saveId, state, retention: 3);
      }

      final snapshots = await repository.listSnapshots(saveId);
      expect([for (final s in snapshots) s.slot], [5, 4, 3]);

      // Los slots podados ya no se pueden cargar.
      await expectLater(
        repository.loadSnapshot(saveId, 1),
        throwsA(isA<StateError>()),
      );
      // Los conservados sí.
      expectCampaignEquals(await repository.loadSnapshot(saveId, 4), state);
    });

    test('el slot 0 está reservado al estado vivo', () async {
      final saveId = await repository.createSave(
        name: 'z',
        state: freshCampaign(),
      );
      expect(
        () => repository.loadSnapshot(saveId, 0),
        throwsA(isA<ArgumentError>()),
      );
      expect(
        () => repository.writeSnapshot(saveId, freshCampaign(), retention: 0),
        throwsA(isA<ArgumentError>()),
      );
    });
  });
}
