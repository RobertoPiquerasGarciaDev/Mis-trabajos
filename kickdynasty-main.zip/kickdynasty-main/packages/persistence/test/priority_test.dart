@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/priority_codec.dart';
import 'package:kickdynasty_persistence/src/repository/priority_repository.dart';
import 'package:test/test.dart';

PriorityState _sampleState() => PriorityState(
  collection: PriorityCollection(
    ownerId: PersonId('person-priority-persist'),
    entries: [
      PriorityEntry(
        id: PriorityId('priority-persist-1'),
        observerPersonId: PersonId('person-priority-persist'),
        sourceGoalId: GoalId('goal-persist-1'),
        goalType: GoalType.maintainTrust,
        summary: 'Atención hacia: Quiero mantener la confianza',
        strength: PriorityStrength(0.66),
        rank: PriorityRank(1),
        type: PriorityType.dominant,
        origin: PriorityOrigin.goalDerived,
        reason: PriorityReason.goalStrength,
        createdAt: const MemoryTimestamp(season: 1, week: 2),
        updatedAt: const MemoryTimestamp(season: 1, week: 2),
      ),
    ],
  ),
);

void main() {
  group('PriorityCodec', () {
    test('roundtrip JSON', () {
      final state = _sampleState();
      expect(decodePriorityState(encodePriorityState(state)), state);
    });

    test('roundtrip lista', () {
      final states = [_sampleState()];
      expect(decodePriorityStateList(encodePriorityStateList(states)), states);
    });
  });

  group('PriorityRepository', () {
    late SaveDatabase database;
    late PriorityRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = PriorityRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar prioridades', () async {
      final state = _sampleState();
      await repository.saveAll(saveId: 1, slot: 0, states: [state]);
      expect(await repository.list(saveId: 1, slot: 0), [state]);
      expect(
        await repository.get(
          saveId: 1,
          slot: 0,
          personId: state.collection.ownerId!,
        ),
        state,
      );
    });
  });
}
