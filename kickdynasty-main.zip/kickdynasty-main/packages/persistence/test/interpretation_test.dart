@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/interpretation_codec.dart';
import 'package:kickdynasty_persistence/src/repository/interpretation_repository.dart';
import 'package:test/test.dart';

InterpretationState _sampleState() => InterpretationState(
  collection: InterpretationCollection(
    ownerId: PersonId('person-interp-persist'),
    entries: [
      InterpretationEntry(
        id: InterpretationId('interpret-persist-1'),
        observerPersonId: PersonId('person-interp-persist'),
        sourceMemoryIds: [MemoryId('memory-persist-1')],
        sourceRelationIds: const ['person-target'],
        type: InterpretationType.protection,
        confidence: InterpretationConfidence(0.66),
        importance: InterpretationImportance(0.44),
        createdAt: const MemoryTimestamp(season: 1, week: 2),
        expiresAt: const MemoryTimestamp(season: 1, week: 6),
        biasApplied: InterpretationBias.protection,
        summary: 'Mi entrenador me protege',
        source: InterpretationSource.relation,
      ),
    ],
  ),
);

void main() {
  group('InterpretationCodec', () {
    test('roundtrip JSON', () {
      final state = _sampleState();
      expect(
        decodeInterpretationState(encodeInterpretationState(state)),
        state,
      );
    });

    test('roundtrip lista', () {
      final states = [_sampleState()];
      expect(
        decodeInterpretationStateList(encodeInterpretationStateList(states)),
        states,
      );
    });
  });

  group('InterpretationRepository', () {
    late SaveDatabase database;
    late InterpretationRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = InterpretationRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar interpretaciones', () async {
      final state = _sampleState();
      await repository.saveAll(saveId: 1, slot: 0, states: [state]);
      expect(await repository.list(saveId: 1, slot: 0), [state]);
      expect(
        await repository.get(
          saveId: 1,
          slot: 0,
          personId: state.collection.ownerId!,
        ),
        state,
      );
    });
  });
}
