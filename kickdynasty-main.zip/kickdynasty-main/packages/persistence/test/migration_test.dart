@Tags(['people-first'])
import 'dart:io';

import 'package:drift/drift.dart' hide isNotNull, isNull;
import 'package:drift/native.dart';
// Import de src: los tests del propio paquete verifican también las clases
// generadas (companions) que el barrel público no expone.
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:sqlite3/sqlite3.dart' as raw;
import 'package:test/test.dart';

/// DDL del esquema v1, tal y como lo creaba Drift antes de la v2: sin la
/// columna `campaigns.player_club_id` y sin la tabla `snapshots`.
///
/// Es una copia congelada a propósito: el fixture de una migración debe
/// representar el pasado exacto, no derivarse del esquema actual.
const _schemaV1 = [
  '''
  CREATE TABLE saves (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    created_at_ms INTEGER NOT NULL,
    updated_at_ms INTEGER NOT NULL
  );
  ''',
  '''
  CREATE TABLE campaigns (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    world_seed INTEGER NOT NULL,
    season INTEGER NOT NULL,
    next_round INTEGER NOT NULL,
    PRIMARY KEY (save_id, slot)
  );
  ''',
  '''
  CREATE TABLE league_rows (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    league_id TEXT NOT NULL,
    name TEXT NOT NULL,
    country TEXT NOT NULL,
    level INTEGER NOT NULL,
    sort_order INTEGER NOT NULL,
    PRIMARY KEY (save_id, slot, league_id)
  );
  ''',
  '''
  CREATE TABLE club_rows (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    club_id TEXT NOT NULL,
    league_id TEXT NOT NULL,
    name TEXT NOT NULL,
    code TEXT NOT NULL,
    country TEXT NOT NULL,
    reputation INTEGER NOT NULL,
    stadium_name TEXT NOT NULL,
    stadium_capacity INTEGER NOT NULL,
    balance INTEGER NOT NULL,
    sort_order INTEGER NOT NULL,
    PRIMARY KEY (save_id, slot, club_id)
  );
  ''',
  '''
  CREATE TABLE player_rows (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    player_id TEXT NOT NULL,
    club_id TEXT NOT NULL,
    name TEXT NOT NULL,
    nationality TEXT NOT NULL,
    position TEXT NOT NULL,
    preferred_foot TEXT NOT NULL,
    age INTEGER NOT NULL,
    pace INTEGER NOT NULL,
    stamina INTEGER NOT NULL,
    strength INTEGER NOT NULL,
    passing INTEGER NOT NULL,
    shooting INTEGER NOT NULL,
    dribbling INTEGER NOT NULL,
    tackling INTEGER NOT NULL,
    positioning INTEGER NOT NULL,
    vision INTEGER NOT NULL,
    composure INTEGER NOT NULL,
    goalkeeping INTEGER NOT NULL,
    potential INTEGER NOT NULL,
    fitness INTEGER NOT NULL,
    morale INTEGER NOT NULL,
    form INTEGER NOT NULL,
    sort_order INTEGER NOT NULL,
    PRIMARY KEY (save_id, slot, player_id)
  );
  ''',
  '''
  CREATE TABLE contract_rows (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    contract_id TEXT NOT NULL,
    player_id TEXT NOT NULL,
    club_id TEXT NOT NULL,
    weekly_wage INTEGER NOT NULL,
    expiry_season INTEGER NOT NULL,
    expiry_week INTEGER NOT NULL,
    sort_order INTEGER NOT NULL,
    PRIMARY KEY (save_id, slot, contract_id)
  );
  ''',
  '''
  CREATE TABLE fixture_rows (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    fixture_id TEXT NOT NULL,
    league_id TEXT NOT NULL,
    season INTEGER NOT NULL,
    round INTEGER NOT NULL,
    home_club_id TEXT NOT NULL,
    away_club_id TEXT NOT NULL,
    sort_order INTEGER NOT NULL,
    PRIMARY KEY (save_id, slot, fixture_id)
  );
  ''',
  '''
  CREATE TABLE result_rows (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    fixture_id TEXT NOT NULL,
    home_goals INTEGER NOT NULL,
    away_goals INTEGER NOT NULL,
    PRIMARY KEY (save_id, slot, fixture_id)
  );
  ''',
  '''
  CREATE TABLE match_event_rows (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    fixture_id TEXT NOT NULL,
    seq INTEGER NOT NULL,
    minute INTEGER NOT NULL,
    side TEXT NOT NULL,
    event_type TEXT NOT NULL,
    player_id TEXT NOT NULL,
    second_player_id TEXT,
    card_type TEXT,
    own_goal INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (save_id, slot, fixture_id, seq)
  );
  ''',
  '''
  CREATE TABLE player_stat_rows (
    save_id INTEGER NOT NULL,
    slot INTEGER NOT NULL,
    player_id TEXT NOT NULL,
    appearances INTEGER NOT NULL,
    goals INTEGER NOT NULL,
    assists INTEGER NOT NULL,
    yellow_cards INTEGER NOT NULL,
    red_cards INTEGER NOT NULL,
    average_rating REAL NOT NULL,
    PRIMARY KEY (save_id, slot, player_id)
  );
  ''',
];

void main() {
  late Directory tempDir;

  setUp(() async {
    driftRuntimeOptions.dontWarnAboutMultipleDatabases = true;
    tempDir = await Directory.systemTemp.createTemp('kickdynasty_migration');
  });

  tearDown(() => tempDir.delete(recursive: true));

  test('una base de datos v1 migra a v2 conservando los datos', () async {
    final file = File('${tempDir.path}/save_v1.db');

    // 1. Fabrica una BD real en formato v1 con datos de una partida.
    final rawDb = raw.sqlite3.open(file.path);
    for (final ddl in _schemaV1) {
      rawDb.execute(ddl);
    }
    rawDb
      ..execute(
        'INSERT INTO saves (id, name, created_at_ms, updated_at_ms) '
        "VALUES (1, 'Partida veterana', 100, 200)",
      )
      ..execute(
        'INSERT INTO campaigns (save_id, slot, world_seed, season, next_round) '
        'VALUES (1, 0, 42, 3, 17)',
      )
      ..execute(
        'INSERT INTO league_rows '
        '(save_id, slot, league_id, name, country, level, sort_order) '
        "VALUES (1, 0, 'league-1', 'Liga Primera', 'ES', 1, 0)",
      )
      ..execute('PRAGMA user_version = 1')
      ..dispose();

    // 2. Ábrela con el esquema actual: Drift ejecuta la migración 1→7.
    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    // 3. Los datos v1 siguen ahí y las columnas nuevas llegan como NULL.
    final campaign = await database.select(database.campaigns).getSingle();
    expect(campaign.saveId, 1);
    expect(campaign.worldSeed, 42);
    expect(campaign.season, 3);
    expect(campaign.nextRound, 17);
    expect(campaign.playerClubId, isNull);
    expect(campaign.playerLineupJson, isNull);

    final save = await database.select(database.saves).getSingle();
    expect(save.name, 'Partida veterana');

    final league = await database.select(database.leagueRows).getSingle();
    expect(league.leagueId, 'league-1');

    // 4. La tabla nueva de la v2 es funcional.
    await database
        .into(database.snapshots)
        .insert(
          SnapshotsCompanion.insert(
            saveId: 1,
            slot: 1,
            season: 3,
            round: 17,
            createdAtMs: 300,
          ),
        );
    final snapshots = await database.select(database.snapshots).get();
    expect(snapshots, hasLength(1));
  });

  test('una base de datos nueva se crea directamente en v16', () async {
    final file = File('${tempDir.path}/save_new.db');
    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    // El esquema recién creado incluye columnas y tablas de v2–v4.
    final columns = await database
        .customSelect("SELECT name FROM pragma_table_info('campaigns')")
        .get();
    expect(
      [for (final row in columns) row.data.values.first],
      containsAll([
        'player_club_id',
        'player_lineup_json',
        'market_overlay_json',
        'last_finances_json',
        'last_training_round',
        'manager_decisions_json',
      ]),
    );
    final tables = await database
        .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
        .get();
    expect(
      [for (final row in tables) row.data.values.first],
      containsAll([
        'snapshots',
        'person_rows',
        'agent_mind_rows',
        'perception_snapshot_rows',
        'memory_collection_rows',
        'relation_rows',
        'interpretation_rows',
        'belief_rows',
        'goal_rows',
        'priority_rows',
        'intention_rows',
      ]),
    );
  });

  test(
    'una base de datos v6 migra a v14 con person_rows y agent_mind_rows',
    () async {
      final file = File('${tempDir.path}/save_v6.db');
      final rawDb = raw.sqlite3.open(file.path);
      for (final ddl in _schemaV1) {
        rawDb.execute(ddl);
      }
      rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
      );
      rawDb.execute('PRAGMA user_version = 6');
      rawDb.dispose();

      final database = SaveDatabase(NativeDatabase(file));
      addTearDown(database.close);

      final version = await database
          .customSelect('PRAGMA user_version')
          .getSingle();
      expect(version.data.values.first, 16);

      final playerColumns = await database
          .customSelect("SELECT name FROM pragma_table_info('player_rows')")
          .get();
      expect([
        for (final row in playerColumns) row.data.values.first,
      ], contains('person_id'));

      final tables = await database
          .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
          .get();
      expect([
        for (final row in tables) row.data.values.first,
      ], contains('agent_mind_rows'));
    },
  );

  test(
    'una base de datos v7 migra a v14 con agent_mind_rows y perception_snapshot_rows',
    () async {
      final file = File('${tempDir.path}/save_v7.db');
      final rawDb = raw.sqlite3.open(file.path);
      for (final ddl in _schemaV1) {
        rawDb.execute(ddl);
      }
      rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
      );
      rawDb.execute(
        'CREATE TABLE person_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
      rawDb.execute('PRAGMA user_version = 7');
      rawDb.dispose();

      final database = SaveDatabase(NativeDatabase(file));
      addTearDown(database.close);

      final version = await database
          .customSelect('PRAGMA user_version')
          .getSingle();
      expect(version.data.values.first, 16);

      final tables = await database
          .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
          .get();
      expect([
        for (final row in tables) row.data.values.first,
      ], containsAll(['agent_mind_rows', 'perception_snapshot_rows']));
    },
  );

  test('una base de datos v8 migra a v14 con perception_snapshot_rows', () async {
    final file = File('${tempDir.path}/save_v8.db');
    final rawDb = raw.sqlite3.open(file.path);
    for (final ddl in _schemaV1) {
      rawDb.execute(ddl);
    }
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;');
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
    );
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
    );
    rawDb.execute(
      'CREATE TABLE person_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
    rawDb.execute(
      'CREATE TABLE agent_mind_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'agent_mind_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('PRAGMA user_version = 8');
    rawDb.dispose();

    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    final tables = await database
        .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
        .get();
    expect([
      for (final row in tables) row.data.values.first,
    ], containsAll(['perception_snapshot_rows', 'memory_collection_rows']));
  });

  test('una base de datos v9 migra a v14 con memory_collection_rows', () async {
    final file = File('${tempDir.path}/save_v9.db');
    final rawDb = raw.sqlite3.open(file.path);
    for (final ddl in _schemaV1) {
      rawDb.execute(ddl);
    }
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;');
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
    );
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
    );
    rawDb.execute(
      'CREATE TABLE person_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
    rawDb.execute(
      'CREATE TABLE agent_mind_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'agent_mind_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE perception_snapshot_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, observer_id TEXT NOT NULL, '
      'snapshot_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, observer_id));',
    );
    rawDb.execute('PRAGMA user_version = 9');
    rawDb.dispose();

    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    final tables = await database
        .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
        .get();
    expect(
      [for (final row in tables) row.data.values.first],
      containsAll([
        'memory_collection_rows',
        'relation_rows',
        'interpretation_rows',
        'belief_rows',
      ]),
    );
  });

  test('una base de datos v10 migra a v14 con relation_rows', () async {
    final file = File('${tempDir.path}/save_v10.db');
    final rawDb = raw.sqlite3.open(file.path);
    for (final ddl in _schemaV1) {
      rawDb.execute(ddl);
    }
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;');
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
    );
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
    );
    rawDb.execute(
      'CREATE TABLE person_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
    rawDb.execute(
      'CREATE TABLE agent_mind_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'agent_mind_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE perception_snapshot_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, observer_id TEXT NOT NULL, '
      'snapshot_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, observer_id));',
    );
    rawDb.execute(
      'CREATE TABLE memory_collection_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'memory_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('PRAGMA user_version = 10');
    rawDb.dispose();

    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    final tables = await database
        .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
        .get();
    expect([
      for (final row in tables) row.data.values.first,
    ], containsAll(['relation_rows', 'interpretation_rows', 'belief_rows']));
  });

  test('una base de datos v11 migra a v14 con interpretation_rows', () async {
    final file = File('${tempDir.path}/save_v11.db');
    final rawDb = raw.sqlite3.open(file.path);
    for (final ddl in _schemaV1) {
      rawDb.execute(ddl);
    }
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;');
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
    );
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
    );
    rawDb.execute(
      'CREATE TABLE person_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
    rawDb.execute(
      'CREATE TABLE agent_mind_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'agent_mind_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE perception_snapshot_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, observer_id TEXT NOT NULL, '
      'snapshot_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, observer_id));',
    );
    rawDb.execute(
      'CREATE TABLE memory_collection_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'memory_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE relation_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'relation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('PRAGMA user_version = 11');
    rawDb.dispose();

    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    final tables = await database
        .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
        .get();
    expect([
      for (final row in tables) row.data.values.first,
    ], containsAll(['interpretation_rows', 'belief_rows']));
  });

  test('una base de datos v12 migra a v13 con belief_rows', () async {
    final file = File('${tempDir.path}/save_v12.db');
    final rawDb = raw.sqlite3.open(file.path);
    for (final ddl in _schemaV1) {
      rawDb.execute(ddl);
    }
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;');
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
    );
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
    );
    rawDb.execute(
      'CREATE TABLE person_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
    rawDb.execute(
      'CREATE TABLE agent_mind_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'agent_mind_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE perception_snapshot_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, observer_id TEXT NOT NULL, '
      'snapshot_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, observer_id));',
    );
    rawDb.execute(
      'CREATE TABLE memory_collection_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'memory_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE relation_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'relation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE interpretation_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'interpretation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('PRAGMA user_version = 12');
    rawDb.dispose();

    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    final tables = await database
        .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
        .get();
    expect([
      for (final row in tables) row.data.values.first,
    ], contains('belief_rows'));
  });

  test('una base de datos v13 migra a v14 con goal_rows', () async {
    final file = File('${tempDir.path}/save_v13.db');
    final rawDb = raw.sqlite3.open(file.path);
    for (final ddl in _schemaV1) {
      rawDb.execute(ddl);
    }
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;');
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
    );
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
    );
    rawDb.execute(
      'CREATE TABLE person_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
    rawDb.execute(
      'CREATE TABLE agent_mind_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'agent_mind_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE perception_snapshot_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, observer_id TEXT NOT NULL, '
      'snapshot_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, observer_id));',
    );
    rawDb.execute(
      'CREATE TABLE memory_collection_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'memory_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE relation_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'relation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE interpretation_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'interpretation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE belief_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'belief_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('PRAGMA user_version = 13');
    rawDb.dispose();

    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    final tables = await database
        .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
        .get();
    expect([
      for (final row in tables) row.data.values.first,
    ], contains('goal_rows'));
  });

  test('una base de datos v14 migra a v15 con priority_rows e intention_rows', () async {
    final file = File('${tempDir.path}/save_v14.db');
    final rawDb = raw.sqlite3.open(file.path);
    for (final ddl in _schemaV1) {
      rawDb.execute(ddl);
    }
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;');
    rawDb.execute('ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;');
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
    );
    rawDb.execute(
      'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
    );
    rawDb.execute(
      'CREATE TABLE person_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
    rawDb.execute(
      'CREATE TABLE agent_mind_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'agent_mind_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE perception_snapshot_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, observer_id TEXT NOT NULL, '
      'snapshot_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, observer_id));',
    );
    rawDb.execute(
      'CREATE TABLE memory_collection_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'memory_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE relation_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'relation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE interpretation_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'interpretation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE belief_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'belief_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute(
      'CREATE TABLE goal_rows ('
      'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
      'goal_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
      'PRIMARY KEY (save_id, slot, person_id));',
    );
    rawDb.execute('PRAGMA user_version = 14');
    rawDb.dispose();

    final database = SaveDatabase(NativeDatabase(file));
    addTearDown(database.close);

    final version = await database
        .customSelect('PRAGMA user_version')
        .getSingle();
    expect(version.data.values.first, 16);

    final tables = await database
        .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
        .get();
    expect([
      for (final row in tables) row.data.values.first,
    ], containsAll(['priority_rows', 'intention_rows']));
  });

  test(
    'una base de datos v15 migra a v16 con decision_rows y decision_record_rows',
    () async {
      final file = File('${tempDir.path}/save_v15.db');
      final rawDb = raw.sqlite3.open(file.path);
      for (final ddl in _schemaV1) {
        rawDb.execute(ddl);
      }
      rawDb.execute('ALTER TABLE campaigns ADD COLUMN player_club_id TEXT;');
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN player_lineup_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN market_overlay_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN last_finances_json TEXT;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN last_training_round INTEGER;',
      );
      rawDb.execute(
        'ALTER TABLE campaigns ADD COLUMN manager_decisions_json TEXT;',
      );
      rawDb.execute(
        'CREATE TABLE person_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'person_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute('ALTER TABLE player_rows ADD COLUMN person_id TEXT;');
      rawDb.execute(
        'CREATE TABLE agent_mind_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'agent_mind_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute(
        'CREATE TABLE perception_snapshot_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, observer_id TEXT NOT NULL, '
        'snapshot_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, observer_id));',
      );
      rawDb.execute(
        'CREATE TABLE memory_collection_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'memory_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute(
        'CREATE TABLE relation_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'relation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute(
        'CREATE TABLE interpretation_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'interpretation_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute(
        'CREATE TABLE belief_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'belief_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute(
        'CREATE TABLE goal_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'goal_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute(
        'CREATE TABLE priority_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'priority_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute(
        'CREATE TABLE intention_rows ('
        'save_id INTEGER NOT NULL, slot INTEGER NOT NULL, person_id TEXT NOT NULL, '
        'intention_json TEXT NOT NULL, sort_order INTEGER NOT NULL, '
        'PRIMARY KEY (save_id, slot, person_id));',
      );
      rawDb.execute('PRAGMA user_version = 15');
      rawDb.dispose();

      final database = SaveDatabase(NativeDatabase(file));
      addTearDown(database.close);

      final version = await database
          .customSelect('PRAGMA user_version')
          .getSingle();
      expect(version.data.values.first, 16);

      final tables = await database
          .customSelect("SELECT name FROM sqlite_master WHERE type = 'table'")
          .get();
      expect([
        for (final row in tables) row.data.values.first,
      ], containsAll(['decision_rows', 'decision_record_rows']));
    },
  );
}
