@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/person/person_codec.dart';
import 'package:kickdynasty_persistence/src/repository/person_repository.dart';
import 'package:test/test.dart';

void main() {
  group('PersonCodec', () {
    test('roundtrip lista de personas', () {
      final person = Person(
        id: PersonId('person-codec-1'),
        firstName: DisplayName('Ana'),
        lastName: DisplayName('Lopez'),
        birthDate: BirthDate(year: 1990, month: 3, day: 8),
        nationality: CountryCode('ES'),
        primaryLanguage: 'es',
        gender: PersonGender.female,
        origin: PersonOrigin(
          country: CountryCode('ES'),
          city: 'Madrid',
          generation: 1,
          economicContext: 'middle',
          appearanceYear: 2024,
          cohort: 'codec',
          derivedWorldSeed: 1,
          birthContextHash: 99,
        ),
        personality: PersonalityProfile(
          ambition: TraitScore(40),
          patience: TraitScore(41),
          prudence: TraitScore(42),
          aggressiveness: TraitScore(43),
          pride: TraitScore(44),
          ego: TraitScore(45),
          professionalism: TraitScore(46),
          empathy: TraitScore(47),
          emotionalStability: TraitScore(48),
          leadership: TraitScore(49),
          memoryTrait: TraitScore(50),
          pressureTolerance: TraitScore(51),
        ),
        values: PersonValues(
          loyalty: TraitScore(50),
          meritocracy: TraitScore(51),
          family: TraitScore(52),
          prestige: TraitScore(53),
          security: TraitScore(54),
        ),
        philosophy: PersonPhilosophy(
          pragmatism: TraitScore(55),
          youthFocus: TraitScore(56),
          attackingStyle: TraitScore(57),
          financialPrudence: TraitScore(58),
          institutionalLoyalty: TraitScore(59),
        ),
        competencies: GeneralCompetencies(
          intelligence: TraitScore(60),
          negotiation: TraitScore(61),
          analysis: TraitScore(62),
          communication: TraitScore(63),
          adaptability: TraitScore(64),
        ),
        traits: PermanentTraits(
          charisma: TraitScore(65),
          workEthic: TraitScore(66),
          resilience: TraitScore(67),
          creativity: TraitScore(68),
          discipline: TraitScore(69),
        ),
        cognitivePotential: TraitScore(70),
        initialReputation: Rating(60),
        role: PersonRole.president,
      );

      final encoded = encodePersonList([person]);
      final decoded = decodePersonList(encoded);
      expect(decoded, [person]);
    });
  });

  group('PersonRepository', () {
    late SaveDatabase database;
    late PersonRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = PersonRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar personas', () async {
      final person = Person(
        id: PersonId('person-repo-1'),
        firstName: DisplayName('Luis'),
        lastName: DisplayName('Garcia'),
        birthDate: BirthDate(year: 1988, month: 1, day: 2),
        nationality: CountryCode('ES'),
        primaryLanguage: 'es',
        gender: PersonGender.male,
        origin: PersonOrigin(
          country: CountryCode('ES'),
          city: 'Sevilla',
          generation: 1,
          economicContext: 'humble',
          appearanceYear: 2023,
          cohort: 'repo',
          derivedWorldSeed: 5,
          birthContextHash: 12,
        ),
        personality: PersonalityProfile(
          ambition: TraitScore(10),
          patience: TraitScore(11),
          prudence: TraitScore(12),
          aggressiveness: TraitScore(13),
          pride: TraitScore(14),
          ego: TraitScore(15),
          professionalism: TraitScore(16),
          empathy: TraitScore(17),
          emotionalStability: TraitScore(18),
          leadership: TraitScore(19),
          memoryTrait: TraitScore(20),
          pressureTolerance: TraitScore(21),
        ),
        values: PersonValues(
          loyalty: TraitScore(22),
          meritocracy: TraitScore(23),
          family: TraitScore(24),
          prestige: TraitScore(25),
          security: TraitScore(26),
        ),
        philosophy: PersonPhilosophy(
          pragmatism: TraitScore(27),
          youthFocus: TraitScore(28),
          attackingStyle: TraitScore(29),
          financialPrudence: TraitScore(30),
          institutionalLoyalty: TraitScore(31),
        ),
        competencies: GeneralCompetencies(
          intelligence: TraitScore(32),
          negotiation: TraitScore(33),
          analysis: TraitScore(34),
          communication: TraitScore(35),
          adaptability: TraitScore(36),
        ),
        traits: PermanentTraits(
          charisma: TraitScore(37),
          workEthic: TraitScore(38),
          resilience: TraitScore(39),
          creativity: TraitScore(40),
          discipline: TraitScore(41),
        ),
        cognitivePotential: TraitScore(42),
        initialReputation: Rating(50),
        role: PersonRole.manager,
      );

      await repository.saveAll(saveId: 1, slot: 0, persons: [person]);
      final loaded = await repository.list(saveId: 1, slot: 0);
      expect(loaded, [person]);
      expect(await repository.get(saveId: 1, slot: 0, id: person.id), person);
    });
  });
}
