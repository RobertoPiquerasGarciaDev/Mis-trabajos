/// Estados de campaña realistas para los tests de persistencia.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

/// Construye un estado de campaña completo simulando una temporada entera
/// con el motor real: mundo de 2 ligas × 20 clubes, 760 resultados con sus
/// eventos y estadísticas de más de mil jugadores.
CampaignState fullSeasonCampaign({int seed = 11, bool withPlayerClub = true}) {
  final world = WorldGenerator().generate(seed: seed);
  final simulator = SeasonSimulator();
  final outcome = simulator.simulateSeason(world: world, season: 1, seed: seed);

  final endWorld = GeneratedWorld(
    seed: world.seed,
    leagues: [
      for (final league in outcome.leagues)
        GeneratedLeague(
          league: league.league,
          level: league.level,
          clubs: league.clubs,
        ),
    ],
  );

  return CampaignState(
    world: endWorld,
    season: 1,
    nextRound: 39,
    fixtures: [for (final league in outcome.leagues) ...league.fixtures],
    results: {for (final league in outcome.leagues) ...league.results},
    stats: outcome.playerStats,
    playerClubId: withPlayerClub
        ? outcome.leagues.first.clubs.first.club.id
        : null,
  );
}

/// Estado recién creado: mundo virgen, calendario programado, nada jugado.
CampaignState freshCampaign({int seed = 5}) {
  final world = WorldGenerator().generate(seed: seed);
  const scheduler = FixtureScheduler();
  final fixtures = <Fixture>[];
  for (var li = 0; li < world.leagues.length; li++) {
    fixtures.addAll(
      scheduler.schedule(
        league: world.leagues[li].league,
        season: 1,
        rng: Xoshiro256StarStar.fromSeed(derivedSeed(seed, li)),
      ),
    );
  }
  return CampaignState(
    world: world,
    season: 1,
    nextRound: 1,
    fixtures: fixtures,
    results: const {},
    stats: const {},
  );
}

/// Igualdad profunda entre dos estados de campaña, campo a campo.
///
/// `GeneratedWorld` y `CampaignState` no definen `==` (son agregados, no
/// value objects); la igualdad se verifica pieza a pieza apoyándose en el
/// `==` de las entidades del dominio.
void expectCampaignEquals(CampaignState actual, CampaignState expected) {
  expect(actual.season, expected.season);
  expect(actual.nextRound, expected.nextRound);
  expect(actual.playerClubId, expected.playerClubId);
  expect(actual.world.seed, expected.world.seed);

  expect(actual.world.leagues.length, expected.world.leagues.length);
  for (var li = 0; li < expected.world.leagues.length; li++) {
    final actualLeague = actual.world.leagues[li];
    final expectedLeague = expected.world.leagues[li];
    expect(actualLeague.league, expectedLeague.league);
    expect(actualLeague.level, expectedLeague.level);
    expect(actualLeague.clubs.length, expectedLeague.clubs.length);
    for (var ci = 0; ci < expectedLeague.clubs.length; ci++) {
      final actualClub = actualLeague.clubs[ci];
      final expectedClub = expectedLeague.clubs[ci];
      expect(actualClub.club, expectedClub.club);
      expect(actualClub.squad.clubId, expectedClub.squad.clubId);
      expect(actualClub.squad.players, expectedClub.squad.players);
      expect(actualClub.contracts, expectedClub.contracts);
    }
  }

  expect(actual.fixtures, expected.fixtures);

  expect(actual.results.length, expected.results.length);
  for (final entry in expected.results.entries) {
    expect(actual.results[entry.key], entry.value, reason: entry.key.value);
  }

  expect(actual.stats.length, expected.stats.length);
  for (final entry in expected.stats.entries) {
    final actualStats = actual.stats[entry.key];
    expect(actualStats, isNotNull, reason: entry.key.value);
    expect(actualStats!.playerId, entry.value.playerId);
    expect(actualStats.appearances, entry.value.appearances);
    expect(actualStats.goals, entry.value.goals);
    expect(actualStats.assists, entry.value.assists);
    expect(actualStats.yellowCards, entry.value.yellowCards);
    expect(actualStats.redCards, entry.value.redCards);
    expect(actualStats.averageRating, entry.value.averageRating);
  }
}
