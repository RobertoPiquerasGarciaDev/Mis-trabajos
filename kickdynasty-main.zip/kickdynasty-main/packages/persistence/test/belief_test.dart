@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/belief_codec.dart';
import 'package:kickdynasty_persistence/src/repository/belief_repository.dart';
import 'package:test/test.dart';

BeliefState _sampleState() => BeliefState(
  collection: BeliefCollection(
    ownerId: PersonId('person-belief-persist'),
    entries: [
      BeliefEntry(
        id: BeliefId('belief-persist-1'),
        observerPersonId: PersonId('person-belief-persist'),
        type: BeliefType.protection,
        category: BeliefCategory.self,
        summary: 'Creo que mi entrenador me protege',
        confidence: BeliefConfidence(0.66),
        strength: BeliefStrength(0.44),
        origin: BeliefOrigin.isolatedInterpretation,
        sourceInterpretationIds: [InterpretationId('interpret-persist-1')],
        createdAt: const MemoryTimestamp(season: 1, week: 2),
        updatedAt: const MemoryTimestamp(season: 1, week: 2),
        lastConfirmed: const MemoryTimestamp(season: 1, week: 2),
        contradictoryBeliefIds: const [],
      ),
    ],
  ),
);

void main() {
  group('BeliefCodec', () {
    test('roundtrip JSON', () {
      final state = _sampleState();
      expect(decodeBeliefState(encodeBeliefState(state)), state);
    });

    test('roundtrip lista', () {
      final states = [_sampleState()];
      expect(decodeBeliefStateList(encodeBeliefStateList(states)), states);
    });
  });

  group('BeliefRepository', () {
    late SaveDatabase database;
    late BeliefRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = BeliefRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar creencias', () async {
      final state = _sampleState();
      await repository.saveAll(saveId: 1, slot: 0, states: [state]);
      expect(await repository.list(saveId: 1, slot: 0), [state]);
      expect(
        await repository.get(
          saveId: 1,
          slot: 0,
          personId: state.collection.ownerId!,
        ),
        state,
      );
    });
  });
}
