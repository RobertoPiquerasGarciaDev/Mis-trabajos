@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/memory_codec.dart';
import 'package:kickdynasty_persistence/src/repository/memory_repository.dart';
import 'package:test/test.dart';

MemoryCollection _sampleCollection() => MemoryCollection(
  ownerId: PersonId('person-mem-persist-1'),
  entries: [
    MemoryEntry(
      id: MemoryId('memory-persist-1'),
      ownerId: PersonId('person-mem-persist-1'),
      type: MemoryType.perceivedFact,
      whatHappened: 'club.name=FC Test',
      subjectId: 'club-1',
      involvedPersonIds: const [],
      perceivedAt: const MemoryTimestamp(season: 1, week: 1),
      source: PerceptionSource.directObservation,
      origin: KnowledgeOrigin.public,
      confidenceAtCapture: PerceptionConfidence(0.7),
      importance: MemoryImportance(0.5),
      strength: MemoryStrength(0.7),
      decay: MemoryDecay.initial,
      factKey: 'club.name',
      perceivedValue: 'FC Test',
    ),
  ],
);

void main() {
  group('MemoryCodec', () {
    test('roundtrip JSON', () {
      final collection = _sampleCollection();
      expect(
        decodeMemoryCollection(encodeMemoryCollection(collection)),
        collection,
      );
    });
  });

  group('MemoryRepository', () {
    late SaveDatabase database;
    late MemoryRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = MemoryRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar colecciones', () async {
      final collection = _sampleCollection();
      await repository.saveAll(saveId: 1, slot: 0, collections: [collection]);
      expect(await repository.list(saveId: 1, slot: 0), [collection]);
      expect(
        await repository.get(saveId: 1, slot: 0, personId: collection.ownerId!),
        collection,
      );
    });
  });
}
