@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/agent_mind_codec.dart';
import 'package:kickdynasty_persistence/src/repository/agent_mind_repository.dart';
import 'package:test/test.dart';

AgentMind _sampleMind() {
  final trait = TraitScore(40);
  return AgentMind(
    personId: PersonId('person-am-1'),
    personality: PersonalitySnapshot(
      profile: PersonalityProfile(
        ambition: trait,
        patience: trait,
        prudence: trait,
        aggressiveness: trait,
        pride: trait,
        ego: trait,
        professionalism: trait,
        empathy: trait,
        emotionalStability: trait,
        leadership: trait,
        memoryTrait: trait,
        pressureTolerance: trait,
      ),
    ),
    memory: const MemoryState.empty(),
    beliefs: const BeliefState.empty(),
    goals: const GoalState.empty(),
    priorities: const PriorityState.empty(),
    intentions: const IntentionState.empty(),
    decisions: const DecisionState.empty(),
    perception: const PerceptionState.empty(),
    relations: const RelationState.empty(),
    interpretation: const InterpretationState.empty(),
    emotion: EmotionalState.initial,
    learning: LearningState.initial,
  );
}

void main() {
  group('AgentMindCodec', () {
    test('roundtrip JSON', () {
      final mind = _sampleMind();
      final decoded = AgentMind.fromJson(
        decodeAgentMind(encodeAgentMind(mind)).toJson(),
      );
      expect(decoded, mind);
    });
  });

  group('AgentMindRepository', () {
    late SaveDatabase database;
    late AgentMindRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = AgentMindRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar mentes', () async {
      final mind = _sampleMind();
      await repository.saveAll(saveId: 1, slot: 0, minds: [mind]);
      expect(await repository.list(saveId: 1, slot: 0), [mind]);
      expect(
        await repository.get(saveId: 1, slot: 0, personId: mind.personId),
        mind,
      );
    });
  });
}
