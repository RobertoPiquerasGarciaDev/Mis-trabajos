@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/intention_codec.dart';
import 'package:kickdynasty_persistence/src/repository/intention_repository.dart';
import 'package:test/test.dart';

IntentionState _sampleState() => IntentionState(
  collection: IntentionCollection(
    ownerId: PersonId('person-intention-persist'),
    entries: [
      IntentionEntry(
        id: IntentionId('intention-persist-1'),
        observerPersonId: PersonId('person-intention-persist'),
        sourcePriorityId: PriorityId('priority-persist-1'),
        type: IntentionType.wantToMaintainTrust,
        summary: 'Quiero mantener la confianza que percibo',
        strength: IntentionStrength(0.55),
        status: IntentionStatus.active,
        createdAt: const MemoryTimestamp(season: 1, week: 2),
        updatedAt: const MemoryTimestamp(season: 1, week: 2),
      ),
    ],
  ),
);

void main() {
  group('IntentionCodec', () {
    test('roundtrip JSON', () {
      final state = _sampleState();
      expect(decodeIntentionState(encodeIntentionState(state)), state);
    });

    test('roundtrip lista', () {
      final states = [_sampleState()];
      expect(
        decodeIntentionStateList(encodeIntentionStateList(states)),
        states,
      );
    });
  });

  group('IntentionRepository', () {
    late SaveDatabase database;
    late IntentionRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = IntentionRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar intenciones', () async {
      final state = _sampleState();
      await repository.saveAll(saveId: 1, slot: 0, states: [state]);
      expect(await repository.list(saveId: 1, slot: 0), [state]);
      expect(
        await repository.get(
          saveId: 1,
          slot: 0,
          personId: state.collection.ownerId!,
        ),
        state,
      );
    });
  });
}
