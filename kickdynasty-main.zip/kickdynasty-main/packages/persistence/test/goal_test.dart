@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/goal_codec.dart';
import 'package:kickdynasty_persistence/src/repository/goal_repository.dart';
import 'package:test/test.dart';

GoalState _sampleState() => GoalState(
  collection: GoalCollection(
    ownerId: PersonId('person-goal-persist'),
    entries: [
      GoalEntry(
        id: GoalId('goal-persist-1'),
        observerPersonId: PersonId('person-goal-persist'),
        type: GoalType.seekProtection,
        category: GoalCategory.personal,
        summary: 'Quiero sentirme protegido en mi entorno',
        priority: GoalPriority(0.66),
        strength: GoalStrength(0.44),
        origin: GoalOrigin.beliefDerived,
        status: GoalStatus.active,
        timeHorizon: GoalTimeHorizon.shortTerm,
        sourceBeliefIds: [BeliefId('belief-persist-1')],
        createdAt: const MemoryTimestamp(season: 1, week: 2),
        updatedAt: const MemoryTimestamp(season: 1, week: 2),
        lastReviewed: const MemoryTimestamp(season: 1, week: 2),
      ),
    ],
  ),
);

void main() {
  group('GoalCodec', () {
    test('roundtrip JSON', () {
      final state = _sampleState();
      expect(decodeGoalState(encodeGoalState(state)), state);
    });

    test('roundtrip lista', () {
      final states = [_sampleState()];
      expect(decodeGoalStateList(encodeGoalStateList(states)), states);
    });
  });

  group('GoalRepository', () {
    late SaveDatabase database;
    late GoalRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = GoalRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar objetivos', () async {
      final state = _sampleState();
      await repository.saveAll(saveId: 1, slot: 0, states: [state]);
      expect(await repository.list(saveId: 1, slot: 0), [state]);
      expect(
        await repository.get(
          saveId: 1,
          slot: 0,
          personId: state.collection.ownerId!,
        ),
        state,
      );
    });
  });
}
