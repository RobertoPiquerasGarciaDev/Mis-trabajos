@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/relation_codec.dart';
import 'package:kickdynasty_persistence/src/repository/relation_repository.dart';
import 'package:test/test.dart';

RelationState _sampleState() => RelationState(
  observerId: PersonId('person-rel-persist'),
  entries: [
    RelationEntry(
      observerPersonId: PersonId('person-rel-persist'),
      targetPersonId: PersonId('person-rel-target'),
      type: RelationType.president,
      trust: RelationTrust(0.2),
      respect: RelationRespect(0.8),
      affinity: RelationAffinity(0.4),
      confidence: RelationConfidence(0.65),
      strength: RelationStrength(0.5),
      history: const RelationHistory.empty(),
      knownSince: const MemoryTimestamp(season: 1, week: 2),
      lastInteraction: null,
      origin: RelationOrigin.structural,
      tags: const [RelationTag.staffHierarchy],
    ),
  ],
);

void main() {
  group('RelationCodec', () {
    test('roundtrip JSON', () {
      final state = _sampleState();
      expect(decodeRelationState(encodeRelationState(state)), state);
    });
  });

  group('RelationRepository', () {
    late SaveDatabase database;
    late RelationRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = RelationRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar relaciones', () async {
      final state = _sampleState();
      await repository.saveAll(saveId: 1, slot: 0, states: [state]);
      expect(await repository.list(saveId: 1, slot: 0), [state]);
      expect(
        await repository.get(saveId: 1, slot: 0, personId: state.observerId!),
        state,
      );
    });
  });
}
