@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/perception_snapshot_codec.dart';
import 'package:kickdynasty_persistence/src/repository/perception_snapshot_repository.dart';
import 'package:test/test.dart';

PerceptionSnapshot _sampleSnapshot() => PerceptionSnapshot(
  observerId: PersonId('person-perc-1'),
  season: 1,
  week: 2,
  facts: [
    PerceivedFact(
      subjectId: 'player-1',
      factKey: 'player.name',
      value: 'Test Player',
      source: PerceptionSource.directObservation,
      confidence: PerceptionConfidence(0.75),
      age: PerceptionAge.fresh,
      visibility: VisibilityLevel.full,
      quality: ObservationQuality(TraitScore(65)),
      origin: KnowledgeOrigin.self,
    ),
  ],
  availableSources: [PerceptionSource.directObservation],
);

void main() {
  group('PerceptionSnapshotCodec', () {
    test('roundtrip JSON', () {
      final snapshot = _sampleSnapshot();
      final decoded = decodePerceptionSnapshot(
        encodePerceptionSnapshot(snapshot),
      );
      expect(decoded, snapshot);
    });
  });

  group('PerceptionSnapshotRepository', () {
    late SaveDatabase database;
    late PerceptionSnapshotRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = PerceptionSnapshotRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar snapshots', () async {
      final snapshot = _sampleSnapshot();
      await repository.saveAll(saveId: 1, slot: 0, snapshots: [snapshot]);
      expect(await repository.list(saveId: 1, slot: 0), [snapshot]);
      expect(
        await repository.get(
          saveId: 1,
          slot: 0,
          observerId: snapshot.observerId,
        ),
        snapshot,
      );
    });
  });
}
