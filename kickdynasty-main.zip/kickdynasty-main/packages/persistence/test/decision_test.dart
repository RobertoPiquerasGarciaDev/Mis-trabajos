@Tags(['people-first'])
import 'package:drift/native.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_persistence/src/database/save_database.dart';
import 'package:kickdynasty_persistence/src/intelligence/decision_codec.dart';
import 'package:kickdynasty_persistence/src/intelligence/decision_record_codec.dart';
import 'package:kickdynasty_persistence/src/repository/decision_record_repository.dart';
import 'package:kickdynasty_persistence/src/repository/decision_repository.dart';
import 'package:test/test.dart';

DecisionState _sampleState() => DecisionState(
  collection: DecisionCollection(
    ownerId: PersonId('person-decision-persist'),
    entries: [
      DecisionEntry(
        id: DecisionId('decision-persist-1'),
        observerPersonId: PersonId('person-decision-persist'),
        sourceIntentionId: IntentionId('intention-persist-1'),
        type: DecisionType.unilateral,
        origin: DecisionOrigin.internalConsolidation,
        status: DecisionStatus.committed,
        summary: 'Me comprometo con mi postura',
        rationale: 'Tras sopesar internamente',
        strength: DecisionStrength(0.6),
        sourcePriorityIds: [PriorityId('priority-persist-1')],
        rejectedAlternatives: const [],
        unknownsAcknowledged: const ['No conozco todas las consecuencias'],
        createdAt: const MemoryTimestamp(season: 1, week: 2),
        updatedAt: const MemoryTimestamp(season: 1, week: 2),
      ),
    ],
  ),
);

DecisionRecord _sampleRecord() => DecisionRecord(
  id: 'dr-persist-1',
  protocolType: DeliberationProtocolType.transferOutDeliberation,
  clubId: ClubId('club-persist'),
  season: 1,
  week: 2,
  instanceId: 'protocol-persist-1',
  outcome: MandateOutcome.proceed,
  participants: const [],
  proposalSummary: 'Propuesta cognitiva',
);

void main() {
  group('DecisionCodec', () {
    test('roundtrip JSON', () {
      final state = _sampleState();
      expect(decodeDecisionState(encodeDecisionState(state)), state);
    });

    test('roundtrip lista', () {
      final states = [_sampleState()];
      expect(decodeDecisionStateList(encodeDecisionStateList(states)), states);
    });
  });

  group('DecisionRecordCodec', () {
    test('roundtrip JSON', () {
      final record = _sampleRecord();
      expect(decodeDecisionRecord(encodeDecisionRecord(record)), record);
    });

    test('roundtrip lista', () {
      final records = [_sampleRecord()];
      expect(
        decodeDecisionRecordList(encodeDecisionRecordList(records)),
        records,
      );
    });
  });

  group('DecisionRepository', () {
    late SaveDatabase database;
    late DecisionRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = DecisionRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar decisiones', () async {
      final state = _sampleState();
      await repository.saveAll(saveId: 1, slot: 0, states: [state]);
      expect(await repository.list(saveId: 1, slot: 0), [state]);
      expect(
        await repository.get(
          saveId: 1,
          slot: 0,
          personId: state.collection.ownerId!,
        ),
        state,
      );
    });
  });

  group('DecisionRecordRepository', () {
    late SaveDatabase database;
    late DecisionRecordRepository repository;

    setUp(() {
      database = SaveDatabase(NativeDatabase.memory());
      repository = DecisionRecordRepository(database);
    });

    tearDown(() async => database.close());

    test('guardar y listar registros', () async {
      final record = _sampleRecord();
      await repository.saveAll(saveId: 1, slot: 0, records: [record]);
      expect(await repository.list(saveId: 1, slot: 0), [record]);
      expect(
        await repository.get(saveId: 1, slot: 0, recordId: record.id),
        record,
      );
    });
  });
}
