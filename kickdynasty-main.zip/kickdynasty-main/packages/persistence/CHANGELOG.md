# Changelog

## 0.3.0 — 2026-07-07

### Added

- Columna `campaigns.manager_decisions_json` (esquema v6) para cola de
  decisiones del manager humano.

## 0.2.0

Fase 5 — Persistencia.

- Esquema Drift normalizado de 11 tablas claveadas por `(save_id, slot)`:
  slot 0 = estado vivo, slots ≥ 1 = snapshots por jornada.
- `SaveDatabase` con esquema versionado (v2) y migración v1→v2 explícita
  (columna `campaigns.player_club_id` + tabla `snapshots`), testeada sobre
  una base de datos real fabricada en formato v1.
- `SaveRepository`: crear/sobrescribir/cargar/listar/borrar guardados y
  snapshots con retención configurable; escrituras transaccionales; reloj
  inyectable para tests.
- Roundtrip sin pérdida verificado con igualdad profunda campo a campo
  sobre una temporada completa simulada por el motor real.

## 0.1.0

- Esqueleto del paquete (Fase 0).
