# Changelog — kickdynasty_engine

## Unreleased — Simulation Deepening

- `selectionReadinessFactor`: disponibilidad pre-partido alineada con forma,
  moral y lesión (`team_strength.dart`).
- `LineupSelector`: usa la misma lógica de condición que el simulador; rota
  jugadores lesionados (fitness ≤ umbral de `ConditionCycle`).
- Suite de estrés multi-temporada (50/100 T) con detección de anomalías
  (`season_stress_test.dart`).
- Iteración ciclo de vida: `PlayerGenerator.sampleYouthIngressAge` alinea
  edad de regens con `WorldGenConfig.ageBuckets` (≤24); auditoría de
  retiros/regens en `SeasonAdvanceResult`; suite `ecosystem_lifecycle_test`
  (20–200 T, tag `lifecycle`).
- Iteración pirámide del talento: `talent_pyramid_runner.dart` + tests
  50–500 T (tag `pyramid`); distribución OVR, flujo, movilidad y permanencia
  en élite.
- Iteración desarrollo por potencial: `PotentialDevelopmentModel`,
  `potential_development.dart`, minutos al cierre de temporada, prospectos/
  extraordinarios/cohortes PA en generación.

## 0.5.0

- `SeasonSimulator.bootstrapCampaign`: estado inicial con calendario programado.
- `SeasonSimulator.playRound`: juega una jornada sobre `CampaignState` con
  las mismas semillas que `simulateSeason` (equivalencia testeada).
- `SeasonSimulator.tableFor`: clasificación parcial o final de una liga.
- `RoundOutcome` / `CampaignPlayResult`: desglose de la jornada disputada.

## 0.4.0

- `CampaignState`: agregado inmutable de partida en curso (mundo actual +
  temporada + calendario + resultados + estadísticas + club del jugador).
  Es la unidad que persiste `kickdynasty_persistence` y sobre la que la
  capa de aplicación avanzará jornadas (Fase 6).

## 0.3.0

Temporada completa (cierre de la Fase 4 del roadmap).

- `FixtureScheduler`: calendario round-robin a doble vuelta (método del
  círculo) barajado por semilla; vuelta espejada con localía invertida.
- `LeagueTable`: clasificación con desempates (puntos, diferencia, goles,
  mini-liga de enfrentamientos directos por grupo empatado, fallback
  determinista).
- `ConditionCycle`: fatiga post-partido y recuperación semanal parcial
  (presión de rotación), lesionados a físico mínimo, moral por resultados
  y forma por valoración.
- `PlayerDevelopment`: progresión hacia el potencial por edad, declive con
  sesgo físico, retiros probabilísticos y regens 1:1 por posición con
  contrato (`PlayerGenerator` acepta edad fija para canteranos).
- `SeasonSimulator`: temporada completa (recuperación semanal →
  alineaciones automáticas → partidos → efectos) + `advanceSeason` con
  desarrollo, retiros, regens y ascensos/descensos entre niveles.
- `SeasonConfig.standard()`: todo el balance de temporada como datos
  (ADR 0005).
- 21 tests de temporada (propiedades del calendario, desempates,
  ciclo de condición, desarrollo, cierre contable de la tabla, golden de la
  semilla 42) + 7 tests `balance` de estabilidad a 4 temporadas
  encadenadas (población, calidad, edad, goles, rotación, debut de regens).

## 0.2.0

Simulación de partido (cierre de la Fase 3 del roadmap).

- `MatchEngineConfig.standard()`: balance completo del partido como datos
  (ADR 0005) — fuerzas, ocasiones, táctica, disciplina, lesiones, cambios y
  valoraciones — calibrado por la suite estadística.
- Modelo de fuerzas puro (`computeUnitScores`, `positionFactor`): tres
  unidades por equipo con pesos por rol y línea, condición
  (físico/forma/moral), fatiga por minutos, penalización por jugar fuera de
  posición y modificadores tácticos.
- `MatchSimulator`: posesiones minuto a minuto con localía, urgencia por
  marcador, goles con goleador/asistente reales, propia puerta, tarjetas
  (amarilla, doble amarilla, roja), lesiones con cambio forzoso,
  sustituciones de IA por fatiga y valoraciones 4–10 por participante.
- `MatchReport` + `TeamMatchStats`: posesión, disparos, disparos a puerta,
  xG y tarjetas por equipo.
- `TeamSheet` (plantilla + alineación validadas) y `LineupSelector`
  (auto-alineación determinista para IA y simulación de jornadas).
- 20 tests unitarios/propiedades (integridad de eventos sobre 100 partidos,
  golden de la semilla 42) + 12 tests estadísticos `--tags balance` sobre
  más de 10 000 partidos.

## 0.1.0

Generación procedural de mundo (cierre de la Fase 2 del roadmap).

- `Rng`: interfaz de aleatoriedad inyectable con helpers (uniformes, rangos,
  pesos, gaussiana Box–Muller).
- `Xoshiro256StarStar` + `splitMix64`/`derivedSeed`: PRNG determinista de
  producción con flujos independientes por subsistema.
- `WorldGenConfig.standard()`: 2 divisiones × 20 clubes × 26 jugadores;
  todo el balance de generación como datos (ADR 0005).
- `attributeOffsetsByPosition`: perfil de atributos por posición.
- `namePoolsByCountry`: contenido ficticio para ES, GB, DE, FR, IT, PT
  (ADR 0006).
- `WorldGenerator` → `GeneratedWorld`: mundo completo reproducible por
  semilla, con invariantes del dominio garantizados en construcción.
- 33 tests: determinismo del PRNG, propiedades estadísticas de las
  distribuciones y golden de regresión (huella exacta de la semilla 42).
