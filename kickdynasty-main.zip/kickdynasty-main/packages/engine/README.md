# kickdynasty_engine

Motor de simulación determinista de KickDynasty. Dart puro: sin I/O, sin
Flutter, sin reloj de sistema. Depende únicamente de `kickdynasty_domain`.

## Contrato del paquete

- **Determinista** (ADR 0002): toda la aleatoriedad entra por `Rng`,
  inyectado y semiado. Mismo `(input, semilla)` → mismo output, siempre.
  Verificado por tests golden.
- **Balance como datos** (ADR 0005): las constantes del juego viven en
  configuraciones versionadas (`WorldGenConfig`), no en la lógica. Las
  propiedades estadísticas se validan en tests.
- **Contenido ficticio** (ADR 0006): ciudades y clubes inventados; nombres de
  persona comunes de cada idioma sin referencia a personas reales.

> Nota de plataforma: el determinismo se apoya en los enteros de 64 bits de
> la Dart VM (Android, iOS, escritorio, tests). El paquete **no es apto para
> compilación web** (`dart2js`).

## Módulos

### `random` — aleatoriedad inyectable

- `Rng`: interfaz con primitiva `nextBits53()` y helpers derivados
  (`nextInt`, `rangeInt`, `chance`, `pick`, `pickIndexWeighted`, `gaussian`).
- `Xoshiro256StarStar`: implementación de producción (xoshiro256**,
  semiado con SplitMix64).
- `derivedSeed(seed, stream)`: semillas independientes por subsistema. La
  generación de cada club usa su propio flujo: cambiar cuánta aleatoriedad
  consume un club no altera el resto del mundo.

### `config` — balance como datos

- `WorldGenConfig`: ligas, plantilla tipo, distribución de edades, bandas de
  calidad y reputación por nivel, pies, nacionalidades, salarios, contratos,
  tesorería y estadios. `WorldGenConfig.standard()` define el mundo del
  juego: 2 divisiones × 20 clubes.
- `MatchEngineConfig`: todo el balance del partido — modelo de fuerzas
  (pesos por rol y línea, penalizaciones por posición, condición y fatiga),
  ocasiones y conversión, efecto de cada instrucción táctica, disciplina,
  lesiones, reglas de cambio y valoraciones. `MatchEngineConfig.standard()`
  es la calibración validada por la suite `--tags balance`.
- `SeasonConfig`: ciclo de condición entre jornadas (fatiga, recuperación,
  moral, forma), desarrollo al cierre de temporada (progresión, declive,
  retiros, regens) y número de ascensos/descensos.
  `SeasonConfig.standard()` mantiene una población estable a varias
  temporadas (validado por la suite `--tags balance`).
- `attributeOffsetsByPosition`: identidad futbolística de cada posición
  (offsets de cada atributo respecto a la calidad base del jugador).
- `namePoolsByCountry`: pools de nombres por país (ES, GB, DE, FR, IT, PT).

### `worldgen` — generación procedural

- `WorldGenerator.generate(seed:)` → `GeneratedWorld` (ligas → clubes →
  plantillas + contratos). Los invariantes del dominio (`Squad`, `League`)
  se garantizan en construcción: un mundo generado es válido o la
  generación falla.
- `PlayerGenerator`: edad por tramos, calidad por nivel de liga con descuento
  juvenil, atributos = calidad + offset por posición + ruido, potencial
  creciente cuanto más joven, salario geométrico según calidad.
- `ClubGenerator`: identidad única por mundo (nombre, código, estadio) con
  registros de colisiones.

### `match` — simulación de partido

- `MatchSimulator.simulate(fixtureId:, home:, away:, rng:)` → `MatchReport`.
  Modelo de posesiones minuto a minuto: la batalla de mediocampos reparte la
  posesión, cada ocasión enfrenta ataque contra defensa y la definición
  produce eventos con jugadores reales (goleador, asistente con pesos por
  visión/pase, goles en propia puerta).
- Modificadores en juego: táctica completa (mentalidad, tempo, amplitud,
  presión, línea, estilo de pase), condición (físico/forma/moral), fatiga
  acumulada por minutos, jugar fuera de posición, localía, urgencia por
  marcador y expulsiones (jugar con 10 debilita todas las unidades).
- Disciplina y lesiones: amarillas, dobles amarillas (con contención del
  amonestado), rojas directas y lesiones que fuerzan cambios.
- Sustituciones de IA: cambio forzoso por lesión y rotación programada del
  jugador más fatigado, respetando el máximo de cambios.
- `MatchReport`: `MatchResult` coherente por construcción + estadísticas de
  equipo (posesión, disparos, xG, tarjetas) + valoración 4–10 de cada
  participante.
- `TeamSheet`: plantilla + alineación validadas juntas; `LineupSelector`:
  auto-alineación determinista (mejor jugador por puesto × forma/moral/físico,
  rotación de lesionados, banquillo con portero suplente, capitán) para la IA.
- `computeUnitScores` y `positionFactor` son públicos y puros: el modelo de
  fuerzas es testeable sin simular partidos.

### `season` — temporada completa

- `FixtureScheduler`: round-robin a doble vuelta por el método del círculo
  (cada club juega una vez por jornada; la vuelta espeja la ida con la
  localía invertida), barajado por semilla.
- `LeagueTable`: clasificación con desempates — puntos, diferencia, goles a
  favor, mini-liga de enfrentamientos directos entre el grupo empatado
  (resuelta por grupo, no por pares, para evitar intransitividades) y
  fallback determinista.
- `ConditionCycle`: fatiga post-partido, recuperación semanal parcial (la
  presión de rotación nace aquí), desplome del lesionado, moral de
  vestuario por resultados y forma ligada a la valoración.
- `PlayerDevelopment`: progresión hacia el potencial por bandas de edad,
  declive (lo físico decae más rápido), retiros probabilísticos y
  canteranos de reemplazo 1:1 por posición (regens con contrato).
- `SeasonSimulator.simulateSeason(...)` → `SeasonOutcome` (tablas,
  resultados, estadísticas por jugador) y
  `SeasonSimulator.advanceSeason(...)` → mundo de la temporada siguiente
  con desarrollo, retiros, regens y ascensos/descensos.
- `CampaignState`: el agregado de partida en curso (mundo actual +
  calendario + resultados + estadísticas + club del jugador). Es la unidad
  que guarda/carga `kickdynasty_persistence` y sobre la que la capa de
  aplicación avanza jornadas.
- `SeasonSimulator.bootstrapCampaign` / `playRound` / `tableFor`: avance
  jornada a jornada con equivalencia determinista respecto a
  `simulateSeason`.

## Uso

```dart
final world = WorldGenerator().generate(seed: 42);
final clubs = world.leagues.first.clubs;

TeamSheet sheet(GeneratedClub c) =>
    TeamSheet(squad: c.squad, lineup: LineupSelector().select(squad: c.squad));

final report = MatchSimulator().simulate(
  fixtureId: FixtureId('j1-p1'),
  home: sheet(clubs[0]),
  away: sheet(clubs[1]),
  rng: Xoshiro256StarStar.fromSeed(derivedSeed(42, 1)),
);
print('${report.result.homeGoals}-${report.result.awayGoals}');
```

## Tests

```bash
cd packages/engine
dart test --exclude-tags balance   # unitarios + propiedades + goldens
dart test --tags balance           # suite estadística (miles de partidos)
```

La suite `balance` es el contrato de "juego sano": goles por partido en
[2.2, 3.2], localía sin dominar (40–52 % de victorias locales entre
iguales), +15 de calidad gana el 70–92 % de los partidos, disciplina y
lesiones en bandas realistas y efectos tácticos con la dirección correcta.
Cambiar `MatchEngineConfig.standard()` exige mantenerla en verde.

Los tests golden (`worldgen_test.dart`, `match_test.dart`) fijan la huella
exacta de la semilla 42. Si cambian, o es un cambio de balance deliberado
(actualiza la huella y el CHANGELOG) o es una regresión de determinismo.
