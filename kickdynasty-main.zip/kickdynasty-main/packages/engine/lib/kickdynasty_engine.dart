/// Motor de simulación determinista de KickDynasty.
///
/// Todas las funciones del motor tienen la forma
/// `(estado, configuración, rng) → resultado`: sin I/O, sin reloj de sistema
/// y con la aleatoriedad inyectada. Mismo input y semilla producen siempre el
/// mismo output (ADR 0002).
///
/// El balance del juego vive en configuración como datos versionados
/// (ADR 0005) y se valida con la suite estadística `--tags balance`.
///
/// Nota de plataforma: el determinismo se apoya en los enteros de 64 bits de
/// la Dart VM (Android, iOS, escritorio, tests); el paquete no es apto para
/// compilación web.
library;

export 'src/config/attribute_model.dart';
export 'src/config/match_engine_config.dart';
export 'src/config/name_pools.dart';
export 'src/config/potential_development_config.dart';
export 'src/config/season_config.dart';
export 'src/config/world_gen_config.dart';
export 'src/intelligence/agent_mind_factory.dart';
export 'src/intelligence/agent_mind_tick.dart';
export 'src/intelligence/belief_builder.dart';
export 'src/intelligence/belief_consolidator.dart';
export 'src/intelligence/decision_builder.dart';
export 'src/intelligence/deliberation_convocation_selector.dart';
export 'src/intelligence/goal_builder.dart';
export 'src/intelligence/intention_builder.dart';
export 'src/intelligence/internal_deliberation_engine.dart';
export 'src/intelligence/interpretation_builder.dart';
export 'src/intelligence/memory_builder.dart';
export 'src/intelligence/observable_world.dart';
export 'src/intelligence/perception_builder.dart';
export 'src/intelligence/person_club_index.dart';
export 'src/intelligence/priority_builder.dart';
export 'src/intelligence/priority_ranker.dart';
export 'src/intelligence/relation_builder.dart';
export 'src/intelligence/social_deliberation_engine.dart';
export 'src/match/lineup_selector.dart';
export 'src/match/match_report.dart';
export 'src/match/match_simulator.dart';
export 'src/match/team_sheet.dart';
export 'src/match/team_strength.dart';
export 'src/random/rng.dart';
export 'src/random/xoshiro.dart';
export 'src/season/campaign_state.dart';
export 'src/season/condition_cycle.dart';
export 'src/season/fixture_scheduler.dart';
export 'src/season/league_table.dart';
export 'src/season/player_development.dart';
export 'src/season/player_overall.dart';
export 'src/season/potential_development.dart';
export 'src/season/round_outcome.dart';
export 'src/season/season_simulator.dart';
export 'src/worldgen/club_generator.dart';
export 'src/worldgen/name_generator.dart';
export 'src/worldgen/person_generator.dart';
export 'src/worldgen/player_generator.dart';
export 'src/worldgen/world_generator.dart';
