/// Constructor determinista de relaciones desde percepción y memoria (PF-5).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Construye [RelationState] sin interpretar ni acceder a Reality.
final class RelationBuilder {
  /// Crea el builder.
  const RelationBuilder();

  /// Genera relaciones estructurales mínimas para [observer].
  ///
  /// PF-5: solo usa [Person], [PerceptionSnapshot] y [MemoryCollection].
  /// Determinista: mismos inputs → mismo grafo.
  RelationState build({
    required Person observer,
    required List<Person> clubPeers,
    required PerceptionSnapshot? perception,
    required MemoryCollection memory,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final timestamp = MemoryTimestamp(season: season, week: week);
    final rememberedSubjects = {
      for (final entry in memory.entries) entry.subjectId,
    };
    final perceivedSubjects = {
      if (perception != null)
        for (final fact in perception.facts) fact.subjectId,
    };

    final entries = <RelationEntry>[
      _selfEntry(
        observer: observer,
        timestamp: timestamp,
        worldSeed: worldSeed,
      ),
    ];

    for (final peer in clubPeers) {
      if (peer.id == observer.id) continue;
      final type = _relationType(
        observerRole: observer.role,
        targetRole: peer.role,
      );
      if (type == null) continue;
      entries.add(
        _peerEntry(
          observer: observer,
          target: peer,
          type: type,
          timestamp: timestamp,
          worldSeed: worldSeed,
          remembered: rememberedSubjects.contains(peer.id.value),
          perceived: perceivedSubjects.isNotEmpty,
        ),
      );
    }

    entries.sort(
      (a, b) => a.targetPersonId.value.compareTo(b.targetPersonId.value),
    );

    return RelationState(observerId: observer.id, entries: entries);
  }

  RelationEntry _selfEntry({
    required Person observer,
    required MemoryTimestamp timestamp,
    required int worldSeed,
  }) {
    return RelationEntry(
      observerPersonId: observer.id,
      targetPersonId: observer.id,
      type: RelationType.self,
      trust: RelationTrust.absolute,
      respect: RelationRespect.absolute,
      affinity: RelationAffinity.absolute,
      confidence: RelationConfidence(1.0),
      strength: RelationStrength(1.0),
      history: RelationHistory(
        events: [RelationHistoryEvent(at: timestamp, kind: 'structural.self')],
      ),
      knownSince: timestamp,
      lastInteraction: timestamp,
      origin: RelationOrigin.structural,
      tags: const [RelationTag.structural],
    );
  }

  RelationEntry _peerEntry({
    required Person observer,
    required Person target,
    required RelationType type,
    required MemoryTimestamp timestamp,
    required int worldSeed,
    required bool remembered,
    required bool perceived,
  }) {
    final trust = _dimension<RelationTrust>(
      observerId: observer.id,
      targetId: target.id,
      worldSeed: worldSeed,
      domain: 'relation.trust.${type.name}',
      map: (v) => RelationTrust((v * 2 - 1).clamp(-1.0, 1.0)),
    );
    final respect = _dimension<RelationRespect>(
      observerId: observer.id,
      targetId: target.id,
      worldSeed: worldSeed,
      domain: 'relation.respect.${type.name}',
      map: (v) => RelationRespect(v),
    );
    final affinity = _dimension<RelationAffinity>(
      observerId: observer.id,
      targetId: target.id,
      worldSeed: worldSeed,
      domain: 'relation.affinity.${type.name}',
      map: (v) => RelationAffinity(v),
    );
    var confidence = _dimension<RelationConfidence>(
      observerId: observer.id,
      targetId: target.id,
      worldSeed: worldSeed,
      domain: 'relation.confidence.${type.name}',
      map: (v) => RelationConfidence(v),
    );
    var strength = _dimension<RelationStrength>(
      observerId: observer.id,
      targetId: target.id,
      worldSeed: worldSeed,
      domain: 'relation.strength.${type.name}',
      map: (v) => RelationStrength(v),
    );

    final tags = <RelationTag>[
      RelationTag.sameClub,
      RelationTag.structural,
      if (perceived) RelationTag.perceived,
      if (remembered) RelationTag.remembered,
      if (_isStaffHierarchy(type)) RelationTag.staffHierarchy,
    ];

    var origin = RelationOrigin.structural;
    if (remembered && perceived) {
      origin = RelationOrigin.memory;
    } else if (remembered) {
      origin = RelationOrigin.memory;
    } else if (perceived) {
      origin = RelationOrigin.perception;
    }

    if (remembered) {
      final boost = _dimension<double>(
        observerId: observer.id,
        targetId: target.id,
        worldSeed: worldSeed,
        domain: 'relation.memoryBoost',
        map: (v) => v,
      );
      confidence = RelationConfidence(
        (confidence.value + boost * 0.1).clamp(0.0, 1.0),
      );
      strength = RelationStrength(
        (strength.value + boost * 0.05).clamp(0.0, 1.0),
      );
    }

    return RelationEntry(
      observerPersonId: observer.id,
      targetPersonId: target.id,
      type: type,
      trust: trust,
      respect: respect,
      affinity: affinity,
      confidence: confidence,
      strength: strength,
      history: RelationHistory(
        events: [
          RelationHistoryEvent(at: timestamp, kind: 'structural.${type.name}'),
        ],
      ),
      knownSince: timestamp,
      lastInteraction: perceived || remembered ? timestamp : null,
      origin: origin,
      tags: tags,
    );
  }

  T _dimension<T>({
    required PersonId observerId,
    required PersonId targetId,
    required int worldSeed,
    required String domain,
    required T Function(double normalized) map,
  }) {
    final raw = personDerive(
      personId: observerId,
      worldSeed: worldSeed,
      domain: '$domain.${targetId.value}',
    ).abs();
    return map((raw % 1001) / 1000.0);
  }

  RelationType? _relationType({
    required PersonRole observerRole,
    required PersonRole targetRole,
  }) {
    if (observerRole == PersonRole.player && targetRole == PersonRole.player) {
      return RelationType.teammate;
    }
    if (targetRole == PersonRole.manager &&
        observerRole != PersonRole.manager) {
      return RelationType.manager;
    }
    if (targetRole == PersonRole.sportingDirector &&
        observerRole != PersonRole.sportingDirector) {
      return RelationType.sportingDirector;
    }
    if (targetRole == PersonRole.president &&
        observerRole != PersonRole.president) {
      return RelationType.president;
    }
    if (_isStaffRole(observerRole) &&
        _isStaffRole(targetRole) &&
        observerRole != targetRole) {
      return RelationType.staffPeer;
    }
    return null;
  }

  bool _isStaffRole(PersonRole role) => switch (role) {
    PersonRole.manager ||
    PersonRole.sportingDirector ||
    PersonRole.president => true,
    _ => false,
  };

  bool _isStaffHierarchy(RelationType type) => switch (type) {
    RelationType.manager ||
    RelationType.sportingDirector ||
    RelationType.president ||
    RelationType.staffPeer => true,
    _ => false,
  };
}
