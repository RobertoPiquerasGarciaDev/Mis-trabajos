/// Consolidador determinista Interpretation → Belief (PF-7).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Agrupa candidatos y produce creencias con infraestructura de refuerzo.
final class BeliefConsolidator {
  /// Crea el consolidador.
  const BeliefConsolidator();

  /// Consolida candidatos en creencias persistentes.
  BeliefConsolidation consolidate({
    required List<BeliefCandidate> candidates,
    required PersonId observerId,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final sorted = [...candidates]
      ..sort((a, b) => a.consolidationKey.compareTo(b.consolidationKey));
    final grouped = <String, List<BeliefCandidate>>{};
    for (final candidate in sorted) {
      grouped.putIfAbsent(candidate.consolidationKey, () => []).add(candidate);
    }

    var isolatedCount = 0;
    var consolidatedGroups = 0;
    final beliefs = <BeliefEntry>[];
    final relationTargets = <BeliefId, String?>{};
    final timestamp = MemoryTimestamp(season: season, week: week);

    for (final entry in grouped.entries) {
      final group = entry.value;
      if (group.length >= BeliefConsolidation.minSupportForStrongBelief) {
        consolidatedGroups++;
      } else {
        isolatedCount += group.length;
      }
      final belief = _beliefFromGroup(
        group: group,
        observerId: observerId,
        worldSeed: worldSeed,
        domain: entry.key,
        timestamp: timestamp,
      );
      beliefs.add(belief);
      relationTargets[belief.id] = _relationTargetFromKey(entry.key);
    }

    beliefs.sort((a, b) => a.id.value.compareTo(b.id.value));
    final linked = _linkContradictions(beliefs, relationTargets);

    return BeliefConsolidation(
      candidates: sorted,
      beliefs: linked,
      isolatedCandidateCount: isolatedCount,
      consolidatedGroupCount: consolidatedGroups,
    );
  }

  BeliefEntry _beliefFromGroup({
    required List<BeliefCandidate> group,
    required PersonId observerId,
    required int worldSeed,
    required String domain,
    required MemoryTimestamp timestamp,
  }) {
    final consolidated =
        group.length >= BeliefConsolidation.minSupportForStrongBelief;
    final origin = consolidated
        ? BeliefOrigin.consolidatedInterpretations
        : BeliefOrigin.isolatedInterpretation;

    final avgConfidence =
        group.map((c) => c.tentativeConfidence.value).reduce((a, b) => a + b) /
        group.length;
    final avgStrength =
        group.map((c) => c.tentativeStrength.value).reduce((a, b) => a + b) /
        group.length;

    final confidenceBoost = consolidated ? 0.12 : 0.0;
    final strengthBoost = consolidated ? 0.18 : 0.0;
    var strength = (avgStrength + strengthBoost).clamp(0.0, 1.0);
    if (!consolidated) {
      strength = strength.clamp(0.0, BeliefConsolidation.isolatedStrengthCap);
    }

    final representative = group.first;
    final sourceIds = [
      for (final candidate in group) candidate.sourceInterpretationId,
    ]..sort((a, b) => a.value.compareTo(b.value));

    final raw = personDerive(
      personId: observerId,
      worldSeed: worldSeed,
      domain: 'belief.id.$domain',
    );
    final summary = consolidated
        ? 'Creo que ${representative.summary.toLowerCase()}'
        : 'Podría ser cierto que ${representative.summary.toLowerCase()}';

    return BeliefEntry(
      id: BeliefId('belief-${raw.toRadixString(16).padLeft(16, '0')}'),
      observerPersonId: observerId,
      type: representative.type,
      category: representative.category,
      summary: summary,
      confidence: BeliefConfidence(
        (avgConfidence + confidenceBoost).clamp(0.0, 1.0),
      ),
      strength: BeliefStrength(strength),
      origin: origin,
      sourceInterpretationIds: sourceIds,
      createdAt: representative.createdAt,
      updatedAt: timestamp,
      lastConfirmed: timestamp,
      contradictoryBeliefIds: const [],
    );
  }

  List<BeliefEntry> _linkContradictions(
    List<BeliefEntry> beliefs,
    Map<BeliefId, String?> relationTargets,
  ) {
    final opposition = <BeliefType, BeliefType>{
      BeliefType.trust: BeliefType.lossOfStatus,
      BeliefType.lossOfStatus: BeliefType.trust,
      BeliefType.protection: BeliefType.lossOfStatus,
      BeliefType.institutionalSupport: BeliefType.lossOfStatus,
    };

    final updated = [...beliefs];
    for (var i = 0; i < updated.length; i++) {
      final left = updated[i];
      final leftTarget = relationTargets[left.id];
      if (leftTarget == null) continue;

      final contradictions = <BeliefId>[];
      for (var j = 0; j < updated.length; j++) {
        if (i == j) continue;
        final right = updated[j];
        if (relationTargets[right.id] != leftTarget) continue;
        final opposed = opposition[left.type];
        if (opposed == null || right.type != opposed) continue;
        contradictions.add(right.id);
      }
      if (contradictions.isEmpty) continue;
      contradictions.sort((a, b) => a.value.compareTo(b.value));
      updated[i] = BeliefEntry(
        id: left.id,
        observerPersonId: left.observerPersonId,
        type: left.type,
        category: left.category,
        summary: left.summary,
        confidence: left.confidence,
        strength: left.strength,
        origin: left.origin,
        sourceInterpretationIds: left.sourceInterpretationIds,
        createdAt: left.createdAt,
        updatedAt: left.updatedAt,
        lastConfirmed: left.lastConfirmed,
        contradictoryBeliefIds: contradictions,
      );
    }
    return updated;
  }

  String? _relationTargetFromKey(String consolidationKey) {
    const marker = 'rel:';
    final start = consolidationKey.indexOf(marker);
    if (start == -1) return null;
    final rest = consolidationKey.substring(start + marker.length);
    final pipe = rest.indexOf('|');
    return pipe == -1 ? rest : rest.substring(0, pipe);
  }
}
