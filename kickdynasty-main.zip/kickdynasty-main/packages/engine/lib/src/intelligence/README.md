# Intelligence module (People First)

Motor cognitivo y deliberación CPU — **PF-0: placeholder**.

Implementación prevista en fases PF-2…PF-16 del
[PEOPLE_FIRST_IMPLEMENTATION_PLAN.md](../../../docs/PEOPLE_FIRST_IMPLEMENTATION_PLAN.md).

## Reglas

- Tipos de deliberación viven en `kickdynasty_domain` (`DecisionRecord`, …).
- Lógica cognitiva vive aquí (`AgentMind`, protocolos ejecutables).
- Sin I/O; determinismo ADR 0002.
- `market` / `economy` / `contracts` solo reciben `ExecutedMandate`.

## PF-0

Solo este README. Sin código de simulación hasta PF-2.
