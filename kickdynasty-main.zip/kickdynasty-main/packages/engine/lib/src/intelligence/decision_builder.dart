/// Constructor determinista de decisiones cognitivas (PF-10).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Consolida [SocialDeliberationResult] en [DecisionCollection].
final class DecisionBuilder {
  /// Crea el builder.
  const DecisionBuilder();

  /// Genera decisiones desde el resultado de deliberación.
  ///
  /// Determinista: mismos inputs → mismas decisiones.
  DecisionCollection build({
    required Person person,
    required IntentionEntry intention,
    required PriorityCollection priorities,
    required SocialDeliberationResult result,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final timestamp = MemoryTimestamp(season: season, week: week);
    final priorityIds = [
      for (final entry in priorities.entries)
        if (entry.type != PriorityType.latent) entry.id,
    ];

    final type = result.convocation.deferred
        ? DecisionType.deferred
        : result.convocation.requiresSocialProtocol
        ? DecisionType.socialResolved
        : DecisionType.unilateral;

    final origin = result.convocation.requiresSocialProtocol
        ? DecisionOrigin.socialProtocol
        : DecisionOrigin.internalConsolidation;

    final status = switch (result.outcome) {
      MandateOutcome.defer => DecisionStatus.deferred,
      MandateOutcome.reject => DecisionStatus.deferred,
      MandateOutcome.proceed => DecisionStatus.committed,
    };

    final strengthBase = intention.strength.value;
    final strength = DecisionStrength(switch (result.outcome) {
      MandateOutcome.proceed => (strengthBase * 0.85 + 0.1).clamp(0.0, 1.0),
      MandateOutcome.defer => (strengthBase * 0.45).clamp(0.0, 1.0),
      MandateOutcome.reject => (strengthBase * 0.3).clamp(0.0, 1.0),
    });

    final entry = DecisionEntry(
      id: DecisionId(
        'decision-${personDerive(personId: person.id, worldSeed: worldSeed, domain: 'decision.id.${intention.id.value}').toRadixString(16).padLeft(16, '0')}',
      ),
      observerPersonId: person.id,
      sourceIntentionId: intention.id,
      type: type,
      origin: origin,
      status: status,
      summary: _summaryFor(intention, result),
      rationale: _rationaleFor(intention, result),
      strength: strength,
      sourcePriorityIds: priorityIds,
      rejectedAlternatives: result.rejectedPaths,
      unknownsAcknowledged: _unknowns(intention, result),
      protocolType: result.protocolType,
      decisionRecordId: result.decisionRecord?.id,
      instanceId: result.instanceId,
      createdAt: timestamp,
      updatedAt: timestamp,
    );

    return DecisionCollection(ownerId: person.id, entries: [entry]);
  }

  String _summaryFor(
    IntentionEntry intention,
    SocialDeliberationResult result,
  ) {
    return switch (result.outcome) {
      MandateOutcome.proceed =>
        'Me comprometo con la postura: ${intention.summary}',
      MandateOutcome.defer =>
        'Prefiero diferir mi compromiso sobre: ${intention.summary}',
      MandateOutcome.reject =>
        'No puedo comprometerme ahora con: ${intention.summary}',
    };
  }

  String _rationaleFor(
    IntentionEntry intention,
    SocialDeliberationResult result,
  ) {
    if (result.convocation.requiresSocialProtocol) {
      return 'Tras deliberación social (${result.protocolType!.name}), '
          'considero correcto sostener: ${intention.summary} '
          '(desenlace: ${result.outcome.name})';
    }
    return 'Tras sopesar internamente, considero correcto: ${intention.summary} '
        '(${result.convocation.reason})';
  }

  List<String> _unknowns(
    IntentionEntry intention,
    SocialDeliberationResult result,
  ) {
    final unknowns = <String>[
      'No conozco todas las consecuencias futuras de esta postura',
    ];
    if (result.convocation.requiresSocialProtocol &&
        result.dissent.isNotEmpty) {
      unknowns.add(
        'No sé si el disenso registrado cambiará el desenlace final',
      );
    }
    if (intention.type == IntentionType.wantToLeaveClub) {
      unknowns.add('No sé con certeza qué club me acogería');
    }
    return unknowns;
  }
}
