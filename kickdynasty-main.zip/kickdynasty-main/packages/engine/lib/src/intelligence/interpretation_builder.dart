/// Constructor determinista de interpretaciones (PF-6).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Construye [InterpretationCollection] sin decidir ni acceder a Reality.
final class InterpretationBuilder {
  /// Crea el builder.
  const InterpretationBuilder();

  /// Genera hipótesis interpretativas desde percepción, memoria y relaciones.
  ///
  /// Determinista: mismos inputs → mismas interpretaciones.
  InterpretationCollection build({
    required Person observer,
    required PersonalitySnapshot personality,
    required PerceptionSnapshot? perception,
    required MemoryCollection memory,
    required RelationState relations,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final createdAt = MemoryTimestamp(season: season, week: week);
    final bias = _selectBias(
      observer: observer,
      personality: personality,
      worldSeed: worldSeed,
    );
    final entries = <InterpretationEntry>[
      ..._fromRelations(
        observer: observer,
        relations: relations,
        memory: memory,
        createdAt: createdAt,
        bias: bias,
        worldSeed: worldSeed,
        season: season,
        week: week,
      ),
      ..._fromMemory(
        observer: observer,
        memory: memory,
        relations: relations,
        createdAt: createdAt,
        bias: bias,
        worldSeed: worldSeed,
        season: season,
        week: week,
      ),
      if (perception != null && perception.facts.isNotEmpty)
        ..._fromPerception(
          observer: observer,
          perception: perception,
          createdAt: createdAt,
          bias: bias,
          worldSeed: worldSeed,
        ),
    ]..sort((a, b) => a.id.value.compareTo(b.id.value));

    return InterpretationCollection(ownerId: observer.id, entries: entries);
  }

  List<InterpretationEntry> _fromRelations({
    required Person observer,
    required RelationState relations,
    required MemoryCollection memory,
    required MemoryTimestamp createdAt,
    required InterpretationBias bias,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final entries = <InterpretationEntry>[];
    for (final relation in relations.entries) {
      if (relation.type == RelationType.self) continue;
      final type = _typeForRelation(relation, observer.role);
      final summary = _summaryForRelation(
        relation: relation,
        observerRole: observer.role,
        worldSeed: worldSeed,
        observerId: observer.id,
      );
      if (summary == null) continue;
      entries.add(
        _entry(
          observer: observer,
          domain:
              'relation.${relation.targetPersonId.value}.${relation.type.name}',
          type: type,
          summary: summary,
          source: memory.entries.isEmpty
              ? InterpretationSource.relation
              : InterpretationSource.combined,
          sourceMemoryIds: [
            for (final mem in memory.entries)
              if (mem.subjectId == relation.targetPersonId.value) mem.id,
          ],
          sourceRelationIds: [relation.targetPersonId.value],
          confidence: _confidence(
            observer.id,
            worldSeed,
            'relation.${relation.targetPersonId.value}',
            relation.confidence.value,
          ),
          importance: _importance(
            observer.id,
            worldSeed,
            'relation.${relation.type.name}',
            relation.strength.value,
          ),
          createdAt: createdAt,
          expiresAt: MemoryTimestamp(season: season, week: week + 4),
          bias: bias,
          worldSeed: worldSeed,
        ),
      );
    }
    return entries;
  }

  List<InterpretationEntry> _fromMemory({
    required Person observer,
    required MemoryCollection memory,
    required RelationState relations,
    required MemoryTimestamp createdAt,
    required InterpretationBias bias,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final entries = <InterpretationEntry>[];
    for (final mem in memory.entries) {
      final summary = _summaryForMemory(
        memory: mem,
        observerRole: observer.role,
        worldSeed: worldSeed,
        observerId: observer.id,
      );
      if (summary == null) continue;
      entries.add(
        _entry(
          observer: observer,
          domain: 'memory.${mem.id.value}',
          type: _typeForMemory(mem.factKey, observer.role),
          summary: summary,
          source: relations.entries.length > 1
              ? InterpretationSource.combined
              : InterpretationSource.memory,
          sourceMemoryIds: [mem.id],
          sourceRelationIds: const [],
          confidence: _confidence(
            observer.id,
            worldSeed,
            'memory.${mem.id.value}',
            mem.confidenceAtCapture.value,
          ),
          importance: _importance(
            observer.id,
            worldSeed,
            'memory.${mem.factKey}',
            mem.importance.value,
          ),
          createdAt: createdAt,
          expiresAt: MemoryTimestamp(season: season, week: week + 2),
          bias: bias,
          worldSeed: worldSeed,
        ),
      );
    }
    return entries;
  }

  List<InterpretationEntry> _fromPerception({
    required Person observer,
    required PerceptionSnapshot perception,
    required MemoryTimestamp createdAt,
    required InterpretationBias bias,
    required int worldSeed,
  }) {
    if (perception.facts.isEmpty) return const [];
    final fact = perception.facts.first;
    final summary = _summaryForPerceptionFact(
      fact: fact,
      observerRole: observer.role,
      worldSeed: worldSeed,
      observerId: observer.id,
    );
    return [
      _entry(
        observer: observer,
        domain: 'perception.${fact.subjectId}.${fact.factKey}',
        type: InterpretationType.perceivedMeaning,
        summary: summary,
        source: InterpretationSource.perception,
        sourceMemoryIds: const [],
        sourceRelationIds: const [],
        confidence: _confidence(
          observer.id,
          worldSeed,
          'perception.${fact.factKey}',
          fact.confidence.value,
        ),
        importance: _importance(
          observer.id,
          worldSeed,
          'perception.${fact.factKey}',
          0.4,
        ),
        createdAt: createdAt,
        expiresAt: null,
        bias: bias,
        worldSeed: worldSeed,
      ),
    ];
  }

  InterpretationEntry _entry({
    required Person observer,
    required String domain,
    required InterpretationType type,
    required String summary,
    required InterpretationSource source,
    required List<MemoryId> sourceMemoryIds,
    required List<String> sourceRelationIds,
    required InterpretationConfidence confidence,
    required InterpretationImportance importance,
    required MemoryTimestamp createdAt,
    required MemoryTimestamp? expiresAt,
    required InterpretationBias bias,
    required int worldSeed,
  }) {
    final raw = personDerive(
      personId: observer.id,
      worldSeed: worldSeed,
      domain: 'interpretation.id.$domain',
    );
    return InterpretationEntry(
      id: InterpretationId(
        'interpret-${raw.toRadixString(16).padLeft(16, '0')}',
      ),
      observerPersonId: observer.id,
      sourceMemoryIds: sourceMemoryIds,
      sourceRelationIds: sourceRelationIds,
      type: type,
      confidence: confidence,
      importance: importance,
      createdAt: createdAt,
      expiresAt: expiresAt,
      biasApplied: bias,
      summary: summary,
      source: source,
    );
  }

  InterpretationBias _selectBias({
    required Person observer,
    required PersonalitySnapshot personality,
    required int worldSeed,
  }) {
    final profile = personality.profile;
    final scores = <InterpretationBias, int>{
      InterpretationBias.confirmation: profile.prudence.value,
      InterpretationBias.recency: profile.memoryTrait.value,
      InterpretationBias.protection: profile.empathy.value,
      InterpretationBias.rivalry: profile.aggressiveness.value,
      InterpretationBias.familiarity: profile.professionalism.value,
    };
    var best = InterpretationBias.none;
    var bestScore = -1;
    for (final entry in scores.entries) {
      final tieBreak = personDerive(
        personId: observer.id,
        worldSeed: worldSeed,
        domain: 'interpretation.bias.${entry.key.name}',
      ).abs();
      final score = entry.value * 1000 + (tieBreak % 1000);
      if (score > bestScore) {
        bestScore = score;
        best = entry.key;
      }
    }
    return best;
  }

  InterpretationType _typeForRelation(
    RelationEntry relation,
    PersonRole observerRole,
  ) {
    return switch (relation.type) {
      RelationType.manager when relation.trust.value >= 0 =>
        observerRole == PersonRole.player
            ? InterpretationType.protection
            : InterpretationType.trust,
      RelationType.manager => InterpretationType.lossOfStatus,
      RelationType.president => InterpretationType.support,
      RelationType.teammate when relation.respect.value >= 0.6 =>
        InterpretationType.leadership,
      RelationType.teammate => InterpretationType.squadCohesion,
      RelationType.sportingDirector => InterpretationType.roleClarity,
      _ => InterpretationType.trust,
    };
  }

  InterpretationType _typeForMemory(String factKey, PersonRole role) {
    if (factKey.contains('fitness') || factKey.contains('form')) {
      return role == PersonRole.player
          ? InterpretationType.needToImprove
          : InterpretationType.perceivedMeaning;
    }
    if (factKey.contains('morale')) return InterpretationType.squadCohesion;
    return InterpretationType.perceivedMeaning;
  }

  String? _summaryForRelation({
    required RelationEntry relation,
    required PersonRole observerRole,
    required int worldSeed,
    required PersonId observerId,
  }) {
    final templates = switch ((
      observerRole,
      relation.type,
      relation.trust.value >= 0,
    )) {
      (PersonRole.player, RelationType.manager, true) => [
        'Mi entrenador me protege',
        'Confía en mí',
      ],
      (PersonRole.player, RelationType.manager, false) => [
        'Estoy perdiendo protagonismo',
        'El entrenador ya no confía en mí',
      ],
      (PersonRole.player, RelationType.president, true) => [
        'Este presidente me apoya',
      ],
      (PersonRole.player, RelationType.teammate, _)
          when relation.respect.value >= 0.6 =>
        ['Este compañero parece un líder'],
      (PersonRole.manager, RelationType.president, _) => [
        'La directiva respalda mi criterio',
      ],
      (PersonRole.manager, RelationType.sportingDirector, _) => [
        'El director deportivo comparte mi visión',
      ],
      (_, RelationType.sportingDirector, true) => [
        'Puedo confiar en el director deportivo',
      ],
      _ => null,
    };
    if (templates == null || templates.isEmpty) return null;
    final index = personDerive(
      personId: observerId,
      worldSeed: worldSeed,
      domain:
          'interpretation.summary.relation.${relation.targetPersonId.value}',
    ).abs();
    return templates[index % templates.length];
  }

  String? _summaryForMemory({
    required MemoryEntry memory,
    required PersonRole observerRole,
    required int worldSeed,
    required PersonId observerId,
  }) {
    final templates = switch ((observerRole, memory.factKey)) {
      (PersonRole.player, 'player.fitness') => [
        'Necesito mejorar',
        'Mi cuerpo no responde como quiero',
      ],
      (PersonRole.player, 'player.form') => [
        'No estoy en mi mejor momento',
        'Debo demostrar más en el campo',
      ],
      (PersonRole.manager, 'player.morale') => [
        'El vestuario necesita atención',
      ],
      (_, 'club.name') => ['Este es mi club'],
      _ => null,
    };
    if (templates == null) return null;
    final index = personDerive(
      personId: observerId,
      worldSeed: worldSeed,
      domain: 'interpretation.summary.memory.${memory.id.value}',
    ).abs();
    return templates[index % templates.length];
  }

  String _summaryForPerceptionFact({
    required PerceivedFact fact,
    required PersonRole observerRole,
    required int worldSeed,
    required PersonId observerId,
  }) {
    final templates = switch ((observerRole, fact.factKey)) {
      (PersonRole.player, 'player.skillBand') => [
        'Puedo competir a este nivel',
        'Aún me falta para ser titular indiscutible',
      ],
      (PersonRole.president, 'club.reputation') => [
        'Nuestro club tiene peso en la liga',
      ],
      _ => ['Lo que veo encaja con lo que recuerdo'],
    };
    final index = personDerive(
      personId: observerId,
      worldSeed: worldSeed,
      domain: 'interpretation.summary.perception.${fact.factKey}',
    ).abs();
    return templates[index % templates.length];
  }

  InterpretationConfidence _confidence(
    PersonId observerId,
    int worldSeed,
    String domain,
    double anchor,
  ) {
    final raw = personDerive(
      personId: observerId,
      worldSeed: worldSeed,
      domain: 'interpretation.confidence.$domain',
    ).abs();
    return InterpretationConfidence(
      (anchor * 0.7 + (raw % 301) / 1000.0).clamp(0.0, 1.0),
    );
  }

  InterpretationImportance _importance(
    PersonId observerId,
    int worldSeed,
    String domain,
    double anchor,
  ) {
    final raw = personDerive(
      personId: observerId,
      worldSeed: worldSeed,
      domain: 'interpretation.importance.$domain',
    ).abs();
    return InterpretationImportance(
      (anchor * 0.6 + (raw % 401) / 1000.0).clamp(0.0, 1.0),
    );
  }
}
