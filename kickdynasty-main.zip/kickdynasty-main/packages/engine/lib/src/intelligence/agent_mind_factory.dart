/// Fábrica determinista de [AgentMind] inicial (PF-2).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Construye mentes iniciales sin razonamiento ni aprendizaje.
final class AgentMindFactory {
  /// Crea la fábrica.
  const AgentMindFactory();

  /// Construye el [AgentMind] inicial de [person].
  ///
  /// Determinista: misma [person] + [worldSeed] → misma mente.
  AgentMind createInitial({required Person person, required int worldSeed}) {
    return AgentMind(
      personId: person.id,
      personality: PersonalitySnapshot.fromPerson(person),
      memory: const MemoryState.empty(),
      beliefs: const BeliefState.empty(),
      goals: const GoalState.empty(),
      priorities: const PriorityState.empty(),
      intentions: const IntentionState.empty(),
      decisions: const DecisionState.empty(),
      perception: const PerceptionState.empty(),
      relations: const RelationState.empty(),
      interpretation: const InterpretationState.empty(),
      emotion: _initialEmotion(personId: person.id, worldSeed: worldSeed),
      learning: LearningState.initial,
    );
  }

  EmotionalState _initialEmotion({
    required PersonId personId,
    required int worldSeed,
  }) {
    // PF-2: baseline neutro derivado determinísticamente (sin dinámica emocional).
    double component(String domain) {
      final raw = personDerive(
        personId: personId,
        worldSeed: worldSeed,
        domain: 'emotion.initial.$domain',
      );
      return (raw.abs() % 1001) / 1000.0;
    }

    return EmotionalState(
      fear: component('fear'),
      anger: component('anger'),
      euphoria: component('euphoria'),
      anxiety: component('anxiety'),
      woundedPride: component('woundedPride'),
      relief: component('relief'),
      distrust: component('distrust'),
    );
  }
}
