/// Constructor determinista de fotografías perceptivas (PF-3).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/intelligence/observable_world.dart';

/// Infraestructura de fuentes futuras — PF-3 solo activa observación directa.
const perceptionInfrastructureSources = [
  PerceptionSource.directObservation,
  PerceptionSource.scoutingReport,
  PerceptionSource.media,
  PerceptionSource.chronicle,
  PerceptionSource.rumor,
  PerceptionSource.conversation,
  PerceptionSource.institution,
  PerceptionSource.introspection,
];

/// Construye [PerceptionSnapshot] sin interpretar ni inferir.
final class PerceptionBuilder {
  /// Crea el builder.
  const PerceptionBuilder();

  /// Genera la fotografía perceptiva de [observer] en [season]/[week].
  ///
  /// Determinista: mismos inputs → mismo snapshot.
  PerceptionSnapshot build({
    required Person observer,
    required ClubId? observerClubId,
    required ObservableWorld world,
    required int season,
    required int week,
    required int worldSeed,
    PlayerId? linkedPlayerId,
  }) {
    final facts = <PerceivedFact>[];

    if (observerClubId != null) {
      facts.addAll(
        _ownClubFacts(
          observer: observer,
          clubId: observerClubId,
          world: world,
          worldSeed: worldSeed,
        ),
      );
    }

    if (observer.role == PersonRole.player &&
        observerClubId != null &&
        linkedPlayerId != null) {
      facts.addAll(
        _selfPlayerFacts(
          observer: observer,
          clubId: observerClubId,
          linkedPlayerId: linkedPlayerId,
          world: world,
          worldSeed: worldSeed,
        ),
      );
    }

    facts.addAll(
      _publicClubFacts(
        observer: observer,
        observerClubId: observerClubId,
        world: world,
      ),
    );

    facts.sort(_factSortKey);

    return PerceptionSnapshot(
      observerId: observer.id,
      season: season,
      week: week,
      facts: facts,
      availableSources: perceptionInfrastructureSources,
    );
  }

  List<PerceivedFact> _ownClubFacts({
    required Person observer,
    required ClubId clubId,
    required ObservableWorld world,
    required int worldSeed,
  }) {
    if (!_seesOwnSquad(observer.role)) return const [];

    final squad = world.playersByClub[clubId] ?? const [];
    final quality = _observationQuality(observer, worldSeed);
    final facts = <PerceivedFact>[];

    for (final player in squad) {
      final subjectId = player.id.value;
      facts
        ..add(
          _fact(
            subjectId: subjectId,
            factKey: 'player.name',
            value: player.name,
            observer: observer,
            worldSeed: worldSeed,
            quality: quality,
            visibility: VisibilityLevel.full,
          ),
        )
        ..add(
          _fact(
            subjectId: subjectId,
            factKey: 'player.position',
            value: player.position,
            observer: observer,
            worldSeed: worldSeed,
            quality: quality,
            visibility: VisibilityLevel.full,
          ),
        )
        ..add(
          _fact(
            subjectId: subjectId,
            factKey: 'player.fitness',
            value: '${player.fitness}',
            observer: observer,
            worldSeed: worldSeed,
            quality: quality,
            visibility: VisibilityLevel.full,
          ),
        )
        ..add(
          _fact(
            subjectId: subjectId,
            factKey: 'player.morale',
            value: '${player.morale}',
            observer: observer,
            worldSeed: worldSeed,
            quality: quality,
            visibility: VisibilityLevel.full,
          ),
        )
        ..add(
          _fact(
            subjectId: subjectId,
            factKey: 'player.form',
            value: '${player.form}',
            observer: observer,
            worldSeed: worldSeed,
            quality: quality,
            visibility: VisibilityLevel.full,
          ),
        )
        ..add(
          _fact(
            subjectId: subjectId,
            factKey: 'player.skillBand',
            value: '${player.skillBandMin}-${player.skillBandMax}',
            observer: observer,
            worldSeed: worldSeed,
            quality: quality,
            visibility: VisibilityLevel.partial,
            ambiguity: '${player.skillBandMin}-${player.skillBandMax}',
          ),
        );
    }

    final club = world.clubs.firstWhere((c) => c.id == clubId);
    facts.add(
      _fact(
        subjectId: clubId.value,
        factKey: 'club.name',
        value: club.name,
        observer: observer,
        worldSeed: worldSeed,
        quality: quality,
        visibility: VisibilityLevel.full,
      ),
    );

    return facts;
  }

  List<PerceivedFact> _selfPlayerFacts({
    required Person observer,
    required ClubId clubId,
    required PlayerId linkedPlayerId,
    required ObservableWorld world,
    required int worldSeed,
  }) {
    final squad = world.playersByClub[clubId] ?? const [];
    ObservablePlayerView? matched;
    for (final player in squad) {
      if (player.id == linkedPlayerId) {
        matched = player;
        break;
      }
    }
    if (matched == null) return const [];

    final quality = ObservationQuality(TraitScore(85));
    return [
      _fact(
        subjectId: matched.id.value,
        factKey: 'self.fitness',
        value: '${matched.fitness}',
        observer: observer,
        worldSeed: worldSeed,
        quality: quality,
        visibility: VisibilityLevel.full,
        source: PerceptionSource.introspection,
        origin: KnowledgeOrigin.self,
      ),
    ];
  }

  List<PerceivedFact> _publicClubFacts({
    required Person observer,
    required ClubId? observerClubId,
    required ObservableWorld world,
  }) {
    final facts = <PerceivedFact>[];
    for (final club in world.clubs) {
      if (club.id == observerClubId) continue;
      facts.add(
        _fact(
          subjectId: club.id.value,
          factKey: 'club.name',
          value: club.name,
          observer: observer,
          worldSeed: 0,
          quality: ObservationQuality(TraitScore(70)),
          visibility: VisibilityLevel.partial,
          origin: KnowledgeOrigin.public,
        ),
      );
      facts.add(
        _fact(
          subjectId: club.id.value,
          factKey: 'club.reputation',
          value: '${club.reputation}',
          observer: observer,
          worldSeed: 0,
          quality: ObservationQuality(TraitScore(60)),
          visibility: VisibilityLevel.partial,
          origin: KnowledgeOrigin.public,
        ),
      );
    }
    return facts;
  }

  bool _seesOwnSquad(PersonRole role) => switch (role) {
    PersonRole.player ||
    PersonRole.manager ||
    PersonRole.sportingDirector ||
    PersonRole.president => true,
    _ => false,
  };

  ObservationQuality _observationQuality(Person observer, int worldSeed) {
    final raw = personDerive(
      personId: observer.id,
      worldSeed: worldSeed,
      domain: 'perception.quality',
    ).abs();
    return ObservationQuality(TraitScore(55 + (raw % 35)));
  }

  PerceivedFact _fact({
    required String subjectId,
    required String factKey,
    required String value,
    required Person observer,
    required int worldSeed,
    required ObservationQuality quality,
    required VisibilityLevel visibility,
    PerceptionSource source = PerceptionSource.directObservation,
    KnowledgeOrigin origin = KnowledgeOrigin.self,
    String ambiguity = '',
  }) {
    final confidenceRaw = personDerive(
      personId: observer.id,
      worldSeed: worldSeed,
      domain: 'perception.confidence.$subjectId.$factKey',
    ).abs();
    final confidence = PerceptionConfidence(
      (0.55 + (confidenceRaw % 401) / 1000.0).clamp(0.0, 1.0),
    );

    return PerceivedFact(
      subjectId: subjectId,
      factKey: factKey,
      value: value,
      source: source,
      confidence: confidence,
      age: PerceptionAge.fresh,
      visibility: visibility,
      quality: quality,
      origin: origin,
      ambiguity: ambiguity,
    );
  }
}

int _factSortKey(PerceivedFact a, PerceivedFact b) {
  final subject = a.subjectId.compareTo(b.subjectId);
  if (subject != 0) return subject;
  return a.factKey.compareTo(b.factKey);
}
