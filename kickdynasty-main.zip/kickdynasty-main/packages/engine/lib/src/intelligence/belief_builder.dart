/// Constructor determinista de creencias (PF-7).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/intelligence/belief_consolidator.dart';

/// Construye [BeliefCollection] solo desde interpretación, memoria y relaciones.
final class BeliefBuilder {
  /// Crea el builder.
  const BeliefBuilder({
    BeliefConsolidator consolidator = const BeliefConsolidator(),
  }) : _consolidator = consolidator;

  final BeliefConsolidator _consolidator;

  /// Genera creencias consolidadas desde interpretaciones existentes.
  ///
  /// Determinista: mismos inputs → mismas creencias.
  BeliefCollection build({
    required Person observer,
    required InterpretationCollection interpretations,
    required MemoryCollection memory,
    required RelationState relations,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final candidates = _candidatesFromInterpretations(
      observer: observer,
      interpretations: interpretations,
      memory: memory,
      relations: relations,
      worldSeed: worldSeed,
    );
    final consolidation = _consolidator.consolidate(
      candidates: candidates,
      observerId: observer.id,
      worldSeed: worldSeed,
      season: season,
      week: week,
    );
    return BeliefCollection(
      ownerId: observer.id,
      entries: consolidation.beliefs,
    );
  }

  List<BeliefCandidate> _candidatesFromInterpretations({
    required Person observer,
    required InterpretationCollection interpretations,
    required MemoryCollection memory,
    required RelationState relations,
    required int worldSeed,
  }) {
    final candidates = <BeliefCandidate>[];
    for (final interpretation in interpretations.entries) {
      final category = _categoryFor(
        interpretation: interpretation,
        observerRole: observer.role,
        memory: memory,
        relations: relations,
      );
      final type = _typeFor(interpretation.type);
      final relationTarget = interpretation.sourceRelationIds.isEmpty
          ? null
          : interpretation.sourceRelationIds.first;
      final reinforcement = _reinforcementFactor(
        interpretation: interpretation,
        memory: memory,
        relations: relations,
      );
      final tentativeConfidence = BeliefConfidence(
        (interpretation.confidence.value * 0.85 * reinforcement).clamp(
          0.0,
          1.0,
        ),
      );
      final tentativeStrength = BeliefStrength(
        (interpretation.importance.value * 0.55 * reinforcement).clamp(
          0.0,
          1.0,
        ),
      );
      candidates.add(
        BeliefCandidate(
          observerPersonId: observer.id,
          sourceInterpretationId: interpretation.id,
          type: type,
          category: category,
          summary: interpretation.summary,
          tentativeConfidence: tentativeConfidence,
          tentativeStrength: tentativeStrength,
          consolidationKey: _consolidationKey(
            type: type,
            category: category,
            summary: interpretation.summary,
            relationTarget: relationTarget,
          ),
          createdAt: interpretation.createdAt,
        ),
      );
    }
    candidates.sort(
      (a, b) => a.sourceInterpretationId.value.compareTo(
        b.sourceInterpretationId.value,
      ),
    );
    return candidates;
  }

  BeliefType _typeFor(InterpretationType type) => switch (type) {
    InterpretationType.trust => BeliefType.trust,
    InterpretationType.lossOfStatus => BeliefType.lossOfStatus,
    InterpretationType.needToImprove => BeliefType.selfImprovement,
    InterpretationType.protection => BeliefType.protection,
    InterpretationType.leadership => BeliefType.leadership,
    InterpretationType.support => BeliefType.institutionalSupport,
    InterpretationType.squadCohesion => BeliefType.squadCohesion,
    InterpretationType.roleClarity => BeliefType.roleClarity,
    InterpretationType.perceivedMeaning => BeliefType.worldView,
  };

  BeliefCategory _categoryFor({
    required InterpretationEntry interpretation,
    required PersonRole observerRole,
    required MemoryCollection memory,
    required RelationState relations,
  }) {
    if (interpretation.sourceRelationIds.isNotEmpty) {
      return switch (interpretation.type) {
        InterpretationType.support ||
        InterpretationType.squadCohesion => BeliefCategory.club,
        InterpretationType.needToImprove ||
        InterpretationType.lossOfStatus ||
        InterpretationType.roleClarity => BeliefCategory.self,
        _ => BeliefCategory.otherPerson,
      };
    }
    if (interpretation.sourceMemoryIds.isNotEmpty) {
      final memoryEntry = memory.entries.where(
        (entry) => entry.id == interpretation.sourceMemoryIds.first,
      );
      if (memoryEntry.isNotEmpty) {
        return switch (memoryEntry.first.factKey) {
          'player.fitness' || 'player.form' => BeliefCategory.self,
          'player.morale' => BeliefCategory.club,
          'club.name' => BeliefCategory.club,
          _ => BeliefCategory.career,
        };
      }
    }
    if (interpretation.source == InterpretationSource.perception) {
      return observerRole == PersonRole.player
          ? BeliefCategory.competition
          : BeliefCategory.world;
    }
    return BeliefCategory.world;
  }

  double _reinforcementFactor({
    required InterpretationEntry interpretation,
    required MemoryCollection memory,
    required RelationState relations,
  }) {
    var factor = 1.0;
    if (interpretation.sourceMemoryIds.isNotEmpty &&
        memory.entries.any(
          (entry) => interpretation.sourceMemoryIds.contains(entry.id),
        )) {
      factor += 0.05;
    }
    if (interpretation.sourceRelationIds.isNotEmpty) {
      final target = interpretation.sourceRelationIds.first;
      if (relations.entries.any(
        (entry) => entry.targetPersonId.value == target,
      )) {
        factor += 0.05;
      }
    }
    return factor;
  }

  String _consolidationKey({
    required BeliefType type,
    required BeliefCategory category,
    required String summary,
    required String? relationTarget,
  }) {
    final normalized = summary.toLowerCase().trim();
    final rel = relationTarget ?? 'general';
    return '${type.name}|${category.name}|rel:$rel|$normalized';
  }
}
