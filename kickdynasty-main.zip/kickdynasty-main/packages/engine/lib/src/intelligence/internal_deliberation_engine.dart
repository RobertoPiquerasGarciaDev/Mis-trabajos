/// Motor de deliberación interna (PF-9).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Transforma prioridades en candidatos a intención — sin decisiones.
final class InternalDeliberationEngine {
  /// Crea el motor.
  const InternalDeliberationEngine();

  /// Delibera internamente sobre las prioridades vigentes.
  ///
  /// Determinista: mismo [DeliberationContext] → mismo [DeliberationResult].
  DeliberationResult deliberate(DeliberationContext context) {
    final candidates = <IntentionCandidate>[];
    final rejected = <String>[];

    final focusPriorities =
        context.priorities.entries
            .where((p) => p.type != PriorityType.latent)
            .toList()
          ..sort((a, b) => a.rank.value.compareTo(b.rank.value));

    for (final priority in focusPriorities) {
      final mapping = _mapPriority(priority: priority, context: context);
      if (mapping == null) {
        rejected.add(
          'Descartado ${priority.id.value}: postura demasiado débil',
        );
        continue;
      }
      candidates.add(
        IntentionCandidate(
          observerPersonId: context.person.id,
          sourcePriorityId: priority.id,
          type: mapping.type,
          summary: mapping.summary,
          tentativeStrength: IntentionStrength(
            (priority.strength.value * 0.7 + mapping.strengthBoost).clamp(
              0.0,
              1.0,
            ),
          ),
          status: mapping.status,
          createdAt: MemoryTimestamp(
            season: context.season,
            week: context.week,
          ),
        ),
      );
    }

    if (focusPriorities.isEmpty) {
      rejected.add('Sin prioridades activas — postura de diferimiento');
      candidates.add(
        IntentionCandidate(
          observerPersonId: context.person.id,
          sourcePriorityId: PriorityId(
            'priority-defer-${context.person.id.value}',
          ),
          type: IntentionType.wantToDefer,
          summary: 'Prefiero esperar antes de adoptar una postura clara',
          tentativeStrength: IntentionStrength(0.25),
          status: IntentionStatus.deferred,
          createdAt: MemoryTimestamp(
            season: context.season,
            week: context.week,
          ),
        ),
      );
    }

    candidates.sort(
      (a, b) => a.sourcePriorityId.value.compareTo(b.sourcePriorityId.value),
    );
    return DeliberationResult(candidates: candidates, rejectedPaths: rejected);
  }

  _Mapping? _mapPriority({
    required PriorityEntry priority,
    required DeliberationContext context,
  }) {
    if (priority.strength.value < 0.15) return null;

    final person = context.person;
    final profile = context.personality.profile;
    final ambitionNorm = profile.ambition.value / 100.0;
    final empathyNorm = profile.empathy.value / 100.0;
    final loyaltyNorm = person.values.loyalty.value / 100.0;

    var type = _baseIntention(priority.goalType);
    var summary = _summaryFor(type, priority.summary);
    var strengthBoost = 0.0;
    var status = IntentionStatus.active;

    if (priority.type == PriorityType.latent ||
        priority.strength.value < 0.35) {
      type = IntentionType.wantToDefer;
      summary = 'Prefiero diferir mi postura sobre: ${priority.summary}';
      status = IntentionStatus.deferred;
      strengthBoost = -0.1;
    } else {
      type = _roleModulatedType(
        base: type,
        goalType: priority.goalType,
        role: person.role,
        person: person,
        emotion: context.emotion,
      );
      summary = _roleModulatedSummary(
        type: type,
        prioritySummary: priority.summary,
        role: person.role,
      );
      strengthBoost = _personalityBoost(
        type: type,
        ambitionNorm: ambitionNorm,
        empathyNorm: empathyNorm,
        loyaltyNorm: loyaltyNorm,
      );
    }

    if (priority.type == PriorityType.dominant) {
      strengthBoost += 0.08;
    }

    return _Mapping(
      type: type,
      summary: summary,
      strengthBoost: strengthBoost,
      status: status,
    );
  }

  IntentionType _baseIntention(GoalType goalType) => switch (goalType) {
    GoalType.maintainTrust => IntentionType.wantToMaintainTrust,
    GoalType.regainStatus => IntentionType.wantToRegainStatus,
    GoalType.improveSelf => IntentionType.wantToImproveSelf,
    GoalType.seekProtection => IntentionType.wantToSeekProtection,
    GoalType.assertLeadership => IntentionType.wantToAssertLeadership,
    GoalType.alignWithInstitution => IntentionType.wantToAlignWithInstitution,
    GoalType.strengthenSquad => IntentionType.wantToStrengthenSquad,
    GoalType.clarifyRole => IntentionType.wantToClarifyRole,
    GoalType.understandWorld => IntentionType.wantToUnderstandWorld,
    GoalType.buildLegacy => IntentionType.wantToBuildLegacy,
  };

  IntentionType _roleModulatedType({
    required IntentionType base,
    required GoalType goalType,
    required PersonRole role,
    required Person person,
    required EmotionalState emotion,
  }) {
    return switch (role) {
      PersonRole.player
          when goalType == GoalType.seekProtection &&
              emotion.fear + emotion.anxiety >= 0.9 =>
        IntentionType.wantToLeaveClub,
      PersonRole.player
          when goalType == GoalType.alignWithInstitution &&
              person.values.loyalty.value >= 65 =>
        IntentionType.wantToRenew,
      PersonRole.player when goalType == GoalType.maintainTrust =>
        IntentionType.wantToTrustPerson,
      PersonRole.sportingDirector
          when goalType == GoalType.regainStatus ||
              goalType == GoalType.assertLeadership =>
        IntentionType.wantToSellPlayer,
      PersonRole.sportingDirector || PersonRole.youthDirector
          when goalType == GoalType.buildLegacy ||
              goalType == GoalType.strengthenSquad =>
        IntentionType.wantToBetOnYouth,
      PersonRole.scout || PersonRole.scoutingLead
          when goalType == GoalType.understandWorld =>
        IntentionType.wantToUnderstandWorld,
      _ => base,
    };
  }

  String _summaryFor(IntentionType type, String prioritySummary) =>
      switch (type) {
        IntentionType.wantToLeaveClub =>
          'Siento que quiero salir del club ($prioritySummary)',
        IntentionType.wantToRenew =>
          'Quiero renovar o permanecer ($prioritySummary)',
        IntentionType.wantToTrustPerson =>
          'Quiero confiar en alguien ($prioritySummary)',
        IntentionType.wantToSellPlayer =>
          'Quiero vender a un futbolista ($prioritySummary)',
        IntentionType.wantToBetOnYouth =>
          'Quiero apostar por cantera ($prioritySummary)',
        IntentionType.wantToMaintainTrust =>
          'Quiero mantener la confianza que percibo ($prioritySummary)',
        IntentionType.wantToRegainStatus =>
          'Quiero recuperar estatus ($prioritySummary)',
        IntentionType.wantToImproveSelf =>
          'Quiero mejorar personalmente ($prioritySummary)',
        IntentionType.wantToSeekProtection =>
          'Quiero buscar protección ($prioritySummary)',
        IntentionType.wantToAssertLeadership =>
          'Quiero ejercer liderazgo ($prioritySummary)',
        IntentionType.wantToAlignWithInstitution =>
          'Quiero alinearme con la institución ($prioritySummary)',
        IntentionType.wantToStrengthenSquad =>
          'Quiero fortalecer el grupo ($prioritySummary)',
        IntentionType.wantToClarifyRole =>
          'Quiero clarificar mi rol ($prioritySummary)',
        IntentionType.wantToUnderstandWorld =>
          'Quiero comprender el entorno ($prioritySummary)',
        IntentionType.wantToBuildLegacy =>
          'Quiero dejar huella ($prioritySummary)',
        IntentionType.wantToDefer => 'Prefiero esperar ($prioritySummary)',
      };

  String _roleModulatedSummary({
    required IntentionType type,
    required String prioritySummary,
    required PersonRole role,
  }) {
    final roleLabel = switch (role) {
      PersonRole.player => 'como jugador',
      PersonRole.manager => 'como entrenador',
      PersonRole.sportingDirector => 'como director deportivo',
      PersonRole.president => 'como presidente',
      PersonRole.scout => 'como scout',
      PersonRole.youthDirector => 'como responsable de cantera',
      PersonRole.scoutingLead => 'como jefe de scouting',
      PersonRole.medicalLead => 'como jefe médico',
    };
    return '${_summaryFor(type, prioritySummary)} $roleLabel';
  }

  double _personalityBoost({
    required IntentionType type,
    required double ambitionNorm,
    required double empathyNorm,
    required double loyaltyNorm,
  }) {
    return switch (type) {
      IntentionType.wantToRegainStatus ||
      IntentionType.wantToAssertLeadership ||
      IntentionType.wantToBuildLegacy => ambitionNorm * 0.08,
      IntentionType.wantToMaintainTrust ||
      IntentionType.wantToTrustPerson ||
      IntentionType.wantToStrengthenSquad => empathyNorm * 0.07,
      IntentionType.wantToAlignWithInstitution ||
      IntentionType.wantToRenew => loyaltyNorm * 0.06,
      _ => 0.0,
    };
  }
}

final class _Mapping {
  const _Mapping({
    required this.type,
    required this.summary,
    required this.strengthBoost,
    required this.status,
  });

  final IntentionType type;
  final String summary;
  final double strengthBoost;
  final IntentionStatus status;
}
