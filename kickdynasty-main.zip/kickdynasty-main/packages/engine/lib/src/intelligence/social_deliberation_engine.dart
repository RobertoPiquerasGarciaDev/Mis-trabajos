/// Motor de deliberación social (PF-10).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/intelligence/deliberation_convocation_selector.dart';

/// Ejecuta protocolos sociales hasta resolución — sin ejecución ni mandato.
final class SocialDeliberationEngine {
  /// Crea el motor.
  const SocialDeliberationEngine({
    DeliberationConvocationSelector convocationSelector =
        const DeliberationConvocationSelector(),
  }) : _convocationSelector = convocationSelector;

  final DeliberationConvocationSelector _convocationSelector;

  /// Delibera socialmente sobre las intenciones del proponente.
  ///
  /// Determinista: mismo contexto → mismo resultado.
  SocialDeliberationResult deliberate({
    required SocialDeliberationContext context,
    required SocialParticipantIndex participants,
  }) {
    final intention = _dominantIntention(context.intentions);
    if (intention == null) {
      return SocialDeliberationResult.deferred(
        convocation: const DeliberationConvocation.deferred(
          reason: 'Sin intenciones activas',
        ),
        sourceIntentionId: IntentionId(
          'intention-empty-${context.proponent.id.value}',
        ),
        rejectedPaths: const ['Sin intenciones para deliberar'],
      );
    }

    final convocation = _convocationSelector.select(
      intention: intention,
      person: context.proponent,
    );
    if (convocation.deferred) {
      return SocialDeliberationResult.deferred(
        convocation: convocation,
        sourceIntentionId: intention.id,
        rejectedPaths: [convocation.reason],
      );
    }

    if (!convocation.requiresSocialProtocol) {
      return _unilateralResult(
        context: context,
        intention: intention,
        convocation: convocation,
      );
    }

    return _socialResult(
      context: context,
      intention: intention,
      convocation: convocation,
      participants: participants,
    );
  }

  IntentionEntry? _dominantIntention(IntentionCollection intentions) {
    final active =
        intentions.entries
            .where((e) => e.status != IntentionStatus.deferred)
            .toList()
          ..sort((a, b) {
            final byStrength = b.strength.value.compareTo(a.strength.value);
            if (byStrength != 0) return byStrength;
            return a.id.value.compareTo(b.id.value);
          });
    return active.isEmpty ? null : active.first;
  }

  SocialDeliberationResult _unilateralResult({
    required SocialDeliberationContext context,
    required IntentionEntry intention,
    required DeliberationConvocation convocation,
  }) {
    return SocialDeliberationResult(
      convocation: convocation,
      sourceIntentionId: intention.id,
      outcome: MandateOutcome.proceed,
      participants: [
        DeliberationParticipant(
          personId: context.proponent.id,
          roleId: context.proponent.role.name,
          stance: ParticipantStance.proponent,
          summary: intention.summary,
        ),
      ],
      proposalSummary: _proposalSummary(intention),
      dissent: const [],
      rejectedPaths: const [],
    );
  }

  SocialDeliberationResult _socialResult({
    required SocialDeliberationContext context,
    required IntentionEntry intention,
    required DeliberationConvocation convocation,
    required SocialParticipantIndex participants,
  }) {
    final protocolType = convocation.protocolType!;
    final instanceId = _instanceId(context: context, intention: intention);
    final clubId = context.clubId;
    if (clubId == null) {
      return SocialDeliberationResult.deferred(
        convocation: convocation,
        sourceIntentionId: intention.id,
        rejectedPaths: const ['Sin club asociado — no se convoca protocolo'],
      );
    }

    final seed = deliberationProtocolSeed(
      worldSeed: context.worldSeed,
      season: context.season,
      week: context.week,
      clubId: clubId.value,
      protocolType: protocolType,
      instanceId: instanceId,
    );

    final protocolParticipants = _buildParticipants(
      context: context,
      intention: intention,
      participants: participants,
      seed: seed,
    );
    final dissent = _collectDissent(protocolParticipants);
    final outcome = _resolveOutcome(
      intention: intention,
      participants: protocolParticipants,
      seed: seed,
    );

    final recordId =
        'dr-${personDerive(personId: context.proponent.id, worldSeed: context.worldSeed, domain: 'decision_record.$instanceId').toRadixString(16).padLeft(16, '0')}';

    final record = DecisionRecord(
      id: recordId,
      protocolType: protocolType,
      clubId: clubId,
      season: context.season,
      week: context.week,
      instanceId: instanceId,
      outcome: outcome,
      participants: protocolParticipants,
      proposalSummary: _proposalSummary(intention),
      dissent: dissent,
    );

    return SocialDeliberationResult(
      convocation: convocation,
      sourceIntentionId: intention.id,
      outcome: outcome,
      participants: protocolParticipants,
      proposalSummary: record.proposalSummary,
      dissent: dissent,
      rejectedPaths: const [],
      protocolType: protocolType,
      instanceId: instanceId,
      decisionRecord: record,
    );
  }

  String _instanceId({
    required SocialDeliberationContext context,
    required IntentionEntry intention,
  }) {
    return 'protocol-${context.proponent.id.value}-${intention.id.value}';
  }

  String _proposalSummary(IntentionEntry intention) =>
      'Propuesta cognitiva: ${intention.summary}';

  List<DeliberationParticipant> _buildParticipants({
    required SocialDeliberationContext context,
    required IntentionEntry intention,
    required SocialParticipantIndex participants,
    required int seed,
  }) {
    final entries = <DeliberationParticipant>[
      DeliberationParticipant(
        personId: context.proponent.id,
        roleId: context.proponent.role.name,
        stance: ParticipantStance.proponent,
        summary: intention.summary,
      ),
    ];

    for (final person in context.clubPersons) {
      if (person.id == context.proponent.id) continue;
      final profile = participants[person.id];
      if (profile == null) continue;
      final stance = _stanceFor(
        proponent: context.proponent,
        participant: person,
        profile: profile,
        seed: seed,
      );
      if (stance == ParticipantStance.inform) continue;
      entries.add(
        DeliberationParticipant(
          personId: person.id,
          roleId: person.role.name,
          stance: stance,
          summary: _stanceSummary(stance, person.role),
        ),
      );
    }

    entries.sort((a, b) => a.personId.value.compareTo(b.personId.value));
    return entries;
  }

  ParticipantStance _stanceFor({
    required Person proponent,
    required Person participant,
    required SocialParticipantProfile profile,
    required int seed,
  }) {
    if (participant.role == PersonRole.president) {
      final prudence = profile.personality.profile.prudence.value / 100.0;
      return prudence >= 0.65
          ? ParticipantStance.veto
          : ParticipantStance.support;
    }
    if (participant.role == PersonRole.sportingDirector &&
        proponent.role == PersonRole.player) {
      return ParticipantStance.support;
    }
    if (participant.role == PersonRole.manager &&
        (proponent.role == PersonRole.sportingDirector ||
            proponent.role == PersonRole.player)) {
      final empathy = profile.personality.profile.empathy.value / 100.0;
      return empathy >= 0.55
          ? ParticipantStance.support
          : ParticipantStance.oppose;
    }

    final raw = personDerive(
      personId: participant.id,
      worldSeed: seed,
      domain: 'social.stance.${proponent.id.value}',
    );
    final norm = (raw.abs() % 1001) / 1000.0;
    if (norm >= 0.75) return ParticipantStance.oppose;
    if (norm >= 0.45) return ParticipantStance.abstain;
    return ParticipantStance.support;
  }

  String _stanceSummary(ParticipantStance stance, PersonRole role) {
    return switch (stance) {
      ParticipantStance.proponent => 'Impulsa la propuesta',
      ParticipantStance.support => 'Apoya la postura (${role.name})',
      ParticipantStance.oppose => 'Se opone (${role.name})',
      ParticipantStance.abstain => 'Se abstiene (${role.name})',
      ParticipantStance.veto => 'Veta la propuesta (${role.name})',
      ParticipantStance.inform => 'Informa sin postura',
    };
  }

  List<String> _collectDissent(List<DeliberationParticipant> participants) {
    return [
      for (final participant in participants)
        if (participant.stance == ParticipantStance.oppose ||
            participant.stance == ParticipantStance.veto)
          participant.summary.isEmpty
              ? 'Oposición de ${participant.roleId}'
              : participant.summary,
    ];
  }

  MandateOutcome _resolveOutcome({
    required IntentionEntry intention,
    required List<DeliberationParticipant> participants,
    required int seed,
  }) {
    if (participants.any((p) => p.stance == ParticipantStance.veto)) {
      return MandateOutcome.reject;
    }
    final opposition = participants
        .where((p) => p.stance == ParticipantStance.oppose)
        .length;
    final support = participants
        .where(
          (p) =>
              p.stance == ParticipantStance.support ||
              p.stance == ParticipantStance.proponent,
        )
        .length;
    if (opposition > support && intention.strength.value < 0.7) {
      return MandateOutcome.defer;
    }
    if (opposition > support + 1) {
      return MandateOutcome.reject;
    }
    final deferBias = (seed.abs() % 1000) / 1000.0;
    if (deferBias < 0.08 && intention.strength.value < 0.55) {
      return MandateOutcome.defer;
    }
    return MandateOutcome.proceed;
  }
}
