/// Vista observable del mundo — frontera Reality → Perception (PF-3).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/season/campaign_state.dart';
import 'package:kickdynasty_engine/src/season/player_overall.dart';
import 'package:meta/meta.dart';

/// Jugador visible sin atributos internos ni potencial.
@immutable
final class ObservablePlayerView {
  /// Crea la vista observable.
  const ObservablePlayerView({
    required this.id,
    required this.clubId,
    required this.name,
    required this.nationality,
    required this.position,
    required this.ageYears,
    required this.fitness,
    required this.morale,
    required this.form,
    required this.skillBandMin,
    required this.skillBandMax,
  });

  /// Identificador del jugador.
  final PlayerId id;

  /// Club al que pertenece.
  final ClubId clubId;

  /// Nombre visible.
  final String name;

  /// Nacionalidad ISO.
  final String nationality;

  /// Posición natural.
  final String position;

  /// Edad en años.
  final int ageYears;

  /// Estado físico observable (0–100).
  final int fitness;

  /// Moral observable (0–100).
  final int morale;

  /// Forma observable (0–100).
  final int form;

  /// Banda inferior de habilidad percibida (sin OVR exacto).
  final int skillBandMin;

  /// Banda superior de habilidad percibida.
  final int skillBandMax;
}

/// Club visible con datos de dominio público.
@immutable
final class ObservableClubView {
  /// Crea la vista observable.
  const ObservableClubView({
    required this.id,
    required this.name,
    required this.reputation,
    required this.country,
  });

  /// Identificador del club.
  final ClubId id;

  /// Nombre visible.
  final String name;

  /// Reputación pública (1–99).
  final int reputation;

  /// País ISO.
  final String country;
}

/// Recorte de Reality con solo hechos observables (PF-3).
@immutable
final class ObservableWorld {
  /// Crea el mundo observable.
  const ObservableWorld({required this.clubs, required this.playersByClub});

  /// Clubes del mundo.
  final List<ObservableClubView> clubs;

  /// Plantillas indexadas por club.
  final Map<ClubId, List<ObservablePlayerView>> playersByClub;

  /// Extrae datos observables desde [state] — único punto de lectura de Reality.
  factory ObservableWorld.fromCampaignState(CampaignState state) {
    final clubs = <ObservableClubView>[];
    final playersByClub = <ClubId, List<ObservablePlayerView>>{};

    for (final generatedClub in state.world.allClubs) {
      final club = generatedClub.club;
      clubs.add(
        ObservableClubView(
          id: club.id,
          name: club.name.value,
          reputation: club.reputation.value,
          country: club.country.value,
        ),
      );

      playersByClub[club.id] = [
        for (final player in generatedClub.squad.players)
          _observablePlayer(player, club.id),
      ];
    }

    return ObservableWorld(clubs: clubs, playersByClub: playersByClub);
  }
}

ObservablePlayerView _observablePlayer(Player player, ClubId clubId) {
  final ovr = playerOverallRating(player);
  final blur = (ovr + player.id.value.hashCode).abs() % 5;
  final min = (ovr - blur - 2).clamp(1, 99);
  final max = (ovr + blur + 2).clamp(1, 99);
  return ObservablePlayerView(
    id: player.id,
    clubId: clubId,
    name: player.name.value,
    nationality: player.nationality.value,
    position: player.position.name,
    ageYears: player.age.years,
    fitness: player.fitness.value,
    morale: player.morale.value,
    form: player.form.value,
    skillBandMin: min,
    skillBandMax: max,
  );
}
