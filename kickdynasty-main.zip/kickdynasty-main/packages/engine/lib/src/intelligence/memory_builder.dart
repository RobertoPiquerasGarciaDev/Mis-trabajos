/// Constructor determinista de recuerdos desde percepción (PF-4).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Construye [MemoryCollection] sin interpretar ni acceder a Reality.
final class MemoryBuilder {
  /// Crea el builder.
  const MemoryBuilder();

  /// Consolida hechos percibidos en recuerdos estructurados.
  ///
  /// PF-4: mapeo 1:1 desde [PerceptionSnapshot.facts] — sin olvido activo.
  /// Determinista: mismos inputs → misma colección.
  MemoryCollection buildFromPerception({
    required PersonId ownerId,
    required PerceptionSnapshot snapshot,
    required int worldSeed,
  }) {
    final timestamp = MemoryTimestamp(
      season: snapshot.season,
      week: snapshot.week,
    );
    final entries = [
      for (final fact in snapshot.facts)
        _entryFromFact(
          ownerId: ownerId,
          snapshot: snapshot,
          fact: fact,
          timestamp: timestamp,
          worldSeed: worldSeed,
        ),
    ]..sort((a, b) => a.id.value.compareTo(b.id.value));

    return MemoryCollection(ownerId: ownerId, entries: entries);
  }

  MemoryEntry _entryFromFact({
    required PersonId ownerId,
    required PerceptionSnapshot snapshot,
    required PerceivedFact fact,
    required MemoryTimestamp timestamp,
    required int worldSeed,
  }) {
    final importanceRaw = personDerive(
      personId: ownerId,
      worldSeed: worldSeed,
      domain: 'memory.importance.${fact.subjectId}.${fact.factKey}',
    ).abs();
    final importance = MemoryImportance(
      (0.3 + (importanceRaw % 501) / 1000.0).clamp(0.0, 1.0),
    );
    final decayRateRaw = personDerive(
      personId: ownerId,
      worldSeed: worldSeed,
      domain: 'memory.decayRate.${fact.factKey}',
    ).abs();

    return MemoryEntry(
      id: _memoryId(
        ownerId: ownerId,
        worldSeed: worldSeed,
        snapshot: snapshot,
        fact: fact,
      ),
      ownerId: ownerId,
      type: MemoryType.perceivedFact,
      whatHappened: '${fact.factKey}=${fact.value}',
      subjectId: fact.subjectId,
      involvedPersonIds: const [],
      perceivedAt: timestamp,
      source: fact.source,
      origin: fact.origin,
      confidenceAtCapture: fact.confidence,
      importance: importance,
      strength: MemoryStrength(fact.confidence.value),
      decay: MemoryDecay(
        decayRate: (decayRateRaw % 1001) / 10000.0,
        lastRecall: timestamp,
      ),
      factKey: fact.factKey,
      perceivedValue: fact.value,
    );
  }

  MemoryId _memoryId({
    required PersonId ownerId,
    required int worldSeed,
    required PerceptionSnapshot snapshot,
    required PerceivedFact fact,
  }) {
    final raw = personDerive(
      personId: ownerId,
      worldSeed: worldSeed,
      domain:
          'memory.id.${snapshot.season}.${snapshot.week}.${fact.subjectId}.${fact.factKey}',
    );
    return MemoryId('memory-${raw.toRadixString(16).padLeft(16, '0')}');
  }
}
