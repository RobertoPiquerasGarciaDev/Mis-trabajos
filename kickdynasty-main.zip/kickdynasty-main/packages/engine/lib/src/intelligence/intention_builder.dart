/// Constructor determinista de intenciones (PF-9).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Consolida [DeliberationResult] en [IntentionCollection].
final class IntentionBuilder {
  /// Crea el builder.
  const IntentionBuilder();

  /// Genera intenciones desde candidatos de deliberación.
  ///
  /// Determinista: mismos inputs → mismas intenciones.
  IntentionCollection build({
    required Person person,
    required DeliberationResult result,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final timestamp = MemoryTimestamp(season: season, week: week);
    final entries = [
      for (final candidate in result.candidates)
        IntentionEntry(
          id: IntentionId(
            'intention-${personDerive(personId: person.id, worldSeed: worldSeed, domain: 'intention.id.${candidate.sourcePriorityId.value}').toRadixString(16).padLeft(16, '0')}',
          ),
          observerPersonId: person.id,
          sourcePriorityId: candidate.sourcePriorityId,
          type: candidate.type,
          summary: candidate.summary,
          strength: candidate.tentativeStrength,
          status: candidate.status,
          createdAt: candidate.createdAt,
          updatedAt: timestamp,
        ),
    ]..sort((a, b) => a.id.value.compareTo(b.id.value));

    return IntentionCollection(ownerId: person.id, entries: entries);
  }
}
