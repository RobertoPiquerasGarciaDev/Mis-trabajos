/// Índice persona → club para percepción (PF-3).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/season/campaign_state.dart';
import 'package:kickdynasty_engine/src/worldgen/person_generator.dart';

/// Construye el mapa persona → club afiliado desde el estado de campaña.
Map<PersonId, ClubId> buildPersonClubIndex(CampaignState state) {
  final worldSeed = state.world.seed;
  final index = <PersonId, ClubId>{};

  for (final generatedClub in state.world.allClubs) {
    final clubId = generatedClub.club.id;
    for (final role in minimumStaffRoles) {
      index[syntheticStaffPersonId(
            worldSeed: worldSeed,
            clubId: clubId,
            role: role,
          )] =
          clubId;
    }
    for (final player in generatedClub.squad.players) {
      final personId =
          player.personId ??
          syntheticPlayerPersonId(worldSeed: worldSeed, playerId: player.id);
      index[personId] = clubId;
    }
  }

  return index;
}

/// Construye el mapa persona → jugador vinculado (solo roles player).
Map<PersonId, PlayerId> buildPersonPlayerIndex(CampaignState state) {
  final worldSeed = state.world.seed;
  final index = <PersonId, PlayerId>{};

  for (final generatedClub in state.world.allClubs) {
    for (final player in generatedClub.squad.players) {
      final personId =
          player.personId ??
          syntheticPlayerPersonId(worldSeed: worldSeed, playerId: player.id);
      index[personId] = player.id;
    }
  }

  return index;
}
