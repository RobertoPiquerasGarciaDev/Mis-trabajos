/// Ranking determinista de prioridades (PF-9).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Ordena candidatos y produce [PriorityCollection].
final class PriorityRanker {
  /// Crea el ranker.
  const PriorityRanker();

  /// Asigna rango y tipo de foco a cada candidato.
  ///
  /// Determinista: mismos inputs → misma colección.
  PriorityCollection rank({
    required Person person,
    required List<PriorityCandidate> candidates,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final sorted = [...candidates]
      ..sort((a, b) {
        final byStrength = b.tentativeStrength.value.compareTo(
          a.tentativeStrength.value,
        );
        if (byStrength != 0) return byStrength;
        return a.sourceGoalId.value.compareTo(b.sourceGoalId.value);
      });

    final timestamp = MemoryTimestamp(season: season, week: week);
    final entries = <PriorityEntry>[];

    for (var i = 0; i < sorted.length; i++) {
      final candidate = sorted[i];
      final rank = PriorityRank(i + 1);
      final type = switch (rank.value) {
        1 => PriorityType.dominant,
        2 || 3 => PriorityType.active,
        _ => PriorityType.latent,
      };
      final raw = personDerive(
        personId: person.id,
        worldSeed: worldSeed,
        domain: 'priority.id.${candidate.sourceGoalId.value}',
      );
      entries.add(
        PriorityEntry(
          id: PriorityId('priority-${raw.toRadixString(16).padLeft(16, '0')}'),
          observerPersonId: person.id,
          sourceGoalId: candidate.sourceGoalId,
          goalType: candidate.goalType,
          summary: candidate.summary,
          strength: candidate.tentativeStrength,
          rank: rank,
          type: type,
          origin: candidate.origin,
          reason: candidate.reason,
          createdAt: candidate.createdAt,
          updatedAt: timestamp,
        ),
      );
    }

    return PriorityCollection(ownerId: person.id, entries: entries);
  }
}
