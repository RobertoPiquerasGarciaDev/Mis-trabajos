/// Tick cognitivo no-op (PF-2).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Ejecuta un tick cognitivo — PF-2: devuelve la mente sin cambios.
AgentMind tickAgentMind(
  AgentMind mind, {
  AgentMindTickDepth depth = AgentMindTickDepth.shallow,
}) {
  return mind;
}
