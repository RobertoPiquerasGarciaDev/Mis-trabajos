/// Selector determinista de convocatoria social (PF-10).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Evalúa si una intención requiere protocolo social o puede ser unilateral.
final class DeliberationConvocationSelector {
  /// Crea el selector.
  const DeliberationConvocationSelector();

  /// Determina la convocatoria para una intención.
  DeliberationConvocation select({
    required IntentionEntry intention,
    required Person person,
  }) {
    if (intention.status == IntentionStatus.deferred ||
        intention.type == IntentionType.wantToDefer) {
      return DeliberationConvocation.deferred(
        reason: 'Intención en diferimiento — sin compromiso suficiente',
      );
    }
    if (intention.strength.value < 0.35) {
      return DeliberationConvocation.deferred(
        reason: 'Postura demasiado débil para escalar',
      );
    }

    return switch (intention.type) {
      IntentionType.wantToSellPlayer => DeliberationConvocation.protocol(
        type: DeliberationProtocolType.transferOutDeliberation,
        reason: 'La intención de vender requiere protocolo institucional',
      ),
      IntentionType.wantToLeaveClub => DeliberationConvocation.protocol(
        type: DeliberationProtocolType.transferOutDeliberation,
        reason: 'La intención de salir requiere protocolo de salida',
      ),
      IntentionType.wantToRenew => DeliberationConvocation.protocol(
        type: DeliberationProtocolType.renewalDeliberation,
        reason: 'La intención de renovar requiere protocolo contractual',
      ),
      IntentionType.wantToBetOnYouth => DeliberationConvocation.protocol(
        type: DeliberationProtocolType.promotionDeliberation,
        reason: 'Apostar por cantera requiere protocolo de promoción',
      ),
      IntentionType.wantToAssertLeadership || IntentionType.wantToClarifyRole
          when person.role == PersonRole.manager =>
        DeliberationConvocation.unilateral(
          reason:
              'El entrenador puede consolidar postura táctica unilateralmente',
        ),
      IntentionType.wantToStrengthenSquad
          when person.role == PersonRole.manager =>
        DeliberationConvocation.unilateral(
          reason:
              'El entrenador puede sostener postura de grupo unilateralmente',
        ),
      IntentionType.wantToUnderstandWorld when _isPeripheralRole(person.role) =>
        DeliberationConvocation.unilateral(
          reason: 'Postura informativa sin impacto institucional directo',
        ),
      _ => DeliberationConvocation.unilateral(
        reason: 'Consolidación unilateral desde intención interna',
      ),
    };
  }

  bool _isPeripheralRole(PersonRole role) =>
      role == PersonRole.scout ||
      role == PersonRole.scoutingLead ||
      role == PersonRole.medicalLead;
}
