/// Constructor determinista de objetivos (PF-8).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Construye [GoalCollection] solo desde creencias y perfil cognitivo.
final class GoalBuilder {
  /// Crea el builder.
  const GoalBuilder();

  /// Genera objetivos desde creencias existentes.
  ///
  /// Determinista: mismos inputs → mismos objetivos.
  GoalCollection build({
    required Person person,
    required BeliefCollection beliefs,
    required PersonalitySnapshot personality,
    required int worldSeed,
    required int season,
    required int week,
  }) {
    final candidates = _candidatesFromBeliefs(
      person: person,
      beliefs: beliefs,
      personality: personality,
    );
    final timestamp = MemoryTimestamp(season: season, week: week);
    final entries = [
      for (final candidate in candidates)
        _goalFromCandidate(
          candidate: candidate,
          person: person,
          personality: personality,
          worldSeed: worldSeed,
          timestamp: timestamp,
        ),
    ]..sort((a, b) => a.id.value.compareTo(b.id.value));
    return GoalCollection(ownerId: person.id, entries: entries);
  }

  List<GoalCandidate> _candidatesFromBeliefs({
    required Person person,
    required BeliefCollection beliefs,
    required PersonalitySnapshot personality,
  }) {
    final candidates = <GoalCandidate>[];
    for (final belief in beliefs.entries) {
      final type = _typeFor(belief.type);
      final category = _categoryFor(belief.category, belief.type, person);
      final summary = _summaryFor(belief.type, belief.summary);
      final priority = GoalPriority(
        (belief.confidence.value * 0.7 + belief.strength.value * 0.3).clamp(
          0.0,
          1.0,
        ),
      );
      final strength = GoalStrength(
        (belief.strength.value * 0.8 + belief.confidence.value * 0.2).clamp(
          0.0,
          1.0,
        ),
      );
      candidates.add(
        GoalCandidate(
          observerPersonId: person.id,
          sourceBeliefId: belief.id,
          type: type,
          category: category,
          summary: summary,
          tentativePriority: priority,
          tentativeStrength: strength,
          createdAt: belief.createdAt,
        ),
      );
    }
    candidates.sort(
      (a, b) => a.sourceBeliefId.value.compareTo(b.sourceBeliefId.value),
    );
    return candidates;
  }

  GoalEntry _goalFromCandidate({
    required GoalCandidate candidate,
    required Person person,
    required PersonalitySnapshot personality,
    required int worldSeed,
    required MemoryTimestamp timestamp,
  }) {
    final modulation = _modulation(
      candidate: candidate,
      person: person,
      personality: personality,
    );
    final raw = personDerive(
      personId: person.id,
      worldSeed: worldSeed,
      domain: 'goal.id.${candidate.sourceBeliefId.value}',
    );

    return GoalEntry(
      id: GoalId('goal-${raw.toRadixString(16).padLeft(16, '0')}'),
      observerPersonId: person.id,
      type: candidate.type,
      category: modulation.category,
      summary: modulation.summary,
      priority: GoalPriority(
        (candidate.tentativePriority.value + modulation.priorityDelta).clamp(
          0.0,
          1.0,
        ),
      ),
      strength: GoalStrength(
        (candidate.tentativeStrength.value + modulation.strengthDelta).clamp(
          0.0,
          1.0,
        ),
      ),
      origin: modulation.origin,
      status: GoalStatus.active,
      timeHorizon: _timeHorizonFor(candidate.type, person),
      sourceBeliefIds: [candidate.sourceBeliefId],
      createdAt: candidate.createdAt,
      updatedAt: timestamp,
      lastReviewed: timestamp,
    );
  }

  GoalType _typeFor(BeliefType type) => switch (type) {
    BeliefType.trust => GoalType.maintainTrust,
    BeliefType.lossOfStatus => GoalType.regainStatus,
    BeliefType.selfImprovement => GoalType.improveSelf,
    BeliefType.protection => GoalType.seekProtection,
    BeliefType.leadership => GoalType.assertLeadership,
    BeliefType.institutionalSupport => GoalType.alignWithInstitution,
    BeliefType.squadCohesion => GoalType.strengthenSquad,
    BeliefType.roleClarity => GoalType.clarifyRole,
    BeliefType.worldView => GoalType.understandWorld,
  };

  GoalCategory _categoryFor(
    BeliefCategory category,
    BeliefType type,
    Person person,
  ) {
    final base = switch (category) {
      BeliefCategory.self => GoalCategory.personal,
      BeliefCategory.otherPerson => GoalCategory.social,
      BeliefCategory.club => GoalCategory.institutional,
      BeliefCategory.competition => GoalCategory.sporting,
      BeliefCategory.career => GoalCategory.professional,
      BeliefCategory.world => GoalCategory.world,
    };
    if (type == BeliefType.selfImprovement &&
        person.personality.ambition.value >= 70) {
      return GoalCategory.legacy;
    }
    if (type == BeliefType.protection && person.values.security.value >= 65) {
      return GoalCategory.financial;
    }
    return base;
  }

  String _summaryFor(BeliefType type, String beliefSummary) {
    final normalized = beliefSummary.toLowerCase().trim();
    return switch (type) {
      BeliefType.trust =>
        'Quiero mantener la confianza que percibo ($normalized)',
      BeliefType.lossOfStatus =>
        'Quiero recuperar el estatus que siento que pierdo ($normalized)',
      BeliefType.selfImprovement =>
        'Quiero mejorar en lo que considero mis debilidades ($normalized)',
      BeliefType.protection =>
        'Quiero sentirme protegido en mi entorno ($normalized)',
      BeliefType.leadership =>
        'Quiero ejercer o consolidar mi liderazgo ($normalized)',
      BeliefType.institutionalSupport =>
        'Quiero alinearme con el apoyo institucional que percibo ($normalized)',
      BeliefType.squadCohesion =>
        'Quiero fortalecer la cohesión del grupo ($normalized)',
      BeliefType.roleClarity =>
        'Quiero clarificar mi rol dentro del equipo ($normalized)',
      BeliefType.worldView =>
        'Quiero comprender mejor mi entorno ($normalized)',
    };
  }

  GoalTimeHorizon _timeHorizonFor(GoalType type, Person person) {
    if (type == GoalType.buildLegacy ||
        (type == GoalType.improveSelf &&
            person.personality.ambition.value >= 75)) {
      return GoalTimeHorizon.longTerm;
    }
    return switch (type) {
      GoalType.maintainTrust ||
      GoalType.seekProtection ||
      GoalType.clarifyRole => GoalTimeHorizon.shortTerm,
      GoalType.regainStatus ||
      GoalType.assertLeadership ||
      GoalType.strengthenSquad => GoalTimeHorizon.mediumTerm,
      GoalType.alignWithInstitution ||
      GoalType.understandWorld => GoalTimeHorizon.permanent,
      GoalType.improveSelf => GoalTimeHorizon.mediumTerm,
      GoalType.buildLegacy => GoalTimeHorizon.longTerm,
    };
  }

  _Modulation _modulation({
    required GoalCandidate candidate,
    required Person person,
    required PersonalitySnapshot personality,
  }) {
    var priorityDelta = 0.0;
    var strengthDelta = 0.0;
    var origin = GoalOrigin.beliefDerived;
    var category = candidate.category;
    var summary = candidate.summary;

    final profile = personality.profile;
    final ambitionNorm = profile.ambition.value / 100.0;
    final empathyNorm = profile.empathy.value / 100.0;
    final loyaltyNorm = person.values.loyalty.value / 100.0;
    final pragmatismNorm = person.philosophy.pragmatism.value / 100.0;

    switch (candidate.type) {
      case GoalType.regainStatus ||
          GoalType.improveSelf ||
          GoalType.assertLeadership:
        priorityDelta += ambitionNorm * 0.08;
        strengthDelta += ambitionNorm * 0.06;
        if (ambitionNorm >= 0.65) origin = GoalOrigin.personalityModulated;
      case GoalType.maintainTrust || GoalType.strengthenSquad:
        priorityDelta += empathyNorm * 0.06;
        strengthDelta += empathyNorm * 0.05;
        if (empathyNorm >= 0.6 && origin == GoalOrigin.beliefDerived) {
          origin = GoalOrigin.personalityModulated;
        }
      case GoalType.alignWithInstitution:
        priorityDelta += loyaltyNorm * 0.07;
        strengthDelta += pragmatismNorm * 0.05;
        if (loyaltyNorm >= 0.6) origin = GoalOrigin.valuesModulated;
        if (pragmatismNorm >= 0.6 && origin == GoalOrigin.beliefDerived) {
          origin = GoalOrigin.philosophyModulated;
        }
      case GoalType.seekProtection:
        final securityNorm = person.values.security.value / 100.0;
        priorityDelta += securityNorm * 0.07;
        if (securityNorm >= 0.65) {
          origin = GoalOrigin.valuesModulated;
          category = GoalCategory.financial;
          summary =
              'Quiero sentir estabilidad y protección en mi situación ($summary)';
        }
      case GoalType.clarifyRole ||
          GoalType.understandWorld ||
          GoalType.buildLegacy:
        break;
    }

    if (candidate.type == GoalType.improveSelf &&
        person.personality.ambition.value >= 80) {
      category = GoalCategory.legacy;
      summary = 'Quiero dejar huella mejorando como profesional ($summary)';
      if (origin == GoalOrigin.beliefDerived) {
        origin = GoalOrigin.personalityModulated;
      }
    }

    return _Modulation(
      priorityDelta: priorityDelta,
      strengthDelta: strengthDelta,
      origin: origin,
      category: category,
      summary: summary,
    );
  }
}

final class _Modulation {
  const _Modulation({
    required this.priorityDelta,
    required this.strengthDelta,
    required this.origin,
    required this.category,
    required this.summary,
  });

  final double priorityDelta;
  final double strengthDelta;
  final GoalOrigin origin;
  final GoalCategory category;
  final String summary;
}
