/// Constructor determinista de candidatos a prioridad (PF-9).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Construye [PriorityCandidate] solo desde Goals y perfil cognitivo.
final class PriorityBuilder {
  /// Crea el builder.
  const PriorityBuilder();

  /// Genera candidatos desde objetivos activos.
  ///
  /// Determinista: mismos inputs → mismos candidatos.
  List<PriorityCandidate> buildCandidates({
    required Person person,
    required GoalCollection goals,
    required PersonalitySnapshot personality,
    required EmotionalState emotion,
    required MemoryCollection memory,
    required RelationState relations,
    required int season,
    required int week,
  }) {
    final timestamp = MemoryTimestamp(season: season, week: week);
    final candidates = <PriorityCandidate>[];

    for (final goal in goals.entries) {
      if (goal.status != GoalStatus.active) continue;
      final modulation = _modulation(
        goal: goal,
        person: person,
        personality: personality,
        emotion: emotion,
        memory: memory,
        relations: relations,
      );
      candidates.add(
        PriorityCandidate(
          observerPersonId: person.id,
          sourceGoalId: goal.id,
          goalType: goal.type,
          summary: 'Atención hacia: ${goal.summary}',
          tentativeStrength: PriorityStrength(
            (goal.priority.value * 0.45 +
                    goal.strength.value * 0.35 +
                    modulation.strengthDelta)
                .clamp(0.0, 1.0),
          ),
          origin: modulation.origin,
          reason: modulation.reason,
          createdAt: timestamp,
        ),
      );
    }

    candidates.sort(
      (a, b) => a.sourceGoalId.value.compareTo(b.sourceGoalId.value),
    );
    return candidates;
  }

  _Modulation _modulation({
    required GoalEntry goal,
    required Person person,
    required PersonalitySnapshot personality,
    required EmotionalState emotion,
    required MemoryCollection memory,
    required RelationState relations,
  }) {
    var strengthDelta = 0.0;
    var origin = PriorityOrigin.goalDerived;
    var reason = PriorityReason.goalStrength;

    final profile = personality.profile;
    final ambitionNorm = profile.ambition.value / 100.0;
    final empathyNorm = profile.empathy.value / 100.0;
    final emotionalNorm = profile.emotionalStability.value / 100.0;

    switch (goal.type) {
      case GoalType.regainStatus || GoalType.assertLeadership:
        final prideBoost = emotion.woundedPride * 0.12;
        strengthDelta += ambitionNorm * 0.08 + prideBoost;
        if (prideBoost >= 0.06) {
          origin = PriorityOrigin.emotionModulated;
          reason = PriorityReason.emotionalPressure;
        } else if (ambitionNorm >= 0.6) {
          origin = PriorityOrigin.personalityModulated;
          reason = PriorityReason.personalityFocus;
        }
      case GoalType.seekProtection:
        final fearBoost = (emotion.fear + emotion.anxiety) * 0.06;
        strengthDelta += fearBoost + (1 - emotionalNorm) * 0.04;
        if (fearBoost >= 0.05) {
          origin = PriorityOrigin.emotionModulated;
          reason = PriorityReason.emotionalPressure;
        }
      case GoalType.maintainTrust || GoalType.strengthenSquad:
        strengthDelta += empathyNorm * 0.07;
        if (empathyNorm >= 0.6) {
          origin = PriorityOrigin.personalityModulated;
          reason = PriorityReason.personalityFocus;
        }
      case GoalType.alignWithInstitution:
        final loyaltyNorm = person.values.loyalty.value / 100.0;
        strengthDelta += loyaltyNorm * 0.06;
        if (loyaltyNorm >= 0.65) {
          origin = PriorityOrigin.personalityModulated;
          reason = PriorityReason.roleContext;
        }
      case GoalType.clarifyRole:
        strengthDelta += (1 - emotionalNorm) * 0.05;
        reason = PriorityReason.roleContext;
      case GoalType.improveSelf ||
          GoalType.understandWorld ||
          GoalType.buildLegacy:
        break;
    }

    final memoryBoost = _memoryResonance(memory);
    if (memoryBoost >= 0.04) {
      strengthDelta += memoryBoost;
      if (origin == PriorityOrigin.goalDerived) {
        origin = PriorityOrigin.memoryModulated;
        reason = PriorityReason.memoryResonance;
      }
    }

    final relationBoost = _relationInfluence(relations, person.id);
    if (relationBoost >= 0.04) {
      strengthDelta += relationBoost;
      if (origin == PriorityOrigin.goalDerived ||
          origin == PriorityOrigin.memoryModulated) {
        origin = PriorityOrigin.relationModulated;
        reason = PriorityReason.relationInfluence;
      }
    }

    return _Modulation(
      strengthDelta: strengthDelta,
      origin: origin,
      reason: reason,
    );
  }

  double _memoryResonance(MemoryCollection memory) {
    if (memory.entries.isEmpty) return 0;
    final avg =
        memory.entries.map((e) => e.strength.value).reduce((a, b) => a + b) /
        memory.entries.length;
    return (avg * 0.08).clamp(0.0, 0.1);
  }

  double _relationInfluence(RelationState relations, PersonId observerId) {
    final relevant = relations.entries
        .where((e) => e.observerPersonId == observerId)
        .toList();
    if (relevant.isEmpty) return 0;
    final avgTrust =
        relevant.map((e) => e.trust.value).reduce((a, b) => a + b) /
        relevant.length;
    return ((avgTrust.abs()) * 0.08).clamp(0.0, 0.08);
  }
}

final class _Modulation {
  const _Modulation({
    required this.strengthDelta,
    required this.origin,
    required this.reason,
  });

  final double strengthDelta;
  final PriorityOrigin origin;
  final PriorityReason reason;
}
