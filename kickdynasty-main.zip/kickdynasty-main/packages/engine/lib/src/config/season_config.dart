/// Configuración de la temporada (ADR 0005: balance como datos).
///
/// Todo lo que gobierna el ciclo entre jornadas (fatiga y recuperación,
/// moral, forma) y el cierre de temporada (progresión, envejecimiento,
/// retiros, regens, ascensos y descensos) vive aquí. La suite
/// `--tags balance` valida que estos números mantienen una población de
/// jugadores estable a varias temporadas.
library;

import 'package:kickdynasty_engine/src/config/world_gen_config.dart';
import 'package:meta/meta.dart';

/// Ciclo de condición física, moral y forma entre jornadas.
@immutable
final class ConditionCycleModel {
  /// Crea el modelo.
  const ConditionCycleModel({
    required this.starterFatigue,
    required this.substituteFatigue,
    required this.recoveryFraction,
    required this.injuredFitness,
    required this.moraleWin,
    required this.moraleDraw,
    required this.moraleLoss,
    required this.moraleBaseline,
    required this.moraleReversion,
    required this.formUpdateFactor,
    required this.formDecayFactor,
    required this.formNeutral,
  });

  /// Puntos de estado físico que pierde un titular por partido.
  final int starterFatigue;

  /// Puntos de estado físico que pierde un suplente que entró.
  final int substituteFatigue;

  /// Fracción del déficit de estado físico que se recupera cada semana.
  ///
  /// Un titular fijo se estabiliza en torno a 88; un jugador que descansa
  /// converge a 100. De ahí sale la presión de rotación.
  final double recoveryFraction;

  /// Estado físico al que cae un jugador lesionado en partido. Con la
  /// recuperación semanal tarda 3–4 jornadas en volver a estar pleno.
  final int injuredFitness;

  /// Moral que gana toda la plantilla con una victoria.
  final int moraleWin;

  /// Moral que gana la plantilla con un empate.
  final int moraleDraw;

  /// Moral que pierde la plantilla con una derrota (valor negativo).
  final int moraleLoss;

  /// Moral hacia la que revierte lentamente toda la plantilla.
  final int moraleBaseline;

  /// Fracción de reversión semanal hacia [moraleBaseline].
  final double moraleReversion;

  /// Fracción de acercamiento de la forma del participante hacia el nivel
  /// marcado por su valoración de partido.
  final double formUpdateFactor;

  /// Fracción de decaimiento semanal de la forma de quien no juega hacia
  /// [formNeutral].
  final double formDecayFactor;

  /// Forma neutral.
  final int formNeutral;
}

/// Progresión, envejecimiento y retiros al cierre de temporada.
@immutable
final class DevelopmentModel {
  /// Crea el modelo.
  const DevelopmentModel({
    required this.growthFractionByMaxAge,
    required this.maxGrowthPerSeason,
    required this.declinePointsByMinAge,
    required this.physicalDeclineFactor,
    required this.technicalDeclineFactor,
    required this.developmentNoise,
    required this.retirementChanceByAge,
    required this.forcedRetirementAge,
    required this.regenAgeRange,
    required this.preseasonFitness,
  });

  /// Fracción del margen de mejora (potencial − mejor atributo) que se
  /// gana por temporada, según la edad: lista de `(edad máxima, fracción)`
  /// ordenada; la primera banda cuya edad máxima cubre al jugador aplica.
  final List<(int maxAge, double fraction)> growthFractionByMaxAge;

  /// Tope de puntos de mejora por atributo y temporada.
  final double maxGrowthPerSeason;

  /// Puntos de declive por temporada según la edad: lista de
  /// `(edad mínima, puntos)` ordenada descendente; la primera banda cuya
  /// edad mínima cubre al jugador aplica.
  final List<(int minAge, double points)> declinePointsByMinAge;

  /// Multiplicador del declive sobre atributos físicos (ritmo, resistencia,
  /// fuerza).
  final double physicalDeclineFactor;

  /// Multiplicador del declive sobre el resto de atributos.
  final double technicalDeclineFactor;

  /// Ruido gaussiano del desarrollo (puntos por atributo).
  final double developmentNoise;

  /// Probabilidad de retiro al cierre de temporada según la edad cumplida.
  final Map<int, double> retirementChanceByAge;

  /// Edad a la que el retiro es seguro.
  final int forcedRetirementAge;

  /// Edad de los canteranos que reemplazan a los retirados.
  final IntRange regenAgeRange;

  /// Estado físico con el que se arranca la pretemporada.
  final IntRange preseasonFitness;

  /// Fracción de crecimiento para [age].
  double growthFractionFor(int age) {
    for (final (maxAge, fraction) in growthFractionByMaxAge) {
      if (age <= maxAge) return fraction;
    }
    return 0;
  }

  /// Puntos de declive para [age].
  double declinePointsFor(int age) {
    for (final (minAge, points) in declinePointsByMinAge) {
      if (age >= minAge) return points;
    }
    return 0;
  }

  /// Probabilidad de retiro para [age].
  double retirementChanceFor(int age) {
    if (age >= forcedRetirementAge) return 1;
    return retirementChanceByAge[age] ?? 0;
  }
}

/// Configuración completa de la temporada.
@immutable
final class SeasonConfig {
  /// Crea una configuración a medida.
  const SeasonConfig({
    required this.condition,
    required this.development,
    required this.promotionRelegationCount,
  });

  /// Ciclo de condición entre jornadas.
  final ConditionCycleModel condition;

  /// Desarrollo de jugadores al cierre de temporada.
  final DevelopmentModel development;

  /// Clubes que intercambian categoría entre niveles adyacentes al cierre
  /// de temporada (descienden los últimos N, ascienden los primeros N).
  final int promotionRelegationCount;

  /// Configuración estándar del juego, validada por la suite `balance`.
  factory SeasonConfig.standard() => const SeasonConfig(
    condition: ConditionCycleModel(
      starterFatigue: 14,
      substituteFatigue: 6,
      recoveryFraction: 0.55,
      injuredFitness: 35,
      moraleWin: 5,
      moraleDraw: 1,
      moraleLoss: -5,
      moraleBaseline: 60,
      moraleReversion: 0.08,
      formUpdateFactor: 0.35,
      formDecayFactor: 0.15,
      formNeutral: 50,
    ),
    development: DevelopmentModel(
      growthFractionByMaxAge: [(20, 0.40), (23, 0.28), (26, 0.14)],
      maxGrowthPerSeason: 3,
      declinePointsByMinAge: [(36, 3.5), (33, 2.2), (30, 1.2)],
      physicalDeclineFactor: 1.5,
      technicalDeclineFactor: 0.7,
      developmentNoise: 0.8,
      retirementChanceByAge: {
        33: 0.05,
        34: 0.12,
        35: 0.25,
        36: 0.45,
        37: 0.65,
        38: 0.85,
      },
      forcedRetirementAge: 39,
      regenAgeRange: IntRange(16, 19),
      preseasonFitness: IntRange(88, 98),
    ),
    promotionRelegationCount: 3,
  );
}
