/// Configuración del motor de partidos (ADR 0005: balance como datos).
///
/// Todas las constantes que determinan cómo se juega un partido viven aquí.
/// La suite `--tags balance` valida que estos números producen un juego
/// sano (goles por partido, correlación fuerza-resultado, disciplina);
/// cambiarlos sin pasar esa suite rompe el CI.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/attribute_model.dart';
import 'package:meta/meta.dart';

/// Multiplicadores de una táctica sobre las tres unidades del equipo.
@immutable
final class UnitModifiers {
  /// Crea los multiplicadores; 1.0 = neutro.
  const UnitModifiers({this.attack = 1, this.midfield = 1, this.defence = 1});

  /// Factor sobre la unidad de ataque.
  final double attack;

  /// Factor sobre la unidad de mediocampo.
  final double midfield;

  /// Factor sobre la unidad de defensa.
  final double defence;
}

/// Perfil de una unidad (defensa, mediocampo o ataque): cuánto aporta cada
/// línea del campo y con qué atributos se mide esa aportación.
@immutable
final class UnitModel {
  /// Crea el perfil de la unidad.
  const UnitModel({required this.contributions, required this.roleWeights});

  /// Peso de cada línea del campo en la unidad.
  final Map<PositionGroup, double> contributions;

  /// Atributos (y su peso) con los que un jugador de cada línea aporta a la
  /// unidad. Los pesos de cada línea deben sumar 1.
  final Map<PositionGroup, Map<AttributeKey, double>> roleWeights;
}

/// Penalizaciones por jugar fuera de la posición natural.
@immutable
final class PositionPenalties {
  /// Crea la tabla de penalizaciones (factores multiplicativos, 1 = sin
  /// penalización).
  const PositionPenalties({
    required this.samePosition,
    required this.sameGroup,
    required this.adjacentGroup,
    required this.farGroup,
    required this.crossGoalkeeper,
  });

  /// En su posición exacta.
  final double samePosition;

  /// Otra posición de su misma línea.
  final double sameGroup;

  /// Línea contigua (p. ej. central jugando de mediocentro).
  final double adjacentGroup;

  /// Dos o más líneas de distancia (defensa ↔ ataque).
  final double farGroup;

  /// Portero jugando fuera o jugador de campo bajo palos.
  final double crossGoalkeeper;
}

/// Modelo de fuerza de equipo: condición, fatiga, posición y táctica.
@immutable
final class StrengthModel {
  /// Crea el modelo.
  const StrengthModel({
    required this.positionPenalties,
    required this.fitnessFloor,
    required this.formSwing,
    required this.moraleSwing,
    required this.fatiguePerMinute,
    required this.goalkeeperFatigueFactor,
    required this.defenceUnit,
    required this.midfieldUnit,
    required this.attackUnit,
    required this.mentalityModifiers,
    required this.defensiveLineModifiers,
    required this.widthModifiers,
    required this.passingModifiers,
    required this.possessionElasticity,
  });

  /// Penalizaciones por jugar fuera de posición.
  final PositionPenalties positionPenalties;

  /// Factor de condición con estado físico 0 (con 100 el factor es 1).
  final double fitnessFloor;

  /// Amplitud del efecto de la forma (±swing/2 entre forma 0 y 100).
  final double formSwing;

  /// Amplitud del efecto de la moral (±swing/2 entre moral 0 y 100).
  final double moraleSwing;

  /// Puntos de estado físico efectivo perdidos por minuto jugado.
  final double fatiguePerMinute;

  /// Fracción de la fatiga que sufre el portero.
  final double goalkeeperFatigueFactor;

  /// Perfil de la unidad defensiva.
  final UnitModel defenceUnit;

  /// Perfil de la unidad de mediocampo.
  final UnitModel midfieldUnit;

  /// Perfil de la unidad ofensiva.
  final UnitModel attackUnit;

  /// Efecto de la mentalidad sobre las unidades.
  final Map<Mentality, UnitModifiers> mentalityModifiers;

  /// Efecto de la altura de la línea defensiva.
  final Map<DefensiveLine, UnitModifiers> defensiveLineModifiers;

  /// Efecto de la amplitud.
  final Map<Width, UnitModifiers> widthModifiers;

  /// Efecto del estilo de pase.
  final Map<PassingStyle, UnitModifiers> passingModifiers;

  /// Exponente que convierte la razón de mediocampos en cuota de posesión.
  final double possessionElasticity;
}

/// Modelo de creación y conversión de ocasiones.
@immutable
final class ChanceModel {
  /// Crea el modelo.
  const ChanceModel({
    required this.chancesPerMinute,
    required this.tempoFactors,
    required this.baseConversion,
    required this.conversionSpread,
    required this.minGoalProbability,
    required this.maxGoalProbability,
    required this.onTargetSaveShare,
    required this.ownGoalShare,
    required this.assistProbability,
    required this.scorerGroupWeights,
    required this.urgencyFromMinute,
    required this.losingAttackBoost,
    required this.winningAttackFactor,
    required this.winningDefenceBoost,
  });

  /// Probabilidad de que haya una ocasión en un minuto (tempo estándar).
  final double chancesPerMinute;

  /// Multiplicador de ocasiones según el tempo de cada equipo.
  final Map<Tempo, double> tempoFactors;

  /// Probabilidad de gol de una ocasión entre fuerzas iguales.
  final double baseConversion;

  /// Escala (en puntos de fuerza) de la sensibilidad ataque-defensa.
  final double conversionSpread;

  /// Suelo de la probabilidad de gol por ocasión.
  final double minGoalProbability;

  /// Techo de la probabilidad de gol por ocasión.
  final double maxGoalProbability;

  /// Probabilidad de que un disparo no convertido vaya entre los tres palos.
  final double onTargetSaveShare;

  /// Fracción de goles que son en propia puerta.
  final double ownGoalShare;

  /// Probabilidad de que un gol tenga asistencia.
  final double assistProbability;

  /// Peso de cada línea al elegir goleador.
  final Map<PositionGroup, double> scorerGroupWeights;

  /// Minuto a partir del cual el marcador altera el empuje de los equipos.
  final int urgencyFromMinute;

  /// Empuje ofensivo del que va perdiendo.
  final double losingAttackBoost;

  /// Factor ofensivo del que va ganando (suele ser < 1).
  final double winningAttackFactor;

  /// Refuerzo defensivo del que va ganando.
  final double winningDefenceBoost;
}

/// Modelo disciplinario (tarjetas).
@immutable
final class DisciplineModel {
  /// Crea el modelo.
  const DisciplineModel({
    required this.cardsPerSidePerMinute,
    required this.directRedShare,
    required this.pressingFactors,
    required this.bookedRestraintFactor,
  });

  /// Probabilidad de tarjeta por equipo y minuto (presión media).
  final double cardsPerSidePerMinute;

  /// Fracción de tarjetas que son roja directa.
  final double directRedShare;

  /// Multiplicador del riesgo de tarjeta según la presión propia.
  final Map<PressingIntensity, double> pressingFactors;

  /// Factor sobre el peso de un jugador ya amonestado al repartir la
  /// siguiente tarjeta: modela que un jugador con amarilla se contiene.
  final double bookedRestraintFactor;
}

/// Modelo de lesiones durante el partido.
@immutable
final class InjuryModel {
  /// Crea el modelo.
  const InjuryModel({required this.injuriesPerSidePerMinute});

  /// Probabilidad de lesión por equipo y minuto.
  final double injuriesPerSidePerMinute;
}

/// Reglas de sustitución de la IA de partido.
@immutable
final class SubstitutionModel {
  /// Crea el modelo.
  const SubstitutionModel({
    required this.scheduledMinutes,
    required this.maxSubstitutions,
    required this.fitnessThreshold,
  });

  /// Minutos en los que se evalúan cambios programados.
  final List<int> scheduledMinutes;

  /// Máximo de cambios por equipo.
  final int maxSubstitutions;

  /// Estado físico efectivo por debajo del cual un titular es candidato a
  /// ser sustituido.
  final double fitnessThreshold;
}

/// Modelo de valoraciones post-partido (escala 4–10).
@immutable
final class RatingModel {
  /// Crea el modelo.
  const RatingModel({
    required this.base,
    required this.goal,
    required this.assist,
    required this.ownGoal,
    required this.yellowCard,
    required this.sendingOff,
    required this.win,
    required this.draw,
    required this.cleanSheetDefence,
    required this.concededPenaltyDefence,
    required this.attackBlankPenalty,
    required this.noiseStdDev,
    required this.min,
    required this.max,
  });

  /// Valoración de partida.
  final double base;

  /// Bonus por gol.
  final double goal;

  /// Bonus por asistencia.
  final double assist;

  /// Penalización por gol en propia puerta.
  final double ownGoal;

  /// Penalización por amarilla.
  final double yellowCard;

  /// Penalización por expulsión.
  final double sendingOff;

  /// Bonus a los participantes del equipo ganador.
  final double win;

  /// Bonus por empate.
  final double draw;

  /// Bonus a portero y defensas por dejar la puerta a cero.
  final double cleanSheetDefence;

  /// Penalización a portero y defensas por cada gol encajado.
  final double concededPenaltyDefence;

  /// Penalización a los atacantes si su equipo no marca.
  final double attackBlankPenalty;

  /// Ruido aleatorio de la valoración.
  final double noiseStdDev;

  /// Valoración mínima.
  final double min;

  /// Valoración máxima.
  final double max;
}

/// Configuración completa del motor de partidos.
@immutable
final class MatchEngineConfig {
  /// Crea una configuración a medida.
  const MatchEngineConfig({
    required this.homeAdvantage,
    required this.strength,
    required this.chances,
    required this.discipline,
    required this.injuries,
    required this.substitutions,
    required this.ratings,
  });

  /// Factor multiplicativo sobre las unidades del equipo local.
  final double homeAdvantage;

  /// Modelo de fuerza de equipo.
  final StrengthModel strength;

  /// Modelo de ocasiones.
  final ChanceModel chances;

  /// Modelo disciplinario.
  final DisciplineModel discipline;

  /// Modelo de lesiones.
  final InjuryModel injuries;

  /// Reglas de sustitución.
  final SubstitutionModel substitutions;

  /// Modelo de valoraciones.
  final RatingModel ratings;

  /// Configuración estándar del juego, calibrada por la suite `balance`.
  factory MatchEngineConfig.standard() => const MatchEngineConfig(
    homeAdvantage: 1.05,
    strength: StrengthModel(
      positionPenalties: PositionPenalties(
        samePosition: 1,
        sameGroup: 0.92,
        adjacentGroup: 0.8,
        farGroup: 0.68,
        crossGoalkeeper: 0.45,
      ),
      fitnessFloor: 0.7,
      formSwing: 0.12,
      moraleSwing: 0.10,
      fatiguePerMinute: 0.16,
      goalkeeperFatigueFactor: 0.3,
      defenceUnit: UnitModel(
        contributions: {
          PositionGroup.goalkeeper: 0.35,
          PositionGroup.defence: 0.45,
          PositionGroup.midfield: 0.15,
          PositionGroup.attack: 0.05,
        },
        roleWeights: {
          PositionGroup.goalkeeper: {
            AttributeKey.goalkeeping: 0.65,
            AttributeKey.positioning: 0.2,
            AttributeKey.composure: 0.15,
          },
          PositionGroup.defence: {
            AttributeKey.tackling: 0.4,
            AttributeKey.positioning: 0.25,
            AttributeKey.strength: 0.2,
            AttributeKey.pace: 0.15,
          },
          PositionGroup.midfield: {
            AttributeKey.tackling: 0.45,
            AttributeKey.positioning: 0.3,
            AttributeKey.stamina: 0.25,
          },
          PositionGroup.attack: {
            AttributeKey.tackling: 0.5,
            AttributeKey.stamina: 0.3,
            AttributeKey.positioning: 0.2,
          },
        },
      ),
      midfieldUnit: UnitModel(
        contributions: {
          PositionGroup.goalkeeper: 0.02,
          PositionGroup.defence: 0.18,
          PositionGroup.midfield: 0.55,
          PositionGroup.attack: 0.25,
        },
        roleWeights: {
          PositionGroup.goalkeeper: {
            AttributeKey.passing: 0.6,
            AttributeKey.vision: 0.2,
            AttributeKey.composure: 0.2,
          },
          PositionGroup.defence: {
            AttributeKey.passing: 0.5,
            AttributeKey.vision: 0.25,
            AttributeKey.composure: 0.25,
          },
          PositionGroup.midfield: {
            AttributeKey.passing: 0.35,
            AttributeKey.vision: 0.3,
            AttributeKey.stamina: 0.2,
            AttributeKey.dribbling: 0.15,
          },
          PositionGroup.attack: {
            AttributeKey.dribbling: 0.4,
            AttributeKey.passing: 0.3,
            AttributeKey.vision: 0.3,
          },
        },
      ),
      attackUnit: UnitModel(
        contributions: {
          PositionGroup.goalkeeper: 0,
          PositionGroup.defence: 0.08,
          PositionGroup.midfield: 0.35,
          PositionGroup.attack: 0.57,
        },
        roleWeights: {
          PositionGroup.goalkeeper: {AttributeKey.passing: 1},
          PositionGroup.defence: {
            AttributeKey.shooting: 0.3,
            AttributeKey.strength: 0.3,
            AttributeKey.pace: 0.2,
            AttributeKey.positioning: 0.2,
          },
          PositionGroup.midfield: {
            AttributeKey.vision: 0.3,
            AttributeKey.passing: 0.25,
            AttributeKey.shooting: 0.25,
            AttributeKey.dribbling: 0.2,
          },
          PositionGroup.attack: {
            AttributeKey.shooting: 0.35,
            AttributeKey.pace: 0.2,
            AttributeKey.dribbling: 0.2,
            AttributeKey.positioning: 0.15,
            AttributeKey.composure: 0.1,
          },
        },
      ),
      mentalityModifiers: {
        Mentality.veryDefensive: UnitModifiers(attack: 0.85, defence: 1.10),
        Mentality.defensive: UnitModifiers(attack: 0.93, defence: 1.05),
        Mentality.balanced: UnitModifiers(),
        Mentality.attacking: UnitModifiers(attack: 1.08, defence: 0.94),
        Mentality.veryAttacking: UnitModifiers(attack: 1.15, defence: 0.86),
      },
      defensiveLineModifiers: {
        DefensiveLine.deep: UnitModifiers(defence: 1.03, attack: 0.98),
        DefensiveLine.standard: UnitModifiers(),
        DefensiveLine.high: UnitModifiers(midfield: 1.03, defence: 0.96),
      },
      widthModifiers: {
        Width.narrow: UnitModifiers(midfield: 1.02, attack: 0.98),
        Width.standard: UnitModifiers(),
        Width.wide: UnitModifiers(attack: 1.02, midfield: 0.98),
      },
      passingModifiers: {
        PassingStyle.short: UnitModifiers(midfield: 1.02, attack: 0.99),
        PassingStyle.mixed: UnitModifiers(),
        PassingStyle.direct: UnitModifiers(attack: 1.02, midfield: 0.98),
      },
      possessionElasticity: 3,
    ),
    chances: ChanceModel(
      chancesPerMinute: 0.28,
      tempoFactors: {Tempo.slow: 0.88, Tempo.standard: 1, Tempo.fast: 1.15},
      baseConversion: 0.105,
      conversionSpread: 12,
      minGoalProbability: 0.02,
      maxGoalProbability: 0.33,
      onTargetSaveShare: 0.38,
      ownGoalShare: 0.02,
      assistProbability: 0.65,
      scorerGroupWeights: {
        PositionGroup.goalkeeper: 0.01,
        PositionGroup.defence: 0.09,
        PositionGroup.midfield: 0.28,
        PositionGroup.attack: 0.62,
      },
      urgencyFromMinute: 60,
      losingAttackBoost: 1.08,
      winningAttackFactor: 0.95,
      winningDefenceBoost: 1.03,
    ),
    discipline: DisciplineModel(
      cardsPerSidePerMinute: 0.021,
      directRedShare: 0.03,
      pressingFactors: {
        PressingIntensity.low: 0.8,
        PressingIntensity.medium: 1,
        PressingIntensity.high: 1.35,
      },
      bookedRestraintFactor: 0.25,
    ),
    injuries: InjuryModel(injuriesPerSidePerMinute: 0.0017),
    substitutions: SubstitutionModel(
      scheduledMinutes: [60, 70, 80],
      maxSubstitutions: 5,
      fitnessThreshold: 78,
    ),
    ratings: RatingModel(
      base: 6,
      goal: 1,
      assist: 0.6,
      ownGoal: -0.8,
      yellowCard: -0.4,
      sendingOff: -1.2,
      win: 0.4,
      draw: 0.1,
      cleanSheetDefence: 0.5,
      concededPenaltyDefence: -0.15,
      attackBlankPenalty: -0.3,
      noiseStdDev: 0.45,
      min: 4,
      max: 10,
    ),
  );
}
