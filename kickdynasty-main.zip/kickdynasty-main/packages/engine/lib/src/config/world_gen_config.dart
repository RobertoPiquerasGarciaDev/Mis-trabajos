/// Configuración de la generación procedural de mundo (ADR 0005 y 0006).
///
/// Todo lo que decide "cómo es" el mundo generado —tamaños, distribuciones,
/// medias de calidad, salarios— vive aquí como datos versionados. El
/// generador no contiene números mágicos.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:meta/meta.dart';

/// Rango entero cerrado `min..max`.
@immutable
final class IntRange {
  /// Crea el rango; [min] debe ser ≤ [max].
  const IntRange(this.min, this.max) : assert(min <= max, 'min > max');

  /// Límite inferior (inclusive).
  final int min;

  /// Límite superior (inclusive).
  final int max;
}

/// Especificación de una liga a generar.
@immutable
final class LeagueSpec {
  /// Crea la especificación.
  const LeagueSpec({
    required this.name,
    required this.countryCode,
    required this.clubCount,
    required this.level,
  });

  /// Nombre de la competición.
  final String name;

  /// País (clave de los pools de nombres, ISO alfa-2).
  final String countryCode;

  /// Número de clubes (debe cumplir los invariantes de `League`).
  final int clubCount;

  /// Nivel de la pirámide: 1 es la máxima categoría.
  final int level;
}

/// Banda de calidad de los jugadores de un nivel de liga.
@immutable
final class QualityBand {
  /// Crea la banda.
  const QualityBand({required this.mean, required this.stdDev});

  /// Calidad media de un jugador del nivel.
  final double mean;

  /// Desviación típica de la calidad.
  final double stdDev;
}

/// Tramo de edad con su peso relativo en la distribución.
@immutable
final class AgeBucket {
  /// Crea el tramo.
  const AgeBucket({required this.range, required this.weight});

  /// Edades del tramo (inclusive).
  final IntRange range;

  /// Peso relativo del tramo.
  final double weight;
}

/// Configuración completa de la generación de mundo.
@immutable
final class WorldGenConfig {
  /// Crea una configuración a medida (para tests o mundos alternativos).
  const WorldGenConfig({
    required this.leagues,
    required this.squadTemplate,
    required this.ageBuckets,
    required this.qualityByLevel,
    required this.reputationByLevel,
    required this.attributeStdDev,
    required this.developmentAge,
    required this.youthPenaltyPerYear,
    required this.potentialPerYear,
    required this.potentialNoise,
    required this.leftFootShare,
    required this.eitherFootShare,
    required this.domesticShare,
    required this.nationalityPool,
    required this.fitnessRange,
    required this.moraleRange,
    required this.formRange,
    required this.wageBase,
    required this.wageGrowthPerPoint,
    required this.wageMinimum,
    required this.wageRounding,
    required this.contractSeasons,
    required this.balancePerReputationPoint,
    required this.stadiumBaseCapacity,
    required this.stadiumCapacityPerReputationPoint,
    required this.stadiumCapacityNoise,
    required this.stadiumCapacityRounding,
  });

  /// Ligas a generar.
  final List<LeagueSpec> leagues;

  /// Composición de la plantilla: jugadores a generar por posición.
  /// El total debe cumplir los invariantes de `Squad`.
  final Map<Position, int> squadTemplate;

  /// Distribución de edades.
  final List<AgeBucket> ageBuckets;

  /// Banda de calidad por nivel de liga.
  final Map<int, QualityBand> qualityByLevel;

  /// Rango de reputación de club por nivel de liga.
  final Map<int, IntRange> reputationByLevel;

  /// Ruido de cada atributo alrededor de la calidad base + offset.
  final double attributeStdDev;

  /// Edad de madurez: por debajo, la calidad actual se descuenta y el
  /// potencial crece.
  final int developmentAge;

  /// Descuento de calidad actual por cada año por debajo de
  /// [developmentAge].
  final double youthPenaltyPerYear;

  /// Margen de potencial por cada año por debajo de [developmentAge].
  final double potentialPerYear;

  /// Ruido (solo positivo) añadido al potencial.
  final double potentialNoise;

  /// Probabilidad de ser zurdo (posiciones neutras).
  final double leftFootShare;

  /// Probabilidad de ser ambidiestro.
  final double eitherFootShare;

  /// Probabilidad de que un jugador tenga la nacionalidad del país de la
  /// liga.
  final double domesticShare;

  /// Países posibles para jugadores extranjeros (ISO alfa-2).
  final List<String> nationalityPool;

  /// Estado físico inicial.
  final IntRange fitnessRange;

  /// Moral inicial.
  final IntRange moraleRange;

  /// Forma inicial.
  final IntRange formRange;

  /// Salario semanal de referencia para calidad 40.
  final int wageBase;

  /// Crecimiento geométrico del salario por punto de calidad.
  final double wageGrowthPerPoint;

  /// Salario semanal mínimo.
  final int wageMinimum;

  /// Redondeo del salario (múltiplos).
  final int wageRounding;

  /// Duración inicial de contratos, en temporadas completas.
  final IntRange contractSeasons;

  /// Tesorería inicial por punto de reputación.
  final int balancePerReputationPoint;

  /// Aforo base de estadio (reputación 40).
  final int stadiumBaseCapacity;

  /// Aforo adicional por punto de reputación sobre 40.
  final int stadiumCapacityPerReputationPoint;

  /// Ruido multiplicativo del aforo (desviación típica relativa).
  final double stadiumCapacityNoise;

  /// Redondeo del aforo (múltiplos).
  final int stadiumCapacityRounding;

  /// Configuración estándar del juego: un país con dos divisiones de 20
  /// clubes (el criterio de cierre de la Fase 2 del roadmap).
  factory WorldGenConfig.standard() => const WorldGenConfig(
    leagues: [
      LeagueSpec(
        name: 'Primera División Nacional',
        countryCode: 'ES',
        clubCount: 20,
        level: 1,
      ),
      LeagueSpec(
        name: 'Segunda División Nacional',
        countryCode: 'ES',
        clubCount: 20,
        level: 2,
      ),
    ],
    squadTemplate: {
      Position.gk: 3,
      Position.cb: 4,
      Position.lb: 2,
      Position.rb: 2,
      Position.dm: 2,
      Position.cm: 4,
      Position.am: 2,
      Position.lw: 2,
      Position.rw: 2,
      Position.st: 3,
    },
    ageBuckets: [
      AgeBucket(range: IntRange(16, 20), weight: 0.18),
      AgeBucket(range: IntRange(21, 24), weight: 0.30),
      AgeBucket(range: IntRange(25, 29), weight: 0.32),
      AgeBucket(range: IntRange(30, 34), weight: 0.17),
      AgeBucket(range: IntRange(35, 38), weight: 0.03),
    ],
    qualityByLevel: {
      1: QualityBand(mean: 64, stdDev: 6),
      2: QualityBand(mean: 54, stdDev: 6),
    },
    reputationByLevel: {1: IntRange(55, 82), 2: IntRange(38, 60)},
    attributeStdDev: 4,
    developmentAge: 24,
    youthPenaltyPerYear: 1.6,
    potentialPerYear: 1.8,
    potentialNoise: 3,
    leftFootShare: 0.22,
    eitherFootShare: 0.08,
    domesticShare: 0.7,
    nationalityPool: ['ES', 'GB', 'DE', 'FR', 'IT', 'PT'],
    fitnessRange: IntRange(85, 100),
    moraleRange: IntRange(55, 80),
    formRange: IntRange(40, 60),
    wageBase: 650,
    wageGrowthPerPoint: 0.075,
    wageMinimum: 250,
    wageRounding: 50,
    contractSeasons: IntRange(1, 4),
    balancePerReputationPoint: 60000,
    stadiumBaseCapacity: 4000,
    stadiumCapacityPerReputationPoint: 850,
    stadiumCapacityNoise: 0.12,
    stadiumCapacityRounding: 250,
  );

  /// Número total de jugadores por plantilla según [squadTemplate].
  int get squadSize =>
      squadTemplate.values.fold(0, (sum, count) => sum + count);
}
