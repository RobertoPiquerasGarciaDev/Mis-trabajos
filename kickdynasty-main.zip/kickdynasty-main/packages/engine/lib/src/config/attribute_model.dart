/// Modelo de atributos por posición (dato de balance, ADR 0005).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Clave de cada atributo de [PlayerAttributes], para poder tratarlos como
/// datos (offsets, pesos) sin perder el tipado al construir la entidad.
enum AttributeKey {
  /// Velocidad.
  pace,

  /// Resistencia.
  stamina,

  /// Fuerza.
  strength,

  /// Pase.
  passing,

  /// Definición.
  shooting,

  /// Regate.
  dribbling,

  /// Entrada.
  tackling,

  /// Colocación.
  positioning,

  /// Visión.
  vision,

  /// Sangre fría.
  composure,

  /// Portería.
  goalkeeping,
}

/// Valor del atributo [key] en [attributes].
int attributeValue(PlayerAttributes attributes, AttributeKey key) =>
    switch (key) {
      AttributeKey.pace => attributes.pace.value,
      AttributeKey.stamina => attributes.stamina.value,
      AttributeKey.strength => attributes.strength.value,
      AttributeKey.passing => attributes.passing.value,
      AttributeKey.shooting => attributes.shooting.value,
      AttributeKey.dribbling => attributes.dribbling.value,
      AttributeKey.tackling => attributes.tackling.value,
      AttributeKey.positioning => attributes.positioning.value,
      AttributeKey.vision => attributes.vision.value,
      AttributeKey.composure => attributes.composure.value,
      AttributeKey.goalkeeping => attributes.goalkeeping.value,
    };

/// Construye [PlayerAttributes] desde un mapa completo de valores por clave.
///
/// Lanza [ArgumentError] si falta alguna clave: el modelo de atributos es
/// total, no parcial.
PlayerAttributes buildAttributes(Map<AttributeKey, Rating> values) {
  Rating require(AttributeKey key) {
    final value = values[key];
    if (value == null) {
      throw ArgumentError('Falta el atributo ${key.name}');
    }
    return value;
  }

  return PlayerAttributes(
    pace: require(AttributeKey.pace),
    stamina: require(AttributeKey.stamina),
    strength: require(AttributeKey.strength),
    passing: require(AttributeKey.passing),
    shooting: require(AttributeKey.shooting),
    dribbling: require(AttributeKey.dribbling),
    tackling: require(AttributeKey.tackling),
    positioning: require(AttributeKey.positioning),
    vision: require(AttributeKey.vision),
    composure: require(AttributeKey.composure),
    goalkeeping: require(AttributeKey.goalkeeping),
  );
}

/// Desplazamiento de cada atributo respecto a la calidad base del jugador,
/// según su posición natural. Las claves ausentes valen 0.
///
/// Es la identidad futbolística de cada posición: un central generado tendrá
/// entrada y fuerza por encima de su calidad base, y definición por debajo.
const Map<Position, Map<AttributeKey, int>> attributeOffsetsByPosition = {
  Position.gk: {
    AttributeKey.goalkeeping: 12,
    AttributeKey.positioning: 4,
    AttributeKey.composure: 2,
    AttributeKey.strength: 2,
    AttributeKey.pace: -8,
    AttributeKey.stamina: -6,
    AttributeKey.passing: -8,
    AttributeKey.shooting: -20,
    AttributeKey.dribbling: -15,
    AttributeKey.tackling: -12,
    AttributeKey.vision: -6,
  },
  Position.cb: {
    AttributeKey.tackling: 8,
    AttributeKey.strength: 8,
    AttributeKey.positioning: 6,
    AttributeKey.goalkeeping: -35,
    AttributeKey.shooting: -12,
    AttributeKey.dribbling: -8,
    AttributeKey.pace: -2,
    AttributeKey.vision: -4,
    AttributeKey.passing: -2,
  },
  Position.lb: {
    AttributeKey.pace: 6,
    AttributeKey.stamina: 6,
    AttributeKey.tackling: 4,
    AttributeKey.positioning: 2,
    AttributeKey.goalkeeping: -35,
    AttributeKey.shooting: -10,
    AttributeKey.vision: -2,
  },
  Position.rb: {
    AttributeKey.pace: 6,
    AttributeKey.stamina: 6,
    AttributeKey.tackling: 4,
    AttributeKey.positioning: 2,
    AttributeKey.goalkeeping: -35,
    AttributeKey.shooting: -10,
    AttributeKey.vision: -2,
  },
  Position.dm: {
    AttributeKey.tackling: 6,
    AttributeKey.positioning: 6,
    AttributeKey.passing: 4,
    AttributeKey.strength: 4,
    AttributeKey.stamina: 4,
    AttributeKey.goalkeeping: -35,
    AttributeKey.shooting: -6,
  },
  Position.cm: {
    AttributeKey.passing: 6,
    AttributeKey.vision: 6,
    AttributeKey.stamina: 4,
    AttributeKey.positioning: 2,
    AttributeKey.goalkeeping: -35,
    AttributeKey.shooting: -2,
  },
  Position.am: {
    AttributeKey.vision: 8,
    AttributeKey.passing: 6,
    AttributeKey.dribbling: 6,
    AttributeKey.shooting: 2,
    AttributeKey.goalkeeping: -35,
    AttributeKey.tackling: -10,
    AttributeKey.strength: -4,
  },
  Position.lw: {
    AttributeKey.pace: 8,
    AttributeKey.dribbling: 8,
    AttributeKey.shooting: 2,
    AttributeKey.vision: 2,
    AttributeKey.goalkeeping: -35,
    AttributeKey.tackling: -10,
    AttributeKey.strength: -4,
  },
  Position.rw: {
    AttributeKey.pace: 8,
    AttributeKey.dribbling: 8,
    AttributeKey.shooting: 2,
    AttributeKey.vision: 2,
    AttributeKey.goalkeeping: -35,
    AttributeKey.tackling: -10,
    AttributeKey.strength: -4,
  },
  Position.st: {
    AttributeKey.shooting: 10,
    AttributeKey.positioning: 6,
    AttributeKey.strength: 4,
    AttributeKey.composure: 4,
    AttributeKey.goalkeeping: -35,
    AttributeKey.tackling: -12,
    AttributeKey.vision: -2,
  },
};
