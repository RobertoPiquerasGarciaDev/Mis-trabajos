/// Generación procedural de identidades de club.
library;

import 'dart:math' as math;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/name_pools.dart';
import 'package:kickdynasty_engine/src/config/world_gen_config.dart';
import 'package:kickdynasty_engine/src/random/rng.dart';
import 'package:kickdynasty_engine/src/worldgen/name_generator.dart';

/// Genera clubes con identidad única (nombre, código, estadio) dentro de un
/// mundo.
///
/// Es **stateful por mundo**: mantiene los registros de nombres y códigos ya
/// usados para garantizar unicidad. Crear una instancia nueva por cada
/// generación de mundo.
final class ClubGenerator {
  /// Crea el generador para un mundo.
  ClubGenerator({required this.config, this.names = const NameGenerator()});

  /// Configuración de balance.
  final WorldGenConfig config;

  /// Acceso a los pools de nombres.
  final NameGenerator names;

  final Set<String> _usedNames = {};
  final Set<String> _usedCodes = {};

  static const int _maxAttempts = 100;

  /// Genera un club del país y nivel de [spec].
  Club generate({
    required ClubId id,
    required LeagueSpec spec,
    required Rng rng,
  }) {
    final pools = names.poolsFor(CountryCode(spec.countryCode));
    final reputationRange = config.reputationByLevel[spec.level];
    if (reputationRange == null) {
      throw StateError('Sin rango de reputación para el nivel ${spec.level}');
    }

    final (:name, :city) = _uniqueClubName(pools, rng);
    final reputation = Rating(
      rng.rangeInt(reputationRange.min, reputationRange.max),
    );

    return Club(
      id: id,
      name: DisplayName(name),
      code: _uniqueCode(city),
      country: CountryCode(spec.countryCode),
      reputation: reputation,
      stadium: _stadium(pools, city, reputation, rng),
      balance: _initialBalance(reputation, rng),
    );
  }

  ({String name, String city}) _uniqueClubName(LocaleNames pools, Rng rng) {
    for (var attempt = 0; attempt < _maxAttempts; attempt++) {
      final city = rng.pick(pools.cities);
      final pattern = rng.pick(pools.clubPatterns);
      final prefix = rng.pick(pools.clubPrefixes);
      final name = pattern.replaceAll('{p}', prefix).replaceAll('{c}', city);
      if (_usedNames.add(name)) return (name: name, city: city);
    }
    throw StateError(
      'No se pudo generar un nombre de club único tras $_maxAttempts '
      'intentos: amplía los pools de la configuración',
    );
  }

  ClubCode _uniqueCode(String city) {
    final letters = city.toUpperCase().replaceAll(RegExp('[^A-Z]'), '');
    final base = letters.length >= 3 ? letters.substring(0, 3) : 'CLB';
    if (_usedCodes.add(base)) return ClubCode(base);

    // Colisión: prueba variantes con la cuarta letra A-Z.
    final stem = base.substring(0, 2);
    for (var i = 0; i < 26; i++) {
      final candidate = '$base${String.fromCharCode(65 + i)}';
      if (_usedCodes.add(candidate)) return ClubCode(candidate);
    }
    for (var i = 0; i < 26; i++) {
      for (var j = 0; j < 26; j++) {
        final candidate =
            '$stem${String.fromCharCode(65 + i)}${String.fromCharCode(65 + j)}';
        if (_usedCodes.add(candidate)) return ClubCode(candidate);
      }
    }
    throw StateError('Espacio de códigos de club agotado');
  }

  Stadium _stadium(LocaleNames pools, String city, Rating reputation, Rng rng) {
    final pattern = rng.pick(pools.stadiumPatterns);
    final name = pattern.replaceAll('{c}', city);

    final base =
        config.stadiumBaseCapacity +
        (reputation.value - 40) * config.stadiumCapacityPerReputationPoint;
    final noisy =
        base * (1 + rng.gaussian(stdDev: config.stadiumCapacityNoise));
    final rounded =
        (noisy / config.stadiumCapacityRounding).round() *
        config.stadiumCapacityRounding;
    final capacity = math.max(
      Stadium.minCapacity,
      math.min(Stadium.maxCapacity, rounded),
    );

    return Stadium(name: DisplayName(name), capacity: capacity);
  }

  Money _initialBalance(Rating reputation, Rng rng) {
    final base = reputation.value * config.balancePerReputationPoint;
    final noisy = base * (1 + rng.gaussian(stdDev: 0.15));
    return Money(math.max(base ~/ 4, noisy.round()));
  }
}
