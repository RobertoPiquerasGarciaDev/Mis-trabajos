/// Generación de nombres de persona por país.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/name_pools.dart';
import 'package:kickdynasty_engine/src/random/rng.dart';

/// Genera nombres de persona a partir de los pools por país.
final class NameGenerator {
  /// Crea el generador sobre unos [pools] (por defecto, los del juego).
  const NameGenerator({this.pools = namePoolsByCountry});

  /// Pools de nombres por código de país.
  final Map<String, LocaleNames> pools;

  /// Pools del país [country]; lanza [StateError] si no hay datos, porque
  /// una configuración que referencia un país sin pool es un error de
  /// contenido que debe aflorar en tests, no producir nombres vacíos.
  LocaleNames poolsFor(CountryCode country) {
    final localeNames = pools[country.value];
    if (localeNames == null) {
      throw StateError('No hay pool de nombres para el país ${country.value}');
    }
    return localeNames;
  }

  /// Nombre completo de una persona del país [country].
  DisplayName personName(CountryCode country, Rng rng) {
    final localeNames = poolsFor(country);
    final first = rng.pick(localeNames.firstNames);
    final last = rng.pick(localeNames.lastNames);
    return DisplayName('$first $last');
  }
}
