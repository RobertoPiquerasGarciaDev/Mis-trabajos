/// Generación procedural del mundo completo (ADR 0002, 0005, 0006).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/world_gen_config.dart';
import 'package:kickdynasty_engine/src/random/xoshiro.dart';
import 'package:kickdynasty_engine/src/worldgen/club_generator.dart';
import 'package:kickdynasty_engine/src/worldgen/player_generator.dart';
import 'package:meta/meta.dart';

/// Un club generado con su plantilla y los contratos de sus jugadores.
@immutable
final class GeneratedClub {
  /// Crea el agregado.
  const GeneratedClub({
    required this.club,
    required this.squad,
    required this.contracts,
  });

  /// El club.
  final Club club;

  /// Su plantilla (invariantes de `Squad` garantizados en construcción).
  final Squad squad;

  /// Contratos de todos los jugadores de la plantilla.
  final List<Contract> contracts;
}

/// Una liga generada con sus clubes.
@immutable
final class GeneratedLeague {
  /// Crea el agregado.
  const GeneratedLeague({
    required this.league,
    required this.level,
    required this.clubs,
  });

  /// La liga (invariantes de `League` garantizados en construcción).
  final League league;

  /// Nivel de la pirámide (1 = máxima categoría).
  final int level;

  /// Clubes participantes con sus plantillas.
  final List<GeneratedClub> clubs;
}

/// El mundo completo producido por [WorldGenerator].
@immutable
final class GeneratedWorld {
  /// Crea el mundo.
  const GeneratedWorld({required this.seed, required this.leagues});

  /// Semilla con la que se generó (mismo seed → mismo mundo).
  final int seed;

  /// Ligas generadas.
  final List<GeneratedLeague> leagues;

  /// Todos los clubes del mundo.
  Iterable<GeneratedClub> get allClubs =>
      leagues.expand((league) => league.clubs);

  /// Todos los jugadores del mundo.
  Iterable<Player> get allPlayers =>
      allClubs.expand((club) => club.squad.players);

  /// Todos los contratos del mundo.
  Iterable<Contract> get allContracts =>
      allClubs.expand((club) => club.contracts);
}

/// Genera mundos completos de forma determinista.
///
/// Cada club consume un generador de números derivado de
/// `(seed, liga, club)`, de modo que la generación de un club es
/// independiente de las demás: cambiar cuánta aleatoriedad consume un club
/// no altera el resto del mundo.
final class WorldGenerator {
  /// Crea el generador con una [config] (por defecto, la estándar).
  WorldGenerator({WorldGenConfig? config})
    : config = config ?? WorldGenConfig.standard();

  /// Configuración de balance de la generación.
  final WorldGenConfig config;

  /// Genera el mundo completo a partir de [seed].
  GeneratedWorld generate({required int seed}) {
    final playerGenerator = PlayerGenerator(config: config);
    final clubGenerator = ClubGenerator(config: config);

    final leagues = <GeneratedLeague>[];
    for (var li = 0; li < config.leagues.length; li++) {
      final spec = config.leagues[li];
      final leagueCountry = CountryCode(spec.countryCode);

      final clubs = <GeneratedClub>[];
      for (var ci = 0; ci < spec.clubCount; ci++) {
        final rng = Xoshiro256StarStar.fromSeed(
          derivedSeed(seed, (li + 1) * 1000000 + (ci + 1)),
        );
        final clubId = ClubId('club-${li + 1}-${ci + 1}');
        final club = clubGenerator.generate(id: clubId, spec: spec, rng: rng);

        final players = <Player>[];
        final contracts = <Contract>[];
        var playerIndex = 0;
        for (final entry in config.squadTemplate.entries) {
          for (var n = 0; n < entry.value; n++) {
            playerIndex++;
            final playerId = PlayerId('${clubId.value}-p$playerIndex');
            final generated = playerGenerator.generate(
              id: playerId,
              position: entry.key,
              leagueCountry: leagueCountry,
              leagueLevel: spec.level,
              rng: rng,
            );
            players.add(generated.player);
            contracts.add(
              Contract(
                id: ContractId('contract-${playerId.value}'),
                playerId: playerId,
                clubId: clubId,
                weeklyWage: generated.weeklyWage,
                expiry: GameDate(
                  season:
                      1 +
                      rng.rangeInt(
                        config.contractSeasons.min,
                        config.contractSeasons.max,
                      ),
                  week: 1,
                ),
              ),
            );
          }
        }

        clubs.add(
          GeneratedClub(
            club: club,
            squad: Squad(clubId: clubId, players: players),
            contracts: List.unmodifiable(contracts),
          ),
        );
      }

      leagues.add(
        GeneratedLeague(
          league: League(
            id: LeagueId('league-${li + 1}'),
            name: DisplayName(spec.name),
            country: leagueCountry,
            clubIds: [for (final club in clubs) club.club.id],
          ),
          level: spec.level,
          clubs: List.unmodifiable(clubs),
        ),
      );
    }

    return GeneratedWorld(seed: seed, leagues: List.unmodifiable(leagues));
  }
}
