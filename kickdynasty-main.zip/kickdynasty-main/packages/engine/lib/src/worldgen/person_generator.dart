/// Generador determinista de personas (AGENT_WORLD_GENERATION §3–5, PF-1).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/name_pools.dart';

/// Roles mínimos de staff por club en migración v6.
const minimumStaffRoles = [
  PersonRole.president,
  PersonRole.sportingDirector,
  PersonRole.manager,
];

/// Genera [Person] de forma pura y reproducible.
final class PersonGenerator {
  /// Crea el generador con pools de nombres opcionales.
  const PersonGenerator({Map<String, LocaleNames>? pools})
    : _pools = pools ?? namePoolsByCountry;

  final Map<String, LocaleNames> _pools;

  LocaleNames _localeFor(CountryCode country) {
    final locale = _pools[country.value];
    if (locale == null) {
      throw StateError('No hay pool de nombres para ${country.value}');
    }
    return locale;
  }

  /// Genera una persona completa a partir de identidad y contexto de origen.
  Person generate({
    required PersonId id,
    required int worldSeed,
    required PersonOrigin origin,
    required PersonRole role,
    required int ageYears,
  }) {
    final nationality = origin.country;
    final locale = _localeFor(nationality);
    final givenIndex =
        personDerive(
          personId: id,
          worldSeed: worldSeed,
          domain: 'identity.givenName',
        ).abs() %
        locale.firstNames.length;
    final familyIndex =
        personDerive(
          personId: id,
          worldSeed: worldSeed,
          domain: 'identity.familyName',
          index: 1,
        ).abs() %
        locale.lastNames.length;

    final given = locale.firstNames[givenIndex];
    final family = locale.lastNames[familyIndex];

    final birthYear = origin.appearanceYear - ageYears;
    final birthMonth =
        (personDerive(
              personId: id,
              worldSeed: worldSeed,
              domain: 'identity.birthMonth',
            ).abs() %
            12) +
        1;
    final birthDay =
        (personDerive(
              personId: id,
              worldSeed: worldSeed,
              domain: 'identity.birthDay',
            ).abs() %
            28) +
        1;

    final gender =
        PersonGender.values[personDerive(
              personId: id,
              worldSeed: worldSeed,
              domain: 'identity.gender',
            ).abs() %
            PersonGender.values.length];

    final primaryLanguage = _primaryLanguageFor(nationality.value);

    final ambition = personDeriveTraitScore(
      personId: id,
      worldSeed: worldSeed,
      domain: 'personality.ambition',
    );
    final prudence = personDeriveTraitScore(
      personId: id,
      worldSeed: worldSeed,
      domain: 'personality.prudence',
      index: ambition.value,
    );

    return Person(
      id: id,
      firstName: DisplayName(given),
      lastName: DisplayName(family),
      birthDate: BirthDate(year: birthYear, month: birthMonth, day: birthDay),
      nationality: nationality,
      primaryLanguage: primaryLanguage,
      gender: gender,
      origin: origin,
      personality: PersonalityProfile(
        ambition: ambition,
        patience: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.patience',
        ),
        prudence: prudence,
        aggressiveness: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.aggressiveness',
        ),
        pride: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.pride',
        ),
        ego: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.ego',
        ),
        professionalism: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.professionalism',
        ),
        empathy: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.empathy',
        ),
        emotionalStability: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.emotionalStability',
        ),
        leadership: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.leadership',
        ),
        memoryTrait: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.memoryTrait',
        ),
        pressureTolerance: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'personality.pressureTolerance',
        ),
      ),
      values: PersonValues(
        loyalty: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'values.loyalty',
        ),
        meritocracy: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'values.meritocracy',
        ),
        family: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'values.family',
        ),
        prestige: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'values.prestige',
        ),
        security: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'values.security',
        ),
      ),
      philosophy: PersonPhilosophy(
        pragmatism: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'philosophy.pragmatism',
        ),
        youthFocus: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'philosophy.youthFocus',
        ),
        attackingStyle: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'philosophy.attackingStyle',
        ),
        financialPrudence: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'philosophy.financialPrudence',
        ),
        institutionalLoyalty: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'philosophy.institutionalLoyalty',
        ),
      ),
      competencies: GeneralCompetencies(
        intelligence: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'competency.intelligence',
        ),
        negotiation: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'competency.negotiation',
        ),
        analysis: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'competency.analysis',
        ),
        communication: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'competency.communication',
        ),
        adaptability: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'competency.adaptability',
        ),
      ),
      traits: PermanentTraits(
        charisma: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'traits.charisma',
        ),
        workEthic: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'traits.workEthic',
        ),
        resilience: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'traits.resilience',
        ),
        creativity: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'traits.creativity',
        ),
        discipline: personDeriveTraitScore(
          personId: id,
          worldSeed: worldSeed,
          domain: 'traits.discipline',
        ),
      ),
      cognitivePotential: personDeriveTraitScore(
        personId: id,
        worldSeed: worldSeed,
        domain: 'cognitive.potential',
      ),
      initialReputation: Rating.clamped(
        personDerive(
              personId: id,
              worldSeed: worldSeed,
              domain: 'reputation.initial',
            ).abs() %
            Rating.max,
      ),
      role: role,
    );
  }

  /// Construye [PersonOrigin] determinista para un contexto de nacimiento.
  PersonOrigin buildOrigin({
    required int worldSeed,
    required CountryCode country,
    required String city,
    required String cohort,
    required int generation,
    required int appearanceYear,
    String? academy,
    bool sportingFamily = false,
    String economicContext = 'middle',
  }) {
    return PersonOrigin(
      country: country,
      city: city,
      academy: academy,
      sportingFamily: sportingFamily,
      generation: generation,
      economicContext: economicContext,
      appearanceYear: appearanceYear,
      cohort: cohort,
      derivedWorldSeed: worldSeed,
      birthContextHash: personBirthContextHash(
        worldSeed: worldSeed,
        country: country.value,
        city: city,
        cohort: cohort,
        generation: generation,
      ),
    );
  }

  String _primaryLanguageFor(String countryCode) => switch (countryCode) {
    'ES' => 'es',
    'GB' || 'EN' => 'en',
    'FR' => 'fr',
    'DE' => 'de',
    'IT' => 'it',
    'PT' => 'pt',
    'BR' => 'pt',
    'AR' => 'es',
    _ => 'en',
  };
}
