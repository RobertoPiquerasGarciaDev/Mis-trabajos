/// Generación procedural de jugadores.
library;

import 'dart:math' as math;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/attribute_model.dart';
import 'package:kickdynasty_engine/src/config/world_gen_config.dart';
import 'package:kickdynasty_engine/src/random/rng.dart';
import 'package:kickdynasty_engine/src/worldgen/name_generator.dart';
import 'package:meta/meta.dart';

/// Jugador generado junto con su salario semanal sugerido.
///
/// El salario se calcula de la calidad base usada en la generación (no de
/// los atributos con ruido), por lo que se devuelve junto al jugador en
/// lugar de recalcularse fuera.
@immutable
final class GeneratedPlayer {
  /// Crea el resultado de generación.
  const GeneratedPlayer({required this.player, required this.weeklyWage});

  /// El jugador generado.
  final Player player;

  /// Salario semanal acorde a su calidad.
  final Money weeklyWage;
}

/// Genera jugadores coherentes con la posición, el nivel de liga y la
/// configuración de balance.
final class PlayerGenerator {
  /// Crea el generador.
  const PlayerGenerator({
    required this.config,
    this.names = const NameGenerator(),
  });

  /// Configuración de balance de la generación.
  final WorldGenConfig config;

  /// Generador de nombres de persona.
  final NameGenerator names;

  /// Genera un jugador de [position] para una liga de país [leagueCountry]
  /// y nivel [leagueLevel].
  ///
  /// Si se indica [age] se usa esa edad en lugar de muestrear la
  /// distribución (los canteranos que reemplazan retiros entran jóvenes);
  /// el descuento juvenil de calidad se aplica igual, así que un regen de
  /// 17 años llega verde pero con potencial.
  GeneratedPlayer generate({
    required PlayerId id,
    required Position position,
    required CountryCode leagueCountry,
    required int leagueLevel,
    required Rng rng,
    int? age,
  }) {
    final band = config.qualityByLevel[leagueLevel];
    if (band == null) {
      throw StateError('Sin banda de calidad para el nivel $leagueLevel');
    }

    final effectiveAge = age ?? _sampleAge(rng);
    final yearsToDevelop = math.max(0, config.developmentAge - effectiveAge);

    final baseQuality = rng.gaussian(mean: band.mean, stdDev: band.stdDev);
    final currentQuality =
        baseQuality - yearsToDevelop * config.youthPenaltyPerYear;

    final offsets = attributeOffsetsByPosition[position] ?? const {};
    final values = <AttributeKey, Rating>{
      for (final key in AttributeKey.values)
        key: Rating.clamped(
          (currentQuality +
                  (offsets[key] ?? 0) +
                  rng.gaussian(stdDev: config.attributeStdDev))
              .round(),
        ),
    };

    final potentialQuality =
        currentQuality +
        yearsToDevelop * config.potentialPerYear +
        rng.gaussian(stdDev: config.potentialNoise).abs();

    final nationality = rng.chance(config.domesticShare)
        ? leagueCountry
        : CountryCode(
            rng.pick([
              for (final code in config.nationalityPool)
                if (code != leagueCountry.value) code,
            ]),
          );

    final player = Player(
      id: id,
      name: names.personName(nationality, rng),
      nationality: nationality,
      position: position,
      preferredFoot: _sampleFoot(position, rng),
      age: Age(effectiveAge),
      attributes: buildAttributes(values),
      potential: Rating.clamped(potentialQuality.round()),
      fitness: Fitness(
        rng.rangeInt(config.fitnessRange.min, config.fitnessRange.max),
      ),
      morale: Morale(
        rng.rangeInt(config.moraleRange.min, config.moraleRange.max),
      ),
      form: Form(rng.rangeInt(config.formRange.min, config.formRange.max)),
    );

    return GeneratedPlayer(
      player: player,
      weeklyWage: _wageFor(currentQuality),
    );
  }

  int _sampleAge(Rng rng) {
    final bucketIndex = rng.pickIndexWeighted([
      for (final bucket in config.ageBuckets) bucket.weight,
    ]);
    final range = config.ageBuckets[bucketIndex].range;
    return rng.rangeInt(range.min, range.max);
  }

  PreferredFoot _sampleFoot(Position position, Rng rng) {
    if (rng.chance(config.eitherFootShare)) return PreferredFoot.either;
    final leftShare = switch (position) {
      Position.lb || Position.lw => 0.6,
      Position.rb || Position.rw => 0.12,
      _ => config.leftFootShare,
    };
    return rng.chance(leftShare) ? PreferredFoot.left : PreferredFoot.right;
  }

  Money _wageFor(double quality) {
    final raw =
        config.wageBase * math.pow(1 + config.wageGrowthPerPoint, quality - 40);
    final rounded = (raw / config.wageRounding).round() * config.wageRounding;
    return Money(math.max(config.wageMinimum, rounded));
  }
}
