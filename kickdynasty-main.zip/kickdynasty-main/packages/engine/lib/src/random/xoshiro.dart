/// Implementación de producción del [Rng]: xoshiro256** semiado con SplitMix64.
///
/// Nota de plataforma: el determinismo se apoya en la aritmética entera de
/// 64 bits con desbordamiento envolvente de la Dart VM (Android, iOS,
/// escritorio y tests). Este paquete NO es apto para compilación web
/// (`dart2js`), donde los enteros pierden precisión por encima de 2^53.
library;

import 'package:kickdynasty_engine/src/random/rng.dart';

/// Mezcla SplitMix64: dispersa [x] en un entero de 64 bits bien distribuido.
///
/// Se usa para derivar semillas y para inicializar el estado de
/// [Xoshiro256StarStar].
int splitMix64(int x) {
  var z = x + 0x9E3779B97F4A7C15;
  z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9;
  z = (z ^ (z >>> 27)) * 0x94D049BB133111EB;
  return z ^ (z >>> 31);
}

/// Deriva una semilla independiente para el flujo [stream] a partir de
/// [seed].
///
/// Permite que subsistemas (p. ej. la generación de cada club) tengan su
/// propio generador sin que un cambio en el orden de consumo de uno afecte
/// a los demás.
int derivedSeed(int seed, int stream) =>
    splitMix64(splitMix64(seed) ^ splitMix64(stream));

/// Generador xoshiro256**: rápido, de alta calidad estadística y con estado
/// compacto (256 bits).
final class Xoshiro256StarStar extends Rng {
  /// Crea el generador expandiendo [seed] con SplitMix64.
  Xoshiro256StarStar.fromSeed(int seed) {
    var x = seed;
    for (var i = 0; i < 4; i++) {
      x = splitMix64(x);
      // El estado todo-ceros es el único inválido para xoshiro.
      _state[i] = x != 0 ? x : 0x9E3779B97F4A7C15;
    }
  }

  final List<int> _state = List.filled(4, 0);

  static int _rotl(int x, int k) => (x << k) | (x >>> (64 - k));

  int _next() {
    final result = _rotl(_state[1] * 5, 7) * 9;
    final t = _state[1] << 17;
    _state[2] ^= _state[0];
    _state[3] ^= _state[1];
    _state[1] ^= _state[2];
    _state[0] ^= _state[3];
    _state[2] ^= t;
    _state[3] = _rotl(_state[3], 45);
    return result;
  }

  @override
  int nextBits53() => _next() >>> 11;
}
