/// Fuente de aleatoriedad inyectable del motor (ADR 0002).
///
/// Todo el motor recibe su aleatoriedad a través de [Rng]. Está prohibido
/// usar `dart:math` `Random` directamente o cualquier otra fuente implícita:
/// con la misma semilla, el motor produce siempre el mismo resultado.
library;

import 'dart:math' as math;

/// Fuente de aleatoriedad determinista del motor.
///
/// Las implementaciones deben ser reproducibles: misma semilla → misma
/// secuencia. La primitiva abstracta es [nextBits53]; el resto de métodos
/// derivan de ella y son comunes a todas las implementaciones.
abstract base class Rng {
  /// Devuelve 53 bits uniformes: un entero en `0 .. 2^53 - 1`.
  int nextBits53();

  /// Uniforme continuo en `[0, 1)`.
  double nextDouble() => nextBits53() / _two53;

  /// Entero uniforme en `0 .. max - 1`. [max] debe ser > 0.
  int nextInt(int max) {
    if (max <= 0) {
      throw ArgumentError.value(max, 'max', 'debe ser > 0');
    }
    // El sesgo del módulo es < 2^-40 para los rangos que usa el juego.
    return nextBits53() % max;
  }

  /// Entero uniforme en `min .. max`, ambos inclusive.
  int rangeInt(int min, int max) {
    if (min > max) {
      throw ArgumentError('rangeInt requiere min <= max ($min > $max)');
    }
    return min + nextInt(max - min + 1);
  }

  /// `true` con probabilidad [p] (0 = nunca, 1 = siempre).
  bool chance(double p) => nextDouble() < p;

  /// Elemento uniforme de [items], que no puede estar vacía.
  T pick<T>(List<T> items) {
    if (items.isEmpty) {
      throw ArgumentError('pick requiere una lista no vacía');
    }
    return items[nextInt(items.length)];
  }

  /// Índice de [weights] elegido con probabilidad proporcional a su peso.
  ///
  /// Los pesos deben ser ≥ 0 y sumar > 0.
  int pickIndexWeighted(List<double> weights) {
    var total = 0.0;
    for (final weight in weights) {
      if (weight < 0) {
        throw ArgumentError('los pesos deben ser >= 0 (recibido: $weight)');
      }
      total += weight;
    }
    if (total <= 0) {
      throw ArgumentError('la suma de pesos debe ser > 0');
    }
    var remaining = nextDouble() * total;
    for (var i = 0; i < weights.length; i++) {
      remaining -= weights[i];
      if (remaining < 0) return i;
    }
    return weights.length - 1;
  }

  double? _spareGaussian;

  /// Muestra de una distribución normal con [mean] y [stdDev] (Box–Muller).
  double gaussian({double mean = 0, double stdDev = 1}) {
    final spare = _spareGaussian;
    if (spare != null) {
      _spareGaussian = null;
      return mean + stdDev * spare;
    }
    final u1 = 1.0 - nextDouble(); // evita log(0)
    final u2 = nextDouble();
    final radius = math.sqrt(-2.0 * math.log(u1));
    final theta = 2.0 * math.pi * u2;
    _spareGaussian = radius * math.sin(theta);
    return mean + stdDev * radius * math.cos(theta);
  }

  static const double _two53 = 9007199254740992.0; // 2^53
}
