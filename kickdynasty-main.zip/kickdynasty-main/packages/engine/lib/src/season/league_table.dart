/// Clasificación de liga con criterios de desempate.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:meta/meta.dart';

/// Línea de la clasificación de un club.
@immutable
final class TableRow {
  /// Crea la línea.
  const TableRow({
    required this.clubId,
    required this.played,
    required this.won,
    required this.drawn,
    required this.lost,
    required this.goalsFor,
    required this.goalsAgainst,
  });

  /// Línea a cero para un club que aún no ha jugado.
  const TableRow.empty(this.clubId)
    : played = 0,
      won = 0,
      drawn = 0,
      lost = 0,
      goalsFor = 0,
      goalsAgainst = 0;

  /// Club.
  final ClubId clubId;

  /// Partidos jugados.
  final int played;

  /// Victorias.
  final int won;

  /// Empates.
  final int drawn;

  /// Derrotas.
  final int lost;

  /// Goles a favor.
  final int goalsFor;

  /// Goles en contra.
  final int goalsAgainst;

  /// Puntos (3 por victoria, 1 por empate).
  int get points => won * 3 + drawn;

  /// Diferencia de goles.
  int get goalDifference => goalsFor - goalsAgainst;

  /// Línea con un resultado más incorporado.
  TableRow adding({required int scored, required int conceded}) => TableRow(
    clubId: clubId,
    played: played + 1,
    won: won + (scored > conceded ? 1 : 0),
    drawn: drawn + (scored == conceded ? 1 : 0),
    lost: lost + (scored < conceded ? 1 : 0),
    goalsFor: goalsFor + scored,
    goalsAgainst: goalsAgainst + conceded,
  );

  @override
  String toString() =>
      '${clubId.value}: $points pts ($played PJ, $goalsFor-$goalsAgainst)';
}

/// Clasificación ordenada de una liga.
///
/// Criterios de desempate, en orden: puntos, diferencia de goles, goles a
/// favor, puntos de la mini-liga entre todos los empatados
/// (enfrentamientos directos) y, como último recurso determinista, el
/// identificador del club.
///
/// El head-to-head se resuelve por grupo de empatados y no por pares: la
/// comparación pareja a pareja puede ser intransitiva (A gana a B, B a C y
/// C a A) y rompería la ordenación.
@immutable
final class LeagueTable {
  const LeagueTable._(this.rows);

  /// Líneas ordenadas de mejor a peor.
  final List<TableRow> rows;

  /// Posición (1-based) del club [clubId].
  int positionOf(ClubId clubId) =>
      rows.indexWhere((row) => row.clubId == clubId) + 1;

  /// Calcula la clasificación de [clubs] a partir de los [results] de sus
  /// [fixtures]. Los fixtures sin resultado (aún no jugados) se ignoran.
  factory LeagueTable.compute({
    required List<ClubId> clubs,
    required List<Fixture> fixtures,
    required Map<FixtureId, MatchResult> results,
  }) {
    final rowsByClub = <ClubId, TableRow>{
      for (final clubId in clubs) clubId: TableRow.empty(clubId),
    };

    for (final fixture in fixtures) {
      final result = results[fixture.id];
      if (result == null) continue;
      rowsByClub.update(
        fixture.homeClubId,
        (row) =>
            row.adding(scored: result.homeGoals, conceded: result.awayGoals),
      );
      rowsByClub.update(
        fixture.awayClubId,
        (row) =>
            row.adding(scored: result.awayGoals, conceded: result.homeGoals),
      );
    }

    // Primera pasada: criterios globales (transitivos por construcción).
    final rows = rowsByClub.values.toList()
      ..sort((a, b) {
        final byPoints = b.points.compareTo(a.points);
        if (byPoints != 0) return byPoints;
        final byDifference = b.goalDifference.compareTo(a.goalDifference);
        if (byDifference != 0) return byDifference;
        final byScored = b.goalsFor.compareTo(a.goalsFor);
        if (byScored != 0) return byScored;
        return a.clubId.value.compareTo(b.clubId.value);
      });

    // Segunda pasada: cada grupo empatado a puntos, diferencia y goles se
    // reordena por su mini-liga de enfrentamientos directos.
    final ordered = <TableRow>[];
    var start = 0;
    while (start < rows.length) {
      var end = start + 1;
      while (end < rows.length && _tied(rows[start], rows[end])) {
        end++;
      }
      final group = rows.sublist(start, end);
      if (group.length > 1) {
        final groupIds = {for (final row in group) row.clubId};
        final headToHead = _headToHeadPoints(groupIds, fixtures, results);
        group.sort((a, b) {
          final byHeadToHead = headToHead[b.clubId]!.compareTo(
            headToHead[a.clubId]!,
          );
          if (byHeadToHead != 0) return byHeadToHead;
          return a.clubId.value.compareTo(b.clubId.value);
        });
      }
      ordered.addAll(group);
      start = end;
    }

    return LeagueTable._(List.unmodifiable(ordered));
  }

  static bool _tied(TableRow a, TableRow b) =>
      a.points == b.points &&
      a.goalDifference == b.goalDifference &&
      a.goalsFor == b.goalsFor;

  /// Puntos de cada club de [group] en los partidos disputados entre sí.
  static Map<ClubId, int> _headToHeadPoints(
    Set<ClubId> group,
    List<Fixture> fixtures,
    Map<FixtureId, MatchResult> results,
  ) {
    final points = {for (final clubId in group) clubId: 0};
    for (final fixture in fixtures) {
      if (!group.contains(fixture.homeClubId) ||
          !group.contains(fixture.awayClubId)) {
        continue;
      }
      final result = results[fixture.id];
      if (result == null) continue;
      if (result.homeGoals > result.awayGoals) {
        points.update(fixture.homeClubId, (p) => p + 3);
      } else if (result.homeGoals < result.awayGoals) {
        points.update(fixture.awayClubId, (p) => p + 3);
      } else {
        points.update(fixture.homeClubId, (p) => p + 1);
        points.update(fixture.awayClubId, (p) => p + 1);
      }
    }
    return points;
  }
}
