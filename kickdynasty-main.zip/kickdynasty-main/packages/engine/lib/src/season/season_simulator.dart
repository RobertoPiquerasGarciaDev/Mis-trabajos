/// Orquestador de temporada: calendario, jornadas con rotación y fatiga,
/// clasificaciones, estadísticas de jugador y rollover al año siguiente
/// (desarrollo, retiros, regens, ascensos y descensos).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/match_engine_config.dart';
import 'package:kickdynasty_engine/src/config/season_config.dart';
import 'package:kickdynasty_engine/src/config/world_gen_config.dart';
import 'package:kickdynasty_engine/src/match/lineup_selector.dart';
import 'package:kickdynasty_engine/src/match/match_report.dart';
import 'package:kickdynasty_engine/src/match/match_simulator.dart';
import 'package:kickdynasty_engine/src/match/team_sheet.dart';
import 'package:kickdynasty_engine/src/random/xoshiro.dart';
import 'package:kickdynasty_engine/src/season/campaign_state.dart';
import 'package:kickdynasty_engine/src/season/condition_cycle.dart';
import 'package:kickdynasty_engine/src/season/fixture_scheduler.dart';
import 'package:kickdynasty_engine/src/season/league_table.dart';
import 'package:kickdynasty_engine/src/season/player_development.dart';
import 'package:kickdynasty_engine/src/season/round_outcome.dart';
import 'package:kickdynasty_engine/src/worldgen/player_generator.dart';
import 'package:kickdynasty_engine/src/worldgen/world_generator.dart';
import 'package:meta/meta.dart';

/// Estadísticas acumuladas de un jugador en una temporada.
@immutable
final class PlayerSeasonStats {
  /// Crea las estadísticas.
  const PlayerSeasonStats({
    required this.playerId,
    required this.appearances,
    required this.goals,
    required this.assists,
    required this.yellowCards,
    required this.redCards,
    required this.averageRating,
  });

  /// Jugador.
  final PlayerId playerId;

  /// Partidos en los que participó.
  final int appearances;

  /// Goles (sin contar propias puertas).
  final int goals;

  /// Asistencias.
  final int assists;

  /// Amarillas.
  final int yellowCards;

  /// Expulsiones.
  final int redCards;

  /// Valoración media (0 si no jugó).
  final double averageRating;
}

/// Resultado de la temporada de una liga.
@immutable
final class LeagueSeasonOutcome {
  /// Crea el resultado.
  const LeagueSeasonOutcome({
    required this.league,
    required this.level,
    required this.clubs,
    required this.fixtures,
    required this.results,
    required this.table,
  });

  /// La liga.
  final League league;

  /// Nivel de la pirámide.
  final int level;

  /// Estado final de los clubes (plantillas con la condición de la última
  /// jornada).
  final List<GeneratedClub> clubs;

  /// Calendario completo.
  final List<Fixture> fixtures;

  /// Resultado de cada fixture.
  final Map<FixtureId, MatchResult> results;

  /// Clasificación final.
  final LeagueTable table;
}

/// Resultado completo de una temporada del mundo.
@immutable
final class SeasonOutcome {
  /// Crea el resultado.
  const SeasonOutcome({
    required this.season,
    required this.leagues,
    required this.playerStats,
  });

  /// Temporada disputada.
  final int season;

  /// Resultado por liga.
  final List<LeagueSeasonOutcome> leagues;

  /// Estadísticas de todos los jugadores que participaron.
  final Map<PlayerId, PlayerSeasonStats> playerStats;
}

/// Acumulador mutable interno de estadísticas de jugador.
final class _StatsAccumulator {
  int appearances = 0;
  int goals = 0;
  int assists = 0;
  int yellowCards = 0;
  int redCards = 0;
  double ratingSum = 0;

  _StatsAccumulator();

  /// Reconstruye el acumulador desde estadísticas ya persistidas.
  ///
  /// La suma de valoraciones es aproximada (el promedio guardado está
  /// redondeado), pero es suficiente para continuar acumulando jornadas
  /// tras guardar/cargar.
  factory _StatsAccumulator.fromStats(PlayerSeasonStats stats) {
    return _StatsAccumulator()
      ..appearances = stats.appearances
      ..goals = stats.goals
      ..assists = stats.assists
      ..yellowCards = stats.yellowCards
      ..redCards = stats.redCards
      ..ratingSum = stats.appearances == 0
          ? 0
          : stats.averageRating * stats.appearances;
  }

  PlayerSeasonStats build(PlayerId id) => PlayerSeasonStats(
    playerId: id,
    appearances: appearances,
    goals: goals,
    assists: assists,
    yellowCards: yellowCards,
    redCards: redCards,
    averageRating: appearances == 0
        ? 0
        : (ratingSum / appearances * 10).round() / 10,
  );
}

/// Simula temporadas completas de forma determinista.
///
/// Cada partido consume un generador derivado de
/// `(semilla, liga, jornada, cruce)`: la simulación de un partido es
/// independiente de cuánta aleatoriedad consuman los demás.
final class SeasonSimulator {
  /// Crea el simulador; sin argumentos usa las configuraciones estándar.
  SeasonSimulator({
    MatchEngineConfig? matchConfig,
    SeasonConfig? seasonConfig,
    WorldGenConfig? worldConfig,
  }) : seasonConfig = seasonConfig ?? SeasonConfig.standard(),
       worldConfig = worldConfig ?? WorldGenConfig.standard(),
       _matchSimulator = MatchSimulator(config: matchConfig),
       _lineupSelector = LineupSelector(config: matchConfig);

  /// Balance de la temporada.
  final SeasonConfig seasonConfig;

  /// Balance del mundo (plantilla tipo, calidad de cantera, contratos).
  final WorldGenConfig worldConfig;

  final MatchSimulator _matchSimulator;
  final LineupSelector _lineupSelector;

  static const _scheduleStream = 900000;

  /// Crea el estado inicial de una partida nueva: mundo generado y calendario
  /// de la temporada 1 programado con la misma semilla que
  /// [simulateSeason].
  CampaignState bootstrapCampaign({
    required int seed,
    ClubId? playerClubId,
    int season = 1,
  }) {
    final world = WorldGenerator(config: worldConfig).generate(seed: seed);
    const scheduler = FixtureScheduler();
    final fixtures = <Fixture>[];
    for (var li = 0; li < world.leagues.length; li++) {
      fixtures.addAll(
        scheduler.schedule(
          league: world.leagues[li].league,
          season: season,
          rng: Xoshiro256StarStar.fromSeed(
            derivedSeed(seed, _scheduleStream + li),
          ),
        ),
      );
    }
    return CampaignState(
      world: world,
      season: season,
      nextRound: 1,
      fixtures: fixtures,
      results: const {},
      stats: const {},
      playerClubId: playerClubId,
    );
  }

  /// Juega la próxima jornada de [state] y devuelve el estado actualizado.
  ///
  /// Usa la misma derivación de semillas que [simulateSeason], de modo que
  /// jugar jornada a jornada produce los mismos resultados que simular la
  /// temporada entera de una vez.
  CampaignPlayResult playRound({required CampaignState state}) {
    if (state.isSeasonComplete) {
      throw StateError(
        'La temporada ${state.season} ya está completa '
        '(jornada ${state.nextRound})',
      );
    }

    final seed = state.world.seed;
    final round = state.nextRound;
    final cycle = ConditionCycle(model: seasonConfig.condition);
    final stats = {
      for (final entry in state.stats.entries)
        entry.key: _StatsAccumulator.fromStats(entry.value),
    };

    final squads = {
      for (final club in state.world.allClubs) club.club.id: club.squad,
    };
    for (final clubId in squads.keys.toList()) {
      squads[clubId] = cycle.weeklyRecovery(squads[clubId]!);
    }

    final leagueIndex = {
      for (var i = 0; i < state.world.leagues.length; i++)
        state.world.leagues[i].league.id: i,
    };

    final roundFixtures = state.fixtures
        .where((fixture) => fixture.round == round)
        .toList();
    final matches = <RoundMatchOutcome>[];
    final results = Map<FixtureId, MatchResult>.from(state.results);

    final byLeague = <LeagueId, List<Fixture>>{};
    for (final fixture in roundFixtures) {
      byLeague.putIfAbsent(fixture.leagueId, () => []).add(fixture);
    }

    for (final entry in byLeague.entries) {
      final li = leagueIndex[entry.key]!;
      final leagueFixtures = entry.value;
      for (var mi = 0; mi < leagueFixtures.length; mi++) {
        final fixture = leagueFixtures[mi];
        final homeSheet = TeamSheet(
          squad: squads[fixture.homeClubId]!,
          lineup: _lineupSelector.select(squad: squads[fixture.homeClubId]!),
        );
        final awaySheet = TeamSheet(
          squad: squads[fixture.awayClubId]!,
          lineup: _lineupSelector.select(squad: squads[fixture.awayClubId]!),
        );

        final report = _matchSimulator.simulate(
          fixtureId: fixture.id,
          home: homeSheet,
          away: awaySheet,
          rng: Xoshiro256StarStar.fromSeed(
            derivedSeed(seed, (li + 1) * 100000 + round * 100 + mi),
          ),
        );
        results[fixture.id] = report.result;
        matches.add(RoundMatchOutcome(fixture: fixture, report: report));

        squads[fixture.homeClubId] = cycle.afterMatch(
          squad: squads[fixture.homeClubId]!,
          sheet: homeSheet,
          report: report,
          side: TeamSide.home,
        );
        squads[fixture.awayClubId] = cycle.afterMatch(
          squad: squads[fixture.awayClubId]!,
          sheet: awaySheet,
          report: report,
          side: TeamSide.away,
        );

        _accumulateStats(stats, report);
      }
    }

    final nextWorld = GeneratedWorld(
      seed: state.world.seed,
      leagues: [
        for (final league in state.world.leagues)
          GeneratedLeague(
            league: league.league,
            level: league.level,
            clubs: [
              for (final club in league.clubs)
                GeneratedClub(
                  club: club.club,
                  squad: squads[club.club.id]!,
                  contracts: club.contracts,
                ),
            ],
          ),
      ],
    );

    final nextState = CampaignState(
      world: nextWorld,
      season: state.season,
      nextRound: round + 1,
      fixtures: state.fixtures,
      results: results,
      stats: {
        for (final entry in stats.entries)
          entry.key: entry.value.build(entry.key),
      },
      playerClubId: state.playerClubId,
    );

    return CampaignPlayResult(
      state: nextState,
      round: RoundOutcome(round: round, matches: List.unmodifiable(matches)),
    );
  }

  /// Clasificación parcial o final de una liga dentro de [state].
  LeagueTable tableFor({
    required CampaignState state,
    required LeagueId leagueId,
  }) {
    final league = state.world.leagues
        .firstWhere((l) => l.league.id == leagueId)
        .league;
    final fixtures = state.fixtures
        .where((f) => f.leagueId == leagueId)
        .toList();
    return LeagueTable.compute(
      clubs: league.clubIds,
      fixtures: fixtures,
      results: state.results,
    );
  }

  /// Simula la temporada [season] completa del [world].
  ///
  /// No muta [world]: devuelve el estado final dentro del
  /// [SeasonOutcome]. La rotación emerge del ciclo de condición: el
  /// selector de alineaciones pondera el estado físico, así que los
  /// titulares fatigados rotan solos.
  SeasonOutcome simulateSeason({
    required GeneratedWorld world,
    required int season,
    required int seed,
  }) {
    const scheduler = FixtureScheduler();
    final cycle = ConditionCycle(model: seasonConfig.condition);
    final leagueOutcomes = <LeagueSeasonOutcome>[];
    final stats = <PlayerId, _StatsAccumulator>{};

    for (var li = 0; li < world.leagues.length; li++) {
      final generatedLeague = world.leagues[li];
      final fixtures = scheduler.schedule(
        league: generatedLeague.league,
        season: season,
        rng: Xoshiro256StarStar.fromSeed(
          derivedSeed(seed, _scheduleStream + li),
        ),
      );

      final squads = <ClubId, Squad>{
        for (final club in generatedLeague.clubs) club.club.id: club.squad,
      };
      final results = <FixtureId, MatchResult>{};
      final rounds = fixtures
          .map((f) => f.round)
          .reduce((a, b) => a > b ? a : b);

      for (var round = 1; round <= rounds; round++) {
        for (final clubId in squads.keys) {
          squads[clubId] = cycle.weeklyRecovery(squads[clubId]!);
        }

        final roundFixtures = fixtures.where((f) => f.round == round).toList();
        for (var mi = 0; mi < roundFixtures.length; mi++) {
          final fixture = roundFixtures[mi];
          final homeSheet = TeamSheet(
            squad: squads[fixture.homeClubId]!,
            lineup: _lineupSelector.select(squad: squads[fixture.homeClubId]!),
          );
          final awaySheet = TeamSheet(
            squad: squads[fixture.awayClubId]!,
            lineup: _lineupSelector.select(squad: squads[fixture.awayClubId]!),
          );

          final report = _matchSimulator.simulate(
            fixtureId: fixture.id,
            home: homeSheet,
            away: awaySheet,
            rng: Xoshiro256StarStar.fromSeed(
              derivedSeed(seed, (li + 1) * 100000 + round * 100 + mi),
            ),
          );
          results[fixture.id] = report.result;

          squads[fixture.homeClubId] = cycle.afterMatch(
            squad: squads[fixture.homeClubId]!,
            sheet: homeSheet,
            report: report,
            side: TeamSide.home,
          );
          squads[fixture.awayClubId] = cycle.afterMatch(
            squad: squads[fixture.awayClubId]!,
            sheet: awaySheet,
            report: report,
            side: TeamSide.away,
          );

          _accumulateStats(stats, report);
        }
      }

      leagueOutcomes.add(
        LeagueSeasonOutcome(
          league: generatedLeague.league,
          level: generatedLeague.level,
          clubs: List.unmodifiable([
            for (final club in generatedLeague.clubs)
              GeneratedClub(
                club: club.club,
                squad: squads[club.club.id]!,
                contracts: club.contracts,
              ),
          ]),
          fixtures: fixtures,
          results: Map.unmodifiable(results),
          table: LeagueTable.compute(
            clubs: generatedLeague.league.clubIds,
            fixtures: fixtures,
            results: results,
          ),
        ),
      );
    }

    return SeasonOutcome(
      season: season,
      leagues: List.unmodifiable(leagueOutcomes),
      playerStats: Map.unmodifiable({
        for (final entry in stats.entries)
          entry.key: entry.value.build(entry.key),
      }),
    );
  }

  /// Cierra la temporada y devuelve el mundo listo para la siguiente:
  /// desarrollo de jugadores, retiros con regens, contratos de canteranos
  /// y ascensos/descensos entre niveles adyacentes.
  GeneratedWorld advanceSeason({
    required SeasonOutcome outcome,
    required int seed,
  }) {
    final development = PlayerDevelopment(
      model: seasonConfig.development,
      playerGenerator: PlayerGenerator(config: worldConfig),
    );
    final nextSeason = outcome.season + 1;

    // 1. Desarrollo por club (flujo de aleatoriedad propio por club).
    final developedLeagues = <LeagueSeasonOutcome, List<GeneratedClub>>{};
    var clubStream = 0;
    for (final leagueOutcome in outcome.leagues) {
      final developedClubs = <GeneratedClub>[];
      for (final generatedClub in leagueOutcome.clubs) {
        clubStream++;
        final rng = Xoshiro256StarStar.fromSeed(
          derivedSeed(seed, 500000 + clubStream),
        );
        final result = development.endOfSeason(
          squad: generatedClub.squad,
          season: nextSeason,
          leagueCountry: generatedClub.club.country,
          leagueLevel: leagueOutcome.level,
          rng: rng,
        );

        final retiredIds = {for (final p in result.retired) p.id};
        final contracts = <Contract>[
          for (final contract in generatedClub.contracts)
            if (!retiredIds.contains(contract.playerId)) contract,
          for (final regen in result.regens)
            Contract(
              id: ContractId('contract-${regen.player.id.value}'),
              playerId: regen.player.id,
              clubId: generatedClub.club.id,
              weeklyWage: regen.weeklyWage,
              expiry: GameDate(
                season: nextSeason + worldConfig.contractSeasons.max,
                week: 1,
              ),
            ),
        ];

        developedClubs.add(
          GeneratedClub(
            club: generatedClub.club,
            squad: result.squad,
            contracts: List.unmodifiable(contracts),
          ),
        );
      }
      developedLeagues[leagueOutcome] = developedClubs;
    }

    // 2. Ascensos y descensos entre niveles adyacentes.
    final ordered = outcome.leagues.toList()
      ..sort((a, b) => a.level.compareTo(b.level));
    final clubsByLeague = {
      for (final leagueOutcome in ordered)
        leagueOutcome: List<GeneratedClub>.of(developedLeagues[leagueOutcome]!),
    };

    final swap = seasonConfig.promotionRelegationCount;
    for (var i = 0; i + 1 < ordered.length; i++) {
      final upper = ordered[i];
      final lower = ordered[i + 1];
      final relegatedIds = upper.table.rows.reversed
          .take(swap)
          .map((row) => row.clubId)
          .toSet();
      final promotedIds = lower.table.rows
          .take(swap)
          .map((row) => row.clubId)
          .toSet();

      final upperClubs = clubsByLeague[upper]!;
      final lowerClubs = clubsByLeague[lower]!;
      final relegated = upperClubs
          .where((c) => relegatedIds.contains(c.club.id))
          .toList();
      final promoted = lowerClubs
          .where((c) => promotedIds.contains(c.club.id))
          .toList();

      upperClubs
        ..removeWhere((c) => relegatedIds.contains(c.club.id))
        ..addAll(promoted);
      lowerClubs
        ..removeWhere((c) => promotedIds.contains(c.club.id))
        ..addAll(relegated);
    }

    // 3. Reconstruir las ligas con sus nuevos miembros.
    return GeneratedWorld(
      seed: seed,
      leagues: List.unmodifiable([
        for (final leagueOutcome in ordered)
          GeneratedLeague(
            league: League(
              id: leagueOutcome.league.id,
              name: DisplayName(leagueOutcome.league.name.value),
              country: leagueOutcome.league.country,
              clubIds: [
                for (final club in clubsByLeague[leagueOutcome]!) club.club.id,
              ],
            ),
            level: leagueOutcome.level,
            clubs: List.unmodifiable(clubsByLeague[leagueOutcome]!),
          ),
      ]),
    );
  }

  void _accumulateStats(
    Map<PlayerId, _StatsAccumulator> stats,
    MatchReport report,
  ) {
    _StatsAccumulator of(PlayerId id) =>
        stats.putIfAbsent(id, () => _StatsAccumulator());

    for (final entry in report.ratings.entries) {
      of(entry.key)
        ..appearances += 1
        ..ratingSum += entry.value;
    }

    for (final event in report.result.events) {
      switch (event) {
        case GoalScored(:final scorerId, :final assistantId, :final ownGoal):
          if (!ownGoal) {
            of(scorerId).goals += 1;
            if (assistantId != null) of(assistantId).assists += 1;
          }
        case CardIssued(:final playerId, :final cardType):
          if (cardType == CardType.yellow) {
            of(playerId).yellowCards += 1;
          } else {
            of(playerId).redCards += 1;
          }
        case PlayerInjured():
        case Substitution():
          break;
      }
    }
  }
}
