/// Estado completo de una partida en curso.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/season/season_simulator.dart';
import 'package:kickdynasty_engine/src/worldgen/world_generator.dart';
import 'package:meta/meta.dart';

/// El agregado que se guarda y se carga: el mundo en su estado actual más
/// el progreso de la temporada en curso.
///
/// Es la unidad de persistencia (la capa `persistence` lo mapea a SQL) y
/// la unidad de avance del juego (la capa `application` juega jornadas
/// sobre él). Es inmutable: avanzar produce un estado nuevo.
@immutable
final class CampaignState {
  /// Crea el estado validando los escalares.
  CampaignState({
    required this.world,
    required this.season,
    required this.nextRound,
    required List<Fixture> fixtures,
    required Map<FixtureId, MatchResult> results,
    required Map<PlayerId, PlayerSeasonStats> stats,
    this.playerClubId,
    this.playerLineup,
    Map<String, MatchLineup> clubLineups = const {},
  }) : fixtures = List.unmodifiable(fixtures),
       results = Map.unmodifiable(results),
       stats = Map.unmodifiable(stats),
       clubLineups = Map.unmodifiable(clubLineups) {
    if (season < 1) {
      throw DomainInvariantViolation(
        'CampaignState.season debe ser >= 1 (recibido: $season)',
      );
    }
    if (nextRound < 1) {
      throw DomainInvariantViolation(
        'CampaignState.nextRound debe ser >= 1 (recibido: $nextRound)',
      );
    }
  }

  /// El mundo en su estado actual (plantillas con la condición del día).
  final GeneratedWorld world;

  /// Temporada en curso (≥ 1).
  final int season;

  /// Próxima jornada a disputar (≥ 1; mayor que el total de jornadas
  /// significa temporada terminada, lista para el rollover).
  final int nextRound;

  /// Calendario completo de la temporada en curso (todas las ligas).
  final List<Fixture> fixtures;

  /// Resultados de los fixtures ya disputados.
  final Map<FixtureId, MatchResult> results;

  /// Estadísticas de jugador acumuladas en la temporada en curso.
  final Map<PlayerId, PlayerSeasonStats> stats;

  /// Club dirigido por el jugador humano (`null` = partida espectador).
  final ClubId? playerClubId;

  /// Alineación confirmada del club del jugador para la próxima jornada.
  final MatchLineup? playerLineup;

  /// Alineaciones confirmadas por club (clave = id del club).
  final Map<String, MatchLineup> clubLineups;

  /// `true` si todas las jornadas de la temporada están disputadas.
  bool get isSeasonComplete => results.length == fixtures.length;

  /// Club del jugador en [state], si existe.
  static GeneratedClub? playerClub(CampaignState state) {
    final id = state.playerClubId;
    if (id == null) return null;
    for (final club in state.world.allClubs) {
      if (club.club.id == id) return club;
    }
    return null;
  }

  /// Próximo partido del club del jugador, o `null`.
  static Fixture? nextPlayerFixture(CampaignState state) {
    final clubId = state.playerClubId;
    if (clubId == null || state.isSeasonComplete) return null;
    final round = state.nextRound;
    for (final fixture in state.fixtures) {
      if (fixture.round != round) continue;
      if (fixture.homeClubId == clubId || fixture.awayClubId == clubId) {
        return fixture;
      }
    }
    return null;
  }

  /// Partidos de la liga del jugador ordenados por jornada.
  static List<Fixture> playerLeagueFixtures(CampaignState state) {
    final club = playerClub(state);
    if (club == null) return const [];
    LeagueId? leagueId;
    for (final league in state.world.leagues) {
      if (league.clubs.any((c) => c.club.id == club.club.id)) {
        leagueId = league.league.id;
        break;
      }
    }
    if (leagueId == null) return const [];
    return state.fixtures.where((f) => f.leagueId == leagueId).toList()
      ..sort((a, b) {
        final roundCmp = a.round.compareTo(b.round);
        if (roundCmp != 0) return roundCmp;
        return a.id.value.compareTo(b.id.value);
      });
  }

  /// Copia con campos sustituidos.
  CampaignState copyWith({
    GeneratedWorld? world,
    int? season,
    int? nextRound,
    List<Fixture>? fixtures,
    Map<FixtureId, MatchResult>? results,
    Map<PlayerId, PlayerSeasonStats>? stats,
    ClubId? playerClubId,
    MatchLineup? playerLineup,
    bool clearPlayerLineup = false,
    Map<String, MatchLineup>? clubLineups,
  }) => CampaignState(
    world: world ?? this.world,
    season: season ?? this.season,
    nextRound: nextRound ?? this.nextRound,
    fixtures: fixtures ?? this.fixtures,
    results: results ?? this.results,
    stats: stats ?? this.stats,
    playerClubId: playerClubId ?? this.playerClubId,
    playerLineup: clearPlayerLineup
        ? null
        : (playerLineup ?? this.playerLineup),
    clubLineups: clubLineups ?? this.clubLineups,
  );
}
