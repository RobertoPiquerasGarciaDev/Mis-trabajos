/// Ciclo de condición entre jornadas: fatiga post-partido, recuperación
/// semanal, moral por resultados y forma por rendimiento.
///
/// Funciones puras `(Squad, contexto) → Squad`. La presión de rotación del
/// juego nace aquí: un titular fijo no vuelve a estar pleno entre jornadas,
/// así que alinear siempre a los mismos once sale caro.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/season_config.dart';
import 'package:kickdynasty_engine/src/match/match_report.dart';
import 'package:kickdynasty_engine/src/match/team_sheet.dart';

/// Aplica el ciclo semanal de condición de una plantilla.
final class ConditionCycle {
  /// Crea el ciclo con su [model] de balance.
  const ConditionCycle({required this.model});

  /// Parámetros del ciclo (fatiga, recuperación, moral, forma).
  final ConditionCycleModel model;

  /// Recuperación semanal previa a la jornada: el estado físico recupera
  /// una fracción del déficit, la moral revierte hacia su línea base y la
  /// forma de todos decae ligeramente hacia el valor neutral.
  Squad weeklyRecovery(Squad squad) {
    return Squad(
      clubId: squad.clubId,
      players: [
        for (final player in squad.players)
          player.copyWith(
            fitness: Fitness.clamped(
              (player.fitness.value +
                      (Fitness.max - player.fitness.value) *
                          model.recoveryFraction)
                  .round(),
            ),
            morale: Morale.clamped(
              (player.morale.value +
                      (model.moraleBaseline - player.morale.value) *
                          model.moraleReversion)
                  .round(),
            ),
            form: Form.clamped(
              (player.form.value +
                      (model.formNeutral - player.form.value) *
                          model.formDecayFactor)
                  .round(),
            ),
          ),
      ],
    );
  }

  /// Efectos de un partido sobre la plantilla de un club: fatiga de los
  /// que jugaron, desplome físico del lesionado, moral de todo el vestuario
  /// según el resultado y forma de los participantes según su valoración.
  Squad afterMatch({
    required Squad squad,
    required TeamSheet sheet,
    required MatchReport report,
    required TeamSide side,
  }) {
    final starters = sheet.lineup.starters.toSet();
    final cameOn = <PlayerId>{};
    final injured = <PlayerId>{};
    for (final event in report.result.events) {
      if (event.side != side) continue;
      switch (event) {
        case Substitution(:final playerInId):
          cameOn.add(playerInId);
        case PlayerInjured(:final playerId):
          injured.add(playerId);
        case GoalScored():
        case CardIssued():
          break;
      }
    }

    final goalsFor = side == TeamSide.home
        ? report.result.homeGoals
        : report.result.awayGoals;
    final goalsAgainst = side == TeamSide.home
        ? report.result.awayGoals
        : report.result.homeGoals;
    final moraleDelta = goalsFor > goalsAgainst
        ? model.moraleWin
        : goalsFor == goalsAgainst
        ? model.moraleDraw
        : model.moraleLoss;

    return Squad(
      clubId: squad.clubId,
      players: [
        for (final player in squad.players)
          _afterMatchPlayer(
            player,
            isStarter: starters.contains(player.id),
            cameOn: cameOn.contains(player.id),
            isInjured: injured.contains(player.id),
            rating: report.ratings[player.id],
            moraleDelta: moraleDelta,
          ),
      ],
    );
  }

  Player _afterMatchPlayer(
    Player player, {
    required bool isStarter,
    required bool cameOn,
    required bool isInjured,
    required double? rating,
    required int moraleDelta,
  }) {
    var fitness = player.fitness.value;
    if (isInjured) {
      fitness = model.injuredFitness;
    } else if (isStarter) {
      fitness -= model.starterFatigue;
    } else if (cameOn) {
      fitness -= model.substituteFatigue;
    }

    var form = player.form.value;
    if (rating != null) {
      // Valoración 6 ≈ forma 50; cada punto de valoración mueve el nivel
      // objetivo 25 puntos de forma.
      final target = (50 + (rating - 6) * 25).clamp(0, 100);
      form = (form + (target - form) * model.formUpdateFactor).round();
    }

    return player.copyWith(
      fitness: Fitness.clamped(fitness),
      morale: Morale.clamped(player.morale.value + moraleDelta),
      form: Form.clamped(form),
    );
  }
}
