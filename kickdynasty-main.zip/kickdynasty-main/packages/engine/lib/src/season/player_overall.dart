/// Valoración agregada (OVR) en el motor.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Calcula la valoración general de [player] (1–99).
int playerOverallRating(Player player) {
  final attrs = player.attributes;
  final fieldAvg =
      (attrs.pace.value +
          attrs.stamina.value +
          attrs.strength.value +
          attrs.passing.value +
          attrs.shooting.value +
          attrs.dribbling.value +
          attrs.tackling.value +
          attrs.positioning.value +
          attrs.vision.value +
          attrs.composure.value) ~/
      10;
  if (player.position.isGoalkeeper) {
    return ((fieldAvg + attrs.goalkeeping.value * 2) / 3).round();
  }
  return fieldAvg;
}
