/// Calendario de liga: round-robin a doble vuelta por el método del círculo.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/random/rng.dart';

/// Genera calendarios de liga correctos y deterministas.
///
/// Método del círculo: con `n` clubes salen `n − 1` jornadas de ida
/// (cada club juega exactamente una vez por jornada) y la vuelta espeja
/// la ida con la localía invertida. Total: `2(n − 1)` jornadas y cada par
/// de clubes se enfrenta exactamente dos veces, una en cada campo.
final class FixtureScheduler {
  /// Crea el planificador.
  const FixtureScheduler();

  /// Genera el calendario completo de [league] para [season].
  ///
  /// El [rng] baraja el orden inicial de los clubes para que cada
  /// temporada tenga un calendario distinto (pero reproducible por
  /// semilla). En la ida se alterna la localía por ronda para repartir
  /// rachas de campo propio.
  List<Fixture> schedule({
    required League league,
    required int season,
    required Rng rng,
  }) {
    final clubs = List<ClubId>.of(league.clubIds);
    // Barajado de Fisher–Yates con el rng inyectado.
    for (var i = clubs.length - 1; i > 0; i--) {
      final j = rng.nextInt(i + 1);
      final tmp = clubs[i];
      clubs[i] = clubs[j];
      clubs[j] = tmp;
    }

    final n = clubs.length;
    final roundsPerLeg = n - 1;
    final matchesPerRound = n ~/ 2;
    final fixtures = <Fixture>[];

    // El club `clubs[0]` queda fijo; el resto rota una posición por jornada.
    final rotating = clubs.sublist(1);

    for (var round = 0; round < roundsPerLeg; round++) {
      final order = [clubs[0], ...rotating];
      for (var match = 0; match < matchesPerRound; match++) {
        final a = order[match];
        final b = order[n - 1 - match];
        // Alterna localía: en el emparejamiento del club fijo, según la
        // paridad de la jornada; en el resto, según el índice del cruce.
        final aHome = match == 0 ? round.isEven : match.isOdd;
        final home = aHome ? a : b;
        final away = aHome ? b : a;

        fixtures.add(
          Fixture(
            id: FixtureId(
              's$season-${league.id.value}-r${round + 1}-m${match + 1}',
            ),
            leagueId: league.id,
            season: season,
            round: round + 1,
            homeClubId: home,
            awayClubId: away,
          ),
        );
      }
      rotating.insert(0, rotating.removeLast());
    }

    // Segunda vuelta: mismos cruces con la localía invertida.
    final firstLeg = List<Fixture>.of(fixtures);
    for (final fixture in firstLeg) {
      final round = fixture.round + roundsPerLeg;
      fixtures.add(
        Fixture(
          id: FixtureId(
            's$season-${league.id.value}-r$round-'
            'm${fixture.id.value.split('-m').last}',
          ),
          leagueId: fixture.leagueId,
          season: season,
          round: round,
          homeClubId: fixture.awayClubId,
          awayClubId: fixture.homeClubId,
        ),
      );
    }

    return List.unmodifiable(fixtures);
  }
}
