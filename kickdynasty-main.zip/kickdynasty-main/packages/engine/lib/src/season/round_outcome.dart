/// Resultado de jugar una jornada sobre una partida en curso.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/match/match_report.dart';
import 'package:kickdynasty_engine/src/season/campaign_state.dart';
import 'package:meta/meta.dart';

/// Un partido disputado en la jornada con su informe completo.
@immutable
final class RoundMatchOutcome {
  /// Crea el resultado del partido.
  const RoundMatchOutcome({required this.fixture, required this.report});

  /// Fixture disputado.
  final Fixture fixture;

  /// Informe del partido (resultado, estadísticas y valoraciones).
  final MatchReport report;
}

/// Resultado agregado de una jornada.
@immutable
final class RoundOutcome {
  /// Crea el resultado de la jornada.
  const RoundOutcome({required this.round, required this.matches});

  /// Número de jornada disputada.
  final int round;

  /// Partidos de la jornada, en el orden del calendario.
  final List<RoundMatchOutcome> matches;
}

/// Estado de campaña tras jugar una jornada más su desglose.
@immutable
final class CampaignPlayResult {
  /// Crea el par estado/outcome.
  const CampaignPlayResult({required this.state, required this.round});

  /// Estado actualizado (mundo, resultados, estadísticas, nextRound++).
  final CampaignState state;

  /// Detalle de la jornada recién disputada.
  final RoundOutcome round;
}
