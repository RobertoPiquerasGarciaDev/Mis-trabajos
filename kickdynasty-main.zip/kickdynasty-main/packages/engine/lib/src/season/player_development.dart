/// Desarrollo de jugadores al cierre de temporada: progresión hacia el
/// potencial, declive por edad, retiros y canteranos de reemplazo (regens).
library;

import 'dart:math' as math;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/attribute_model.dart';
import 'package:kickdynasty_engine/src/config/season_config.dart';
import 'package:kickdynasty_engine/src/random/rng.dart';
import 'package:kickdynasty_engine/src/worldgen/player_generator.dart';
import 'package:meta/meta.dart';

/// Atributos que decaen antes y más rápido con la edad.
const Set<AttributeKey> physicalAttributes = {
  AttributeKey.pace,
  AttributeKey.stamina,
  AttributeKey.strength,
};

/// Resultado del cierre de temporada de una plantilla.
@immutable
final class SquadDevelopment {
  /// Crea el resultado.
  const SquadDevelopment({
    required this.squad,
    required this.retired,
    required this.regens,
  });

  /// Plantilla resultante (desarrollada, sin retirados, con regens).
  final Squad squad;

  /// Jugadores que colgaron las botas.
  final List<Player> retired;

  /// Canteranos generados para reemplazar a los retirados, con su salario
  /// (para que el orquestador les cree contrato).
  final List<GeneratedPlayer> regens;
}

/// Aplica el paso de temporada a los jugadores de un club.
final class PlayerDevelopment {
  /// Crea el sistema con su modelo de balance y el generador con el que
  /// produce canteranos coherentes con el mundo.
  const PlayerDevelopment({required this.model, required this.playerGenerator});

  /// Parámetros de desarrollo (ADR 0005).
  final DevelopmentModel model;

  /// Generador de jugadores para los regens.
  final PlayerGenerator playerGenerator;

  /// Cierra la temporada de [squad]: envejece, progresa o declina a cada
  /// jugador, resuelve retiros y genera canteranos que mantienen la
  /// plantilla dentro de sus invariantes.
  ///
  /// [season] es la temporada que arranca (para los ids de los regens) y
  /// [leagueLevel] fija la calidad de la cantera.
  SquadDevelopment endOfSeason({
    required Squad squad,
    required int season,
    required CountryCode leagueCountry,
    required int leagueLevel,
    required Rng rng,
  }) {
    final developed = <Player>[];
    final retired = <Player>[];

    for (final player in squad.players) {
      final newAge = player.age.years + 1;
      if (newAge > Age.max || rng.chance(model.retirementChanceFor(newAge))) {
        retired.add(player);
        continue;
      }
      developed.add(_developPlayer(player, newAge, rng));
    }

    // Reemplazo 1:1 de los retirados; los porteros se reponen con porteros
    // para no violar el invariante de la plantilla.
    final regens = <GeneratedPlayer>[];
    for (var i = 0; i < retired.length; i++) {
      regens.add(
        playerGenerator.generate(
          id: PlayerId('${squad.clubId.value}-s$season-regen${i + 1}'),
          position: retired[i].position,
          leagueCountry: leagueCountry,
          leagueLevel: leagueLevel,
          rng: rng,
          age: rng.rangeInt(model.regenAgeRange.min, model.regenAgeRange.max),
        ),
      );
    }

    return SquadDevelopment(
      squad: Squad(
        clubId: squad.clubId,
        players: [...developed, ...regens.map((r) => r.player)],
      ),
      retired: List.unmodifiable(retired),
      regens: List.unmodifiable(regens),
    );
  }

  Player _developPlayer(Player player, int newAge, Rng rng) {
    final growthFraction = model.growthFractionFor(newAge);
    final decline = model.declinePointsFor(newAge);

    final currentValues = {
      for (final key in AttributeKey.values)
        key: attributeValue(player.attributes, key),
    };
    // El margen de mejora se mide contra el mejor atributo: los puntos
    // fuertes del jugador se acercan a su potencial y el resto crece en
    // proporción.
    final best = currentValues.values.reduce(math.max);
    final headroom = math.max(0, player.potential.value - best);

    final newValues = <AttributeKey, Rating>{};
    for (final entry in currentValues.entries) {
      var delta = 0.0;
      if (growthFraction > 0) {
        delta += math.min(headroom * growthFraction, model.maxGrowthPerSeason);
      }
      if (decline > 0) {
        delta -=
            decline *
            (physicalAttributes.contains(entry.key)
                ? model.physicalDeclineFactor
                : model.technicalDeclineFactor);
      }
      delta += rng.gaussian(stdDev: model.developmentNoise);
      newValues[entry.key] = Rating.clamped((entry.value + delta).round());
    }

    return player.copyWith(
      age: Age(newAge),
      attributes: buildAttributes(newValues),
      fitness: Fitness(
        rng.rangeInt(model.preseasonFitness.min, model.preseasonFitness.max),
      ),
    );
  }
}
