/// Selección automática de alineación (para la IA y para avanzar jornadas
/// sin intervención del jugador).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/match_engine_config.dart';
import 'package:kickdynasty_engine/src/match/team_strength.dart';

/// Elige la mejor alineación disponible de una plantilla, de forma
/// determinista (sin aleatoriedad: misma plantilla → misma alineación).
final class LineupSelector {
  /// Crea el selector con la configuración de motor que define cómo se
  /// valora a un jugador en cada puesto.
  LineupSelector({MatchEngineConfig? config})
    : config = config ?? MatchEngineConfig.standard();

  /// Configuración del motor (pesos por rol y penalizaciones de posición).
  final MatchEngineConfig config;

  /// Tamaño de banquillo que convoca el selector.
  static const int benchSize = 7;

  /// Elige titulares, banquillo y capitán para [squad].
  ///
  /// Cada puesto de la formación se cubre con el jugador disponible que
  /// maximiza su aportación en ese puesto (rol × penalización de posición ×
  /// estado físico). El banquillo prioriza un portero suplente y completa
  /// con los mejores restantes.
  MatchLineup select({
    required Squad squad,
    Formation? formation,
    TacticalInstructions instructions = const TacticalInstructions(),
  }) {
    final chosenFormation = formation ?? Formation.f433;
    final available = List<Player>.of(squad.players);
    final starters = <PlayerId>[];

    for (final slot in chosenFormation.slots) {
      final best = _bestForSlot(available, slot);
      starters.add(best.id);
      available.remove(best);
    }

    final bench = <PlayerId>[];
    final spareGoalkeeper = _bestOrNull(
      available.where((p) => p.position.isGoalkeeper).toList(),
      Position.gk,
    );
    if (spareGoalkeeper != null) {
      bench.add(spareGoalkeeper.id);
      available.remove(spareGoalkeeper);
    }
    available.sort(
      (a, b) => _slotScore(b, b.position).compareTo(_slotScore(a, a.position)),
    );
    for (final player in available.take(benchSize - bench.length)) {
      bench.add(player.id);
    }

    final captain = _captain(squad, starters);

    return MatchLineup(
      formation: chosenFormation,
      starters: starters,
      bench: bench,
      captainId: captain,
      instructions: instructions,
    );
  }

  Player _bestForSlot(List<Player> available, Position slot) {
    final best = _bestOrNull(available, slot);
    if (best == null) {
      throw StateError('No quedan jugadores para cubrir el puesto $slot');
    }
    return best;
  }

  Player? _bestOrNull(List<Player> candidates, Position slot) {
    Player? best;
    var bestScore = double.negativeInfinity;
    for (final player in candidates) {
      final score = _slotScore(player, slot);
      if (score > bestScore) {
        best = player;
        bestScore = score;
      }
    }
    return best;
  }

  /// Valor de [player] ocupando [slot]: rol de la unidad asociada a la línea
  /// del puesto, penalizado por posición y estado físico.
  double _slotScore(Player player, Position slot) {
    final unit = switch (slot.group) {
      PositionGroup.goalkeeper ||
      PositionGroup.defence => config.strength.defenceUnit,
      PositionGroup.midfield => config.strength.midfieldUnit,
      PositionGroup.attack => config.strength.attackUnit,
    };
    final slotPlayer = SlotPlayer(slot: slot, player: player);
    return roleRating(slotPlayer, unit) *
        positionFactor(
          player.position,
          slot,
          config.strength.positionPenalties,
        ) *
        (0.5 + 0.5 * player.fitness.value / 100);
  }

  PlayerId _captain(Squad squad, List<PlayerId> starters) {
    PlayerId best = starters.first;
    var bestScore = -1;
    for (final id in starters) {
      final player = squad.byId(id)!;
      final score = player.attributes.composure.value + player.age.years;
      if (score > bestScore) {
        best = id;
        bestScore = score;
      }
    }
    return best;
  }
}
