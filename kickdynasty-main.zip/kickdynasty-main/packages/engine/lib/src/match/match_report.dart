/// Informe completo de un partido simulado.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:meta/meta.dart';

/// Estadísticas de equipo de un partido.
@immutable
final class TeamMatchStats {
  /// Crea las estadísticas.
  const TeamMatchStats({
    required this.possessionPct,
    required this.shots,
    required this.shotsOnTarget,
    required this.expectedGoals,
    required this.yellowCards,
    required this.redCards,
  });

  /// Posesión en porcentaje (la suma de ambos equipos es 100).
  final int possessionPct;

  /// Disparos totales.
  final int shots;

  /// Disparos entre los tres palos.
  final int shotsOnTarget;

  /// Goles esperados (xG) acumulados.
  final double expectedGoals;

  /// Amarillas mostradas.
  final int yellowCards;

  /// Expulsiones (roja directa o doble amarilla).
  final int redCards;
}

/// Resultado, estadísticas y valoraciones de un partido simulado.
///
/// El [result] contiene la cronología de eventos con jugadores reales; las
/// [ratings] cubren exactamente a los jugadores que pisaron el campo.
@immutable
final class MatchReport {
  /// Crea el informe.
  const MatchReport({
    required this.result,
    required this.homeStats,
    required this.awayStats,
    required this.ratings,
  });

  /// Resultado con eventos (coherente por construcción, ver
  /// `MatchResult.fromEvents`).
  final MatchResult result;

  /// Estadísticas del equipo local.
  final TeamMatchStats homeStats;

  /// Estadísticas del equipo visitante.
  final TeamMatchStats awayStats;

  /// Valoración (4–10) de cada jugador que participó.
  final Map<PlayerId, double> ratings;
}
