/// Modelo de fuerza de equipo: funciones puras que convierten los jugadores
/// sobre el campo en las tres unidades (defensa, mediocampo, ataque).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/attribute_model.dart';
import 'package:kickdynasty_engine/src/config/match_engine_config.dart';
import 'package:meta/meta.dart';

/// Un jugador sobre el campo, con el puesto de la formación que ocupa y el
/// minuto en el que entró (0 para los titulares).
@immutable
final class SlotPlayer {
  /// Crea la asignación.
  const SlotPlayer({
    required this.slot,
    required this.player,
    this.entryMinute = 0,
  });

  /// Puesto de la formación que ocupa.
  final Position slot;

  /// El jugador.
  final Player player;

  /// Minuto en el que entró al campo.
  final int entryMinute;
}

/// Fuerza de las tres unidades de un equipo en un instante del partido.
@immutable
final class UnitScores {
  /// Crea las puntuaciones.
  const UnitScores({
    required this.defence,
    required this.midfield,
    required this.attack,
  });

  /// Unidad defensiva.
  final double defence;

  /// Unidad de mediocampo.
  final double midfield;

  /// Unidad ofensiva.
  final double attack;
}

/// Factor multiplicativo por jugar en [slot] siendo [natural] la posición
/// natural del jugador.
double positionFactor(
  Position natural,
  Position slot,
  PositionPenalties penalties,
) {
  if (natural == slot) return penalties.samePosition;
  final naturalIsGk = natural.group == PositionGroup.goalkeeper;
  final slotIsGk = slot.group == PositionGroup.goalkeeper;
  if (naturalIsGk != slotIsGk) return penalties.crossGoalkeeper;
  if (natural.group == slot.group) return penalties.sameGroup;
  final distance = (natural.group.index - slot.group.index).abs();
  return distance == 1 ? penalties.adjacentGroup : penalties.farGroup;
}

/// Factor de condición del jugador en [minute]: estado físico (con fatiga
/// acumulada durante el partido), forma y moral.
double conditionFactor(SlotPlayer slotPlayer, int minute, StrengthModel model) {
  final player = slotPlayer.player;
  final fatigueFactor = slotPlayer.slot.group == PositionGroup.goalkeeper
      ? model.goalkeeperFatigueFactor
      : 1.0;
  final minutesPlayed = minute - slotPlayer.entryMinute;
  final effectiveFitness =
      (player.fitness.value -
              model.fatiguePerMinute * fatigueFactor * minutesPlayed)
          .clamp(0.0, 100.0);

  final fitness =
      model.fitnessFloor + (1 - model.fitnessFloor) * effectiveFitness / 100;
  final form =
      1 - model.formSwing / 2 + model.formSwing * player.form.value / 100;
  final morale =
      1 - model.moraleSwing / 2 + model.moraleSwing * player.morale.value / 100;
  return fitness * form * morale;
}

/// Aportación de un jugador a una unidad: sus atributos pesados según la
/// línea del puesto que ocupa.
double roleRating(SlotPlayer slotPlayer, UnitModel unit) {
  final weights = unit.roleWeights[slotPlayer.slot.group] ?? const {};
  var rating = 0.0;
  for (final entry in weights.entries) {
    rating +=
        attributeValue(slotPlayer.player.attributes, entry.key) * entry.value;
  }
  return rating;
}

double _unitScore(
  List<SlotPlayer> onPitch,
  Formation formation,
  UnitModel unit,
  StrengthModel model,
  int minute,
) {
  // El denominador es la contribución del once completo: si un equipo se
  // queda con menos jugadores (expulsión, lesión sin cambios), la unidad
  // pierde fuerza en proporción.
  var denominator = 0.0;
  for (final slot in formation.slots) {
    denominator += unit.contributions[slot.group] ?? 0;
  }
  if (denominator == 0) return 0;

  var numerator = 0.0;
  for (final slotPlayer in onPitch) {
    final contribution = unit.contributions[slotPlayer.slot.group] ?? 0;
    if (contribution == 0) continue;
    numerator +=
        contribution *
        roleRating(slotPlayer, unit) *
        positionFactor(
          slotPlayer.player.position,
          slotPlayer.slot,
          model.positionPenalties,
        ) *
        conditionFactor(slotPlayer, minute, model);
  }
  return numerator / denominator;
}

UnitModifiers _tacticModifiers(
  TacticalInstructions instructions,
  StrengthModel model,
) {
  final parts = [
    model.mentalityModifiers[instructions.mentality],
    model.defensiveLineModifiers[instructions.defensiveLine],
    model.widthModifiers[instructions.width],
    model.passingModifiers[instructions.passingStyle],
  ];
  var attack = 1.0;
  var midfield = 1.0;
  var defence = 1.0;
  for (final modifier in parts) {
    if (modifier == null) continue;
    attack *= modifier.attack;
    midfield *= modifier.midfield;
    defence *= modifier.defence;
  }
  return UnitModifiers(attack: attack, midfield: midfield, defence: defence);
}

/// Calcula la fuerza de las tres unidades de un equipo.
///
/// [onPitch] son los jugadores actualmente sobre el campo (≤ 11);
/// [formation] define la plantilla completa contra la que se normaliza, de
/// modo que jugar con menos hombres debilita al equipo. [homeFactor] aplica
/// la ventaja de campo y [minute] activa la fatiga acumulada.
UnitScores computeUnitScores({
  required List<SlotPlayer> onPitch,
  required Formation formation,
  required TacticalInstructions instructions,
  required StrengthModel model,
  int minute = 0,
  double homeFactor = 1,
}) {
  final modifiers = _tacticModifiers(instructions, model);
  return UnitScores(
    defence:
        _unitScore(onPitch, formation, model.defenceUnit, model, minute) *
        modifiers.defence *
        homeFactor,
    midfield:
        _unitScore(onPitch, formation, model.midfieldUnit, model, minute) *
        modifiers.midfield *
        homeFactor,
    attack:
        _unitScore(onPitch, formation, model.attackUnit, model, minute) *
        modifiers.attack *
        homeFactor,
  );
}
