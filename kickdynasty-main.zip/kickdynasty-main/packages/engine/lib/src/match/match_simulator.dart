/// Simulador de partidos: modelo de posesiones minuto a minuto
/// (construcción → ocasión → definición) con eventos sobre jugadores reales.
library;

import 'dart:math' as math;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/src/config/match_engine_config.dart';
import 'package:kickdynasty_engine/src/match/match_report.dart';
import 'package:kickdynasty_engine/src/match/team_sheet.dart';
import 'package:kickdynasty_engine/src/match/team_strength.dart';
import 'package:kickdynasty_engine/src/random/rng.dart';

/// Estado mutable de un equipo durante la simulación.
final class _SideState {
  _SideState({required this.sheet, required this.side, required this.isHome});

  final TeamSheet sheet;
  final TeamSide side;
  final bool isHome;

  /// Jugadores sobre el campo, con su puesto y minuto de entrada.
  final List<SlotPlayer> onPitch = [];

  /// Suplentes aún disponibles.
  final List<Player> benchAvailable = [];

  /// Todos los que han pisado el campo (para las valoraciones).
  final Set<PlayerId> participants = {};

  /// Amarillas vistas por jugador (para la segunda amarilla).
  final Set<PlayerId> booked = {};

  int substitutionsUsed = 0;
  int goals = 0;
  int shots = 0;
  int shotsOnTarget = 0;
  double expectedGoals = 0;
  int yellowCards = 0;
  int redCards = 0;
  int possessionMinutes = 0;

  Formation get formation => sheet.lineup.formation;
  TacticalInstructions get instructions => sheet.lineup.instructions;

  void setUp() {
    final starters = sheet.lineup.starters;
    for (var i = 0; i < starters.length; i++) {
      final player = sheet.playerById(starters[i]);
      onPitch.add(SlotPlayer(slot: formation.slots[i], player: player));
      participants.add(player.id);
    }
    for (final id in sheet.lineup.bench) {
      benchAvailable.add(sheet.playerById(id));
    }
  }

  UnitScores strengthAt(int minute, MatchEngineConfig config) =>
      computeUnitScores(
        onPitch: onPitch,
        formation: formation,
        instructions: instructions,
        model: config.strength,
        minute: minute,
        homeFactor: isHome ? config.homeAdvantage : 1,
      );

  void remove(PlayerId id) {
    onPitch.removeWhere((slotPlayer) => slotPlayer.player.id == id);
  }
}

/// Simulador determinista de partidos.
///
/// `simulate` es una función pura respecto a `(hojas, semilla)`: el estado
/// mutable vive solo dentro de la llamada. El balance completo del modelo
/// está en [MatchEngineConfig] (ADR 0005).
final class MatchSimulator {
  /// Crea el simulador con una [config] (por defecto, la estándar).
  MatchSimulator({MatchEngineConfig? config})
    : config = config ?? MatchEngineConfig.standard();

  /// Configuración de balance del motor de partidos.
  final MatchEngineConfig config;

  /// Minutos reglamentarios simulados.
  static const int matchMinutes = 90;

  /// Simula el partido de [fixtureId] entre [home] y [away].
  MatchReport simulate({
    required FixtureId fixtureId,
    required TeamSheet home,
    required TeamSheet away,
    required Rng rng,
  }) {
    final homeState = _SideState(sheet: home, side: TeamSide.home, isHome: true)
      ..setUp();
    final awayState = _SideState(
      sheet: away,
      side: TeamSide.away,
      isHome: false,
    )..setUp();
    final events = <MatchEvent>[];

    for (var minute = 1; minute <= matchMinutes; minute++) {
      _scheduledSubstitutions(homeState, minute, events);
      _scheduledSubstitutions(awayState, minute, events);

      _maybeCard(homeState, minute, events, rng);
      _maybeCard(awayState, minute, events, rng);

      _maybeInjury(homeState, minute, events, rng);
      _maybeInjury(awayState, minute, events, rng);

      _maybeChance(homeState, awayState, minute, events, rng);
    }

    final result = MatchResult.fromEvents(fixtureId: fixtureId, events: events);
    final ratings = _ratings(homeState, awayState, events, rng);

    final totalPossession = math.max(
      1,
      homeState.possessionMinutes + awayState.possessionMinutes,
    );
    final homePossessionPct =
        (100 * homeState.possessionMinutes / totalPossession).round();

    return MatchReport(
      result: result,
      homeStats: _stats(homeState, homePossessionPct),
      awayStats: _stats(awayState, 100 - homePossessionPct),
      ratings: ratings,
    );
  }

  // ── Ocasiones ──────────────────────────────────────────────────────────

  void _maybeChance(
    _SideState home,
    _SideState away,
    int minute,
    List<MatchEvent> events,
    Rng rng,
  ) {
    final tempo =
        (config.chances.tempoFactors[home.instructions.tempo]! +
            config.chances.tempoFactors[away.instructions.tempo]!) /
        2;

    final homeStrength = home.strengthAt(minute, config);
    final awayStrength = away.strengthAt(minute, config);
    final share = _possessionShare(homeStrength, awayStrength);
    if (rng.chance(share)) {
      home.possessionMinutes++;
    } else {
      away.possessionMinutes++;
    }

    if (!rng.chance(config.chances.chancesPerMinute * tempo)) return;

    final isHomeChance = rng.chance(share);
    final attacker = isHomeChance ? home : away;
    final defender = isHomeChance ? away : home;
    final attackerStrength = isHomeChance ? homeStrength : awayStrength;
    final defenderStrength = isHomeChance ? awayStrength : homeStrength;

    if (attacker.onPitch.isEmpty || defender.onPitch.isEmpty) return;

    final urgency = _urgency(attacker, defender, minute);
    final attackScore = attackerStrength.attack * urgency.attackFactor;
    final defenceScore = defenderStrength.defence * urgency.defenceFactor;

    final strengthFactor =
        2 *
        _logistic(
          (attackScore - defenceScore) / config.chances.conversionSpread,
        );
    final goalProbability = (config.chances.baseConversion * strengthFactor)
        .clamp(
          config.chances.minGoalProbability,
          config.chances.maxGoalProbability,
        );

    attacker.shots++;
    attacker.expectedGoals += goalProbability;

    if (rng.chance(goalProbability)) {
      attacker.shotsOnTarget++;
      _goal(attacker, defender, minute, events, rng);
    } else if (rng.chance(config.chances.onTargetSaveShare)) {
      attacker.shotsOnTarget++;
    }
  }

  void _goal(
    _SideState attacker,
    _SideState defender,
    int minute,
    List<MatchEvent> events,
    Rng rng,
  ) {
    attacker.goals++;

    if (rng.chance(config.chances.ownGoalShare) &&
        defender.onPitch.isNotEmpty) {
      final culprits = defender.onPitch
          .where((p) => p.slot.group == PositionGroup.defence)
          .toList();
      final scorer = culprits.isNotEmpty
          ? rng.pick(culprits)
          : rng.pick(defender.onPitch);
      events.add(
        GoalScored(
          minute: MatchMinute(minute),
          side: attacker.side,
          scorerId: scorer.player.id,
          ownGoal: true,
        ),
      );
      return;
    }

    final scorer = _weightedByGroup(
      attacker.onPitch,
      config.chances.scorerGroupWeights,
      rng,
      score: (p) =>
          (p.player.attributes.shooting.value +
                  p.player.attributes.positioning.value)
              .toDouble(),
    );

    PlayerId? assistant;
    if (attacker.onPitch.length > 1 &&
        rng.chance(config.chances.assistProbability)) {
      final others = attacker.onPitch
          .where((p) => p.player.id != scorer.player.id)
          .toList();
      assistant = _weightedByGroup(
        others,
        config.chances.scorerGroupWeights,
        rng,
        score: (p) =>
            (p.player.attributes.vision.value +
                    p.player.attributes.passing.value)
                .toDouble(),
      ).player.id;
    }

    events.add(
      GoalScored(
        minute: MatchMinute(minute),
        side: attacker.side,
        scorerId: scorer.player.id,
        assistantId: assistant,
      ),
    );
  }

  ({double attackFactor, double defenceFactor}) _urgency(
    _SideState attacker,
    _SideState defender,
    int minute,
  ) {
    if (minute < config.chances.urgencyFromMinute) {
      return (attackFactor: 1, defenceFactor: 1);
    }
    final diff = attacker.goals - defender.goals;
    if (diff < 0) {
      // El atacante va perdiendo: se vuelca.
      return (attackFactor: config.chances.losingAttackBoost, defenceFactor: 1);
    }
    if (diff > 0) {
      // El atacante va ganando y especula; el rival defiende con más orden.
      return (
        attackFactor: config.chances.winningAttackFactor,
        defenceFactor: config.chances.winningDefenceBoost,
      );
    }
    return (attackFactor: 1, defenceFactor: 1);
  }

  double _possessionShare(UnitScores home, UnitScores away) {
    final elasticity = config.strength.possessionElasticity;
    final homePower =
        math.pow(math.max(home.midfield, 1), elasticity) as double;
    final awayPower =
        math.pow(math.max(away.midfield, 1), elasticity) as double;
    return homePower / (homePower + awayPower);
  }

  // ── Disciplina y lesiones ──────────────────────────────────────────────

  void _maybeCard(
    _SideState side,
    int minute,
    List<MatchEvent> events,
    Rng rng,
  ) {
    if (side.onPitch.isEmpty) return;
    final pressing =
        config.discipline.pressingFactors[side.instructions.pressing]!;
    if (!rng.chance(config.discipline.cardsPerSidePerMinute * pressing)) {
      return;
    }

    final offender = _weightedBy(
      side.onPitch,
      rng,
      weight: (p) =>
          (p.player.attributes.tackling.value.toDouble() +
              switch (p.slot.group) {
                PositionGroup.defence => 25,
                PositionGroup.midfield => 12,
                _ => 0,
              }) *
          // Un jugador con amarilla se contiene.
          (side.booked.contains(p.player.id)
              ? config.discipline.bookedRestraintFactor
              : 1),
    );
    final playerId = offender.player.id;

    final CardType cardType;
    if (rng.chance(config.discipline.directRedShare)) {
      cardType = CardType.red;
    } else if (side.booked.contains(playerId)) {
      cardType = CardType.secondYellow;
    } else {
      cardType = CardType.yellow;
      side.booked.add(playerId);
      side.yellowCards++;
    }

    events.add(
      CardIssued(
        minute: MatchMinute(minute),
        side: side.side,
        playerId: playerId,
        cardType: cardType,
      ),
    );

    if (cardType != CardType.yellow) {
      side.redCards++;
      side.remove(playerId);
    }
  }

  void _maybeInjury(
    _SideState side,
    int minute,
    List<MatchEvent> events,
    Rng rng,
  ) {
    if (side.onPitch.isEmpty) return;
    if (!rng.chance(config.injuries.injuriesPerSidePerMinute)) return;

    final injured = _weightedBy(
      side.onPitch,
      rng,
      weight: (p) => (110 - p.player.fitness.value).toDouble(),
    );
    events.add(
      PlayerInjured(
        minute: MatchMinute(minute),
        side: side.side,
        playerId: injured.player.id,
      ),
    );
    _forcedSubstitution(side, injured, minute, events);
  }

  // ── Sustituciones ──────────────────────────────────────────────────────

  void _forcedSubstitution(
    _SideState side,
    SlotPlayer leaving,
    int minute,
    List<MatchEvent> events,
  ) {
    side.remove(leaving.player.id);
    if (side.substitutionsUsed >= config.substitutions.maxSubstitutions ||
        side.benchAvailable.isEmpty) {
      return; // Sin cambios disponibles: el equipo sigue con uno menos.
    }
    final replacement = _bestReplacement(side, leaving.slot);
    _bringOn(side, replacement, leaving, minute, events);
  }

  void _scheduledSubstitutions(
    _SideState side,
    int minute,
    List<MatchEvent> events,
  ) {
    if (!config.substitutions.scheduledMinutes.contains(minute)) return;
    if (side.substitutionsUsed >= config.substitutions.maxSubstitutions ||
        side.benchAvailable.isEmpty) {
      return;
    }

    // Candidato: el jugador de campo más fatigado por debajo del umbral.
    SlotPlayer? tired;
    var worstFitness = config.substitutions.fitnessThreshold;
    for (final slotPlayer in side.onPitch) {
      if (slotPlayer.slot.group == PositionGroup.goalkeeper) continue;
      final minutesPlayed = minute - slotPlayer.entryMinute;
      final effective =
          slotPlayer.player.fitness.value -
          config.strength.fatiguePerMinute * minutesPlayed;
      if (effective < worstFitness) {
        tired = slotPlayer;
        worstFitness = effective;
      }
    }
    if (tired == null) return;

    final replacement = _bestReplacement(side, tired.slot);
    if (replacement == null) return;
    side.remove(tired.player.id);
    _bringOn(side, replacement, tired, minute, events);
  }

  Player? _bestReplacement(_SideState side, Position slot) {
    if (side.benchAvailable.isEmpty) return null;
    final sameGroup = side.benchAvailable
        .where((p) => p.position.group == slot.group)
        .toList();
    final pool = sameGroup.isNotEmpty ? sameGroup : side.benchAvailable;

    Player best = pool.first;
    var bestScore = double.negativeInfinity;
    for (final candidate in pool) {
      final score =
          roleRating(
            SlotPlayer(slot: slot, player: candidate),
            switch (slot.group) {
              PositionGroup.goalkeeper ||
              PositionGroup.defence => config.strength.defenceUnit,
              PositionGroup.midfield => config.strength.midfieldUnit,
              PositionGroup.attack => config.strength.attackUnit,
            },
          ) *
          positionFactor(
            candidate.position,
            slot,
            config.strength.positionPenalties,
          );
      if (score > bestScore) {
        best = candidate;
        bestScore = score;
      }
    }
    return best;
  }

  void _bringOn(
    _SideState side,
    Player? replacement,
    SlotPlayer leaving,
    int minute,
    List<MatchEvent> events,
  ) {
    if (replacement == null) return;
    side.benchAvailable.remove(replacement);
    side.substitutionsUsed++;
    side.participants.add(replacement.id);
    side.onPitch.add(
      SlotPlayer(slot: leaving.slot, player: replacement, entryMinute: minute),
    );
    events.add(
      Substitution(
        minute: MatchMinute(minute),
        side: side.side,
        playerOutId: leaving.player.id,
        playerInId: replacement.id,
      ),
    );
  }

  // ── Valoraciones y estadísticas ────────────────────────────────────────

  Map<PlayerId, double> _ratings(
    _SideState home,
    _SideState away,
    List<MatchEvent> events,
    Rng rng,
  ) {
    final model = config.ratings;
    final ratings = <PlayerId, double>{};

    for (final side in [home, away]) {
      final opponent = side.side == TeamSide.home ? away : home;
      final won = side.goals > opponent.goals;
      final drew = side.goals == opponent.goals;

      for (final id in side.participants) {
        var rating = model.base;
        if (won) rating += model.win;
        if (drew) rating += model.draw;

        final player = side.sheet.playerById(id);
        final isDefensive =
            player.position.group == PositionGroup.goalkeeper ||
            player.position.group == PositionGroup.defence;
        if (isDefensive) {
          rating += opponent.goals == 0
              ? model.cleanSheetDefence
              : model.concededPenaltyDefence * opponent.goals;
        }
        if (player.position.group == PositionGroup.attack && side.goals == 0) {
          rating += model.attackBlankPenalty;
        }
        ratings[id] = rating;
      }
    }

    for (final event in events) {
      switch (event) {
        case GoalScored(:final scorerId, :final assistantId, :final ownGoal):
          if (ownGoal) {
            ratings.update(scorerId, (r) => r + model.ownGoal);
          } else {
            ratings.update(scorerId, (r) => r + model.goal);
            if (assistantId != null) {
              ratings.update(assistantId, (r) => r + model.assist);
            }
          }
        case CardIssued(:final playerId, :final cardType):
          ratings.update(
            playerId,
            (r) =>
                r +
                (cardType == CardType.yellow
                    ? model.yellowCard
                    : model.sendingOff),
          );
        case PlayerInjured():
        case Substitution():
          break;
      }
    }

    for (final id in ratings.keys.toList()) {
      final noisy = ratings[id]! + rng.gaussian(stdDev: model.noiseStdDev);
      final clamped = noisy.clamp(model.min, model.max);
      ratings[id] = (clamped * 10).round() / 10;
    }
    return ratings;
  }

  TeamMatchStats _stats(_SideState side, int possessionPct) => TeamMatchStats(
    possessionPct: possessionPct,
    shots: side.shots,
    shotsOnTarget: side.shotsOnTarget,
    expectedGoals: (side.expectedGoals * 100).round() / 100,
    yellowCards: side.yellowCards,
    redCards: side.redCards,
  );

  // ── Utilidades ─────────────────────────────────────────────────────────

  double _logistic(double x) => 1 / (1 + math.exp(-x));

  SlotPlayer _weightedByGroup(
    List<SlotPlayer> players,
    Map<PositionGroup, double> groupWeights,
    Rng rng, {
    required double Function(SlotPlayer) score,
  }) {
    return _weightedBy(
      players,
      rng,
      weight: (p) =>
          (groupWeights[p.slot.group] ?? 0.01) * math.max(1, score(p)),
    );
  }

  SlotPlayer _weightedBy(
    List<SlotPlayer> players,
    Rng rng, {
    required double Function(SlotPlayer) weight,
  }) {
    final weights = [for (final p in players) math.max(0.001, weight(p))];
    return players[rng.pickIndexWeighted(weights)];
  }
}
