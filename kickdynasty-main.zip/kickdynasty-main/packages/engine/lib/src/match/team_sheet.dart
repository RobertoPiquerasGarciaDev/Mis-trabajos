/// Hoja de equipo: la plantilla y la alineación con la que un club disputa
/// un partido.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:meta/meta.dart';

/// Plantilla + alineación de un club para un partido concreto.
///
/// Invariante: todos los jugadores de la alineación (titulares y banquillo)
/// pertenecen a la plantilla. El simulador solo acepta hojas válidas.
@immutable
final class TeamSheet {
  /// Crea la hoja validando que la alineación sale de la plantilla.
  TeamSheet({required this.squad, required this.lineup}) {
    final missing = <String>[
      for (final id in lineup.starters)
        if (!squad.contains(id)) 'titular ${id.value}',
      for (final id in lineup.bench)
        if (!squad.contains(id)) 'suplente ${id.value}',
    ];
    if (missing.isNotEmpty) {
      throw DomainInvariantViolation(
        'La alineación referencia jugadores fuera de la plantilla '
        'del club ${squad.clubId.value}',
        violations: missing,
      );
    }
  }

  /// Plantilla del club.
  final Squad squad;

  /// Alineación confirmada.
  final MatchLineup lineup;

  /// Club al que pertenece la hoja.
  ClubId get clubId => squad.clubId;

  /// Jugador de la plantilla por [id] (debe existir).
  Player playerById(PlayerId id) {
    final player = squad.byId(id);
    if (player == null) {
      throw DomainInvariantViolation(
        'El jugador ${id.value} no está en la plantilla '
        'de ${squad.clubId.value}',
      );
    }
    return player;
  }
}
