/// Constructores de equipos sintéticos para tests del motor de partidos.
///
/// Los jugadores "uniformes" tienen todos los atributos al mismo valor, lo
/// que da control exacto sobre la diferencia de fuerza entre dos equipos.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Posiciones de una plantilla mínima válida de 18 jugadores.
const List<Position> squadPositions = [
  Position.gk,
  Position.gk,
  Position.cb,
  Position.cb,
  Position.cb,
  Position.lb,
  Position.rb,
  Position.cb,
  Position.dm,
  Position.cm,
  Position.cm,
  Position.am,
  Position.cm,
  Position.st,
  Position.st,
  Position.lw,
  Position.rw,
  Position.st,
];

/// Jugador con todos los atributos al valor [quality].
Player uniformPlayer({
  required String id,
  required Position position,
  required int quality,
  int fitness = 92,
  int morale = 70,
  int form = 50,
  int age = 26,
}) {
  final rating = Rating.clamped(quality);
  return Player(
    id: PlayerId(id),
    name: DisplayName('Jugador $id'),
    nationality: CountryCode('ES'),
    position: position,
    preferredFoot: PreferredFoot.right,
    age: Age(age),
    attributes: PlayerAttributes(
      pace: rating,
      stamina: rating,
      strength: rating,
      passing: rating,
      shooting: rating,
      dribbling: rating,
      tackling: rating,
      positioning: rating,
      vision: rating,
      composure: rating,
      goalkeeping: rating,
    ),
    potential: Rating.clamped(quality + 5),
    fitness: Fitness(fitness),
    morale: Morale(morale),
    form: Form(form),
  );
}

/// Plantilla uniforme de 18 jugadores con calidad [quality].
Squad uniformSquad({required String clubId, required int quality}) {
  return Squad(
    clubId: ClubId(clubId),
    players: [
      for (var i = 0; i < squadPositions.length; i++)
        uniformPlayer(
          id: '$clubId-p$i',
          position: squadPositions[i],
          quality: quality,
        ),
    ],
  );
}

/// Hoja de equipo uniforme lista para simular.
TeamSheet uniformSheet({
  required String clubId,
  required int quality,
  TacticalInstructions instructions = const TacticalInstructions(),
}) {
  final squad = uniformSquad(clubId: clubId, quality: quality);
  final lineup = LineupSelector().select(
    squad: squad,
    instructions: instructions,
  );
  return TeamSheet(squad: squad, lineup: lineup);
}

/// Hoja de equipo a partir de un club generado proceduralmente.
TeamSheet sheetFromGeneratedClub(GeneratedClub generated) {
  final lineup = LineupSelector().select(squad: generated.squad);
  return TeamSheet(squad: generated.squad, lineup: lineup);
}
