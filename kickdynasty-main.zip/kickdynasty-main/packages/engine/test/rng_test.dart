import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  group('Xoshiro256StarStar', () {
    test('misma semilla produce la misma secuencia', () {
      final a = Xoshiro256StarStar.fromSeed(42);
      final b = Xoshiro256StarStar.fromSeed(42);
      for (var i = 0; i < 1000; i++) {
        expect(a.nextBits53(), b.nextBits53());
      }
    });

    test('semillas distintas producen secuencias distintas', () {
      final a = Xoshiro256StarStar.fromSeed(42);
      final b = Xoshiro256StarStar.fromSeed(43);
      final sequenceA = [for (var i = 0; i < 10; i++) a.nextBits53()];
      final sequenceB = [for (var i = 0; i < 10; i++) b.nextBits53()];
      expect(sequenceA, isNot(sequenceB));
    });

    test('nextBits53 devuelve valores en 0..2^53-1', () {
      final rng = Xoshiro256StarStar.fromSeed(7);
      for (var i = 0; i < 10000; i++) {
        final bits = rng.nextBits53();
        expect(bits, greaterThanOrEqualTo(0));
        expect(bits, lessThan(1 << 53));
      }
    });

    test('la semilla 0 es válida (estado saneado, no degenerado)', () {
      final rng = Xoshiro256StarStar.fromSeed(0);
      final draws = {for (var i = 0; i < 100; i++) rng.nextBits53()};
      expect(draws.length, greaterThan(95));
    });
  });

  group('Rng (helpers)', () {
    Rng rng([int seed = 11]) => Xoshiro256StarStar.fromSeed(seed);

    test('nextDouble en [0,1) y con media ~0.5', () {
      final r = rng();
      var sum = 0.0;
      const draws = 20000;
      for (var i = 0; i < draws; i++) {
        final value = r.nextDouble();
        expect(value, greaterThanOrEqualTo(0));
        expect(value, lessThan(1));
        sum += value;
      }
      expect(sum / draws, closeTo(0.5, 0.01));
    });

    test('nextInt respeta los límites y rechaza max <= 0', () {
      final r = rng();
      for (var i = 0; i < 5000; i++) {
        final value = r.nextInt(7);
        expect(value, inInclusiveRange(0, 6));
      }
      expect(() => r.nextInt(0), throwsArgumentError);
      expect(() => r.nextInt(-3), throwsArgumentError);
    });

    test('rangeInt es inclusivo en ambos extremos y valida el orden', () {
      final r = rng();
      final seen = <int>{};
      for (var i = 0; i < 2000; i++) {
        seen.add(r.rangeInt(3, 6));
      }
      expect(seen, {3, 4, 5, 6});
      expect(() => r.rangeInt(5, 4), throwsArgumentError);
    });

    test('chance en los extremos', () {
      final r = rng();
      for (var i = 0; i < 100; i++) {
        expect(r.chance(0), isFalse);
        expect(r.chance(1), isTrue);
      }
    });

    test('pick devuelve elementos de la lista y rechaza vacías', () {
      final r = rng();
      const items = ['a', 'b', 'c'];
      for (var i = 0; i < 200; i++) {
        expect(items, contains(r.pick(items)));
      }
      expect(() => r.pick(<String>[]), throwsArgumentError);
    });

    test('pickIndexWeighted respeta los pesos', () {
      final r = rng();
      final counts = [0, 0, 0];
      const draws = 30000;
      for (var i = 0; i < draws; i++) {
        counts[r.pickIndexWeighted([0.2, 0.3, 0.5])]++;
      }
      expect(counts[0] / draws, closeTo(0.2, 0.02));
      expect(counts[1] / draws, closeTo(0.3, 0.02));
      expect(counts[2] / draws, closeTo(0.5, 0.02));
    });

    test('pickIndexWeighted valida pesos', () {
      final r = rng();
      expect(() => r.pickIndexWeighted([0.5, -0.1]), throwsArgumentError);
      expect(() => r.pickIndexWeighted([0, 0]), throwsArgumentError);
    });

    test('un peso cero nunca sale elegido', () {
      final r = rng();
      for (var i = 0; i < 5000; i++) {
        expect(r.pickIndexWeighted([0, 1, 0]), 1);
      }
    });

    test('gaussian tiene la media y desviación pedidas', () {
      final r = rng();
      const draws = 30000;
      var sum = 0.0;
      var sumSquares = 0.0;
      for (var i = 0; i < draws; i++) {
        final value = r.gaussian(mean: 10, stdDev: 3);
        sum += value;
        sumSquares += value * value;
      }
      final mean = sum / draws;
      final variance = sumSquares / draws - mean * mean;
      expect(mean, closeTo(10, 0.1));
      expect(variance, closeTo(9, 0.5));
    });
  });

  group('derivedSeed', () {
    test('es determinista y separa flujos', () {
      expect(derivedSeed(42, 1), derivedSeed(42, 1));
      expect(derivedSeed(42, 1), isNot(derivedSeed(42, 2)));
      expect(derivedSeed(42, 1), isNot(derivedSeed(43, 1)));
    });

    test('splitMix64 dispersa entradas consecutivas', () {
      final outputs = {for (var i = 0; i < 1000; i++) splitMix64(i)};
      expect(outputs, hasLength(1000));
    });
  });
}
