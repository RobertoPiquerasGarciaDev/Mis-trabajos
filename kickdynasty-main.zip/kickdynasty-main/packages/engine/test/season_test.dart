import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

import 'support/team_builders.dart';

void main() {
  group('FixtureScheduler', () {
    final league = League(
      id: LeagueId('league-t'),
      name: DisplayName('Liga Test'),
      country: CountryCode('ES'),
      clubIds: [for (var i = 1; i <= 20; i++) ClubId('club-$i')],
    );
    final fixtures = const FixtureScheduler().schedule(
      league: league,
      season: 1,
      rng: Xoshiro256StarStar.fromSeed(7),
    );

    test('produce 2(n−1) jornadas con n/2 partidos cada una', () {
      expect(fixtures.length, 380);
      final rounds = <int, int>{};
      for (final fixture in fixtures) {
        rounds.update(fixture.round, (c) => c + 1, ifAbsent: () => 1);
      }
      expect(rounds.length, 38);
      expect(rounds.values.every((count) => count == 10), isTrue);
    });

    test('cada club juega exactamente una vez por jornada', () {
      for (var round = 1; round <= 38; round++) {
        final playing = <ClubId>[];
        for (final fixture in fixtures.where((f) => f.round == round)) {
          playing
            ..add(fixture.homeClubId)
            ..add(fixture.awayClubId);
        }
        expect(playing.toSet().length, 20, reason: 'jornada $round');
      }
    });

    test('cada par se enfrenta dos veces, una en cada campo', () {
      final meetings = <String, int>{};
      for (final fixture in fixtures) {
        final key = '${fixture.homeClubId.value}|${fixture.awayClubId.value}';
        meetings.update(key, (c) => c + 1, ifAbsent: () => 1);
      }
      // 380 emparejamientos dirigidos únicos: cada (local, visitante) una vez.
      expect(meetings.length, 380);
      expect(meetings.values.every((count) => count == 1), isTrue);
    });

    test('la vuelta espeja la ida con la localía invertida', () {
      final firstLeg = fixtures.where((f) => f.round <= 19);
      for (final fixture in firstLeg) {
        final mirrored = fixtures.where(
          (f) =>
              f.round == fixture.round + 19 &&
              f.homeClubId == fixture.awayClubId &&
              f.awayClubId == fixture.homeClubId,
        );
        expect(mirrored, hasLength(1));
      }
    });

    test('es determinista por semilla y distinto entre semillas', () {
      final again = const FixtureScheduler().schedule(
        league: league,
        season: 1,
        rng: Xoshiro256StarStar.fromSeed(7),
      );
      expect(
        [for (final f in again) f.id.value],
        [for (final f in fixtures) f.id.value],
      );
      expect(
        [for (final f in again) f.homeClubId.value],
        [for (final f in fixtures) f.homeClubId.value],
      );

      final other = const FixtureScheduler().schedule(
        league: league,
        season: 2,
        rng: Xoshiro256StarStar.fromSeed(8),
      );
      expect([
        for (final f in other) f.homeClubId.value,
      ], isNot([for (final f in fixtures) f.homeClubId.value]));
    });
  });

  group('LeagueTable', () {
    Fixture fixture(String id, String home, String away) => Fixture(
      id: FixtureId(id),
      leagueId: LeagueId('league-t'),
      season: 1,
      round: 1,
      homeClubId: ClubId(home),
      awayClubId: ClubId(away),
    );

    MatchResult result(String id, int home, int away) =>
        MatchResult(fixtureId: FixtureId(id), homeGoals: home, awayGoals: away);

    test('ordena por puntos, diferencia y goles a favor', () {
      final clubs = [ClubId('a'), ClubId('b'), ClubId('c'), ClubId('d')];
      final fixtures = [
        fixture('f1', 'a', 'b'), // a gana 3-0
        fixture('f2', 'c', 'd'), // c gana 1-0
        fixture('f3', 'b', 'd'), // b gana 2-1
      ];
      final results = {
        FixtureId('f1'): result('f1', 3, 0),
        FixtureId('f2'): result('f2', 1, 0),
        FixtureId('f3'): result('f3', 2, 1),
      };

      final table = LeagueTable.compute(
        clubs: clubs,
        fixtures: fixtures,
        results: results,
      );

      // a y c tienen 3 puntos: a por delante por diferencia (+3 vs +1).
      expect(table.rows[0].clubId, ClubId('a'));
      expect(table.rows[1].clubId, ClubId('c'));
      expect(table.rows[2].clubId, ClubId('b'));
      expect(table.rows[3].clubId, ClubId('d'));
      expect(table.positionOf(ClubId('d')), 4);
      expect(table.rows[0].points, 3);
      expect(table.rows[3].points, 0);
    });

    test(
      'desempata por enfrentamientos directos dentro del grupo empatado',
      () {
        // Triángulo: b ganó a a en el directo; a y b empatan a puntos (3),
        // diferencia (0) y goles a favor (2); x va primero por goles (3).
        // Sin head-to-head, el fallback alfabético pondría a a por delante:
        // este test falla si el criterio directo no se aplica.
        final clubs = [ClubId('a'), ClubId('b'), ClubId('x')];
        final fixtures = [
          fixture('f1', 'b', 'a'),
          fixture('f2', 'a', 'x'),
          fixture('f3', 'x', 'b'),
        ];
        final results = {
          FixtureId('f1'): result('f1', 1, 0), // b gana el directo
          FixtureId('f2'): result('f2', 2, 1),
          FixtureId('f3'): result('f3', 2, 1),
        };

        final table = LeagueTable.compute(
          clubs: clubs,
          fixtures: fixtures,
          results: results,
        );

        expect(table.rows[0].clubId, ClubId('x'));
        expect(table.rows[1].clubId, ClubId('b'));
        expect(table.rows[2].clubId, ClubId('a'));
      },
    );

    test('fixtures sin resultado se ignoran (tabla parcial)', () {
      final clubs = [ClubId('a'), ClubId('b')];
      final fixtures = [fixture('f1', 'a', 'b'), fixture('f2', 'b', 'a')];
      final table = LeagueTable.compute(
        clubs: clubs,
        fixtures: fixtures,
        results: {FixtureId('f1'): result('f1', 1, 0)},
      );
      expect(table.rows.first.played, 1);
      expect(table.rows.last.played, 1);
    });
  });

  group('ConditionCycle', () {
    final cycle = ConditionCycle(model: SeasonConfig.standard().condition);

    test('la recuperación semanal acerca el físico a 100 y la forma a 50', () {
      final squad = Squad(
        clubId: ClubId('club-a'),
        players: [
          for (var i = 0; i < squadPositions.length; i++)
            uniformPlayer(
              id: 'p$i',
              position: squadPositions[i],
              quality: 60,
              fitness: 70,
              morale: 30,
              form: 90,
            ),
        ],
      );
      final recovered = cycle.weeklyRecovery(squad);
      for (final player in recovered.players) {
        expect(player.fitness.value, greaterThan(70));
        expect(player.fitness.value, lessThanOrEqualTo(100));
        expect(player.morale.value, greaterThan(30)); // revierte hacia 60
        expect(player.form.value, lessThan(90)); // decae hacia 50
      }
    });

    test('tras un partido: titulares fatigados, moral según resultado y '
        'forma según valoración', () {
      final homeSquad = uniformSquad(clubId: 'home', quality: 60);
      final awaySquad = uniformSquad(clubId: 'away', quality: 60);
      final homeSheet = TeamSheet(
        squad: homeSquad,
        lineup: LineupSelector().select(squad: homeSquad),
      );
      final awaySheet = TeamSheet(
        squad: awaySquad,
        lineup: LineupSelector().select(squad: awaySquad),
      );
      final report = MatchSimulator().simulate(
        fixtureId: FixtureId('fx-c'),
        home: homeSheet,
        away: awaySheet,
        rng: Xoshiro256StarStar.fromSeed(5),
      );

      final after = cycle.afterMatch(
        squad: homeSquad,
        sheet: homeSheet,
        report: report,
        side: TeamSide.home,
      );

      final injured = report.result.events
          .whereType<PlayerInjured>()
          .where((e) => e.side == TeamSide.home)
          .map((e) => e.playerId)
          .toSet();
      final cameOn = report.result.events
          .whereType<Substitution>()
          .where((e) => e.side == TeamSide.home)
          .map((e) => e.playerInId)
          .toSet();

      final homeWon = report.result.winner == TeamSide.home;
      final homeLost = report.result.winner == TeamSide.away;

      for (final player in after.players) {
        final before = homeSquad.byId(player.id)!;
        if (injured.contains(player.id)) {
          expect(player.fitness.value, 35);
        } else if (homeSheet.lineup.starters.contains(player.id)) {
          expect(player.fitness.value, before.fitness.value - 14);
        } else if (!cameOn.contains(player.id)) {
          expect(player.fitness.value, before.fitness.value);
        }
        if (homeWon) {
          expect(player.morale.value, greaterThan(before.morale.value));
        } else if (homeLost) {
          expect(player.morale.value, lessThan(before.morale.value));
        }
      }
    });
  });

  group('PlayerDevelopment', () {
    final development = PlayerDevelopment(
      model: SeasonConfig.standard().development,
      playerGenerator: PlayerGenerator(config: WorldGenConfig.standard()),
    );

    Squad squadOfAge(int age, {int quality = 55}) => Squad(
      clubId: ClubId('club-a'),
      players: [
        for (var i = 0; i < squadPositions.length; i++)
          uniformPlayer(
            id: 'p$i',
            position: squadPositions[i],
            quality: quality,
            age: age,
          ),
      ],
    );

    double meanAttribute(Squad squad, AttributeKey key) {
      final values = [
        for (final p in squad.players) attributeValue(p.attributes, key),
      ];
      return values.reduce((a, b) => a + b) / values.length;
    }

    test('los jóvenes con margen progresan', () {
      final result = development.endOfSeason(
        squad: squadOfAge(18),
        season: 2,
        leagueCountry: CountryCode('ES'),
        leagueLevel: 1,
        rng: Xoshiro256StarStar.fromSeed(1),
      );
      expect(result.retired, isEmpty);
      expect(
        meanAttribute(result.squad, AttributeKey.passing),
        greaterThan(55),
      );
      for (final player in result.squad.players) {
        expect(player.age.years, 19);
      }
    });

    test('los veteranos declinan, y lo físico más que lo técnico', () {
      final before = squadOfAge(34);
      final result = development.endOfSeason(
        squad: before,
        season: 2,
        leagueCountry: CountryCode('ES'),
        leagueLevel: 1,
        rng: Xoshiro256StarStar.fromSeed(2),
      );
      // Solo los que no se retiraron (35 años tiene un 25 % de retiro).
      final survivors = result.squad.players
          .where((p) => p.age.years == 35)
          .toList();
      expect(survivors, isNotEmpty);
      final paceDrop =
          55 -
          survivors
                  .map((p) => p.attributes.pace.value)
                  .reduce((a, b) => a + b) /
              survivors.length;
      final visionDrop =
          55 -
          survivors
                  .map((p) => p.attributes.vision.value)
                  .reduce((a, b) => a + b) /
              survivors.length;
      expect(paceDrop, greaterThan(0));
      expect(paceDrop, greaterThan(visionDrop));
    });

    test('el retiro es seguro a la edad forzosa y los regens reponen '
        'posición a posición', () {
      final result = development.endOfSeason(
        squad: squadOfAge(38),
        season: 3,
        leagueCountry: CountryCode('ES'),
        leagueLevel: 2,
        rng: Xoshiro256StarStar.fromSeed(3),
      );
      expect(result.retired, hasLength(squadPositions.length));
      expect(result.regens, hasLength(squadPositions.length));

      // La plantilla resultante cumple los invariantes (lo garantiza Squad)
      // y conserva la distribución de posiciones.
      expect(result.squad.size, squadPositions.length);
      for (var i = 0; i < result.retired.length; i++) {
        expect(result.regens[i].player.position, result.retired[i].position);
        final age = result.regens[i].player.age.years;
        expect(age, inInclusiveRange(16, 19));
      }
    });
  });

  group('CampaignState', () {
    test('valida los escalares y expone si la temporada terminó', () {
      final world = WorldGenerator().generate(seed: 3);
      final fixtures = const FixtureScheduler().schedule(
        league: world.leagues.first.league,
        season: 1,
        rng: Xoshiro256StarStar.fromSeed(1),
      );

      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 1,
        fixtures: fixtures,
        results: const {},
        stats: const {},
      );
      expect(state.isSeasonComplete, isFalse);
      expect(state.playerClubId, isNull);

      expect(
        () => CampaignState(
          world: world,
          season: 0,
          nextRound: 1,
          fixtures: fixtures,
          results: const {},
          stats: const {},
        ),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(
        () => CampaignState(
          world: world,
          season: 1,
          nextRound: 0,
          fixtures: fixtures,
          results: const {},
          stats: const {},
        ),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });
  });

  group('SeasonSimulator (cierre de fase: temporada completa)', () {
    final simulator = SeasonSimulator();
    final world = WorldGenerator().generate(seed: 42);
    final outcome = simulator.simulateSeason(world: world, season: 1, seed: 42);

    test('se disputan las 38 jornadas de las 2 ligas', () {
      expect(outcome.leagues, hasLength(2));
      for (final league in outcome.leagues) {
        expect(league.fixtures, hasLength(380));
        expect(league.results, hasLength(380));
        for (final row in league.table.rows) {
          expect(row.played, 38);
          expect(row.won + row.drawn + row.lost, 38);
          expect(row.points, row.won * 3 + row.drawn);
        }
      }
    });

    test('la tabla cierra contablemente', () {
      for (final league in outcome.leagues) {
        final totalFor = league.table.rows.fold(
          0,
          (sum, row) => sum + row.goalsFor,
        );
        final totalAgainst = league.table.rows.fold(
          0,
          (sum, row) => sum + row.goalsAgainst,
        );
        expect(totalFor, totalAgainst);

        final goalsInResults = league.results.values.fold(
          0,
          (sum, r) => sum + r.homeGoals + r.awayGoals,
        );
        expect(totalFor, goalsInResults);

        // 3 puntos por victoria y 2 por empate repartidos por partido.
        final totalPoints = league.table.rows.fold(
          0,
          (sum, row) => sum + row.points,
        );
        final draws = league.results.values.where((r) => r.isDraw).length;
        expect(totalPoints, (380 - draws) * 3 + draws * 2);
      }
    });

    test('las estadísticas de jugador cuadran con los resultados', () {
      final goalsFromStats = outcome.playerStats.values.fold(
        0,
        (sum, stats) => sum + stats.goals,
      );
      var goalsFromEvents = 0;
      var ownGoals = 0;
      for (final league in outcome.leagues) {
        for (final result in league.results.values) {
          for (final goal in result.events.whereType<GoalScored>()) {
            if (goal.ownGoal) {
              ownGoals++;
            } else {
              goalsFromEvents++;
            }
          }
        }
      }
      expect(goalsFromStats, goalsFromEvents);
      expect(goalsFromStats + ownGoals, greaterThan(0));

      for (final stats in outcome.playerStats.values) {
        expect(stats.appearances, greaterThan(0));
        expect(stats.averageRating, inInclusiveRange(4, 10));
        expect(stats.appearances, lessThanOrEqualTo(38));
      }
    });

    test('la condición física final es válida y muestra desgaste', () {
      for (final league in outcome.leagues) {
        for (final club in league.clubs) {
          expect(club.squad.size, world.leagues.first.clubs.first.squad.size);
          for (final player in club.squad.players) {
            expect(player.fitness.value, inInclusiveRange(0, 100));
          }
        }
      }
    });

    test('es determinista: misma semilla, misma clasificación', () {
      final again = simulator.simulateSeason(world: world, season: 1, seed: 42);
      for (var li = 0; li < outcome.leagues.length; li++) {
        expect(
          [for (final row in again.leagues[li].table.rows) row.toString()],
          [for (final row in outcome.leagues[li].table.rows) row.toString()],
        );
      }
    });

    test('golden: campeón y goles de la temporada de la semilla 42', () {
      final champion = outcome.leagues.first.table.rows.first;
      final totalGoals = outcome.leagues.first.table.rows.fold(
        0,
        (sum, row) => sum + row.goalsFor,
      );
      expect(
        '${champion.clubId.value}/${champion.points}/$totalGoals',
        'club-1-16/70/931',
      );
    });

    test('el rollover mantiene el mundo coherente (población estable)', () {
      final nextWorld = simulator.advanceSeason(outcome: outcome, seed: 43);

      expect(nextWorld.leagues, hasLength(2));
      final allClubIds = [
        for (final league in nextWorld.leagues)
          for (final club in league.clubs) club.club.id,
      ];
      expect(allClubIds.toSet().length, 40, reason: 'ningún club se pierde');

      for (final league in nextWorld.leagues) {
        expect(league.clubs, hasLength(20));
        expect(league.league.clubIds, hasLength(20));
        for (final club in league.clubs) {
          // Invariantes de plantilla: tamaño y porteros (Squad los valida
          // en construcción; aquí verificamos que la población no cambió).
          expect(club.squad.size, world.leagues.first.clubs.first.squad.size);
          expect(
            club.squad.players.where((p) => p.position.isGoalkeeper).length,
            greaterThanOrEqualTo(2),
          );
          // Cada jugador tiene contrato.
          final contractPlayerIds = {
            for (final c in club.contracts) c.playerId,
          };
          for (final player in club.squad.players) {
            expect(contractPlayerIds.contains(player.id), isTrue);
          }
        }
      }
    });

    test('el rollover asciende y desciende a los clubes correctos', () {
      final nextWorld = simulator.advanceSeason(outcome: outcome, seed: 43);
      final topTable = outcome.leagues.first.table;
      final secondTable = outcome.leagues.last.table;

      final relegated = topTable.rows.reversed
          .take(3)
          .map((r) => r.clubId)
          .toSet();
      final promoted = secondTable.rows.take(3).map((r) => r.clubId).toSet();

      final newTopIds = {
        for (final c in nextWorld.leagues.first.clubs) c.club.id,
      };
      final newSecondIds = {
        for (final c in nextWorld.leagues.last.clubs) c.club.id,
      };

      expect(newTopIds.containsAll(promoted), isTrue);
      expect(newTopIds.intersection(relegated), isEmpty);
      expect(newSecondIds.containsAll(relegated), isTrue);
      expect(newSecondIds.intersection(promoted), isEmpty);
    });
  });

  group('playRound (jornada a jornada)', () {
    final simulator = SeasonSimulator();

    test('jornada a jornada coincide con simulateSeason completa', () {
      const seed = 42;
      final world = WorldGenerator().generate(seed: seed);

      final full = simulator.simulateSeason(
        world: world,
        season: 1,
        seed: seed,
      );

      var state = simulator.bootstrapCampaign(seed: seed);
      RoundOutcome? lastRound;
      while (!state.isSeasonComplete) {
        final result = simulator.playRound(state: state);
        state = result.state;
        lastRound = result.round;
      }

      expect(state.results.length, full.leagues.first.fixtures.length * 2);
      for (final league in full.leagues) {
        for (final entry in league.results.entries) {
          expect(
            state.results[entry.key]?.homeGoals,
            entry.value.homeGoals,
            reason: entry.key.value,
          );
          expect(
            state.results[entry.key]?.awayGoals,
            entry.value.awayGoals,
            reason: entry.key.value,
          );
        }
      }
      expect(lastRound?.round, 38);
    });

    test('tableFor refleja la clasificación parcial', () {
      var state = simulator.bootstrapCampaign(seed: 7);
      final leagueId = state.world.leagues.first.league.id;

      state = simulator.playRound(state: state).state;
      final table = simulator.tableFor(state: state, leagueId: leagueId);

      expect(table.rows.every((row) => row.played <= 1), isTrue);
      expect(table.rows.first.points, greaterThanOrEqualTo(0));
    });

    test('no permite jugar si la temporada ya terminó', () {
      var state = simulator.bootstrapCampaign(seed: 3);
      while (!state.isSeasonComplete) {
        state = simulator.playRound(state: state).state;
      }
      expect(() => simulator.playRound(state: state), throwsStateError);
    });
  });
}
