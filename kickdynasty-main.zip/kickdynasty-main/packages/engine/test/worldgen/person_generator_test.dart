@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  group('PersonGenerator', () {
    final generator = PersonGenerator();

    PersonOrigin origin(int seed) => generator.buildOrigin(
      worldSeed: seed,
      country: CountryCode('ES'),
      city: 'Valencia',
      cohort: 'gen-test',
      generation: 1,
      appearanceYear: 2024,
    );

    test('misma semilla produce la misma persona', () {
      final id = PersonId('person-gen-1');
      final a = generator.generate(
        id: id,
        worldSeed: 7,
        origin: origin(7),
        role: PersonRole.scout,
        ageYears: 34,
      );
      final b = generator.generate(
        id: id,
        worldSeed: 7,
        origin: origin(7),
        role: PersonRole.scout,
        ageYears: 34,
      );
      expect(a, b);
    });

    test('personId distinto produce persona distinta', () {
      final origin7 = origin(7);
      final a = generator.generate(
        id: PersonId('person-a'),
        worldSeed: 7,
        origin: origin7,
        role: PersonRole.player,
        ageYears: 22,
      );
      final b = generator.generate(
        id: PersonId('person-b'),
        worldSeed: 7,
        origin: origin7,
        role: PersonRole.player,
        ageYears: 22,
      );
      expect(a, isNot(b));
    });
  });
}
