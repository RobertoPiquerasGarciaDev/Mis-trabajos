@Tags(['balance'])
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

import 'support/team_builders.dart';

/// Suite estadística de balance del motor de partidos (ADR 0005).
///
/// Estos tests son el contrato de "juego sano": fijan las bandas aceptables
/// de goles, reparto de resultados, correlación fuerza-resultado y
/// disciplina. Cualquier cambio en `MatchEngineConfig.standard()` debe
/// mantenerlos en verde; si un cambio de diseño mueve una banda a
/// propósito, se ajusta aquí de forma explícita y revisada.
void main() {
  final simulator = MatchSimulator();

  ({
    double goalsPerMatch,
    double homeWinRate,
    double drawRate,
    double yellowsPerMatch,
    double redsPerMatch,
    double injuriesPerMatch,
    double subsPerMatch,
    double shotsPerTeam,
    double homePossession,
  })
  runEqualTeams({required int matches, required int quality}) {
    final home = uniformSheet(clubId: 'home', quality: quality);
    final away = uniformSheet(clubId: 'away', quality: quality);

    var goals = 0;
    var homeWins = 0;
    var draws = 0;
    var yellows = 0;
    var reds = 0;
    var injuries = 0;
    var subs = 0;
    var shots = 0;
    var possession = 0;

    for (var i = 0; i < matches; i++) {
      final report = simulator.simulate(
        fixtureId: FixtureId('fx-$i'),
        home: home,
        away: away,
        rng: Xoshiro256StarStar.fromSeed(derivedSeed(1000, i)),
      );
      goals += report.result.homeGoals + report.result.awayGoals;
      if (report.result.winner == TeamSide.home) homeWins++;
      if (report.result.isDraw) draws++;
      yellows += report.homeStats.yellowCards + report.awayStats.yellowCards;
      reds += report.homeStats.redCards + report.awayStats.redCards;
      injuries += report.result.events.whereType<PlayerInjured>().length;
      subs += report.result.events.whereType<Substitution>().length;
      shots += report.homeStats.shots + report.awayStats.shots;
      possession += report.homeStats.possessionPct;
    }

    return (
      goalsPerMatch: goals / matches,
      homeWinRate: homeWins / matches,
      drawRate: draws / matches,
      yellowsPerMatch: yellows / matches,
      redsPerMatch: reds / matches,
      injuriesPerMatch: injuries / matches,
      subsPerMatch: subs / matches,
      shotsPerTeam: shots / matches / 2,
      homePossession: possession / matches,
    );
  }

  group('equipos iguales (calidad 60, 3000 partidos)', () {
    final stats = runEqualTeams(matches: 3000, quality: 60);

    test('los goles por partido están en la banda del fútbol real', () {
      expect(stats.goalsPerMatch, inInclusiveRange(2.2, 3.2));
    });

    test('la localía existe pero no domina', () {
      expect(stats.homeWinRate, inInclusiveRange(0.40, 0.52));
      expect(stats.drawRate, inInclusiveRange(0.18, 0.35));
    });

    test('la posesión media del local refleja la ventaja de campo', () {
      expect(stats.homePossession, inInclusiveRange(51, 58));
    });

    test('los disparos por equipo son plausibles', () {
      expect(stats.shotsPerTeam, inInclusiveRange(8, 17));
    });

    test('la disciplina está en bandas realistas', () {
      expect(stats.yellowsPerMatch, inInclusiveRange(2.5, 5.5));
      expect(stats.redsPerMatch, inInclusiveRange(0.05, 0.30));
    });

    test('las lesiones son infrecuentes pero existen', () {
      expect(stats.injuriesPerMatch, inInclusiveRange(0.1, 0.6));
    });

    test('hay rotación desde el banquillo', () {
      expect(stats.subsPerMatch, greaterThan(0.2));
    });
  });

  group('correlación fuerza-resultado', () {
    /// Tasa de victorias del equipo fuerte alternando la localía para
    /// neutralizar la ventaja de campo.
    double strongWinRate({
      required int strongQuality,
      required int weakQuality,
      required int matches,
    }) {
      final strong = uniformSheet(clubId: 'strong', quality: strongQuality);
      final weak = uniformSheet(clubId: 'weak', quality: weakQuality);

      var strongWins = 0;
      for (var i = 0; i < matches; i++) {
        final strongAtHome = i.isEven;
        final report = simulator.simulate(
          fixtureId: FixtureId('fx-d$i'),
          home: strongAtHome ? strong : weak,
          away: strongAtHome ? weak : strong,
          rng: Xoshiro256StarStar.fromSeed(derivedSeed(2000, i)),
        );
        final winner = report.result.winner;
        if (winner == null) continue;
        final strongWon = strongAtHome
            ? winner == TeamSide.home
            : winner == TeamSide.away;
        if (strongWon) strongWins++;
      }
      return strongWins / matches;
    }

    test('+15 de calidad gana entre el 70% y el 92% de los partidos', () {
      final rate = strongWinRate(
        strongQuality: 75,
        weakQuality: 60,
        matches: 2000,
      );
      expect(rate, inInclusiveRange(0.70, 0.92));
    });

    test('+7 de calidad da ventaja clara pero no aplastante', () {
      final rate = strongWinRate(
        strongQuality: 67,
        weakQuality: 60,
        matches: 2000,
      );
      expect(rate, inInclusiveRange(0.52, 0.75));
    });

    test('el débil nunca queda matemáticamente eliminado', () {
      final rate = strongWinRate(
        strongQuality: 78,
        weakQuality: 55,
        matches: 2000,
      );
      expect(rate, lessThan(0.97));
    });
  });

  group('tácticas', () {
    test('una mentalidad ultraofensiva produce más goles totales que una '
        'ultradefensiva', () {
      double totalGoals(Mentality mentality) {
        final home = uniformSheet(
          clubId: 'home',
          quality: 60,
          instructions: TacticalInstructions(mentality: mentality),
        );
        final away = uniformSheet(
          clubId: 'away',
          quality: 60,
          instructions: TacticalInstructions(mentality: mentality),
        );
        var goals = 0;
        for (var i = 0; i < 1500; i++) {
          final report = simulator.simulate(
            fixtureId: FixtureId('fx-t$i'),
            home: home,
            away: away,
            rng: Xoshiro256StarStar.fromSeed(derivedSeed(3000, i)),
          );
          goals += report.result.homeGoals + report.result.awayGoals;
        }
        return goals / 1500;
      }

      expect(
        totalGoals(Mentality.veryAttacking),
        greaterThan(totalGoals(Mentality.veryDefensive)),
      );
    });

    test('la presión alta cuesta más tarjetas', () {
      double yellows(PressingIntensity pressing) {
        final home = uniformSheet(
          clubId: 'home',
          quality: 60,
          instructions: TacticalInstructions(pressing: pressing),
        );
        final away = uniformSheet(clubId: 'away', quality: 60);
        var count = 0;
        for (var i = 0; i < 1500; i++) {
          final report = simulator.simulate(
            fixtureId: FixtureId('fx-p$i'),
            home: home,
            away: away,
            rng: Xoshiro256StarStar.fromSeed(derivedSeed(4000, i)),
          );
          count += report.homeStats.yellowCards + report.homeStats.redCards;
        }
        return count / 1500;
      }

      expect(
        yellows(PressingIntensity.high),
        greaterThan(yellows(PressingIntensity.low)),
      );
    });
  });
}
