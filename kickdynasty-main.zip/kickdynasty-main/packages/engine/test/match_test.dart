import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

import 'support/team_builders.dart';

/// Huella textual de un informe para comparar simulaciones completas.
String reportFingerprint(MatchReport report) {
  final buffer = StringBuffer()
    ..write('${report.result.homeGoals}-${report.result.awayGoals}|');
  for (final event in report.result.events) {
    buffer.write('${event.runtimeType}@${event.minute.value};');
  }
  for (final entry in report.ratings.entries) {
    buffer.write('${entry.key.value}=${entry.value};');
  }
  return buffer.toString();
}

void main() {
  final config = MatchEngineConfig.standard();

  group('positionFactor', () {
    final penalties = config.strength.positionPenalties;

    test('posición exacta no penaliza', () {
      expect(positionFactor(Position.st, Position.st, penalties), 1);
    });

    test('misma línea penaliza poco', () {
      expect(
        positionFactor(Position.lw, Position.st, penalties),
        penalties.sameGroup,
      );
    });

    test('línea contigua penaliza más', () {
      expect(
        positionFactor(Position.cb, Position.dm, penalties),
        penalties.adjacentGroup,
      );
    });

    test('defensa jugando de delantero penaliza mucho', () {
      expect(
        positionFactor(Position.cb, Position.st, penalties),
        penalties.farGroup,
      );
    });

    test('jugador de campo bajo palos es la mayor penalización', () {
      expect(
        positionFactor(Position.st, Position.gk, penalties),
        penalties.crossGoalkeeper,
      );
      expect(
        positionFactor(Position.gk, Position.st, penalties),
        penalties.crossGoalkeeper,
      );
    });
  });

  group('computeUnitScores', () {
    List<SlotPlayer> onPitch({required bool goalkeeperUpFront}) {
      final formation = Formation.f433;
      return [
        for (var i = 0; i < formation.slots.length; i++)
          SlotPlayer(
            slot: formation.slots[i],
            player: uniformPlayer(
              id: 'p$i',
              // El último slot del 4-3-3 es un extremo: colocar ahí a un
              // portero debe hundir el ataque.
              position: goalkeeperUpFront && i == formation.slots.length - 1
                  ? Position.gk
                  : formation.slots[i],
              quality: 60,
            ),
          ),
      ];
    }

    test('jugar con un portero de extremo debilita el ataque', () {
      final natural = computeUnitScores(
        onPitch: onPitch(goalkeeperUpFront: false),
        formation: Formation.f433,
        instructions: const TacticalInstructions(),
        model: config.strength,
      );
      final absurd = computeUnitScores(
        onPitch: onPitch(goalkeeperUpFront: true),
        formation: Formation.f433,
        instructions: const TacticalInstructions(),
        model: config.strength,
      );
      expect(absurd.attack, lessThan(natural.attack));
    });

    test('jugar con 10 debilita todas las unidades', () {
      final eleven = onPitch(goalkeeperUpFront: false);
      final full = computeUnitScores(
        onPitch: eleven,
        formation: Formation.f433,
        instructions: const TacticalInstructions(),
        model: config.strength,
      );
      final reduced = computeUnitScores(
        onPitch: eleven.sublist(0, 10),
        formation: Formation.f433,
        instructions: const TacticalInstructions(),
        model: config.strength,
      );
      expect(reduced.defence, lessThan(full.defence));
      expect(reduced.midfield, lessThan(full.midfield));
      expect(reduced.attack, lessThan(full.attack));
    });

    test('la fatiga reduce la fuerza con los minutos', () {
      final eleven = onPitch(goalkeeperUpFront: false);
      final fresh = computeUnitScores(
        onPitch: eleven,
        formation: Formation.f433,
        instructions: const TacticalInstructions(),
        model: config.strength,
      );
      final tired = computeUnitScores(
        onPitch: eleven,
        formation: Formation.f433,
        instructions: const TacticalInstructions(),
        model: config.strength,
        minute: 85,
      );
      expect(tired.midfield, lessThan(fresh.midfield));
    });

    test('la mentalidad ofensiva sube ataque y baja defensa', () {
      final eleven = onPitch(goalkeeperUpFront: false);
      final balanced = computeUnitScores(
        onPitch: eleven,
        formation: Formation.f433,
        instructions: const TacticalInstructions(),
        model: config.strength,
      );
      final attacking = computeUnitScores(
        onPitch: eleven,
        formation: Formation.f433,
        instructions: const TacticalInstructions(
          mentality: Mentality.veryAttacking,
        ),
        model: config.strength,
      );
      expect(attacking.attack, greaterThan(balanced.attack));
      expect(attacking.defence, lessThan(balanced.defence));
    });
  });

  group('TeamSheet', () {
    test('rechaza alineaciones con jugadores fuera de la plantilla', () {
      final squad = uniformSquad(clubId: 'club-a', quality: 60);
      final foreign = uniformSquad(clubId: 'club-b', quality: 60);
      final lineup = LineupSelector().select(squad: foreign);
      expect(
        () => TeamSheet(squad: squad, lineup: lineup),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });
  });

  group('LineupSelector', () {
    test('cubre todos los puestos con jugadores únicos de la plantilla', () {
      final squad = uniformSquad(clubId: 'club-a', quality: 60);
      final lineup = LineupSelector().select(squad: squad);

      expect(lineup.starters.length, 11);
      expect(lineup.starters.toSet().length, 11);
      for (final id in [...lineup.starters, ...lineup.bench]) {
        expect(squad.contains(id), isTrue);
      }
    });

    test('pone un portero natural bajo palos y otro en el banquillo', () {
      final squad = uniformSquad(clubId: 'club-a', quality: 60);
      final lineup = LineupSelector().select(squad: squad);

      final starterGk = squad.byId(lineup.starters.first)!;
      expect(starterGk.position.isGoalkeeper, isTrue);
      final benchGks = lineup.bench
          .map((id) => squad.byId(id)!)
          .where((p) => p.position.isGoalkeeper);
      expect(benchGks, isNotEmpty);
    });

    test('es determinista', () {
      final squad = uniformSquad(clubId: 'club-a', quality: 60);
      expect(
        LineupSelector().select(squad: squad),
        LineupSelector().select(squad: squad),
      );
    });

    test('cubre puestos sin especialista con el mejor sustituto', () {
      // Plantilla sin ningún atacante natural: el 4-3-3 exige tres arriba.
      final positions = [
        Position.gk,
        Position.gk,
        Position.cb,
        Position.cb,
        Position.cb,
        Position.cb,
        Position.lb,
        Position.rb,
        Position.dm,
        Position.dm,
        Position.cm,
        Position.cm,
        Position.cm,
        Position.am,
        Position.am,
        Position.cm,
      ];
      final squad = Squad(
        clubId: ClubId('club-x'),
        players: [
          for (var i = 0; i < positions.length; i++)
            uniformPlayer(id: 'x$i', position: positions[i], quality: 55),
        ],
      );
      final lineup = LineupSelector().select(squad: squad);
      expect(lineup.starters.length, 11);
    });
  });

  group('MatchSimulator', () {
    final simulator = MatchSimulator();

    MatchReport simulate(
      int seed, {
      int homeQuality = 60,
      int awayQuality = 60,
    }) {
      return simulator.simulate(
        fixtureId: FixtureId('fx-$seed'),
        home: uniformSheet(clubId: 'home', quality: homeQuality),
        away: uniformSheet(clubId: 'away', quality: awayQuality),
        rng: Xoshiro256StarStar.fromSeed(seed),
      );
    }

    test('es determinista: misma semilla, mismo informe', () {
      expect(reportFingerprint(simulate(7)), reportFingerprint(simulate(7)));
    });

    test('semillas distintas producen partidos distintos', () {
      expect(
        reportFingerprint(simulate(1)),
        isNot(reportFingerprint(simulate(2))),
      );
    });

    test('las estadísticas son coherentes', () {
      for (var seed = 0; seed < 50; seed++) {
        final report = simulate(seed);
        final home = report.homeStats;
        final away = report.awayStats;

        expect(home.possessionPct + away.possessionPct, 100);
        expect(home.shots, greaterThanOrEqualTo(home.shotsOnTarget));
        expect(
          home.shotsOnTarget,
          greaterThanOrEqualTo(report.result.homeGoals),
        );
        expect(away.shots, greaterThanOrEqualTo(away.shotsOnTarget));
        expect(
          away.shotsOnTarget,
          greaterThanOrEqualTo(report.result.awayGoals),
        );
        expect(home.expectedGoals, greaterThanOrEqualTo(0));
      }
    });

    test('propiedades de integridad sobre 100 partidos', () {
      for (var seed = 0; seed < 100; seed++) {
        final report = simulate(seed);
        final events = report.result.events;

        final homeSquad = uniformSquad(clubId: 'home', quality: 60);
        final awaySquad = uniformSquad(clubId: 'away', quality: 60);
        bool inSquads(PlayerId id) =>
            homeSquad.contains(id) || awaySquad.contains(id);

        // Jugadores fuera del campo en cada instante.
        final offPitch = <PlayerId>{};
        // Jugadores que aún no han entrado (suplentes).
        final notYetOn = <PlayerId>{
          for (final id in LineupSelector().select(squad: homeSquad).bench) id,
          for (final id in LineupSelector().select(squad: awaySquad).bench) id,
        };

        void assertActive(PlayerId id) {
          expect(
            inSquads(id),
            isTrue,
            reason: 'evento de un jugador ajeno a las plantillas',
          );
          expect(
            offPitch.contains(id),
            isFalse,
            reason: 'evento de un jugador ya retirado del campo',
          );
          expect(
            notYetOn.contains(id),
            isFalse,
            reason: 'evento de un suplente que aún no había entrado',
          );
        }

        for (final event in events) {
          switch (event) {
            case GoalScored(:final scorerId, :final assistantId):
              assertActive(scorerId);
              if (assistantId != null) assertActive(assistantId);
            case CardIssued(:final playerId, :final cardType):
              assertActive(playerId);
              if (cardType != CardType.yellow) offPitch.add(playerId);
            case PlayerInjured(:final playerId):
              assertActive(playerId);
              offPitch.add(playerId);
            case Substitution(:final playerOutId, :final playerInId):
              offPitch.add(playerOutId);
              notYetOn.remove(playerInId);
          }
        }

        // Valoraciones: solo participantes, dentro de la escala.
        expect(report.ratings, isNotEmpty);
        for (final entry in report.ratings.entries) {
          expect(inSquads(entry.key), isTrue);
          expect(entry.value, inInclusiveRange(4, 10));
        }
      }
    });

    test('golden: partido de referencia reproducible (semilla 42)', () {
      final report = simulate(42);
      final summary =
          '${report.result.homeGoals}-${report.result.awayGoals}'
          '/${report.result.events.length}';
      expect(summary, '0-1/5');
    });

    test('funciona con equipos generados proceduralmente', () {
      final world = WorldGenerator().generate(seed: 11);
      final clubs = world.leagues.first.clubs;
      final report = simulator.simulate(
        fixtureId: FixtureId('fx-gen'),
        home: sheetFromGeneratedClub(clubs[0]),
        away: sheetFromGeneratedClub(clubs[1]),
        rng: Xoshiro256StarStar.fromSeed(3),
      );
      expect(report.result.homeGoals, greaterThanOrEqualTo(0));
      expect(report.ratings.length, greaterThanOrEqualTo(22));
    });
  });
}
