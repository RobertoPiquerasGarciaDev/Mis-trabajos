import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

/// Huella determinista de un mundo: hash FNV-1a de una serialización
/// canónica de todos sus datos. Si dos mundos tienen la misma huella, son
/// idénticos a efectos de regresión.
String worldFingerprint(GeneratedWorld world) {
  const fnvPrime = 0x100000001b3;
  var hash = 0xcbf29ce484222325;

  void mix(String chunk) {
    for (final unit in chunk.codeUnits) {
      hash ^= unit;
      hash *= fnvPrime;
    }
  }

  for (final league in world.leagues) {
    mix(league.league.id.value);
    mix(league.league.name.value);
    mix('${league.level}');
    for (final generated in league.clubs) {
      final club = generated.club;
      mix(club.id.value);
      mix(club.name.value);
      mix(club.code.value);
      mix('${club.reputation.value}');
      mix(club.stadium.name.value);
      mix('${club.stadium.capacity}');
      mix('${club.balance.amount}');
      for (final player in generated.squad.players) {
        final a = player.attributes;
        mix(player.id.value);
        mix(player.name.value);
        mix(player.nationality.value);
        mix(player.position.name);
        mix(player.preferredFoot.name);
        mix('${player.age.years}');
        mix('${player.potential.value}');
        mix(
          '${a.pace.value},${a.stamina.value},${a.strength.value},'
          '${a.passing.value},${a.shooting.value},${a.dribbling.value},'
          '${a.tackling.value},${a.positioning.value},${a.vision.value},'
          '${a.composure.value},${a.goalkeeping.value}',
        );
        mix(
          '${player.fitness.value},${player.morale.value},'
          '${player.form.value}',
        );
      }
      for (final contract in generated.contracts) {
        mix(contract.id.value);
        mix('${contract.weeklyWage.amount}');
        mix('${contract.expiry}');
      }
    }
  }
  return (hash & 0xFFFFFFFFFFFF).toRadixString(16).padLeft(12, '0');
}

double attributeAverage(PlayerAttributes a) =>
    (a.pace.value +
        a.stamina.value +
        a.strength.value +
        a.passing.value +
        a.shooting.value +
        a.dribbling.value +
        a.tackling.value +
        a.positioning.value +
        a.vision.value +
        a.composure.value +
        a.goalkeeping.value) /
    11;

void main() {
  final world = WorldGenerator().generate(seed: 42);
  final config = WorldGenConfig.standard();

  group('estructura del mundo estándar', () {
    test('2 ligas × 20 clubes × plantilla completa', () {
      expect(world.leagues, hasLength(2));
      for (final league in world.leagues) {
        expect(league.clubs, hasLength(20));
        expect(league.league.clubIds, hasLength(20));
        for (final club in league.clubs) {
          expect(club.squad.size, config.squadSize);
          expect(club.contracts, hasLength(config.squadSize));
        }
      }
      expect(world.allPlayers.length, 2 * 20 * config.squadSize);
    });

    test('los ids, nombres y códigos de club son únicos en todo el mundo', () {
      final clubs = world.allClubs.toList();
      expect(clubs.map((c) => c.club.id.value).toSet(), hasLength(40));
      expect(clubs.map((c) => c.club.name.value).toSet(), hasLength(40));
      expect(clubs.map((c) => c.club.code.value).toSet(), hasLength(40));
    });

    test('los ids de jugador y contrato son únicos y coherentes', () {
      final playerIds = world.allPlayers.map((p) => p.id.value).toSet();
      expect(playerIds, hasLength(world.allPlayers.length));

      for (final club in world.allClubs) {
        for (final contract in club.contracts) {
          expect(contract.clubId, club.club.id);
          expect(club.squad.contains(contract.playerId), isTrue);
        }
      }
    });

    test('cada plantilla cumple la composición por posición del template', () {
      for (final club in world.allClubs) {
        for (final entry in config.squadTemplate.entries) {
          final count = club.squad.players
              .where((p) => p.position == entry.key)
              .length;
          expect(
            count,
            entry.value,
            reason: '${club.club.name.value} / ${entry.key.name}',
          );
        }
      }
    });
  });

  group('reproducibilidad (ADR 0002)', () {
    test('misma semilla → mundo idéntico', () {
      final again = WorldGenerator().generate(seed: 42);
      expect(worldFingerprint(again), worldFingerprint(world));
    });

    test('semillas distintas → mundos distintos', () {
      final other = WorldGenerator().generate(seed: 43);
      expect(worldFingerprint(other), isNot(worldFingerprint(world)));
    });

    test('golden: la semilla 42 produce exactamente el mundo esperado', () {
      // Si este test falla, el motor ha cambiado su output para una semilla
      // fija: o es un cambio de balance deliberado (actualiza la huella y
      // documenta en el CHANGELOG) o es una regresión de determinismo.
      expect(worldFingerprint(world), '19a18878e774');
    });
  });

  group('distribuciones (propiedades de balance)', () {
    test('las edades quedan dentro de los tramos configurados', () {
      final ages = world.allPlayers.map((p) => p.age.years);
      expect(ages.every((age) => age >= 16 && age <= 38), isTrue);
    });

    test('los porteros destacan en portería y los de campo no', () {
      final players = world.allPlayers.toList();
      final goalkeepers = players
          .where((p) => p.position == Position.gk)
          .toList();
      final outfield = players.where((p) => p.position != Position.gk).toList();

      double meanGoalkeeping(List<Player> group) =>
          group
              .map((p) => p.attributes.goalkeeping.value)
              .fold(0, (a, b) => a + b) /
          group.length;

      expect(
        meanGoalkeeping(goalkeepers) - meanGoalkeeping(outfield),
        greaterThan(25),
      );
    });

    test('la primera división es mejor que la segunda', () {
      double leagueMean(GeneratedLeague league) {
        final players = league.clubs.expand((c) => c.squad.players).toList();
        return players
                .map((p) => attributeAverage(p.attributes))
                .fold(0.0, (a, b) => a + b) /
            players.length;
      }

      final first = world.leagues.firstWhere((league) => league.level == 1);
      final second = world.leagues.firstWhere((league) => league.level == 2);
      expect(leagueMean(first) - leagueMean(second), greaterThan(5));
    });

    test('el potencial supera en media a la habilidad actual', () {
      final players = world.allPlayers.toList();
      final margin =
          players
              .map((p) => p.potential.value - attributeAverage(p.attributes))
              .fold(0.0, (a, b) => a + b) /
          players.length;
      expect(margin, greaterThan(0));
    });

    test('la cuota de jugadores nacionales respeta la configuración', () {
      final players = world.allPlayers.toList();
      final domestic = players.where((p) => p.nationality.value == 'ES').length;
      final share = domestic / players.length;
      expect(share, closeTo(config.domesticShare, 0.08));
    });

    test('salarios y contratos dentro de las reglas', () {
      for (final contract in world.allContracts) {
        expect(
          contract.weeklyWage.amount,
          greaterThanOrEqualTo(config.wageMinimum),
        );
        expect(contract.expiry.season, inInclusiveRange(2, 5));
        expect(contract.expiry.week, 1);
      }
    });

    test('estadios y tesorerías dentro de las reglas', () {
      for (final club in world.allClubs) {
        expect(
          club.club.stadium.capacity,
          inInclusiveRange(Stadium.minCapacity, Stadium.maxCapacity),
        );
        expect(club.club.balance.amount, greaterThan(0));
      }
    });

    test('los clubes de primera tienen más reputación media que los de '
        'segunda', () {
      double meanReputation(GeneratedLeague league) =>
          league.clubs
              .map((c) => c.club.reputation.value)
              .fold(0, (a, b) => a + b) /
          league.clubs.length;

      final first = world.leagues.firstWhere((league) => league.level == 1);
      final second = world.leagues.firstWhere((league) => league.level == 2);
      expect(meanReputation(first) - meanReputation(second), greaterThan(10));
    });
  });

  group('robustez de los generadores', () {
    test('NameGenerator falla claramente sin pool para el país', () {
      const generator = NameGenerator();
      expect(
        () => generator.personName(
          CountryCode('XX'),
          Xoshiro256StarStar.fromSeed(1),
        ),
        throwsStateError,
      );
    });

    test('PlayerGenerator falla claramente sin banda de calidad', () {
      final generator = PlayerGenerator(config: WorldGenConfig.standard());
      expect(
        () => generator.generate(
          id: PlayerId('p1'),
          position: Position.cm,
          leagueCountry: CountryCode('ES'),
          leagueLevel: 99,
          rng: Xoshiro256StarStar.fromSeed(1),
        ),
        throwsStateError,
      );
    });

    test('ClubGenerator garantiza códigos únicos ante colisiones', () {
      final config = WorldGenConfig.standard();
      final generator = ClubGenerator(config: config);
      final rng = Xoshiro256StarStar.fromSeed(5);
      final spec = config.leagues.first;
      final codes = <String>{};
      // 40 clubes sobre 20 ciudades: colisiones de código garantizadas.
      for (var i = 0; i < 40; i++) {
        final club = generator.generate(
          id: ClubId('c$i'),
          spec: spec,
          rng: rng,
        );
        expect(
          codes.add(club.code.value),
          isTrue,
          reason: 'código repetido: ${club.code.value}',
        );
      }
    });
  });
}
