@Tags(['people-first'])
import 'dart:io';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _person(PersonId id, PersonRole role, {int worldSeed = 42}) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: worldSeed,
    origin: generator.buildOrigin(
      worldSeed: worldSeed,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'goal-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: role,
    ageYears: role == PersonRole.player ? 24 : 48,
  );
}

BeliefEntry _belief({
  required PersonId observerId,
  required BeliefId id,
  required BeliefType type,
  required String summary,
  BeliefCategory category = BeliefCategory.otherPerson,
}) {
  return BeliefEntry(
    id: id,
    observerPersonId: observerId,
    type: type,
    category: category,
    summary: summary,
    confidence: BeliefConfidence(0.7),
    strength: BeliefStrength(0.6),
    origin: BeliefOrigin.isolatedInterpretation,
    sourceInterpretationIds: [InterpretationId('interpret-${id.value}')],
    createdAt: const MemoryTimestamp(season: 1, week: 1),
    updatedAt: const MemoryTimestamp(season: 1, week: 1),
    lastConfirmed: const MemoryTimestamp(season: 1, week: 1),
    contradictoryBeliefIds: const [],
  );
}

void main() {
  group('GoalBuilder', () {
    test('genera objetivos deterministas desde creencias', () {
      const builder = GoalBuilder();
      final person = _person(PersonId('person-goal-a'), PersonRole.player);
      final beliefs = BeliefCollection(
        ownerId: person.id,
        entries: [
          _belief(
            observerId: person.id,
            id: BeliefId('belief-goal-1'),
            type: BeliefType.trust,
            summary: 'Creo que confía en mí',
          ),
        ],
      );
      final personality = PersonalitySnapshot.fromPerson(person);

      final a = builder.build(
        person: person,
        beliefs: beliefs,
        personality: personality,
        worldSeed: 42,
        season: 1,
        week: 2,
      );
      final b = builder.build(
        person: person,
        beliefs: beliefs,
        personality: personality,
        worldSeed: 42,
        season: 1,
        week: 2,
      );

      expect(a, b);
      expect(a.entries, isNotEmpty);
      expect(a.entries.every((e) => e.passesNonRealityCheck), isTrue);
      expect(a.entries.every((e) => e.sourceBeliefIds.isNotEmpty), isTrue);
    });

    test('un Goal nunca nace desde Reality', () {
      final source = File(
        'lib/src/intelligence/goal_builder.dart',
      ).readAsStringSync();
      expect(source, isNot(contains('ObservableWorld')));
      expect(source, isNot(contains('CampaignState')));
      expect(source, isNot(contains('PerceptionSnapshot')));
      expect(source, isNot(contains('InterpretationCollection')));
      expect(source, isNot(contains('MemoryCollection')));
      expect(source, isNot(contains('RelationState')));
    });

    test('nunca depende de Player, attrs, OVR ni Gameplay', () {
      final source = File(
        'lib/src/intelligence/goal_builder.dart',
      ).readAsStringSync();
      expect(source, isNot(contains('Player(')));
      expect(source, isNot(contains('PlayerAttributes')));
      expect(source, isNot(contains('PlayerId(')));
      expect(source, isNot(contains('overall')));
      expect(source, isNot(contains('potential')));
      expect(source, isNot(contains('WorldWeekTick')));
      expect(source, isNot(contains('ClubAiDirector')));
      expect(source, isNot(contains('MatchSimulator')));
      expect(source, isNot(contains('kickdynasty_economy')));
      expect(source, isNot(contains('kickdynasty_market')));
      expect(source, isNot(contains('Economy')));
      expect(source, isNot(contains('MarketState')));
    });

    test('nunca conoce Deliberation ni Decisions', () {
      final source = File(
        'lib/src/intelligence/goal_builder.dart',
      ).readAsStringSync();
      expect(source, isNot(contains('Deliberation')));
      expect(source, isNot(contains('Decision')));
      expect(source, isNot(contains('ExecutedMandate')));
      expect(source, isNot(contains('ObservableWorld')));
      expect(source, isNot(contains('CampaignState')));
      expect(source, isNot(contains('Random')));
    });

    test('nunca genera acciones', () {
      const builder = GoalBuilder();
      final person = _person(PersonId('person-no-action'), PersonRole.player);
      final collection = builder.build(
        person: person,
        beliefs: BeliefCollection(
          ownerId: person.id,
          entries: [
            _belief(
              observerId: person.id,
              id: BeliefId('belief-no-action'),
              type: BeliefType.lossOfStatus,
              summary: 'Creo que pierdo protagonismo',
            ),
          ],
        ),
        personality: PersonalitySnapshot.fromPerson(person),
        worldSeed: 7,
        season: 1,
        week: 1,
      );

      expect(
        collection.entries.every(
          (entry) =>
              !entry.summary.toLowerCase().contains('fichar') &&
              !entry.summary.toLowerCase().contains('decidir') &&
              !entry.summary.toLowerCase().contains('planificar'),
        ),
        isTrue,
      );
    });

    test('un Goal solo nace desde Beliefs', () {
      const builder = GoalBuilder();
      final person = _person(PersonId('person-from-belief'), PersonRole.player);
      final beliefId = BeliefId('belief-only-source');
      final collection = builder.build(
        person: person,
        beliefs: BeliefCollection(
          ownerId: person.id,
          entries: [
            _belief(
              observerId: person.id,
              id: beliefId,
              type: BeliefType.trust,
              summary: 'Creo que confía en mí',
            ),
          ],
        ),
        personality: PersonalitySnapshot.fromPerson(person),
        worldSeed: 3,
        season: 1,
        week: 1,
      );

      expect(collection.entries, hasLength(1));
      expect(collection.entries.first.sourceBeliefIds, [beliefId]);
      expect(collection.entries.first.origin, GoalOrigin.beliefDerived);
    });

    test(
      'distintos perfiles generan Goals distintos desde las mismas Beliefs',
      () {
        const builder = GoalBuilder();
        final personA = _person(
          PersonId('person-profile-a'),
          PersonRole.player,
          worldSeed: 100,
        );
        final personB = _person(
          PersonId('person-profile-b'),
          PersonRole.player,
          worldSeed: 200,
        );
        final beliefs = BeliefCollection(
          ownerId: personA.id,
          entries: [
            _belief(
              observerId: personA.id,
              id: BeliefId('belief-shared'),
              type: BeliefType.selfImprovement,
              category: BeliefCategory.self,
              summary: 'Creo que debo mejorar',
            ),
          ],
        );

        final goalsA = builder.build(
          person: personA,
          beliefs: beliefs,
          personality: PersonalitySnapshot.fromPerson(personA),
          worldSeed: 11,
          season: 1,
          week: 1,
        );
        final goalsB = builder.build(
          person: personB,
          beliefs: BeliefCollection(
            ownerId: personB.id,
            entries: [
              _belief(
                observerId: personB.id,
                id: BeliefId('belief-shared'),
                type: BeliefType.selfImprovement,
                category: BeliefCategory.self,
                summary: 'Creo que debo mejorar',
              ),
            ],
          ),
          personality: PersonalitySnapshot.fromPerson(personB),
          worldSeed: 11,
          season: 1,
          week: 1,
        );

        expect(
          goalsA.entries.first.priority,
          isNot(equals(goalsB.entries.first.priority)),
        );
      },
    );

    test('una persona puede mantener Goals contradictorios', () {
      const builder = GoalBuilder();
      final person = _person(
        PersonId('person-contradictory'),
        PersonRole.player,
      );
      final collection = builder.build(
        person: person,
        beliefs: BeliefCollection(
          ownerId: person.id,
          entries: [
            _belief(
              observerId: person.id,
              id: BeliefId('belief-trust'),
              type: BeliefType.trust,
              summary: 'Creo que confía en mí',
            ),
            _belief(
              observerId: person.id,
              id: BeliefId('belief-loss'),
              type: BeliefType.lossOfStatus,
              summary: 'Creo que pierdo estatus',
            ),
          ],
        ),
        personality: PersonalitySnapshot.fromPerson(person),
        worldSeed: 5,
        season: 1,
        week: 1,
      );

      expect(collection.entries, hasLength(2));
      expect(
        collection.entries.map((e) => e.type).toSet(),
        containsAll([GoalType.maintainTrust, GoalType.regainStatus]),
      );
    });
  });
}
