@Tags(['people-first'])
import 'dart:io';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _person(PersonId id, PersonRole role) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: 42,
    origin: generator.buildOrigin(
      worldSeed: 42,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'belief-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: role,
    ageYears: role == PersonRole.player ? 24 : 48,
  );
}

InterpretationEntry _interpretation({
  required PersonId observerId,
  required InterpretationId id,
  required InterpretationType type,
  required String summary,
  List<String> relationIds = const [],
}) {
  return InterpretationEntry(
    id: id,
    observerPersonId: observerId,
    sourceMemoryIds: const [],
    sourceRelationIds: relationIds,
    type: type,
    confidence: InterpretationConfidence(0.7),
    importance: InterpretationImportance(0.6),
    createdAt: const MemoryTimestamp(season: 1, week: 1),
    expiresAt: null,
    biasApplied: InterpretationBias.none,
    summary: summary,
    source: InterpretationSource.relation,
  );
}

void main() {
  group('BeliefBuilder', () {
    test('genera creencias deterministas desde interpretaciones', () {
      const builder = BeliefBuilder();
      final observer = _person(PersonId('person-belief-a'), PersonRole.player);
      final interpretations = InterpretationCollection(
        ownerId: observer.id,
        entries: [
          _interpretation(
            observerId: observer.id,
            id: InterpretationId('interpret-belief-1'),
            type: InterpretationType.trust,
            summary: 'Confía en mí',
            relationIds: ['person-manager-1'],
          ),
        ],
      );

      final a = builder.build(
        observer: observer,
        interpretations: interpretations,
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        worldSeed: 42,
        season: 1,
        week: 2,
      );
      final b = builder.build(
        observer: observer,
        interpretations: interpretations,
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        worldSeed: 42,
        season: 1,
        week: 2,
      );

      expect(a, b);
      expect(a.entries, isNotEmpty);
      expect(a.entries.every((e) => e.passesNonRealityCheck), isTrue);
      expect(
        a.entries.every((e) => e.sourceInterpretationIds.isNotEmpty),
        isTrue,
      );
    });

    test('nunca depende de Player, attrs, OVR ni Gameplay', () {
      for (final path in [
        'lib/src/intelligence/belief_builder.dart',
        'lib/src/intelligence/belief_consolidator.dart',
      ]) {
        final source = File(path).readAsStringSync();
        expect(source, isNot(contains('Player(')));
        expect(source, isNot(contains('PlayerAttributes')));
        expect(source, isNot(contains('PlayerId(')));
        expect(source, isNot(contains('overall')));
        expect(source, isNot(contains('potential')));
        expect(source, isNot(contains('WorldWeekTick')));
        expect(source, isNot(contains('ClubAiDirector')));
        expect(source, isNot(contains('MatchSimulator')));
        expect(source, isNot(contains('kickdynasty_economy')));
        expect(source, isNot(contains('kickdynasty_market')));
        expect(source, isNot(contains('Economy')));
        expect(source, isNot(contains('MarketState')));
      }
    });

    test('solo consume Interpretation, Memory y Relations', () {
      for (final path in [
        'lib/src/intelligence/belief_builder.dart',
        'lib/src/intelligence/belief_consolidator.dart',
      ]) {
        final source = File(path).readAsStringSync();
        expect(source, isNot(contains('ObservableWorld')));
        expect(source, isNot(contains('CampaignState')));
        expect(source, isNot(contains('Player(')));
        expect(source, isNot(contains('Random')));
      }
    });

    test('nunca genera acciones', () {
      const builder = BeliefBuilder();
      final observer = _person(PersonId('person-no-action'), PersonRole.player);
      final collection = builder.build(
        observer: observer,
        interpretations: InterpretationCollection(
          ownerId: observer.id,
          entries: [
            _interpretation(
              observerId: observer.id,
              id: InterpretationId('interpret-no-action'),
              type: InterpretationType.lossOfStatus,
              summary: 'Estoy perdiendo protagonismo',
              relationIds: ['person-manager-x'],
            ),
          ],
        ),
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        worldSeed: 7,
        season: 1,
        week: 1,
      );

      expect(
        collection.entries.every(
          (entry) =>
              !entry.summary.toLowerCase().contains('fichar') &&
              !entry.summary.toLowerCase().contains('decidir'),
        ),
        isTrue,
      );
    });

    test(
      'una misma interpretación produce creencias distintas según el rol',
      () {
        const builder = BeliefBuilder();
        final player = _person(
          PersonId('person-role-player'),
          PersonRole.player,
        );
        final manager = _person(
          PersonId('person-role-manager'),
          PersonRole.manager,
        );
        final baseSummary = 'Lo que veo encaja con lo que recuerdo';

        final playerBeliefs = builder.build(
          observer: player,
          interpretations: InterpretationCollection(
            ownerId: player.id,
            entries: [
              _interpretation(
                observerId: player.id,
                id: InterpretationId('interpret-role-player'),
                type: InterpretationType.perceivedMeaning,
                summary: baseSummary,
              ).copyWithSource(InterpretationSource.perception),
            ],
          ),
          memory: const MemoryCollection.empty(),
          relations: const RelationState.empty(),
          worldSeed: 11,
          season: 1,
          week: 1,
        );
        final managerBeliefs = builder.build(
          observer: manager,
          interpretations: InterpretationCollection(
            ownerId: manager.id,
            entries: [
              _interpretation(
                observerId: manager.id,
                id: InterpretationId('interpret-role-manager'),
                type: InterpretationType.perceivedMeaning,
                summary: baseSummary,
              ).copyWithSource(InterpretationSource.perception),
            ],
          ),
          memory: const MemoryCollection.empty(),
          relations: const RelationState.empty(),
          worldSeed: 11,
          season: 1,
          week: 1,
        );

        expect(
          playerBeliefs.entries.first.category,
          BeliefCategory.competition,
        );
        expect(managerBeliefs.entries.first.category, BeliefCategory.world);
      },
    );

    test('una Belief solo nace desde Interpretation', () {
      const builder = BeliefBuilder();
      final observer = _person(
        PersonId('person-from-interp'),
        PersonRole.player,
      );
      final interpretationId = InterpretationId('interpret-only-source');
      final collection = builder.build(
        observer: observer,
        interpretations: InterpretationCollection(
          ownerId: observer.id,
          entries: [
            _interpretation(
              observerId: observer.id,
              id: interpretationId,
              type: InterpretationType.trust,
              summary: 'Confía en mí',
              relationIds: ['person-manager-src'],
            ),
          ],
        ),
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        worldSeed: 3,
        season: 1,
        week: 1,
      );

      expect(collection.entries, hasLength(1));
      expect(collection.entries.first.sourceInterpretationIds, [
        interpretationId,
      ]);
      expect(
        collection.entries.first.origin,
        BeliefOrigin.isolatedInterpretation,
      );
    });
  });

  group('BeliefConsolidator', () {
    test('varias interpretaciones coherentes consolidan una creencia', () {
      const consolidator = BeliefConsolidator();
      final observerId = PersonId('person-consolidate');
      const key = 'trust|otherPerson|rel:mgr|confía en mí';
      final candidates = [
        BeliefCandidate(
          observerPersonId: observerId,
          sourceInterpretationId: InterpretationId('interpret-c-1'),
          type: BeliefType.trust,
          category: BeliefCategory.otherPerson,
          summary: 'Confía en mí',
          tentativeConfidence: BeliefConfidence(0.6),
          tentativeStrength: BeliefStrength(0.5),
          consolidationKey: key,
          createdAt: const MemoryTimestamp(season: 1, week: 1),
        ),
        BeliefCandidate(
          observerPersonId: observerId,
          sourceInterpretationId: InterpretationId('interpret-c-2'),
          type: BeliefType.trust,
          category: BeliefCategory.otherPerson,
          summary: 'Confía en mí',
          tentativeConfidence: BeliefConfidence(0.65),
          tentativeStrength: BeliefStrength(0.52),
          consolidationKey: key,
          createdAt: const MemoryTimestamp(season: 1, week: 2),
        ),
      ];

      final result = consolidator.consolidate(
        candidates: candidates,
        observerId: observerId,
        worldSeed: 99,
        season: 1,
        week: 3,
      );

      expect(result.beliefs, hasLength(1));
      expect(result.beliefs.first.sourceInterpretationIds, hasLength(2));
      expect(
        result.beliefs.first.origin,
        BeliefOrigin.consolidatedInterpretations,
      );
      expect(result.beliefs.first.strength.value, greaterThan(0.45));
    });

    test('dos personas pueden mantener creencias opuestas', () {
      const builder = BeliefBuilder();
      final playerA = _person(PersonId('person-opp-a'), PersonRole.player);
      final playerB = _person(PersonId('person-opp-b'), PersonRole.player);
      final managerId = 'person-manager-opp';

      final beliefsA = builder.build(
        observer: playerA,
        interpretations: InterpretationCollection(
          ownerId: playerA.id,
          entries: [
            _interpretation(
              observerId: playerA.id,
              id: InterpretationId('interpret-opp-trust'),
              type: InterpretationType.trust,
              summary: 'Confía en mí',
              relationIds: [managerId],
            ),
          ],
        ),
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        worldSeed: 5,
        season: 1,
        week: 1,
      );
      final beliefsB = builder.build(
        observer: playerB,
        interpretations: InterpretationCollection(
          ownerId: playerB.id,
          entries: [
            _interpretation(
              observerId: playerB.id,
              id: InterpretationId('interpret-opp-loss'),
              type: InterpretationType.lossOfStatus,
              summary: 'El entrenador ya no confía en mí',
              relationIds: [managerId],
            ),
          ],
        ),
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        worldSeed: 5,
        season: 1,
        week: 1,
      );

      expect(
        beliefsA.entries.map((e) => e.type).toSet(),
        isNot(equals(beliefsB.entries.map((e) => e.type).toSet())),
      );
    });
  });
}

extension on InterpretationEntry {
  InterpretationEntry copyWithSource(InterpretationSource source) =>
      InterpretationEntry(
        id: id,
        observerPersonId: observerPersonId,
        sourceMemoryIds: sourceMemoryIds,
        sourceRelationIds: sourceRelationIds,
        type: type,
        confidence: confidence,
        importance: importance,
        createdAt: createdAt,
        expiresAt: expiresAt,
        biasApplied: biasApplied,
        summary: summary,
        source: source,
      );
}
