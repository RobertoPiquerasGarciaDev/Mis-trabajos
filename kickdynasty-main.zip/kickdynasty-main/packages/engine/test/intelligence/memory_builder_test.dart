@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

PerceptionSnapshot _sampleSnapshot(PersonId observerId) => PerceptionSnapshot(
  observerId: observerId,
  season: 1,
  week: 2,
  facts: [
    PerceivedFact(
      subjectId: 'player-abc',
      factKey: 'player.name',
      value: 'Test Player',
      source: PerceptionSource.directObservation,
      confidence: PerceptionConfidence(0.75),
      age: PerceptionAge.fresh,
      visibility: VisibilityLevel.full,
      quality: ObservationQuality(TraitScore(70)),
      origin: KnowledgeOrigin.self,
    ),
  ],
  availableSources: [PerceptionSource.directObservation],
);

void main() {
  group('MemoryBuilder', () {
    test('misma percepción produce la misma colección', () {
      const builder = MemoryBuilder();
      final ownerId = PersonId('person-builder-1');
      final snapshot = _sampleSnapshot(ownerId);

      final a = builder.buildFromPerception(
        ownerId: ownerId,
        snapshot: snapshot,
        worldSeed: 42,
      );
      final b = builder.buildFromPerception(
        ownerId: ownerId,
        snapshot: snapshot,
        worldSeed: 42,
      );

      expect(a, b);
    });

    test('solo almacena hechos previamente percibidos', () {
      const builder = MemoryBuilder();
      final ownerId = PersonId('person-builder-2');
      final snapshot = _sampleSnapshot(ownerId);
      final collection = builder.buildFromPerception(
        ownerId: ownerId,
        snapshot: snapshot,
        worldSeed: 7,
      );

      expect(collection.entries, hasLength(1));
      expect(collection.entries.first.factKey, 'player.name');
      expect(collection.entries.first.perceivedValue, 'Test Player');
      expect(collection.entries.first.type, MemoryType.perceivedFact);
    });
  });
}
