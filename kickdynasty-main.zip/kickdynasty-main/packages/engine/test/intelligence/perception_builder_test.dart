@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _staffPerson({
  required PersonId id,
  required PersonRole role,
  required int worldSeed,
  required ClubId clubId,
}) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: worldSeed,
    origin: generator.buildOrigin(
      worldSeed: worldSeed,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'perception-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: role,
    ageYears: 45,
  );
}

void main() {
  group('PerceptionBuilder', () {
    test('mismo Reality produce el mismo snapshot', () {
      final world = WorldGenerator().generate(seed: 42);
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 4,
        fixtures: const [],
        results: const {},
        stats: const {},
      );
      final club = world.allClubs.first;
      final managerId = syntheticStaffPersonId(
        worldSeed: world.seed,
        clubId: club.club.id,
        role: PersonRole.manager,
      );
      final manager = _staffPerson(
        id: managerId,
        role: PersonRole.manager,
        worldSeed: world.seed,
        clubId: club.club.id,
      );

      const builder = PerceptionBuilder();
      final observable = ObservableWorld.fromCampaignState(state);

      final a = builder.build(
        observer: manager,
        observerClubId: club.club.id,
        world: observable,
        season: state.season,
        week: state.nextRound,
        worldSeed: state.world.seed,
      );
      final b = builder.build(
        observer: manager,
        observerClubId: club.club.id,
        world: observable,
        season: state.season,
        week: state.nextRound,
        worldSeed: state.world.seed,
      );

      expect(a, b);
    });

    test('no expone potential ni OVR exacto', () {
      final world = WorldGenerator().generate(seed: 7);
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 1,
        fixtures: const [],
        results: const {},
        stats: const {},
      );
      final club = world.allClubs.first;
      final managerId = syntheticStaffPersonId(
        worldSeed: world.seed,
        clubId: club.club.id,
        role: PersonRole.manager,
      );
      final manager = _staffPerson(
        id: managerId,
        role: PersonRole.manager,
        worldSeed: world.seed,
        clubId: club.club.id,
      );

      const builder = PerceptionBuilder();
      final snapshot = builder.build(
        observer: manager,
        observerClubId: club.club.id,
        world: ObservableWorld.fromCampaignState(state),
        season: state.season,
        week: state.nextRound,
        worldSeed: state.world.seed,
      );

      expect(snapshot.passesNonOmniscienceCheck, isTrue);
      expect(
        snapshot.facts.any((f) => f.factKey.contains('potential')),
        isFalse,
      );
      expect(snapshot.facts.any((f) => f.factKey == 'player.overall'), isFalse);
      expect(
        snapshot.facts.any((f) => f.factKey == 'player.skillBand'),
        isTrue,
      );
    });
  });
}
