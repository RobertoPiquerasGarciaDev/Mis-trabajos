@Tags(['people-first'])
import 'dart:io';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _person(PersonId id, PersonRole role, {int worldSeed = 42}) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: worldSeed,
    origin: generator.buildOrigin(
      worldSeed: worldSeed,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'priority-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: role,
    ageYears: role == PersonRole.player ? 24 : 48,
  );
}

GoalEntry _goal({
  required PersonId observerId,
  required GoalId id,
  required GoalType type,
  double priority = 0.6,
  double strength = 0.55,
}) {
  final ts = const MemoryTimestamp(season: 1, week: 1);
  return GoalEntry(
    id: id,
    observerPersonId: observerId,
    type: type,
    category: GoalCategory.personal,
    summary: 'Quiero mantener la confianza que percibo',
    priority: GoalPriority(priority),
    strength: GoalStrength(strength),
    origin: GoalOrigin.beliefDerived,
    status: GoalStatus.active,
    timeHorizon: GoalTimeHorizon.shortTerm,
    sourceBeliefIds: [BeliefId('belief-${id.value}')],
    createdAt: ts,
    updatedAt: ts,
    lastReviewed: ts,
  );
}

void main() {
  group('PriorityBuilder', () {
    test('genera prioridades deterministas desde goals', () {
      const builder = PriorityBuilder();
      const ranker = PriorityRanker();
      final person = _person(PersonId('person-priority-a'), PersonRole.player);
      final goals = GoalCollection(
        ownerId: person.id,
        entries: [
          _goal(
            observerId: person.id,
            id: GoalId('goal-priority-1'),
            type: GoalType.maintainTrust,
          ),
        ],
      );

      final candidatesA = builder.buildCandidates(
        person: person,
        goals: goals,
        personality: PersonalitySnapshot.fromPerson(person),
        emotion: EmotionalState.initial,
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        season: 1,
        week: 2,
      );
      final candidatesB = builder.buildCandidates(
        person: person,
        goals: goals,
        personality: PersonalitySnapshot.fromPerson(person),
        emotion: EmotionalState.initial,
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        season: 1,
        week: 2,
      );
      expect(candidatesA, candidatesB);
      expect(candidatesA, isNotEmpty);
      expect(
        candidatesA.every((c) => c.sourceGoalId.value.startsWith('goal-')),
        isTrue,
      );

      final ranked = ranker.rank(
        person: person,
        candidates: candidatesA,
        worldSeed: 42,
        season: 1,
        week: 2,
      );
      expect(ranked.entries.first.rank, PriorityRank(1));
      expect(ranked.entries.first.type, PriorityType.dominant);
      expect(ranked.entries.every((e) => e.passesNonRealityCheck), isTrue);
    });

    test('Priority nunca nace desde Reality', () {
      for (final file in [
        'lib/src/intelligence/priority_builder.dart',
        'lib/src/intelligence/priority_ranker.dart',
      ]) {
        final source = File(file).readAsStringSync();
        expect(source, isNot(contains('ObservableWorld')));
        expect(source, isNot(contains('CampaignState')));
        expect(source, isNot(contains('PerceptionSnapshot')));
      }
    });

    test('Priority solo nace desde Goals', () {
      const builder = PriorityBuilder();
      final person = _person(PersonId('person-from-goal'), PersonRole.player);
      final goalId = GoalId('goal-only-source');
      final candidates = builder.buildCandidates(
        person: person,
        goals: GoalCollection(
          ownerId: person.id,
          entries: [
            _goal(
              observerId: person.id,
              id: goalId,
              type: GoalType.seekProtection,
            ),
          ],
        ),
        personality: PersonalitySnapshot.fromPerson(person),
        emotion: EmotionalState.initial,
        memory: const MemoryCollection.empty(),
        relations: const RelationState.empty(),
        season: 1,
        week: 1,
      );
      expect(candidates, hasLength(1));
      expect(candidates.first.sourceGoalId, goalId);
    });

    test(
      'distintos perfiles generan Priorities distintas desde los mismos Goals',
      () {
        const builder = PriorityBuilder();
        const ranker = PriorityRanker();
        final personA = _person(
          PersonId('person-profile-a'),
          PersonRole.player,
          worldSeed: 100,
        );
        final personB = _person(
          PersonId('person-profile-b'),
          PersonRole.player,
          worldSeed: 200,
        );
        final goalsA = GoalCollection(
          ownerId: personA.id,
          entries: [
            _goal(
              observerId: personA.id,
              id: GoalId('goal-shared'),
              type: GoalType.regainStatus,
            ),
          ],
        );
        final goalsB = GoalCollection(
          ownerId: personB.id,
          entries: [
            _goal(
              observerId: personB.id,
              id: GoalId('goal-shared'),
              type: GoalType.regainStatus,
            ),
          ],
        );

        final rankedA = ranker.rank(
          person: personA,
          candidates: builder.buildCandidates(
            person: personA,
            goals: goalsA,
            personality: PersonalitySnapshot.fromPerson(personA),
            emotion: EmotionalState.initial,
            memory: const MemoryCollection.empty(),
            relations: const RelationState.empty(),
            season: 1,
            week: 1,
          ),
          worldSeed: 11,
          season: 1,
          week: 1,
        );
        final rankedB = ranker.rank(
          person: personB,
          candidates: builder.buildCandidates(
            person: personB,
            goals: goalsB,
            personality: PersonalitySnapshot.fromPerson(personB),
            emotion: EmotionalState.initial,
            memory: const MemoryCollection.empty(),
            relations: const RelationState.empty(),
            season: 1,
            week: 1,
          ),
          worldSeed: 11,
          season: 1,
          week: 1,
        );

        expect(
          rankedA.entries.first.strength,
          isNot(equals(rankedB.entries.first.strength)),
        );
      },
    );
  });
}
