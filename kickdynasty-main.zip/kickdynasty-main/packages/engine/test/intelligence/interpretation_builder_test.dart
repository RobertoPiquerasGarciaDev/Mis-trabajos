@Tags(['people-first'])
import 'dart:io';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _person(PersonId id, PersonRole role) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: 42,
    origin: generator.buildOrigin(
      worldSeed: 42,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'interpretation-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: role,
    ageYears: role == PersonRole.player ? 24 : 48,
  );
}

RelationState _managerRelation({
  required PersonId observerId,
  required PersonId managerId,
  required double trust,
}) {
  return RelationState(
    observerId: observerId,
    entries: [
      RelationEntry(
        observerPersonId: observerId,
        targetPersonId: managerId,
        type: RelationType.manager,
        trust: RelationTrust(trust),
        respect: RelationRespect(0.6),
        affinity: RelationAffinity(0.4),
        confidence: RelationConfidence(0.7),
        strength: RelationStrength(0.5),
        history: const RelationHistory.empty(),
        knownSince: const MemoryTimestamp(season: 1, week: 1),
        lastInteraction: null,
        origin: RelationOrigin.structural,
        tags: const [RelationTag.staffHierarchy],
      ),
    ],
  );
}

void main() {
  group('InterpretationBuilder', () {
    test('genera interpretaciones deterministas', () {
      const builder = InterpretationBuilder();
      final observer = _person(PersonId('person-player-a'), PersonRole.player);
      final manager = PersonId('person-manager-a');
      final relations = _managerRelation(
        observerId: observer.id,
        managerId: manager,
        trust: 0.3,
      );

      final a = builder.build(
        observer: observer,
        personality: PersonalitySnapshot.fromPerson(observer),
        perception: null,
        memory: MemoryCollection.empty(ownerId: PersonId('person-player-a')),
        relations: relations,
        worldSeed: 42,
        season: 1,
        week: 2,
      );
      final b = builder.build(
        observer: observer,
        personality: PersonalitySnapshot.fromPerson(observer),
        perception: null,
        memory: MemoryCollection.empty(ownerId: PersonId('person-player-a')),
        relations: relations,
        worldSeed: 42,
        season: 1,
        week: 2,
      );

      expect(a, b);
    });

    test('dos personas interpretan distinto el mismo vínculo', () {
      const builder = InterpretationBuilder();
      final player = _person(
        PersonId('person-player-diff-a'),
        PersonRole.player,
      );
      final manager = _person(
        PersonId('person-manager-diff-b'),
        PersonRole.manager,
      );
      final presidentId = PersonId('person-president-diff');
      final playerRelations = RelationState(
        observerId: player.id,
        entries: [
          RelationEntry(
            observerPersonId: player.id,
            targetPersonId: presidentId,
            type: RelationType.president,
            trust: RelationTrust(0.5),
            respect: RelationRespect(0.7),
            affinity: RelationAffinity(0.3),
            confidence: RelationConfidence(0.6),
            strength: RelationStrength(0.5),
            history: const RelationHistory.empty(),
            knownSince: const MemoryTimestamp(season: 1, week: 1),
            lastInteraction: null,
            origin: RelationOrigin.structural,
            tags: const [RelationTag.staffHierarchy],
          ),
        ],
      );
      final managerRelations = RelationState(
        observerId: manager.id,
        entries: [
          RelationEntry(
            observerPersonId: manager.id,
            targetPersonId: presidentId,
            type: RelationType.president,
            trust: RelationTrust(0.5),
            respect: RelationRespect(0.7),
            affinity: RelationAffinity(0.3),
            confidence: RelationConfidence(0.6),
            strength: RelationStrength(0.5),
            history: const RelationHistory.empty(),
            knownSince: const MemoryTimestamp(season: 1, week: 1),
            lastInteraction: null,
            origin: RelationOrigin.structural,
            tags: const [RelationTag.staffHierarchy],
          ),
        ],
      );

      final interpretationPlayer = builder.build(
        observer: player,
        personality: PersonalitySnapshot.fromPerson(player),
        perception: null,
        memory: const MemoryCollection.empty(),
        relations: playerRelations,
        worldSeed: 99,
        season: 1,
        week: 1,
      );
      final interpretationManager = builder.build(
        observer: manager,
        personality: PersonalitySnapshot.fromPerson(manager),
        perception: null,
        memory: const MemoryCollection.empty(),
        relations: managerRelations,
        worldSeed: 99,
        season: 1,
        week: 1,
      );

      expect(
        interpretationPlayer.entries.map((e) => e.summary).toSet(),
        isNot(
          equals(interpretationManager.entries.map((e) => e.summary).toSet()),
        ),
      );
    });

    test('roles distintos producen hipótesis distintas', () {
      const builder = InterpretationBuilder();
      final player = _person(PersonId('person-player-role'), PersonRole.player);
      final manager = _person(
        PersonId('person-manager-role'),
        PersonRole.manager,
      );
      final presidentId = PersonId('person-president-role');
      final playerRelations = RelationState(
        observerId: player.id,
        entries: [
          RelationEntry(
            observerPersonId: player.id,
            targetPersonId: presidentId,
            type: RelationType.president,
            trust: RelationTrust(0.5),
            respect: RelationRespect(0.7),
            affinity: RelationAffinity(0.3),
            confidence: RelationConfidence(0.6),
            strength: RelationStrength(0.5),
            history: const RelationHistory.empty(),
            knownSince: const MemoryTimestamp(season: 1, week: 1),
            lastInteraction: null,
            origin: RelationOrigin.structural,
            tags: const [RelationTag.staffHierarchy],
          ),
        ],
      );
      final managerRelations = RelationState(
        observerId: manager.id,
        entries: [
          RelationEntry(
            observerPersonId: manager.id,
            targetPersonId: presidentId,
            type: RelationType.president,
            trust: RelationTrust(0.5),
            respect: RelationRespect(0.7),
            affinity: RelationAffinity(0.3),
            confidence: RelationConfidence(0.6),
            strength: RelationStrength(0.5),
            history: const RelationHistory.empty(),
            knownSince: const MemoryTimestamp(season: 1, week: 1),
            lastInteraction: null,
            origin: RelationOrigin.structural,
            tags: const [RelationTag.staffHierarchy],
          ),
        ],
      );

      final playerInterpretation = builder.build(
        observer: player,
        personality: PersonalitySnapshot.fromPerson(player),
        perception: null,
        memory: const MemoryCollection.empty(),
        relations: playerRelations,
        worldSeed: 7,
        season: 1,
        week: 1,
      );
      final managerInterpretation = builder.build(
        observer: manager,
        personality: PersonalitySnapshot.fromPerson(manager),
        perception: null,
        memory: const MemoryCollection.empty(),
        relations: managerRelations,
        worldSeed: 7,
        season: 1,
        week: 1,
      );

      expect(
        playerInterpretation.entries.any(
          (e) => e.summary.contains('presidente'),
        ),
        isTrue,
      );
      expect(
        managerInterpretation.entries
            .map((e) => e.summary)
            .toSet()
            .intersection(
              playerInterpretation.entries.map((e) => e.summary).toSet(),
            )
            .isEmpty,
        isTrue,
      );
    });

    test('solo consume Perception, Memory y Relations', () {
      final source = File(
        'lib/src/intelligence/interpretation_builder.dart',
      ).readAsStringSync();
      expect(source, isNot(contains('ObservableWorld')));
      expect(source, isNot(contains('CampaignState')));
      expect(source, isNot(contains('Player(')));
      expect(source, isNot(contains('PlayerAttributes')));
      expect(source, isNot(contains('Random')));
      expect(source, isNot(contains('rng')));
    });

    test('nunca genera decisiones', () {
      const builder = InterpretationBuilder();
      final observer = _person(
        PersonId('person-no-decision'),
        PersonRole.player,
      );
      final managerId = PersonId('person-manager-nodec');
      final collection = builder.build(
        observer: observer,
        personality: PersonalitySnapshot.fromPerson(observer),
        perception: PerceptionSnapshot(
          observerId: observer.id,
          season: 1,
          week: 1,
          facts: [
            PerceivedFact(
              subjectId: 'club-1',
              factKey: 'club.reputation',
              value: 'high',
              source: PerceptionSource.directObservation,
              confidence: PerceptionConfidence(0.8),
              age: PerceptionAge.fresh,
              visibility: VisibilityLevel.full,
              quality: ObservationQuality(TraitScore(70)),
              origin: KnowledgeOrigin.self,
            ),
          ],
          availableSources: const [PerceptionSource.directObservation],
        ),
        memory: MemoryCollection(
          ownerId: observer.id,
          entries: [
            MemoryEntry(
              id: MemoryId('memory-fitness'),
              ownerId: observer.id,
              type: MemoryType.perceivedFact,
              whatHappened: 'player.fitness=low',
              subjectId: managerId.value,
              involvedPersonIds: const [],
              perceivedAt: const MemoryTimestamp(season: 1, week: 1),
              source: PerceptionSource.directObservation,
              origin: KnowledgeOrigin.self,
              confidenceAtCapture: PerceptionConfidence(0.7),
              importance: MemoryImportance(0.5),
              strength: MemoryStrength(0.6),
              decay: const MemoryDecay(decayRate: 0.1),
              factKey: 'player.fitness',
              perceivedValue: 'low',
            ),
          ],
        ),
        relations: _managerRelation(
          observerId: observer.id,
          managerId: managerId,
          trust: -0.2,
        ),
        worldSeed: 13,
        season: 1,
        week: 2,
      );

      expect(collection.entries, isNotEmpty);
      expect(
        collection.entries.every((entry) => entry.passesNonRealityCheck),
        isTrue,
      );
      expect(
        collection.entries.every(
          (entry) =>
              !entry.summary.toLowerCase().contains('decidir') &&
              !entry.summary.toLowerCase().contains('fichar'),
        ),
        isTrue,
      );
    });
  });
}
