@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _samplePerson(PersonId id) {
  final trait = TraitScore(55);
  return Person(
    id: id,
    firstName: DisplayName('Test'),
    lastName: DisplayName('Person'),
    birthDate: BirthDate(year: 1992, month: 5, day: 10),
    nationality: CountryCode('ES'),
    primaryLanguage: 'es',
    gender: PersonGender.male,
    origin: PersonOrigin(
      country: CountryCode('ES'),
      city: 'Madrid',
      generation: 1,
      economicContext: 'middle',
      appearanceYear: 2024,
      cohort: 'factory-test',
      derivedWorldSeed: 99,
      birthContextHash: 1,
    ),
    personality: PersonalityProfile(
      ambition: trait,
      patience: trait,
      prudence: trait,
      aggressiveness: trait,
      pride: trait,
      ego: trait,
      professionalism: trait,
      empathy: trait,
      emotionalStability: trait,
      leadership: trait,
      memoryTrait: trait,
      pressureTolerance: trait,
    ),
    values: PersonValues(
      loyalty: trait,
      meritocracy: trait,
      family: trait,
      prestige: trait,
      security: trait,
    ),
    philosophy: PersonPhilosophy(
      pragmatism: trait,
      youthFocus: trait,
      attackingStyle: trait,
      financialPrudence: trait,
      institutionalLoyalty: trait,
    ),
    competencies: GeneralCompetencies(
      intelligence: trait,
      negotiation: trait,
      analysis: trait,
      communication: trait,
      adaptability: trait,
    ),
    traits: PermanentTraits(
      charisma: trait,
      workEthic: trait,
      resilience: trait,
      creativity: trait,
      discipline: trait,
    ),
    cognitivePotential: trait,
    initialReputation: Rating(60),
    role: PersonRole.player,
  );
}

void main() {
  group('AgentMindFactory', () {
    const factory = AgentMindFactory();

    test('misma persona y semilla producen la misma mente', () {
      final person = _samplePerson(PersonId('person-factory-1'));
      final a = factory.createInitial(person: person, worldSeed: 42);
      final b = factory.createInitial(person: person, worldSeed: 42);
      expect(a, b);
    });

    test('congela personalidad de la persona', () {
      final person = _samplePerson(PersonId('person-factory-2'));
      final mind = factory.createInitial(person: person, worldSeed: 7);
      expect(mind.personId, person.id);
      expect(mind.personality.profile, person.personality);
    });
  });

  group('tickAgentMind', () {
    test('shallow tick no altera la mente', () {
      const factory = AgentMindFactory();
      final person = _samplePerson(PersonId('person-tick-1'));
      final mind = factory.createInitial(person: person, worldSeed: 1);
      final ticked = tickAgentMind(mind);
      expect(identical(ticked, mind), isTrue);
    });
  });
}
