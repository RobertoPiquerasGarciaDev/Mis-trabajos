@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _person(PersonId id, PersonRole role) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: 42,
    origin: generator.buildOrigin(
      worldSeed: 42,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'relation-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: role,
    ageYears: role == PersonRole.player ? 24 : 48,
  );
}

void main() {
  group('RelationBuilder', () {
    test('genera relaciones deterministas', () {
      const builder = RelationBuilder();
      final observer = _person(PersonId('person-player-1'), PersonRole.player);
      final manager = _person(PersonId('person-manager-1'), PersonRole.manager);
      final snapshot = PerceptionSnapshot(
        observerId: observer.id,
        season: 1,
        week: 1,
        facts: const [],
        availableSources: const [PerceptionSource.directObservation],
      );
      const memory = MemoryCollection.empty();

      final a = builder.build(
        observer: observer,
        clubPeers: [observer, manager],
        perception: snapshot,
        memory: memory,
        worldSeed: 42,
        season: 1,
        week: 1,
      );
      final b = builder.build(
        observer: observer,
        clubPeers: [observer, manager],
        perception: snapshot,
        memory: memory,
        worldSeed: 42,
        season: 1,
        week: 1,
      );

      expect(a, b);
    });

    test('incluye self y manager estructural', () {
      const builder = RelationBuilder();
      final observer = _person(PersonId('person-player-2'), PersonRole.player);
      final manager = _person(PersonId('person-manager-2'), PersonRole.manager);
      final snapshot = PerceptionSnapshot(
        observerId: observer.id,
        season: 1,
        week: 1,
        facts: const [],
        availableSources: const [PerceptionSource.directObservation],
      );

      final state = builder.build(
        observer: observer,
        clubPeers: [observer, manager],
        perception: snapshot,
        memory: const MemoryCollection.empty(),
        worldSeed: 7,
        season: 1,
        week: 1,
      );

      expect(state.entries.any((e) => e.type == RelationType.self), isTrue);
      expect(state.entries.any((e) => e.type == RelationType.manager), isTrue);
      expect(state.entries.every((e) => e.passesNonRealityCheck), isTrue);
    });
  });
}
