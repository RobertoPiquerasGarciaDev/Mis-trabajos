@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _person(PersonId id) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: 42,
    origin: generator.buildOrigin(
      worldSeed: 42,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'decision-builder-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: PersonRole.player,
    ageYears: 24,
  );
}

void main() {
  group('DecisionBuilder', () {
    const builder = DecisionBuilder();

    test('consolida resultado social en DecisionCollection', () {
      final person = _person(PersonId('player-decision-builder'));
      final intention = IntentionEntry(
        id: IntentionId('intention-builder-1'),
        observerPersonId: person.id,
        sourcePriorityId: PriorityId('priority-builder-1'),
        type: IntentionType.wantToLeaveClub,
        summary: 'Quiero salir del club',
        strength: IntentionStrength(0.8),
        status: IntentionStatus.active,
        createdAt: const MemoryTimestamp(season: 1, week: 2),
        updatedAt: const MemoryTimestamp(season: 1, week: 2),
      );
      final result = SocialDeliberationResult(
        convocation: DeliberationConvocation.protocol(
          type: DeliberationProtocolType.transferOutDeliberation,
          reason: 'protocolo',
        ),
        sourceIntentionId: intention.id,
        outcome: MandateOutcome.proceed,
        participants: const [],
        proposalSummary: 'Propuesta',
        dissent: const [],
        rejectedPaths: const [],
        protocolType: DeliberationProtocolType.transferOutDeliberation,
        instanceId: 'protocol-1',
        decisionRecord: DecisionRecord(
          id: 'dr-builder-1',
          protocolType: DeliberationProtocolType.transferOutDeliberation,
          clubId: ClubId('club-1'),
          season: 1,
          week: 2,
          instanceId: 'protocol-1',
          outcome: MandateOutcome.proceed,
          participants: const [],
        ),
      );

      final first = builder.build(
        person: person,
        intention: intention,
        priorities: PriorityCollection(
          ownerId: person.id,
          entries: [
            PriorityEntry(
              id: PriorityId('priority-builder-1'),
              observerPersonId: person.id,
              sourceGoalId: GoalId('goal-1'),
              goalType: GoalType.maintainTrust,
              summary: 'Prioridad salida',
              strength: PriorityStrength(0.7),
              rank: PriorityRank(1),
              type: PriorityType.dominant,
              origin: PriorityOrigin.goalDerived,
              reason: PriorityReason.goalStrength,
              createdAt: const MemoryTimestamp(season: 1, week: 2),
              updatedAt: const MemoryTimestamp(season: 1, week: 2),
            ),
          ],
        ),
        result: result,
        worldSeed: 42,
        season: 1,
        week: 2,
      );
      final second = builder.build(
        person: person,
        intention: intention,
        priorities: PriorityCollection(
          ownerId: person.id,
          entries: [
            PriorityEntry(
              id: PriorityId('priority-builder-1'),
              observerPersonId: person.id,
              sourceGoalId: GoalId('goal-1'),
              goalType: GoalType.maintainTrust,
              summary: 'Prioridad salida',
              strength: PriorityStrength(0.7),
              rank: PriorityRank(1),
              type: PriorityType.dominant,
              origin: PriorityOrigin.goalDerived,
              reason: PriorityReason.goalStrength,
              createdAt: const MemoryTimestamp(season: 1, week: 2),
              updatedAt: const MemoryTimestamp(season: 1, week: 2),
            ),
          ],
        ),
        result: result,
        worldSeed: 42,
        season: 1,
        week: 2,
      );

      expect(first, second);
      expect(first.entries, hasLength(1));
      expect(first.entries.single.passesNonRealityCheck, isTrue);
      expect(first.entries.single.type, DecisionType.socialResolved);
      expect(first.entries.single.decisionRecordId, 'dr-builder-1');
    });
  });
}
