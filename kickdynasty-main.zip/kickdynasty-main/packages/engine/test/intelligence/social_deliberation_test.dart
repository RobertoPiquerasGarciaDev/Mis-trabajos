@Tags(['people-first'])
import 'dart:io';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _person(PersonId id, PersonRole role, {int worldSeed = 42}) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: worldSeed,
    origin: generator.buildOrigin(
      worldSeed: worldSeed,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'social-delib-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: role,
    ageYears: role == PersonRole.player ? 24 : 48,
  );
}

IntentionEntry _intention({
  required PersonId observerId,
  required IntentionType type,
  double strength = 0.75,
}) {
  final ts = const MemoryTimestamp(season: 1, week: 2);
  return IntentionEntry(
    id: IntentionId('intention-${type.name}-$observerId'),
    observerPersonId: observerId,
    sourcePriorityId: PriorityId('priority-$observerId'),
    type: type,
    summary: 'Postura: ${type.name}',
    strength: IntentionStrength(strength),
    status: IntentionStatus.active,
    createdAt: ts,
    updatedAt: ts,
  );
}

SocialDeliberationContext _context({
  required Person proponent,
  required IntentionEntry intention,
  required List<Person> clubPersons,
  ClubId? clubId,
}) {
  return SocialDeliberationContext(
    proponent: proponent,
    intentions: IntentionCollection(
      ownerId: proponent.id,
      entries: [intention],
    ),
    priorities: const PriorityCollection.empty(),
    beliefs: const BeliefCollection.empty(),
    memory: const MemoryCollection.empty(),
    relations: const RelationState.empty(),
    personality: PersonalitySnapshot.fromPerson(proponent),
    emotion: EmotionalState.initial,
    clubId: clubId,
    clubPersons: clubPersons,
    worldSeed: 42,
    season: 1,
    week: 2,
  );
}

void main() {
  group('DeliberationConvocationSelector', () {
    const selector = DeliberationConvocationSelector();

    test('wantToSellPlayer requiere protocolo social', () {
      final person = _person(PersonId('player-sell'), PersonRole.player);
      final intention = _intention(
        observerId: person.id,
        type: IntentionType.wantToSellPlayer,
      );
      final convocation = selector.select(intention: intention, person: person);
      expect(convocation.requiresSocialProtocol, isTrue);
      expect(
        convocation.protocolType,
        DeliberationProtocolType.transferOutDeliberation,
      );
    });

    test('manager assertLeadership es unilateral', () {
      final person = _person(PersonId('manager-uni'), PersonRole.manager);
      final intention = _intention(
        observerId: person.id,
        type: IntentionType.wantToAssertLeadership,
      );
      final convocation = selector.select(intention: intention, person: person);
      expect(convocation.unilateralAllowed, isTrue);
      expect(convocation.requiresSocialProtocol, isFalse);
    });

    test('intención débil se difiere', () {
      final person = _person(PersonId('player-weak'), PersonRole.player);
      final intention = _intention(
        observerId: person.id,
        type: IntentionType.wantToRenew,
        strength: 0.2,
      );
      final convocation = selector.select(intention: intention, person: person);
      expect(convocation.deferred, isTrue);
    });
  });

  group('SocialDeliberationEngine', () {
    const engine = SocialDeliberationEngine();

    test('produce resultado determinista', () {
      final player = _person(PersonId('player-social-a'), PersonRole.player);
      final president = _person(PersonId('president-a'), PersonRole.president);
      final clubId = ClubId('club-a');
      final intention = _intention(
        observerId: player.id,
        type: IntentionType.wantToLeaveClub,
      );
      final context = _context(
        proponent: player,
        intention: intention,
        clubPersons: [player, president],
        clubId: clubId,
      );
      final participants = {
        president.id: SocialParticipantProfile(
          person: president,
          personality: PersonalitySnapshot.fromPerson(president),
          emotion: EmotionalState.initial,
        ),
      };

      final first = engine.deliberate(
        context: context,
        participants: participants,
      );
      final second = engine.deliberate(
        context: context,
        participants: participants,
      );
      expect(first, second);
      expect(first.decisionRecord, isNotNull);
    });

    test('unilateral no produce DecisionRecord', () {
      final manager = _person(PersonId('manager-uni-b'), PersonRole.manager);
      final intention = _intention(
        observerId: manager.id,
        type: IntentionType.wantToAssertLeadership,
      );
      final context = _context(
        proponent: manager,
        intention: intention,
        clubPersons: [manager],
        clubId: ClubId('club-b'),
      );

      final result = engine.deliberate(
        context: context,
        participants: const {},
      );
      expect(result.decisionRecord, isNull);
      expect(result.outcome, MandateOutcome.proceed);
    });

    test('SocialDeliberation nunca conoce Reality', () {
      for (final file in [
        'lib/src/intelligence/social_deliberation_engine.dart',
        'lib/src/intelligence/decision_builder.dart',
        'lib/src/intelligence/deliberation_convocation_selector.dart',
      ]) {
        final source = File(file).readAsStringSync();
        expect(source, isNot(contains('ObservableWorld')));
        expect(source, isNot(contains('CampaignState')));
        expect(source, isNot(contains('WorldWeekTick')));
      }
    });

    test('SocialDeliberation nunca produce ExecutedMandate', () {
      final source = File(
        'lib/src/intelligence/social_deliberation_engine.dart',
      ).readAsStringSync();
      expect(source, isNot(contains('ExecutedMandate')));
      expect(source, isNot(contains('Chronicle')));
    });
  });
}
