@Tags(['people-first'])
import 'dart:io';

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Person _person(PersonId id, PersonRole role, {int worldSeed = 42}) {
  const generator = PersonGenerator();
  return generator.generate(
    id: id,
    worldSeed: worldSeed,
    origin: generator.buildOrigin(
      worldSeed: worldSeed,
      country: CountryCode('ES'),
      city: 'Madrid',
      cohort: 'deliberation-test',
      generation: 1,
      appearanceYear: 2024,
      economicContext: 'middle',
    ),
    role: role,
    ageYears: role == PersonRole.player ? 24 : 48,
  );
}

DeliberationContext _context({
  required Person person,
  required PriorityCollection priorities,
  EmotionalState emotion = EmotionalState.initial,
}) {
  return DeliberationContext(
    person: person,
    beliefs: const BeliefCollection.empty(),
    goals: const GoalCollection.empty(),
    priorities: priorities,
    memory: const MemoryCollection.empty(),
    relations: const RelationState.empty(),
    personality: PersonalitySnapshot.fromPerson(person),
    emotion: emotion,
    worldSeed: 42,
    season: 1,
    week: 2,
  );
}

PriorityEntry _priority({
  required PersonId observerId,
  required PriorityId id,
  required GoalType goalType,
  required PriorityType type,
  double strength = 0.7,
}) {
  final ts = const MemoryTimestamp(season: 1, week: 2);
  return PriorityEntry(
    id: id,
    observerPersonId: observerId,
    sourceGoalId: GoalId('goal-${id.value}'),
    goalType: goalType,
    summary: 'Atención hacia: objetivo',
    strength: PriorityStrength(strength),
    rank: PriorityRank(type == PriorityType.dominant ? 1 : 2),
    type: type,
    origin: PriorityOrigin.goalDerived,
    reason: PriorityReason.goalStrength,
    createdAt: ts,
    updatedAt: ts,
  );
}

void main() {
  group('InternalDeliberationEngine', () {
    test('produce intenciones deterministas desde prioridades', () {
      const engine = InternalDeliberationEngine();
      const builder = IntentionBuilder();
      final person = _person(PersonId('person-delib-a'), PersonRole.player);
      final priorities = PriorityCollection(
        ownerId: person.id,
        entries: [
          _priority(
            observerId: person.id,
            id: PriorityId('priority-delib-1'),
            goalType: GoalType.maintainTrust,
            type: PriorityType.dominant,
          ),
        ],
      );

      final resultA = engine.deliberate(
        _context(person: person, priorities: priorities),
      );
      final resultB = engine.deliberate(
        _context(person: person, priorities: priorities),
      );
      expect(resultA, resultB);
      expect(resultA.candidates, isNotEmpty);

      final intentions = builder.build(
        person: person,
        result: resultA,
        worldSeed: 42,
        season: 1,
        week: 2,
      );
      expect(intentions.entries.every((e) => e.passesNonRealityCheck), isTrue);
    });

    test('InternalDeliberation nunca conoce Reality', () {
      for (final file in [
        'lib/src/intelligence/internal_deliberation_engine.dart',
        'lib/src/intelligence/intention_builder.dart',
      ]) {
        final source = File(file).readAsStringSync();
        expect(source, isNot(contains('ObservableWorld')));
        expect(source, isNot(contains('CampaignState')));
        expect(source, isNot(contains('PerceptionSnapshot')));
      }
    });

    test('InternalDeliberation nunca conoce Gameplay', () {
      final source = File(
        'lib/src/intelligence/internal_deliberation_engine.dart',
      ).readAsStringSync();
      expect(source, isNot(contains('Player(')));
      expect(source, isNot(contains('PlayerAttributes')));
      expect(source, isNot(contains('WorldWeekTick')));
      expect(source, isNot(contains('MatchSimulator')));
    });

    test('InternalDeliberation nunca produce Decision', () {
      final source = File(
        'lib/src/intelligence/internal_deliberation_engine.dart',
      ).readAsStringSync();
      expect(source, isNot(contains('DecisionRecord')));
      expect(source, isNot(contains('ExecutedMandate')));
      expect(source, isNot(contains('Decision(')));
    });

    test('InternalDeliberation solo produce Intentions', () {
      const engine = InternalDeliberationEngine();
      final person = _person(
        PersonId('person-only-intentions'),
        PersonRole.manager,
      );
      final result = engine.deliberate(
        _context(
          person: person,
          priorities: PriorityCollection(
            ownerId: person.id,
            entries: [
              _priority(
                observerId: person.id,
                id: PriorityId('priority-only-intentions'),
                goalType: GoalType.assertLeadership,
                type: PriorityType.dominant,
              ),
            ],
          ),
        ),
      );
      expect(result.candidates, isNotEmpty);
    });

    test(
      'mismas Priorities con distinta personalidad producen Intentions distintas',
      () {
        const engine = InternalDeliberationEngine();
        const builder = IntentionBuilder();
        final personA = _person(
          PersonId('person-intent-a'),
          PersonRole.player,
          worldSeed: 50,
        );
        final personB = _person(
          PersonId('person-intent-b'),
          PersonRole.player,
          worldSeed: 150,
        );
        final priorities = PriorityCollection(
          ownerId: personA.id,
          entries: [
            _priority(
              observerId: personA.id,
              id: PriorityId('priority-shared'),
              goalType: GoalType.maintainTrust,
              type: PriorityType.dominant,
              strength: 0.8,
            ),
          ],
        );

        final resultA = engine.deliberate(
          _context(person: personA, priorities: priorities),
        );
        final resultB = engine.deliberate(
          _context(
            person: personB,
            priorities: PriorityCollection(
              ownerId: personB.id,
              entries: [
                _priority(
                  observerId: personB.id,
                  id: PriorityId('priority-shared'),
                  goalType: GoalType.maintainTrust,
                  type: PriorityType.dominant,
                  strength: 0.8,
                ),
              ],
            ),
          ),
        );

        final intentionsA = builder.build(
          person: personA,
          result: resultA,
          worldSeed: 7,
          season: 1,
          week: 2,
        );
        final intentionsB = builder.build(
          person: personB,
          result: resultB,
          worldSeed: 7,
          season: 1,
          week: 2,
        );

        expect(
          intentionsA.entries.first.strength,
          isNot(equals(intentionsB.entries.first.strength)),
        );
      },
    );

    test('Intentions nunca modifican Reality ni ejecutan acciones', () {
      const engine = InternalDeliberationEngine();
      const builder = IntentionBuilder();
      final person = _person(PersonId('person-no-action'), PersonRole.player);
      final result = engine.deliberate(
        _context(
          person: person,
          priorities: PriorityCollection(
            ownerId: person.id,
            entries: [
              _priority(
                observerId: person.id,
                id: PriorityId('priority-no-action'),
                goalType: GoalType.regainStatus,
                type: PriorityType.active,
              ),
            ],
          ),
        ),
      );
      final intentions = builder.build(
        person: person,
        result: result,
        worldSeed: 3,
        season: 1,
        week: 2,
      );
      expect(
        intentions.entries.every(
          (entry) =>
              !entry.summary.toLowerCase().contains('fichar') &&
              !entry.summary.toLowerCase().contains('decidir') &&
              !entry.summary.toLowerCase().contains('planificar'),
        ),
        isTrue,
      );
    });
  });
}
