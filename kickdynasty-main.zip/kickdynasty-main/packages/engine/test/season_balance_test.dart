@Tags(['balance'])
library;

import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

/// Balance de temporada (ADR 0005): el mundo debe seguir siendo un juego
/// sano después de varias temporadas encadenadas, sin deriva de calidad,
/// edad ni población.
void main() {
  const seasonsToRun = 4;

  final simulator = SeasonSimulator();
  var world = WorldGenerator().generate(seed: 42);
  final initialPlayerCount = world.allPlayers.length;

  double meanOverall(GeneratedWorld world) {
    var sum = 0.0;
    var count = 0;
    for (final player in world.allPlayers) {
      sum +=
          (player.attributes.passing.value +
              player.attributes.shooting.value +
              player.attributes.tackling.value +
              player.attributes.positioning.value) /
          4;
      count++;
    }
    return sum / count;
  }

  double meanAge(GeneratedWorld world) {
    var sum = 0;
    var count = 0;
    for (final player in world.allPlayers) {
      sum += player.age.years;
      count++;
    }
    return sum / count;
  }

  final initialQuality = meanOverall(world);
  final initialAge = meanAge(world);
  final goalsPerSeason = <double>[];

  final outcomes = <SeasonOutcome>[];
  for (var season = 1; season <= seasonsToRun; season++) {
    final outcome = simulator.simulateSeason(
      world: world,
      season: season,
      seed: derivedSeed(42, season),
    );
    outcomes.add(outcome);

    var goals = 0;
    var matches = 0;
    for (final league in outcome.leagues) {
      for (final result in league.results.values) {
        goals += result.homeGoals + result.awayGoals;
        matches++;
      }
    }
    goalsPerSeason.add(goals / matches);

    world = simulator.advanceSeason(
      outcome: outcome,
      seed: derivedSeed(43, season),
    );
  }

  test('la población de jugadores es estable', () {
    expect(world.allPlayers.length, initialPlayerCount);
    for (final club in world.allClubs) {
      expect(
        club.squad.players.where((p) => p.position.isGoalkeeper).length,
        greaterThanOrEqualTo(2),
      );
    }
  });

  test('la calidad media del mundo no deriva', () {
    final quality = meanOverall(world);
    expect(
      quality,
      inInclusiveRange(initialQuality - 3, initialQuality + 3),
      reason:
          'calidad inicial $initialQuality, tras '
          '$seasonsToRun temporadas $quality',
    );
  });

  test('la edad media se mantiene en banda realista', () {
    final age = meanAge(world);
    expect(
      age,
      inInclusiveRange(initialAge - 2, initialAge + 2),
      reason: 'edad inicial $initialAge, tras $seasonsToRun temporadas $age',
    );
    expect(age, inInclusiveRange(22, 28));
  });

  test('los goles por partido se mantienen en banda todas las temporadas', () {
    for (final goals in goalsPerSeason) {
      expect(goals, inInclusiveRange(2.2, 3.2));
    }
  });

  test('hay rotación real: cada club usa bastantes más de 11 jugadores', () {
    final lastOutcome = outcomes.last;
    for (final league in lastOutcome.leagues) {
      for (final club in league.clubs) {
        final used = club.squad.players
            .where((p) => (lastOutcome.playerStats[p.id]?.appearances ?? 0) > 0)
            .length;
        expect(
          used,
          greaterThanOrEqualTo(15),
          reason: 'el club ${club.club.id.value} usó $used jugadores',
        );
      }
    }
  });

  test('los canteranos (regens) llegan a debutar', () {
    final regenAppearances = outcomes.last.playerStats.entries
        .where((e) => e.key.value.contains('regen'))
        .fold(0, (sum, e) => sum + e.value.appearances);
    expect(regenAppearances, greaterThan(0));
  });

  test('ninguna edad supera el retiro forzoso', () {
    final maxAge = world.allPlayers
        .map((p) => p.age.years)
        .reduce((a, b) => a > b ? a : b);
    expect(
      maxAge,
      lessThanOrEqualTo(
        SeasonConfig.standard().development.forcedRetirementAge,
      ),
    );
  });
}
