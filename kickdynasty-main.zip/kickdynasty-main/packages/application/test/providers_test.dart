import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';
import 'package:riverpod/riverpod.dart';
import 'package:test/test.dart';

void main() {
  late SaveDatabase database;
  late ProviderContainer container;

  setUp(() {
    database = openSaveDatabaseInMemory();
    container = ProviderContainer(
      overrides: [saveDatabaseProvider.overrideWithValue(database)],
    );
  });

  tearDown(() {
    container.dispose();
    database.close();
  });

  test('startNew deja una sesión activa persistida', () async {
    final bootstrap = SeasonSimulator().bootstrapCampaign(seed: 8);
    final clubId = bootstrap.world.leagues.first.clubs.first.club.id;

    await container
        .read(activeCampaignProvider.notifier)
        .startNew(name: 'Riverpod', seed: 8, playerClubId: clubId);

    final session = container.read(activeCampaignProvider).value;
    expect(session, isNotNull);
    expect(session!.state.playerClubId, clubId);

    final saves = await container.read(savedGamesProvider.future);
    expect(saves, hasLength(1));
    expect(saves.first.name, 'Riverpod');
  });

  test('advanceRound actualiza sesión y refresca guardados', () async {
    final clubId = SeasonSimulator()
        .bootstrapCampaign(seed: 9)
        .world
        .leagues
        .first
        .clubs
        .first
        .club
        .id;

    final notifier = container.read(activeCampaignProvider.notifier);
    await notifier.startNew(name: 'Jornada', seed: 9, playerClubId: clubId);
    await notifier.advanceRound();

    final session = container.read(activeCampaignProvider).value!;
    expect(session.lastRound?.round, 1);
    expect(session.state.nextRound, 2);

    final table = container.read(playerLeagueTableProvider);
    expect(table, isNotNull);
    expect(table!.rows.every((r) => r.played <= 1), isTrue);
  });

  test('load restaura un guardado existente', () async {
    final clubId = SeasonSimulator()
        .bootstrapCampaign(seed: 10)
        .world
        .leagues
        .first
        .clubs
        .first
        .club
        .id;

    final notifier = container.read(activeCampaignProvider.notifier);
    await notifier.startNew(name: 'Cargar', seed: 10, playerClubId: clubId);
    final saveId = container.read(activeCampaignProvider).value!.saveId;
    notifier.clear();

    final summary = (await container.read(
      savedGamesProvider.future,
    )).firstWhere((s) => s.id == saveId);
    await notifier.load(summary);

    expect(container.read(activeCampaignProvider).value?.saveId, saveId);
  });

  test('save persiste sin cambiar la sesión en memoria', () async {
    final clubId = SeasonSimulator()
        .bootstrapCampaign(seed: 11)
        .world
        .leagues
        .first
        .clubs
        .first
        .club
        .id;

    final notifier = container.read(activeCampaignProvider.notifier);
    await notifier.startNew(name: 'Manual', seed: 11, playerClubId: clubId);
    await notifier.save();

    final reloaded = await LoadCampaign(SaveRepository(database))(
      (await container.read(savedGamesProvider.future)).first,
    );
    expect(reloaded.state.world.seed, 11);
  });
}
