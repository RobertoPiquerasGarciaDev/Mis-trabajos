@Tags(['people-first'])
import 'package:kickdynasty_application/src/people_first/synthetic_person_migration.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  group('ensureSyntheticPersons', () {
    test('genera personas deterministas para campaña fresca', () {
      final world = WorldGenerator().generate(seed: 17);
      const scheduler = FixtureScheduler();
      final fixtures = scheduler.schedule(
        league: world.leagues.first.league,
        season: 1,
        rng: Xoshiro256StarStar.fromSeed(17),
      );
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 1,
        fixtures: fixtures,
        results: const {},
        stats: const {},
      );

      final first = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );
      final second = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );

      expect(first.persons.length, second.persons.length);
      expect(first.persons, second.persons);

      final playerCount = world.allClubs
          .map((c) => c.squad.players.length)
          .fold<int>(0, (a, b) => a + b);
      final staffCount = world.allClubs.length * minimumStaffRoles.length;
      expect(first.persons.length, playerCount + staffCount);
    });

    test('enlaza Player.personId sin cambiar atributos deportivos', () {
      final world = WorldGenerator().generate(seed: 3);
      final beforePlayer = world.allClubs.first.squad.players.first;
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 1,
        fixtures: const [],
        results: const {},
        stats: const {},
      );

      final ensured = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );
      final afterPlayer = ensured.state.world.allClubs
          .expand((c) => c.squad.players)
          .firstWhere((p) => p.id == beforePlayer.id);

      expect(afterPlayer.personId, isNotNull);
      expect(afterPlayer.id, beforePlayer.id);
      expect(afterPlayer.name, beforePlayer.name);
      expect(afterPlayer.attributes, beforePlayer.attributes);
      expect(afterPlayer.potential, beforePlayer.potential);
    });
  });
}
