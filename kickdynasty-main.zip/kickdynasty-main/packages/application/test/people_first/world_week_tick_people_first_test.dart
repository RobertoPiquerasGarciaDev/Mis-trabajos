@Tags(['people-first'])
import 'package:kickdynasty_application/src/campaign/club_management_config.dart';
import 'package:kickdynasty_application/src/people_first/people_first_options.dart';
import 'package:kickdynasty_application/src/world/world_week_tick.dart';
import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:kickdynasty_economy/kickdynasty_economy.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_market/kickdynasty_market.dart';
import 'package:test/test.dart';

void main() {
  test('WorldWeekTick expone People First desactivado por defecto', () {
    final tick = WorldWeekTick(
      economy: EconomyEngine(ClubManagementConfig.economy),
      marketEngine: MarketEngine(
        marketConfig: ClubManagementConfig.market,
        economyConfig: ClubManagementConfig.economy,
        contractConfig: ClubManagementConfig.contracts,
      ),
      simulator: SeasonSimulator(),
    );

    expect(tick.peopleFirstOptions, PeopleFirstOptions.defaults);
    expect(tick.peopleFirstOptions.isEnabled, isFalse);
  });

  test('WorldWeekTick acepta feature flags People First', () {
    final flags = FeatureFlags.empty.withFlag(
      PeopleFirstFeatureFlags.enabled,
      enabled: true,
    );
    final tick = WorldWeekTick(
      economy: EconomyEngine(ClubManagementConfig.economy),
      marketEngine: MarketEngine(
        marketConfig: ClubManagementConfig.market,
        economyConfig: ClubManagementConfig.economy,
        contractConfig: ClubManagementConfig.contracts,
      ),
      simulator: SeasonSimulator(),
      peopleFirstOptions: PeopleFirstOptions(featureFlags: flags),
    );

    expect(tick.peopleFirstOptions.isEnabled, isTrue);
    expect(tick.peopleFirstOptions.isShadowMode, isFalse);
  });
}
