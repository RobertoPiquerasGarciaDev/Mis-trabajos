@Tags(['people-first'])
import 'package:kickdynasty_application/src/people_first/perception_migration.dart';
import 'package:kickdynasty_application/src/people_first/synthetic_person_migration.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  group('ensurePerceptionSnapshots', () {
    test('genera snapshots deterministas para personas', () {
      final world = WorldGenerator().generate(seed: 11);
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 2,
        fixtures: const [],
        results: const {},
        stats: const {},
      );
      final ensured = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );

      final first = ensurePerceptionSnapshots(
        state: ensured.state,
        persons: ensured.persons,
        existingSnapshots: const [],
        worldSeed: ensured.state.world.seed,
      );
      final second = ensurePerceptionSnapshots(
        state: ensured.state,
        persons: ensured.persons,
        existingSnapshots: const [],
        worldSeed: ensured.state.world.seed,
      );

      expect(first, second);
      expect(first.length, ensured.persons.length);
      expect(first.every((s) => s.passesNonOmniscienceCheck), isTrue);
    });

    test('attachPerceptionToAgentMinds sincroniza PerceptionState', () {
      final world = WorldGenerator().generate(seed: 5);
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 1,
        fixtures: const [],
        results: const {},
        stats: const {},
      );
      final ensured = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );
      final snapshots = ensurePerceptionSnapshots(
        state: ensured.state,
        persons: ensured.persons,
        existingSnapshots: const [],
        worldSeed: ensured.state.world.seed,
      );
      const factory = AgentMindFactory();
      final minds = [
        for (final person in ensured.persons)
          factory.createInitial(
            person: person,
            worldSeed: ensured.state.world.seed,
          ),
      ];
      final attached = attachPerceptionToAgentMinds(
        minds: minds,
        snapshots: snapshots,
      );

      expect(attached.first.perception.latest, isNotNull);
      expect(
        perceptionSnapshotsFromAgentMinds(attached).length,
        ensured.persons.length,
      );
    });
  });
}
