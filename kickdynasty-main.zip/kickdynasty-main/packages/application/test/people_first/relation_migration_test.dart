@Tags(['people-first'])
import 'package:kickdynasty_application/src/people_first/memory_migration.dart';
import 'package:kickdynasty_application/src/people_first/perception_migration.dart';
import 'package:kickdynasty_application/src/people_first/relation_migration.dart';
import 'package:kickdynasty_application/src/people_first/synthetic_person_migration.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  group('ensureRelations', () {
    test('genera relaciones deterministas desde percepción y memoria', () {
      final world = WorldGenerator().generate(seed: 23);
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 3,
        fixtures: const [],
        results: const {},
        stats: const {},
      );
      final ensured = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );
      final snapshots = ensurePerceptionSnapshots(
        state: ensured.state,
        persons: ensured.persons,
        existingSnapshots: const [],
        worldSeed: ensured.state.world.seed,
      );
      final memories = ensureMemoryCollections(
        persons: ensured.persons,
        perceptionSnapshots: snapshots,
        existingCollections: const [],
        worldSeed: ensured.state.world.seed,
      );
      final clubIndex = buildPersonClubIndex(ensured.state);

      final first = ensureRelations(
        persons: ensured.persons,
        clubIndex: clubIndex,
        perceptionSnapshots: snapshots,
        memoryCollections: memories,
        existingRelations: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );
      final second = ensureRelations(
        persons: ensured.persons,
        clubIndex: clubIndex,
        perceptionSnapshots: snapshots,
        memoryCollections: memories,
        existingRelations: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );

      expect(first, second);
      expect(first.length, ensured.persons.length);
      expect(
        first.any(
          (state) => state.entries.any((e) => e.type == RelationType.self),
        ),
        isTrue,
      );
    });
  });
}
