@Tags(['people-first'])
import 'package:kickdynasty_application/src/people_first/agent_mind_migration.dart';
import 'package:kickdynasty_application/src/people_first/synthetic_person_migration.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  test('ensureAgentMinds genera mentes deterministas por persona', () {
    final world = WorldGenerator().generate(seed: 11);
    final state = CampaignState(
      world: world,
      season: 1,
      nextRound: 1,
      fixtures: const [],
      results: const {},
      stats: const {},
    );
    final persons = ensureSyntheticPersons(
      state: state,
      existingPersons: const [],
    ).persons;

    final first = ensureAgentMinds(
      persons: persons,
      existingMinds: const [],
      worldSeed: state.world.seed,
    );
    final second = ensureAgentMinds(
      persons: persons,
      existingMinds: const [],
      worldSeed: state.world.seed,
    );

    expect(first.length, persons.length);
    expect(first, second);
    expect(first.map((m) => m.personId).toSet().length, persons.length);
  });
}
