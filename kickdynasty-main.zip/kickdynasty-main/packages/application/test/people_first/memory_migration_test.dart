@Tags(['people-first'])
import 'package:kickdynasty_application/src/people_first/memory_migration.dart';
import 'package:kickdynasty_application/src/people_first/perception_migration.dart';
import 'package:kickdynasty_application/src/people_first/synthetic_person_migration.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  group('ensureMemoryCollections', () {
    test('genera recuerdos deterministas desde percepción', () {
      final world = WorldGenerator().generate(seed: 19);
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 2,
        fixtures: const [],
        results: const {},
        stats: const {},
      );
      final ensured = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );
      final snapshots = ensurePerceptionSnapshots(
        state: ensured.state,
        persons: ensured.persons,
        existingSnapshots: const [],
        worldSeed: ensured.state.world.seed,
      );

      final first = ensureMemoryCollections(
        persons: ensured.persons,
        perceptionSnapshots: snapshots,
        existingCollections: const [],
        worldSeed: ensured.state.world.seed,
      );
      final second = ensureMemoryCollections(
        persons: ensured.persons,
        perceptionSnapshots: snapshots,
        existingCollections: const [],
        worldSeed: ensured.state.world.seed,
      );

      expect(first, second);
      expect(first.length, ensured.persons.length);
      expect(first.where((c) => c.entries.isNotEmpty).length, greaterThan(0));
    });
  });
}
