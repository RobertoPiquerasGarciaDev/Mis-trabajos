@Tags(['people-first'])
import 'package:kickdynasty_application/src/people_first/belief_migration.dart';
import 'package:kickdynasty_application/src/people_first/decision_migration.dart';
import 'package:kickdynasty_application/src/people_first/goal_migration.dart';
import 'package:kickdynasty_application/src/people_first/intention_migration.dart';
import 'package:kickdynasty_application/src/people_first/interpretation_migration.dart';
import 'package:kickdynasty_application/src/people_first/memory_migration.dart';
import 'package:kickdynasty_application/src/people_first/perception_migration.dart';
import 'package:kickdynasty_application/src/people_first/priority_migration.dart';
import 'package:kickdynasty_application/src/people_first/relation_migration.dart';
import 'package:kickdynasty_application/src/people_first/synthetic_person_migration.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

Future<
  ({
    List<Person> persons,
    CampaignState state,
    List<AgentMind> mindsWithIntentions,
    Map<PersonId, ClubId> clubIndex,
  })
>
_pipelineThroughIntentions() async {
  final world = WorldGenerator().generate(seed: 31);
  final state = CampaignState(
    world: world,
    season: 1,
    nextRound: 2,
    fixtures: const [],
    results: const {},
    stats: const {},
  );
  final ensured = ensureSyntheticPersons(
    state: state,
    existingPersons: const [],
  );
  final snapshots = ensurePerceptionSnapshots(
    state: ensured.state,
    persons: ensured.persons,
    existingSnapshots: const [],
    worldSeed: ensured.state.world.seed,
  );
  final memories = ensureMemoryCollections(
    persons: ensured.persons,
    perceptionSnapshots: snapshots,
    existingCollections: const [],
    worldSeed: ensured.state.world.seed,
  );
  final clubIndex = buildPersonClubIndex(ensured.state);
  final relations = ensureRelations(
    persons: ensured.persons,
    clubIndex: clubIndex,
    perceptionSnapshots: snapshots,
    memoryCollections: memories,
    existingRelations: const [],
    worldSeed: ensured.state.world.seed,
    season: ensured.state.season,
    week: ensured.state.nextRound,
  );
  final minds = attachRelationsToAgentMinds(
    minds: attachMemoryToAgentMinds(
      minds: attachPerceptionToAgentMinds(
        minds: [
          for (final person in ensured.persons)
            const AgentMindFactory().createInitial(
              person: person,
              worldSeed: ensured.state.world.seed,
            ),
        ],
        snapshots: snapshots,
      ),
      collections: memories,
    ),
    relations: relations,
  );
  final interpretations = ensureInterpretations(
    persons: ensured.persons,
    minds: minds,
    existingInterpretations: const [],
    worldSeed: ensured.state.world.seed,
    season: ensured.state.season,
    week: ensured.state.nextRound,
  );
  final mindsWithInterpretations = attachInterpretationsToAgentMinds(
    minds: minds,
    interpretations: interpretations,
  );
  final beliefs = ensureBeliefs(
    persons: ensured.persons,
    minds: mindsWithInterpretations,
    existingBeliefs: const [],
    worldSeed: ensured.state.world.seed,
    season: ensured.state.season,
    week: ensured.state.nextRound,
  );
  final mindsWithBeliefs = attachBeliefsToAgentMinds(
    minds: mindsWithInterpretations,
    beliefs: beliefs,
  );
  final goals = ensureGoals(
    persons: ensured.persons,
    minds: mindsWithBeliefs,
    existingGoals: const [],
    worldSeed: ensured.state.world.seed,
    season: ensured.state.season,
    week: ensured.state.nextRound,
  );
  final mindsWithGoals = attachGoalsToAgentMinds(
    minds: mindsWithBeliefs,
    goals: goals,
  );
  final priorities = ensurePriorities(
    persons: ensured.persons,
    minds: mindsWithGoals,
    existingPriorities: const [],
    worldSeed: ensured.state.world.seed,
    season: ensured.state.season,
    week: ensured.state.nextRound,
  );
  final mindsWithPriorities = attachPrioritiesToAgentMinds(
    minds: mindsWithGoals,
    priorities: priorities,
  );
  final intentions = ensureIntentions(
    persons: ensured.persons,
    minds: mindsWithPriorities,
    existingIntentions: const [],
    worldSeed: ensured.state.world.seed,
    season: ensured.state.season,
    week: ensured.state.nextRound,
  );
  final mindsWithIntentions = attachIntentionsToAgentMinds(
    minds: mindsWithPriorities,
    intentions: intentions,
  );
  return (
    persons: ensured.persons,
    state: ensured.state,
    mindsWithIntentions: mindsWithIntentions,
    clubIndex: clubIndex,
  );
}

void main() {
  group('ensureDecisions', () {
    test('genera decisiones deterministas tras deliberación social', () async {
      final pipeline = await _pipelineThroughIntentions();

      final first = ensureDecisions(
        persons: pipeline.persons,
        minds: pipeline.mindsWithIntentions,
        clubIndex: pipeline.clubIndex,
        existingDecisions: const [],
        worldSeed: pipeline.state.world.seed,
        season: pipeline.state.season,
        week: pipeline.state.nextRound,
      );
      final second = ensureDecisions(
        persons: pipeline.persons,
        minds: pipeline.mindsWithIntentions,
        clubIndex: pipeline.clubIndex,
        existingDecisions: const [],
        worldSeed: pipeline.state.world.seed,
        season: pipeline.state.season,
        week: pipeline.state.nextRound,
      );

      expect(first, second);
      expect(first.length, pipeline.persons.length);
      expect(first.any((state) => state.entries.isNotEmpty), isTrue);
      expect(
        first
            .expand((state) => state.entries)
            .every((entry) => entry.passesNonRealityCheck),
        isTrue,
      );
    });

    test('respeta decisiones existentes (lazy migration)', () {
      final existing = DecisionState(
        collection: DecisionCollection(
          ownerId: PersonId('person-existing-decision'),
          entries: [],
        ),
      );
      final result = ensureDecisions(
        persons: const [],
        minds: const [],
        clubIndex: const {},
        existingDecisions: [existing],
        worldSeed: 1,
        season: 1,
        week: 1,
      );
      expect(result, [existing]);
    });
  });

  group('ensureDecisionRecords', () {
    test('genera registros deterministas para protocolos sociales', () async {
      final pipeline = await _pipelineThroughIntentions();

      final first = ensureDecisionRecords(
        persons: pipeline.persons,
        minds: pipeline.mindsWithIntentions,
        clubIndex: pipeline.clubIndex,
        existingRecords: const [],
        worldSeed: pipeline.state.world.seed,
        season: pipeline.state.season,
        week: pipeline.state.nextRound,
      );
      final second = ensureDecisionRecords(
        persons: pipeline.persons,
        minds: pipeline.mindsWithIntentions,
        clubIndex: pipeline.clubIndex,
        existingRecords: const [],
        worldSeed: pipeline.state.world.seed,
        season: pipeline.state.season,
        week: pipeline.state.nextRound,
      );

      expect(first, second);
    });

    test('respeta registros existentes (lazy migration)', () {
      final existing = DecisionRecord(
        id: 'dr-existing',
        protocolType: DeliberationProtocolType.renewalDeliberation,
        clubId: ClubId('club-existing'),
        season: 1,
        week: 1,
        instanceId: 'instance-existing',
        outcome: MandateOutcome.proceed,
        participants: const [],
      );
      final result = ensureDecisionRecords(
        persons: const [],
        minds: const [],
        clubIndex: const {},
        existingRecords: [existing],
        worldSeed: 1,
        season: 1,
        week: 1,
      );
      expect(result, [existing]);
    });
  });
}
