@Tags(['people-first'])
import 'package:kickdynasty_application/src/people_first/belief_migration.dart';
import 'package:kickdynasty_application/src/people_first/interpretation_migration.dart';
import 'package:kickdynasty_application/src/people_first/memory_migration.dart';
import 'package:kickdynasty_application/src/people_first/perception_migration.dart';
import 'package:kickdynasty_application/src/people_first/relation_migration.dart';
import 'package:kickdynasty_application/src/people_first/synthetic_person_migration.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  group('ensureBeliefs', () {
    test('genera creencias deterministas desde interpretaciones', () {
      final world = WorldGenerator().generate(seed: 17);
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 2,
        fixtures: const [],
        results: const {},
        stats: const {},
      );
      final ensured = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );
      final snapshots = ensurePerceptionSnapshots(
        state: ensured.state,
        persons: ensured.persons,
        existingSnapshots: const [],
        worldSeed: ensured.state.world.seed,
      );
      final memories = ensureMemoryCollections(
        persons: ensured.persons,
        perceptionSnapshots: snapshots,
        existingCollections: const [],
        worldSeed: ensured.state.world.seed,
      );
      final clubIndex = buildPersonClubIndex(ensured.state);
      final relations = ensureRelations(
        persons: ensured.persons,
        clubIndex: clubIndex,
        perceptionSnapshots: snapshots,
        memoryCollections: memories,
        existingRelations: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );
      final minds = attachRelationsToAgentMinds(
        minds: attachMemoryToAgentMinds(
          minds: attachPerceptionToAgentMinds(
            minds: [
              for (final person in ensured.persons)
                const AgentMindFactory().createInitial(
                  person: person,
                  worldSeed: ensured.state.world.seed,
                ),
            ],
            snapshots: snapshots,
          ),
          collections: memories,
        ),
        relations: relations,
      );
      final interpretations = ensureInterpretations(
        persons: ensured.persons,
        minds: minds,
        existingInterpretations: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );
      final mindsWithInterpretations = attachInterpretationsToAgentMinds(
        minds: minds,
        interpretations: interpretations,
      );

      final first = ensureBeliefs(
        persons: ensured.persons,
        minds: mindsWithInterpretations,
        existingBeliefs: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );
      final second = ensureBeliefs(
        persons: ensured.persons,
        minds: mindsWithInterpretations,
        existingBeliefs: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );

      expect(first, second);
      expect(first.length, ensured.persons.length);
      expect(first.any((state) => state.entries.isNotEmpty), isTrue);
    });

    test('respeta creencias existentes (lazy migration)', () {
      final existing = BeliefState(
        collection: BeliefCollection(
          ownerId: PersonId('person-existing-belief'),
          entries: [],
        ),
      );
      final result = ensureBeliefs(
        persons: const [],
        minds: const [],
        existingBeliefs: [existing],
        worldSeed: 1,
        season: 1,
        week: 1,
      );
      expect(result, [existing]);
    });
  });
}
