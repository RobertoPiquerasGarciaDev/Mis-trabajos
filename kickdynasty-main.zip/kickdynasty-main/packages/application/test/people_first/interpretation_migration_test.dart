@Tags(['people-first'])
import 'package:kickdynasty_application/src/people_first/interpretation_migration.dart';
import 'package:kickdynasty_application/src/people_first/memory_migration.dart';
import 'package:kickdynasty_application/src/people_first/perception_migration.dart';
import 'package:kickdynasty_application/src/people_first/relation_migration.dart';
import 'package:kickdynasty_application/src/people_first/synthetic_person_migration.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:test/test.dart';

void main() {
  group('ensureInterpretations', () {
    test('genera interpretaciones deterministas desde mentes preparadas', () {
      final world = WorldGenerator().generate(seed: 31);
      final state = CampaignState(
        world: world,
        season: 1,
        nextRound: 2,
        fixtures: const [],
        results: const {},
        stats: const {},
      );
      final ensured = ensureSyntheticPersons(
        state: state,
        existingPersons: const [],
      );
      final snapshots = ensurePerceptionSnapshots(
        state: ensured.state,
        persons: ensured.persons,
        existingSnapshots: const [],
        worldSeed: ensured.state.world.seed,
      );
      final memories = ensureMemoryCollections(
        persons: ensured.persons,
        perceptionSnapshots: snapshots,
        existingCollections: const [],
        worldSeed: ensured.state.world.seed,
      );
      final clubIndex = buildPersonClubIndex(ensured.state);
      final relations = ensureRelations(
        persons: ensured.persons,
        clubIndex: clubIndex,
        perceptionSnapshots: snapshots,
        memoryCollections: memories,
        existingRelations: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );
      final minds = attachRelationsToAgentMinds(
        minds: attachMemoryToAgentMinds(
          minds: attachPerceptionToAgentMinds(
            minds: [
              for (final person in ensured.persons)
                const AgentMindFactory().createInitial(
                  person: person,
                  worldSeed: ensured.state.world.seed,
                ),
            ],
            snapshots: snapshots,
          ),
          collections: memories,
        ),
        relations: relations,
      );

      final first = ensureInterpretations(
        persons: ensured.persons,
        minds: minds,
        existingInterpretations: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );
      final second = ensureInterpretations(
        persons: ensured.persons,
        minds: minds,
        existingInterpretations: const [],
        worldSeed: ensured.state.world.seed,
        season: ensured.state.season,
        week: ensured.state.nextRound,
      );

      expect(first, second);
      expect(first.length, ensured.persons.length);
      expect(first.any((state) => state.entries.isNotEmpty), isTrue);
    });

    test('respeta interpretaciones existentes (lazy migration)', () {
      final existing = InterpretationState(
        collection: InterpretationCollection(
          ownerId: PersonId('person-existing'),
          entries: [],
        ),
      );
      final result = ensureInterpretations(
        persons: const [],
        minds: const [],
        existingInterpretations: [existing],
        worldSeed: 1,
        season: 1,
        week: 1,
      );
      expect(result, [existing]);
    });
  });
}
