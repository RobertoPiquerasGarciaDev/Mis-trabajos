import 'package:kickdynasty_application/kickdynasty_application.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';
import 'package:test/test.dart';

void main() {
  late SaveDatabase database;
  late SaveRepository saves;
  late SeasonSimulator simulator;

  setUp(() {
    database = openSaveDatabaseInMemory();
    saves = SaveRepository(database);
    simulator = SeasonSimulator();
  });

  tearDown(() => database.close());

  test('StartNewCampaign crea guardado con club del jugador', () async {
    final useCase = StartNewCampaign(saves, simulator);
    final state = simulator.bootstrapCampaign(seed: 1);
    final clubId = state.world.leagues.first.clubs.first.club.id;

    final session = await useCase(name: 'Test', seed: 1, playerClubId: clubId);

    expect(session.saveName, 'Test');
    expect(session.state.playerClubId, clubId);
    expect(session.state.fixtures, isNotEmpty);

    final loaded = await saves.loadCampaign(session.saveId);
    expect(loaded.playerClubId, clubId);
  });

  test('AdvanceRound persiste resultados y snapshot', () async {
    final start = StartNewCampaign(saves, simulator);
    final advance = AdvanceRound(saves, simulator);
    final state0 = simulator.bootstrapCampaign(seed: 2);
    final clubId = state0.world.leagues.first.clubs.first.club.id;
    var session = await start(name: 'Avance', seed: 2, playerClubId: clubId);

    session = await advance(session);

    expect(session.lastRound, isNotNull);
    expect(session.state.results, isNotEmpty);
    expect(session.state.nextRound, 2);

    final snapshots = await saves.listSnapshots(session.saveId);
    expect(snapshots, hasLength(1));

    final reloaded = await LoadCampaign(saves)(
      SaveSummary(
        id: session.saveId,
        name: session.saveName,
        season: session.state.season,
        nextRound: session.state.nextRound,
        playerClubId: clubId,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      ),
    );
    expect(reloaded.state.results.length, session.state.results.length);
  });
}
