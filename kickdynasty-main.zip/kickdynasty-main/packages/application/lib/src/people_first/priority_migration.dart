/// Migración lazy de PriorityState para saves v15 (PF-9).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura prioridades iniciales desde objetivos consolidados.
List<PriorityState> ensurePriorities({
  required List<Person> persons,
  required List<AgentMind> minds,
  required List<PriorityState> existingPriorities,
  required int worldSeed,
  required int season,
  required int week,
  PriorityBuilder builder = const PriorityBuilder(),
  PriorityRanker ranker = const PriorityRanker(),
}) {
  if (existingPriorities.isNotEmpty) {
    return existingPriorities;
  }

  final mindByPerson = {for (final mind in minds) mind.personId: mind};

  return [
    for (final person in persons)
      if (mindByPerson[person.id] case final mind?)
        PriorityState(
          collection: ranker.rank(
            person: person,
            candidates: builder.buildCandidates(
              person: person,
              goals: mind.goals.collection,
              personality: mind.personality,
              emotion: mind.emotion,
              memory: mind.memory.collection,
              relations: mind.relations,
              season: season,
              week: week,
            ),
            worldSeed: worldSeed,
            season: season,
            week: week,
          ),
        )
      else
        const PriorityState.empty(),
  ];
}

/// Sincroniza prioridades en las mentes correspondientes.
List<AgentMind> attachPrioritiesToAgentMinds({
  required List<AgentMind> minds,
  required List<PriorityState> priorities,
}) {
  final byObserver = {
    for (final state in priorities)
      if (state.collection.ownerId case final observerId?) observerId: state,
  };
  return [
    for (final mind in minds)
      byObserver.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: mind.memory,
              beliefs: mind.beliefs,
              goals: mind.goals,
              priorities: byObserver[mind.personId]!,
              intentions: mind.intentions,
              decisions: mind.decisions,
              perception: mind.perception,
              relations: mind.relations,
              interpretation: mind.interpretation,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae prioridades desde mentes (para persistencia v15).
List<PriorityState> priorityStatesFromAgentMinds(List<AgentMind> minds) {
  return [
    for (final mind in minds)
      if (mind.priorities.collection.ownerId != null) mind.priorities,
  ];
}
