/// Migración lazy de personas sintéticas para saves v6 (PF-1).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura personas persistibles para una campaña sin alterar simulación.
///
/// Si [existingPersons] está vacío, genera personas deterministas para
/// jugadores y staff mínimo por club. Enlaza [Player.personId] sin cambiar
/// atributos deportivos ni IDs existentes.
({CampaignState state, List<Person> persons}) ensureSyntheticPersons({
  required CampaignState state,
  required List<Person> existingPersons,
  PersonGenerator generator = const PersonGenerator(),
}) {
  if (existingPersons.isNotEmpty) {
    return (
      state: _linkPlayerPersonIds(state, existingPersons),
      persons: existingPersons,
    );
  }

  final worldSeed = state.world.seed;
  final persons = <Person>[];
  final playerLinks = <PlayerId, PersonId>{};

  for (final league in state.world.leagues) {
    for (final generatedClub in league.clubs) {
      final club = generatedClub.club;
      final city = _cityForClub(club.id, worldSeed);

      for (final role in minimumStaffRoles) {
        final personId = syntheticStaffPersonId(
          worldSeed: worldSeed,
          clubId: club.id,
          role: role,
        );
        final origin = generator.buildOrigin(
          worldSeed: worldSeed,
          country: club.country,
          city: city,
          cohort: 'staff-v6',
          generation: 1,
          appearanceYear: 2020 + state.season,
          economicContext: 'middle',
        );
        persons.add(
          generator.generate(
            id: personId,
            worldSeed: worldSeed,
            origin: origin,
            role: role,
            ageYears: _staffAge(personId, worldSeed, role),
          ),
        );
      }

      for (final player in generatedClub.squad.players) {
        final personId = syntheticPlayerPersonId(
          worldSeed: worldSeed,
          playerId: player.id,
        );
        playerLinks[player.id] = personId;
        final origin = generator.buildOrigin(
          worldSeed: worldSeed,
          country: player.nationality,
          city: city,
          cohort: 'player-v6',
          generation: 1,
          appearanceYear: 2020 + state.season,
          academy: generatedClub.club.name.value,
          sportingFamily: personDerive(
            personId: personId,
            worldSeed: worldSeed,
            domain: 'origin.sportingFamily',
          ).isEven,
        );
        persons.add(
          generator.generate(
            id: personId,
            worldSeed: worldSeed,
            origin: origin,
            role: PersonRole.player,
            ageYears: player.age.years,
          ),
        );
      }
    }
  }

  return (
    state: _linkPlayerPersonIds(state, persons, links: playerLinks),
    persons: persons,
  );
}

CampaignState _linkPlayerPersonIds(
  CampaignState state,
  List<Person> persons, {
  Map<PlayerId, PersonId>? links,
}) {
  final worldSeed = state.world.seed;
  final resolvedLinks =
      links ??
      {
        for (final club in state.world.allClubs)
          for (final player in club.squad.players)
            player.id:
                player.personId ??
                syntheticPlayerPersonId(
                  worldSeed: worldSeed,
                  playerId: player.id,
                ),
      };

  final leagues = [
    for (final league in state.world.leagues)
      GeneratedLeague(
        league: league.league,
        level: league.level,
        clubs: [
          for (final generatedClub in league.clubs)
            GeneratedClub(
              club: generatedClub.club,
              squad: Squad(
                clubId: generatedClub.squad.clubId,
                players: [
                  for (final player in generatedClub.squad.players)
                    player.copyWith(
                      personId: resolvedLinks[player.id] ?? player.personId,
                    ),
                ],
              ),
              contracts: generatedClub.contracts,
            ),
        ],
      ),
  ];

  return CampaignState(
    world: GeneratedWorld(seed: state.world.seed, leagues: leagues),
    season: state.season,
    nextRound: state.nextRound,
    fixtures: state.fixtures,
    results: state.results,
    stats: state.stats,
    playerClubId: state.playerClubId,
    playerLineup: state.playerLineup,
    clubLineups: state.clubLineups,
  );
}

String _cityForClub(ClubId clubId, int worldSeed) {
  final index =
      personDerive(
        personId: PersonId('_city_'),
        worldSeed: worldSeed,
        domain: 'club.city',
        index: clubId.value.hashCode,
      ).abs() %
      1000;
  return 'City-$index';
}

int _staffAge(PersonId personId, int worldSeed, PersonRole role) {
  final base = personDerive(
    personId: personId,
    worldSeed: worldSeed,
    domain: 'staff.age.${role.name}',
  ).abs();
  return 38 + (base % 25);
}
