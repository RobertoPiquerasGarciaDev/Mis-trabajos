/// Migración lazy de DecisionState y DecisionRecord para saves v16 (PF-10).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura decisiones cognitivas tras deliberación social.
List<DecisionState> ensureDecisions({
  required List<Person> persons,
  required List<AgentMind> minds,
  required Map<PersonId, ClubId> clubIndex,
  required List<DecisionState> existingDecisions,
  required int worldSeed,
  required int season,
  required int week,
  SocialDeliberationEngine deliberationEngine =
      const SocialDeliberationEngine(),
  DecisionBuilder builder = const DecisionBuilder(),
}) {
  if (existingDecisions.isNotEmpty) {
    return existingDecisions;
  }

  final mindByPerson = {for (final mind in minds) mind.personId: mind};
  final participants = buildSocialParticipantIndex(
    persons: persons,
    minds: minds,
  );

  return [
    for (final person in persons)
      if (mindByPerson[person.id] case final mind?)
        _decisionStateForPerson(
          person: person,
          mind: mind,
          persons: persons,
          clubIndex: clubIndex,
          participants: participants,
          deliberationEngine: deliberationEngine,
          builder: builder,
          worldSeed: worldSeed,
          season: season,
          week: week,
        )
      else
        const DecisionState.empty(),
  ];
}

/// Asegura registros sociales append-only generados por protocolos.
List<DecisionRecord> ensureDecisionRecords({
  required List<Person> persons,
  required List<AgentMind> minds,
  required Map<PersonId, ClubId> clubIndex,
  required List<DecisionRecord> existingRecords,
  required int worldSeed,
  required int season,
  required int week,
  SocialDeliberationEngine deliberationEngine =
      const SocialDeliberationEngine(),
}) {
  if (existingRecords.isNotEmpty) {
    return existingRecords;
  }

  final mindByPerson = {for (final mind in minds) mind.personId: mind};
  final participants = buildSocialParticipantIndex(
    persons: persons,
    minds: minds,
  );
  final records = <DecisionRecord>[];
  final seen = <String>{};

  for (final person in persons) {
    final mind = mindByPerson[person.id];
    if (mind == null) continue;
    final result = _socialDeliberationForPerson(
      person: person,
      mind: mind,
      persons: persons,
      clubIndex: clubIndex,
      participants: participants,
      deliberationEngine: deliberationEngine,
      worldSeed: worldSeed,
      season: season,
      week: week,
    );
    final record = result.decisionRecord;
    if (record != null && seen.add(record.id)) {
      records.add(record);
    }
  }

  records.sort((a, b) => a.id.compareTo(b.id));
  return records;
}

/// Sincroniza decisiones en las mentes correspondientes.
List<AgentMind> attachDecisionsToAgentMinds({
  required List<AgentMind> minds,
  required List<DecisionState> decisions,
}) {
  final byObserver = {
    for (final state in decisions)
      if (state.collection.ownerId case final observerId?) observerId: state,
  };
  return [
    for (final mind in minds)
      byObserver.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: mind.memory,
              beliefs: mind.beliefs,
              goals: mind.goals,
              priorities: mind.priorities,
              intentions: mind.intentions,
              decisions: byObserver[mind.personId]!,
              perception: mind.perception,
              relations: mind.relations,
              interpretation: mind.interpretation,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae decisiones desde mentes (para persistencia v16).
List<DecisionState> decisionStatesFromAgentMinds(List<AgentMind> minds) {
  return [
    for (final mind in minds)
      if (mind.decisions.collection.ownerId != null) mind.decisions,
  ];
}

/// Perfiles de participantes indexados por persona.
SocialParticipantIndex buildSocialParticipantIndex({
  required List<Person> persons,
  required List<AgentMind> minds,
}) {
  final mindByPerson = {for (final mind in minds) mind.personId: mind};
  return {
    for (final person in persons)
      if (mindByPerson[person.id] case final mind?)
        person.id: SocialParticipantProfile(
          person: person,
          personality: mind.personality,
          emotion: mind.emotion,
        ),
  };
}

DecisionState _decisionStateForPerson({
  required Person person,
  required AgentMind mind,
  required List<Person> persons,
  required Map<PersonId, ClubId> clubIndex,
  required SocialParticipantIndex participants,
  required SocialDeliberationEngine deliberationEngine,
  required DecisionBuilder builder,
  required int worldSeed,
  required int season,
  required int week,
}) {
  final intention = _dominantIntention(mind.intentions.collection);
  if (intention == null) {
    return const DecisionState.empty();
  }

  final result = _socialDeliberationForPerson(
    person: person,
    mind: mind,
    persons: persons,
    clubIndex: clubIndex,
    participants: participants,
    deliberationEngine: deliberationEngine,
    worldSeed: worldSeed,
    season: season,
    week: week,
  );

  return DecisionState(
    collection: builder.build(
      person: person,
      intention: intention,
      priorities: mind.priorities.collection,
      result: result,
      worldSeed: worldSeed,
      season: season,
      week: week,
    ),
  );
}

SocialDeliberationResult _socialDeliberationForPerson({
  required Person person,
  required AgentMind mind,
  required List<Person> persons,
  required Map<PersonId, ClubId> clubIndex,
  required SocialParticipantIndex participants,
  required SocialDeliberationEngine deliberationEngine,
  required int worldSeed,
  required int season,
  required int week,
}) {
  return deliberationEngine.deliberate(
    context: SocialDeliberationContext(
      proponent: person,
      intentions: mind.intentions.collection,
      priorities: mind.priorities.collection,
      beliefs: mind.beliefs.collection,
      memory: mind.memory.collection,
      relations: mind.relations,
      personality: mind.personality,
      emotion: mind.emotion,
      clubId: clubIndex[person.id],
      clubPersons: _clubPersonsFor(
        proponentId: person.id,
        persons: persons,
        clubIndex: clubIndex,
      ),
      worldSeed: worldSeed,
      season: season,
      week: week,
    ),
    participants: participants,
  );
}

List<Person> _clubPersonsFor({
  required PersonId proponentId,
  required List<Person> persons,
  required Map<PersonId, ClubId> clubIndex,
}) {
  final clubId = clubIndex[proponentId];
  if (clubId == null) return const [];
  return [
    for (final person in persons)
      if (clubIndex[person.id] == clubId) person,
  ];
}

IntentionEntry? _dominantIntention(IntentionCollection intentions) {
  final active =
      intentions.entries
          .where((e) => e.status != IntentionStatus.deferred)
          .toList()
        ..sort((a, b) {
          final byStrength = b.strength.value.compareTo(a.strength.value);
          if (byStrength != 0) return byStrength;
          return a.id.value.compareTo(b.id.value);
        });
  return active.isEmpty ? null : active.first;
}
