/// Migración lazy de MemoryCollection para saves v9 (PF-4).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura recuerdos iniciales desde percepción sin alterar gameplay.
List<MemoryCollection> ensureMemoryCollections({
  required List<Person> persons,
  required List<PerceptionSnapshot> perceptionSnapshots,
  required List<MemoryCollection> existingCollections,
  required int worldSeed,
  MemoryBuilder builder = const MemoryBuilder(),
}) {
  if (existingCollections.isNotEmpty) {
    return existingCollections;
  }

  final snapshotByPerson = {
    for (final snapshot in perceptionSnapshots) snapshot.observerId: snapshot,
  };

  return [
    for (final person in persons)
      if (snapshotByPerson[person.id] case final snapshot?)
        builder.buildFromPerception(
          ownerId: person.id,
          snapshot: snapshot,
          worldSeed: worldSeed,
        )
      else
        MemoryCollection.empty(ownerId: person.id),
  ];
}

/// Sincroniza colecciones en las mentes correspondientes.
List<AgentMind> attachMemoryToAgentMinds({
  required List<AgentMind> minds,
  required List<MemoryCollection> collections,
}) {
  final byOwner = {
    for (final collection in collections)
      if (collection.ownerId case final ownerId?) ownerId: collection,
  };
  return [
    for (final mind in minds)
      byOwner.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: MemoryState(collection: byOwner[mind.personId]!),
              beliefs: mind.beliefs,
              goals: mind.goals,
              priorities: mind.priorities,
              intentions: mind.intentions,
              decisions: mind.decisions,
              perception: mind.perception,
              relations: mind.relations,
              interpretation: mind.interpretation,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae colecciones desde mentes (para persistencia v10).
List<MemoryCollection> memoryCollectionsFromAgentMinds(List<AgentMind> minds) {
  return [
    for (final mind in minds)
      if (mind.memory.collection.ownerId != null) mind.memory.collection,
  ];
}
