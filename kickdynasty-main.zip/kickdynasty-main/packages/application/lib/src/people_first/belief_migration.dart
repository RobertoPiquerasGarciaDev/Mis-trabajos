/// Migración lazy de BeliefState para saves v13 (PF-7).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura creencias iniciales desde interpretaciones consolidadas.
List<BeliefState> ensureBeliefs({
  required List<Person> persons,
  required List<AgentMind> minds,
  required List<BeliefState> existingBeliefs,
  required int worldSeed,
  required int season,
  required int week,
  BeliefBuilder builder = const BeliefBuilder(),
}) {
  if (existingBeliefs.isNotEmpty) {
    return existingBeliefs;
  }

  final mindByPerson = {for (final mind in minds) mind.personId: mind};

  return [
    for (final person in persons)
      if (mindByPerson[person.id] case final mind?)
        BeliefState(
          collection: builder.build(
            observer: person,
            interpretations: mind.interpretation.collection,
            memory: mind.memory.collection,
            relations: mind.relations,
            worldSeed: worldSeed,
            season: season,
            week: week,
          ),
        )
      else
        const BeliefState.empty(),
  ];
}

/// Sincroniza creencias en las mentes correspondientes.
List<AgentMind> attachBeliefsToAgentMinds({
  required List<AgentMind> minds,
  required List<BeliefState> beliefs,
}) {
  final byObserver = {
    for (final state in beliefs)
      if (state.collection.ownerId case final observerId?) observerId: state,
  };
  return [
    for (final mind in minds)
      byObserver.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: mind.memory,
              beliefs: byObserver[mind.personId]!,
              goals: mind.goals,
              priorities: mind.priorities,
              intentions: mind.intentions,
              decisions: mind.decisions,
              perception: mind.perception,
              relations: mind.relations,
              interpretation: mind.interpretation,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae creencias desde mentes (para persistencia v13).
List<BeliefState> beliefStatesFromAgentMinds(List<AgentMind> minds) {
  return [
    for (final mind in minds)
      if (mind.beliefs.collection.ownerId != null) mind.beliefs,
  ];
}
