/// Migración lazy de AgentMind para saves v7 (PF-2).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura un [AgentMind] inicial por persona sin alterar gameplay.
List<AgentMind> ensureAgentMinds({
  required List<Person> persons,
  required List<AgentMind> existingMinds,
  required int worldSeed,
  AgentMindFactory factory = const AgentMindFactory(),
}) {
  if (existingMinds.isNotEmpty) {
    return existingMinds;
  }
  return [
    for (final person in persons)
      factory.createInitial(person: person, worldSeed: worldSeed),
  ];
}
