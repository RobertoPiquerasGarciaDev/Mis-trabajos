/// Migración lazy de GoalState para saves v14 (PF-8).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura objetivos iniciales desde creencias consolidadas.
List<GoalState> ensureGoals({
  required List<Person> persons,
  required List<AgentMind> minds,
  required List<GoalState> existingGoals,
  required int worldSeed,
  required int season,
  required int week,
  GoalBuilder builder = const GoalBuilder(),
}) {
  if (existingGoals.isNotEmpty) {
    return existingGoals;
  }

  final mindByPerson = {for (final mind in minds) mind.personId: mind};

  return [
    for (final person in persons)
      if (mindByPerson[person.id] case final mind?)
        GoalState(
          collection: builder.build(
            person: person,
            beliefs: mind.beliefs.collection,
            personality: mind.personality,
            worldSeed: worldSeed,
            season: season,
            week: week,
          ),
        )
      else
        const GoalState.empty(),
  ];
}

/// Sincroniza objetivos en las mentes correspondientes.
List<AgentMind> attachGoalsToAgentMinds({
  required List<AgentMind> minds,
  required List<GoalState> goals,
}) {
  final byObserver = {
    for (final state in goals)
      if (state.collection.ownerId case final observerId?) observerId: state,
  };
  return [
    for (final mind in minds)
      byObserver.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: mind.memory,
              beliefs: mind.beliefs,
              goals: byObserver[mind.personId]!,
              priorities: mind.priorities,
              intentions: mind.intentions,
              decisions: mind.decisions,
              perception: mind.perception,
              relations: mind.relations,
              interpretation: mind.interpretation,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae objetivos desde mentes (para persistencia v14).
List<GoalState> goalStatesFromAgentMinds(List<AgentMind> minds) {
  return [
    for (final mind in minds)
      if (mind.goals.collection.ownerId != null) mind.goals,
  ];
}
