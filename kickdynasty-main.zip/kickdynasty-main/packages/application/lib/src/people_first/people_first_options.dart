/// Opciones de infraestructura People First para casos de uso (PF-0).
library;

import 'package:kickdynasty_core/kickdynasty_core.dart';

/// Configuración mínima People First — consultable sin activar gameplay.
final class PeopleFirstOptions {
  /// Crea opciones a partir de [featureFlags] (vacío = todo desactivado).
  const PeopleFirstOptions({FeatureFlags featureFlags = FeatureFlags.empty})
    : _featureFlags = featureFlags;

  final FeatureFlags _featureFlags;

  /// Interruptor maestro People First.
  bool get isEnabled =>
      _featureFlags.isEnabled(PeopleFirstFeatureFlags.enabled);

  /// Modo sombra: registrar DecisionRecord sin sustituir IA legacy.
  bool get isShadowMode =>
      _featureFlags.isEnabled(PeopleFirstFeatureFlags.shadowMode);

  /// Deliberación activa (requiere [isEnabled] en fases posteriores).
  bool get isDeliberationEnabled =>
      _featureFlags.isEnabled(PeopleFirstFeatureFlags.deliberation);

  /// Opciones por defecto — comportamiento legacy idéntico.
  static const defaults = PeopleFirstOptions();
}
