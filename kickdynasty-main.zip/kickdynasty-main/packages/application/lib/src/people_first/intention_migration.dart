/// Migración lazy de IntentionState para saves v15 (PF-9).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura intenciones iniciales tras deliberación interna.
List<IntentionState> ensureIntentions({
  required List<Person> persons,
  required List<AgentMind> minds,
  required List<IntentionState> existingIntentions,
  required int worldSeed,
  required int season,
  required int week,
  InternalDeliberationEngine deliberationEngine =
      const InternalDeliberationEngine(),
  IntentionBuilder builder = const IntentionBuilder(),
}) {
  if (existingIntentions.isNotEmpty) {
    return existingIntentions;
  }

  final mindByPerson = {for (final mind in minds) mind.personId: mind};

  return [
    for (final person in persons)
      if (mindByPerson[person.id] case final mind?)
        IntentionState(
          collection: builder.build(
            person: person,
            result: deliberationEngine.deliberate(
              DeliberationContext(
                person: person,
                beliefs: mind.beliefs.collection,
                goals: mind.goals.collection,
                priorities: mind.priorities.collection,
                memory: mind.memory.collection,
                relations: mind.relations,
                personality: mind.personality,
                emotion: mind.emotion,
                worldSeed: worldSeed,
                season: season,
                week: week,
              ),
            ),
            worldSeed: worldSeed,
            season: season,
            week: week,
          ),
        )
      else
        const IntentionState.empty(),
  ];
}

/// Sincroniza intenciones en las mentes correspondientes.
List<AgentMind> attachIntentionsToAgentMinds({
  required List<AgentMind> minds,
  required List<IntentionState> intentions,
}) {
  final byObserver = {
    for (final state in intentions)
      if (state.collection.ownerId case final observerId?) observerId: state,
  };
  return [
    for (final mind in minds)
      byObserver.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: mind.memory,
              beliefs: mind.beliefs,
              goals: mind.goals,
              priorities: mind.priorities,
              intentions: byObserver[mind.personId]!,
              decisions: mind.decisions,
              perception: mind.perception,
              relations: mind.relations,
              interpretation: mind.interpretation,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae intenciones desde mentes (para persistencia v15).
List<IntentionState> intentionStatesFromAgentMinds(List<AgentMind> minds) {
  return [
    for (final mind in minds)
      if (mind.intentions.collection.ownerId != null) mind.intentions,
  ];
}
