/// Migración lazy de InterpretationState para saves v12 (PF-6).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura interpretaciones iniciales desde percepción, memoria y relaciones.
List<InterpretationState> ensureInterpretations({
  required List<Person> persons,
  required List<AgentMind> minds,
  required List<InterpretationState> existingInterpretations,
  required int worldSeed,
  required int season,
  required int week,
  InterpretationBuilder builder = const InterpretationBuilder(),
}) {
  if (existingInterpretations.isNotEmpty) {
    return existingInterpretations;
  }

  final mindByPerson = {for (final mind in minds) mind.personId: mind};

  return [
    for (final person in persons)
      if (mindByPerson[person.id] case final mind?)
        InterpretationState(
          collection: builder.build(
            observer: person,
            personality: mind.personality,
            perception: mind.perception.latest,
            memory: mind.memory.collection,
            relations: mind.relations,
            worldSeed: worldSeed,
            season: season,
            week: week,
          ),
        )
      else
        const InterpretationState.empty(),
  ];
}

/// Sincroniza interpretaciones en las mentes correspondientes.
List<AgentMind> attachInterpretationsToAgentMinds({
  required List<AgentMind> minds,
  required List<InterpretationState> interpretations,
}) {
  final byObserver = {
    for (final state in interpretations)
      if (state.collection.ownerId case final observerId?) observerId: state,
  };
  return [
    for (final mind in minds)
      byObserver.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: mind.memory,
              beliefs: mind.beliefs,
              goals: mind.goals,
              priorities: mind.priorities,
              intentions: mind.intentions,
              decisions: mind.decisions,
              perception: mind.perception,
              relations: mind.relations,
              interpretation: byObserver[mind.personId]!,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae interpretaciones desde mentes (para persistencia v12).
List<InterpretationState> interpretationStatesFromAgentMinds(
  List<AgentMind> minds,
) {
  return [
    for (final mind in minds)
      if (mind.interpretation.collection.ownerId != null) mind.interpretation,
  ];
}
