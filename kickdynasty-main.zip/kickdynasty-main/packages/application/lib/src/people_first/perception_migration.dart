/// Migración lazy de PerceptionSnapshot para saves v8 (PF-3).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Asegura fotografías perceptivas iniciales sin alterar gameplay.
List<PerceptionSnapshot> ensurePerceptionSnapshots({
  required CampaignState state,
  required List<Person> persons,
  required List<PerceptionSnapshot> existingSnapshots,
  required int worldSeed,
  PerceptionBuilder builder = const PerceptionBuilder(),
}) {
  if (existingSnapshots.isNotEmpty) {
    return existingSnapshots;
  }

  final clubIndex = buildPersonClubIndex(state);
  final playerIndex = buildPersonPlayerIndex(state);
  final world = ObservableWorld.fromCampaignState(state);
  final week = state.nextRound;

  return [
    for (final person in persons)
      builder.build(
        observer: person,
        observerClubId: clubIndex[person.id],
        linkedPlayerId: playerIndex[person.id],
        world: world,
        season: state.season,
        week: week,
        worldSeed: worldSeed,
      ),
  ];
}

/// Sincroniza snapshots en las mentes correspondientes.
List<AgentMind> attachPerceptionToAgentMinds({
  required List<AgentMind> minds,
  required List<PerceptionSnapshot> snapshots,
}) {
  final byObserver = {
    for (final snapshot in snapshots) snapshot.observerId: snapshot,
  };
  return [
    for (final mind in minds)
      byObserver.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: mind.memory,
              beliefs: mind.beliefs,
              goals: mind.goals,
              priorities: mind.priorities,
              intentions: mind.intentions,
              decisions: mind.decisions,
              perception: PerceptionState(
                snapshots: [byObserver[mind.personId]!],
              ),
              relations: mind.relations,
              interpretation: mind.interpretation,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae snapshots desde mentes (para persistencia v9).
List<PerceptionSnapshot> perceptionSnapshotsFromAgentMinds(
  List<AgentMind> minds,
) {
  return [
    for (final mind in minds)
      if (mind.perception.latest case final snapshot?) snapshot,
  ];
}
