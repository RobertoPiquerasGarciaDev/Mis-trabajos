/// Migración lazy de RelationState para saves v10 (PF-5).
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';

/// Agrupa personas por club usando el índice PF-3.
Map<ClubId, List<Person>> groupPersonsByClub({
  required List<Person> persons,
  required Map<PersonId, ClubId> clubIndex,
}) {
  final grouped = <ClubId, List<Person>>{};
  for (final person in persons) {
    final clubId = clubIndex[person.id];
    if (clubId == null) continue;
    grouped.putIfAbsent(clubId, () => []).add(person);
  }
  for (final peers in grouped.values) {
    peers.sort((a, b) => a.id.value.compareTo(b.id.value));
  }
  return grouped;
}

/// Asegura relaciones iniciales desde percepción y memoria.
List<RelationState> ensureRelations({
  required List<Person> persons,
  required Map<PersonId, ClubId> clubIndex,
  required List<PerceptionSnapshot> perceptionSnapshots,
  required List<MemoryCollection> memoryCollections,
  required List<RelationState> existingRelations,
  required int worldSeed,
  required int season,
  required int week,
  RelationBuilder builder = const RelationBuilder(),
}) {
  if (existingRelations.isNotEmpty) {
    return existingRelations;
  }

  final peersByClub = groupPersonsByClub(
    persons: persons,
    clubIndex: clubIndex,
  );
  final snapshotByPerson = {
    for (final snapshot in perceptionSnapshots) snapshot.observerId: snapshot,
  };
  final memoryByPerson = {
    for (final collection in memoryCollections)
      if (collection.ownerId case final ownerId?) ownerId: collection,
  };

  return [
    for (final person in persons)
      builder.build(
        observer: person,
        clubPeers: peersByClub[clubIndex[person.id]] ?? const [],
        perception: snapshotByPerson[person.id],
        memory:
            memoryByPerson[person.id] ??
            MemoryCollection.empty(ownerId: person.id),
        worldSeed: worldSeed,
        season: season,
        week: week,
      ),
  ];
}

/// Sincroniza relaciones en las mentes correspondientes.
List<AgentMind> attachRelationsToAgentMinds({
  required List<AgentMind> minds,
  required List<RelationState> relations,
}) {
  final byObserver = {
    for (final state in relations)
      if (state.observerId case final observerId?) observerId: state,
  };
  return [
    for (final mind in minds)
      byObserver.containsKey(mind.personId)
          ? AgentMind(
              personId: mind.personId,
              personality: mind.personality,
              memory: mind.memory,
              beliefs: mind.beliefs,
              goals: mind.goals,
              priorities: mind.priorities,
              intentions: mind.intentions,
              decisions: mind.decisions,
              perception: mind.perception,
              relations: byObserver[mind.personId]!,
              interpretation: mind.interpretation,
              emotion: mind.emotion,
              learning: mind.learning,
            )
          : mind,
  ];
}

/// Extrae relaciones desde mentes (para persistencia v11).
List<RelationState> relationStatesFromAgentMinds(List<AgentMind> minds) {
  return [
    for (final mind in minds)
      if (mind.relations.observerId != null) mind.relations,
  ];
}
