/// Providers Riverpod de la capa de aplicación (ADR 0004).
library;

import 'package:kickdynasty_application/src/campaign/advance_round.dart';
import 'package:kickdynasty_application/src/campaign/campaign_session.dart';
import 'package:kickdynasty_application/src/campaign/list_saves.dart';
import 'package:kickdynasty_application/src/campaign/load_campaign.dart';
import 'package:kickdynasty_application/src/campaign/save_campaign.dart';
import 'package:kickdynasty_application/src/campaign/start_new_campaign.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';
import 'package:riverpod/riverpod.dart';

/// Base de datos de partidas. Debe sobreescribirse en el arranque de la app.
final saveDatabaseProvider = Provider<SaveDatabase>(
  (ref) => throw UnimplementedError(
    'saveDatabaseProvider debe sobreescribirse en main.dart',
  ),
);

/// Repositorio de guardados sobre la base de datos activa.
final saveRepositoryProvider = Provider<SaveRepository>(
  (ref) => SaveRepository(ref.watch(saveDatabaseProvider)),
);

/// Simulador de temporada del motor.
final seasonSimulatorProvider = Provider<SeasonSimulator>(
  (ref) => SeasonSimulator(),
);

final _startNewCampaignProvider = Provider(
  (ref) => StartNewCampaign(
    ref.watch(saveRepositoryProvider),
    ref.watch(seasonSimulatorProvider),
  ),
);

final _loadCampaignProvider = Provider(
  (ref) => LoadCampaign(ref.watch(saveRepositoryProvider)),
);

/// Caso de uso para listar guardados.
final listSavesProvider = Provider(
  (ref) => ListSaves(ref.watch(saveRepositoryProvider)),
);

final _advanceRoundProvider = Provider(
  (ref) => AdvanceRound(
    ref.watch(saveRepositoryProvider),
    ref.watch(seasonSimulatorProvider),
  ),
);

/// Caso de uso para guardar manualmente.
final saveCampaignProvider = Provider(
  (ref) => SaveCampaign(ref.watch(saveRepositoryProvider)),
);

/// Lista de guardados disponibles.
final savedGamesProvider = FutureProvider<List<SaveSummary>>((ref) async {
  return ref.watch(listSavesProvider)();
});

/// Notifier de la partida en curso (`null` = menú principal).
final activeCampaignProvider =
    AsyncNotifierProvider<ActiveCampaignNotifier, CampaignSession?>(
      ActiveCampaignNotifier.new,
    );

/// Notifier de la partida en curso.
class ActiveCampaignNotifier extends AsyncNotifier<CampaignSession?> {
  @override
  Future<CampaignSession?> build() async => null;

  /// Crea una partida nueva y la deja activa.
  Future<void> startNew({
    required String name,
    required int seed,
    required ClubId playerClubId,
  }) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final session = await ref.read(_startNewCampaignProvider)(
        name: name,
        seed: seed,
        playerClubId: playerClubId,
      );
      ref.invalidate(savedGamesProvider);
      return session;
    });
  }

  /// Carga un guardado existente.
  Future<void> load(SaveSummary summary) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      return ref.read(_loadCampaignProvider)(summary);
    });
  }

  /// Juega la próxima jornada.
  Future<void> advanceRound() async {
    final current = state.value;
    if (current == null) return;
    state = const AsyncLoading();
    state = await AsyncValue.guard(() async {
      final updated = await ref.read(_advanceRoundProvider)(current);
      ref.invalidate(savedGamesProvider);
      return updated;
    });
  }

  /// Guarda manualmente el estado actual.
  Future<void> save() async {
    final current = state.value;
    if (current == null) return;
    await ref.read(saveCampaignProvider)(current);
    ref.invalidate(savedGamesProvider);
  }

  /// Cierra la sesión activa (vuelta al menú).
  void clear() {
    state = const AsyncData(null);
  }
}

/// Clasificación de la liga del club del jugador.
final playerLeagueTableProvider = Provider<LeagueTable?>((ref) {
  final session = ref.watch(activeCampaignProvider).value;
  if (session == null) return null;
  final playerClub = playerClubOf(session.state);
  if (playerClub == null) return null;

  final simulator = ref.watch(seasonSimulatorProvider);
  final league = session.state.world.leagues.firstWhere(
    (l) => l.clubs.any((c) => c.club.id == playerClub.club.id),
  );
  return simulator.tableFor(state: session.state, leagueId: league.league.id);
});
