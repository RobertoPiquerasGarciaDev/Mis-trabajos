/// Caso de uso: listar partidas guardadas.
library;

import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';

/// Devuelve los guardados existentes, el más reciente primero.
final class ListSaves {
  /// Crea el caso de uso.
  const ListSaves(this._saves);

  final SaveRepository _saves;

  /// Ejecuta el caso de uso.
  Future<List<SaveSummary>> call() => _saves.listSaves();
}
