/// Caso de uso: guardar manualmente el estado actual.
library;

import 'package:kickdynasty_application/src/campaign/campaign_session.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';

/// Sobrescribe el estado vivo del guardado.
final class SaveCampaign {
  /// Crea el caso de uso.
  const SaveCampaign(this._saves);

  final SaveRepository _saves;

  /// Ejecuta el caso de uso.
  Future<void> call(CampaignSession session) =>
      _saves.saveCampaign(session.saveId, session.state);
}
