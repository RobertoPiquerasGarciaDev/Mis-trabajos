/// Caso de uso: crear una partida nueva y persistirla.
library;

import 'package:kickdynasty_application/src/campaign/campaign_session.dart';
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';

/// Genera el mundo, programa el calendario y crea el guardado inicial.
final class StartNewCampaign {
  /// Crea el caso de uso.
  const StartNewCampaign(this._saves, this._simulator);

  final SaveRepository _saves;
  final SeasonSimulator _simulator;

  /// Ejecuta el caso de uso.
  Future<CampaignSession> call({
    required String name,
    required int seed,
    required ClubId playerClubId,
  }) async {
    final state = _simulator.bootstrapCampaign(
      seed: seed,
      playerClubId: playerClubId,
    );
    final saveId = await _saves.createSave(name: name, state: state);
    return CampaignSession(saveId: saveId, saveName: name, state: state);
  }
}
