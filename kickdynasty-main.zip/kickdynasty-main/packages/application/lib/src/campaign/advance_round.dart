/// Caso de uso: jugar la próxima jornada y persistir el avance.
library;

import 'package:kickdynasty_application/src/campaign/campaign_session.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';

/// Simula la jornada pendiente, guarda el estado y crea un snapshot.
final class AdvanceRound {
  /// Crea el caso de uso.
  const AdvanceRound(this._saves, this._simulator);

  final SaveRepository _saves;
  final SeasonSimulator _simulator;

  /// Ejecuta el caso de uso sobre [session].
  Future<CampaignSession> call(CampaignSession session) async {
    final result = _simulator.playRound(state: session.state);
    await _saves.saveCampaign(session.saveId, result.state);
    await _saves.writeSnapshot(session.saveId, result.state);
    return session.copyWith(state: result.state, lastRound: result.round);
  }
}
