/// Caso de uso: cargar una partida existente.
library;

import 'package:kickdynasty_application/src/campaign/campaign_session.dart';
import 'package:kickdynasty_persistence/kickdynasty_persistence.dart';

/// Carga el estado vivo de un guardado.
final class LoadCampaign {
  /// Crea el caso de uso.
  const LoadCampaign(this._saves);

  final SaveRepository _saves;

  /// Ejecuta el caso de uso a partir del resumen del guardado.
  Future<CampaignSession> call(SaveSummary summary) async {
    final state = await _saves.loadCampaign(summary.id);
    return CampaignSession(
      saveId: summary.id,
      saveName: summary.name,
      state: state,
    );
  }
}
