/// Sesión activa de una partida en curso.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart';
import 'package:meta/meta.dart';

/// Partida cargada o recién creada con su identificador de guardado.
@immutable
final class CampaignSession {
  /// Crea la sesión.
  const CampaignSession({
    required this.saveId,
    required this.saveName,
    required this.state,
    this.lastRound,
  });

  /// Identificador del guardado en SQLite.
  final int saveId;

  /// Nombre visible del guardado.
  final String saveName;

  /// Estado actual de la campaña.
  final CampaignState state;

  /// Última jornada disputada (`null` si aún no se ha jugado ninguna).
  final RoundOutcome? lastRound;

  /// Copia con campos sustituidos.
  CampaignSession copyWith({
    CampaignState? state,
    RoundOutcome? lastRound,
    bool clearLastRound = false,
  }) => CampaignSession(
    saveId: saveId,
    saveName: saveName,
    state: state ?? this.state,
    lastRound: clearLastRound ? null : (lastRound ?? this.lastRound),
  );
}

/// Devuelve el club del jugador humano, o `null` si no hay uno asignado.
GeneratedClub? playerClubOf(CampaignState state) {
  final id = state.playerClubId;
  if (id == null) return null;
  for (final club in state.world.allClubs) {
    if (club.club.id == id) return club;
  }
  return null;
}

/// Resuelve un club por id dentro del mundo de [state].
GeneratedClub? clubById(CampaignState state, ClubId id) {
  for (final club in state.world.allClubs) {
    if (club.club.id == id) return club;
  }
  return null;
}

/// Resuelve el nombre visible de un club por id.
String clubNameOf(CampaignState state, ClubId id) =>
    clubById(state, id)?.club.name.value ?? id.value;
