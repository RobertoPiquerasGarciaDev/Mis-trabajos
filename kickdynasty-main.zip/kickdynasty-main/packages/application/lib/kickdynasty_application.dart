/// Capa de aplicación de KickDynasty: casos de uso y orquestación de estado.
///
/// Cada caso de uso es una clase con un único método público, testeable sin
/// UI. Esta capa conecta el motor (`kickdynasty_engine`) con la persistencia
/// (`kickdynasty_persistence`) y expone providers Riverpod a la presentación.
library;

export 'src/campaign/advance_round.dart';
export 'src/campaign/campaign_session.dart';
export 'src/campaign/list_saves.dart';
export 'src/campaign/load_campaign.dart';
export 'src/campaign/save_campaign.dart';
export 'src/campaign/start_new_campaign.dart';
export 'src/providers.dart';
