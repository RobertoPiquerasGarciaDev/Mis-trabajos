# kickdynasty_application

Casos de uso y orquestación de estado de KickDynasty. Conecta el motor con
la persistencia y expone providers Riverpod a la capa de presentación (ADR
0004).

## Casos de uso

| Clase | Responsabilidad |
|-------|-----------------|
| `StartNewCampaign` | Genera mundo + calendario, crea guardado |
| `LoadCampaign` | Carga estado vivo de un guardado |
| `ListSaves` | Lista partidas guardadas |
| `AdvanceRound` | Juega jornada, guarda y crea snapshot |
| `SaveCampaign` | Guardado manual |

## Providers

- `saveDatabaseProvider` — sobreescribir en `main.dart` con la BD real.
- `activeCampaignProvider` — sesión en curso (`CampaignSession?`).
- `savedGamesProvider` — lista para la pantalla de continuar.
- `playerLeagueTableProvider` — clasificación de la liga del jugador.

## Tests

Sin Flutter: `dart test` con base de datos en memoria y `ProviderContainer`.
