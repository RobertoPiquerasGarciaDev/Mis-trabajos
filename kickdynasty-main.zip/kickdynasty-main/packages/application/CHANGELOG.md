# Changelog

## 0.2.0

Fase 6 — Vertical jugable.

- Casos de uso de campaña: `StartNewCampaign`, `LoadCampaign`, `ListSaves`,
  `AdvanceRound`, `SaveCampaign`.
- `CampaignSession` y helpers (`playerClubOf`, `clubNameOf`).
- Providers Riverpod: `activeCampaignProvider`, `savedGamesProvider`,
  `playerLeagueTableProvider`.
- Tests de casos de uso y providers (91.2 % cobertura).

## 0.1.0

- Esqueleto del paquete (Fase 0).
