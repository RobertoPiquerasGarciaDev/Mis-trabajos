/// Nombres visibles de entidades del juego.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';
import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Nombre visible de una entidad (jugador, club, liga, estadio).
///
/// No vacío, sin espacios de sobra y con longitud máxima [maxLength] para
/// proteger la UI y la persistencia.
extension type const DisplayName._(String value) {
  /// Crea el nombre validando que no esté vacío y no exceda [maxLength].
  factory DisplayName(String value) {
    final trimmed = checkNotBlank(value, 'DisplayName');
    if (trimmed.length > maxLength) {
      throw DomainInvariantViolation(
        'DisplayName no puede exceder $maxLength caracteres '
        '(recibido: ${trimmed.length})',
      );
    }
    return DisplayName._(trimmed);
  }

  /// Longitud máxima admitida.
  static const int maxLength = 60;
}

/// Código corto de club (2–4 letras mayúsculas, p. ej. `FCB`).
extension type const ClubCode._(String value) {
  /// Crea el código validando formato y longitud.
  factory ClubCode(String value) {
    if (!_pattern.hasMatch(value)) {
      throw DomainInvariantViolation(
        'ClubCode debe ser 2-4 letras mayúsculas A-Z (recibido: "$value")',
      );
    }
    return ClubCode._(value);
  }

  static final RegExp _pattern = RegExp(r'^[A-Z]{2,4}$');
}

/// Código de país ISO 3166-1 alfa-2 (dos letras mayúsculas, p. ej. `ES`).
extension type const CountryCode._(String value) {
  /// Crea el código validando el formato de dos letras mayúsculas.
  factory CountryCode(String value) {
    if (!_pattern.hasMatch(value)) {
      throw DomainInvariantViolation(
        'CountryCode debe ser 2 letras mayúsculas A-Z (recibido: "$value")',
      );
    }
    return CountryCode._(value);
  }

  static final RegExp _pattern = RegExp(r'^[A-Z]{2}$');
}
