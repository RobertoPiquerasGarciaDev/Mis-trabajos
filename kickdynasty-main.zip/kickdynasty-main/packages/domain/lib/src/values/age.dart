/// Edad de un jugador.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Edad de un jugador en años, dentro del rango jugable del juego.
extension type const Age._(int years) {
  /// Crea la edad validando el rango [min]..[max].
  factory Age(int years) {
    checkRange(years, min, max, 'Age');
    return Age._(years);
  }

  /// Edad mínima de un jugador en el juego (canterano juvenil).
  static const int min = 14;

  /// Edad máxima de un jugador en el juego.
  static const int max = 50;

  /// `true` si el jugador puede seguir cumpliendo años dentro del rango.
  bool get canGrowOlder => years < max;

  /// Devuelve la edad tras cumplir un año más.
  ///
  /// El motor retira a los jugadores mucho antes de [max]; este límite solo
  /// protege la integridad del dato.
  Age nextYear() => Age(years + 1);
}
