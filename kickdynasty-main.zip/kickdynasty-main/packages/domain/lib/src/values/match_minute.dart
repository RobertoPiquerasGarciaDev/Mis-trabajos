/// Minuto de partido.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Minuto de partido en el que ocurre un evento (1–120).
///
/// Cubre los 90 minutos reglamentarios más una posible prórroga. El descuento
/// se representa dentro del minuto correspondiente (p. ej. 90+3 → 90).
extension type const MatchMinute._(int value) {
  /// Crea el minuto validando el rango [min]..[max].
  factory MatchMinute(int value) {
    checkRange(value, min, max, 'MatchMinute');
    return MatchMinute._(value);
  }

  /// Primer minuto válido.
  static const int min = 1;

  /// Último minuto válido (final de la prórroga).
  static const int max = 120;
}
