/// Valoración de habilidad en la escala única del juego.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Valoración de habilidad en la escala 1–99.
///
/// Se usa para atributos de jugador, potencial y reputación. La escala es
/// única en todo el juego (ADR: vocabulario único del dominio); cualquier
/// otra escala se convierte a esta en su frontera.
extension type const Rating._(int value) {
  /// Crea una valoración validando el rango [min]..[max].
  factory Rating(int value) {
    checkRange(value, min, max, 'Rating');
    return Rating._(value);
  }

  /// Crea una valoración recortando [value] al rango válido.
  ///
  /// Pensada para cálculos de progresión donde el resultado puede salirse
  /// del rango y la regla es saturar, no fallar.
  factory Rating.clamped(int value) => Rating._(value.clamp(min, max));

  /// Valor mínimo de la escala.
  static const int min = 1;

  /// Valor máximo de la escala.
  static const int max = 99;
}
