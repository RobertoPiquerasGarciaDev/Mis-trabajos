/// Calendario del juego.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';
import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:meta/meta.dart';

/// Fecha del calendario del juego: temporada y semana.
///
/// El juego avanza en pasos de una semana. Una temporada tiene
/// [weeksPerSeason] semanas; el reparto entre jornadas de liga, copa y
/// descansos lo decide el motor según la configuración de la competición.
@immutable
final class GameDate implements Comparable<GameDate> {
  /// Crea una fecha validando temporada (≥ 1) y semana (1..[weeksPerSeason]).
  GameDate({required this.season, required this.week}) {
    if (season < 1) {
      throw DomainInvariantViolation(
        'GameDate.season debe ser >= 1 (recibido: $season)',
      );
    }
    checkRange(week, 1, weeksPerSeason, 'GameDate.week');
  }

  /// Número de temporada, empezando en 1.
  final int season;

  /// Semana dentro de la temporada, 1..[weeksPerSeason].
  final int week;

  /// Semanas que componen una temporada.
  static const int weeksPerSeason = 52;

  /// Devuelve la fecha [weeks] semanas después, cruzando temporadas si
  /// hace falta. [weeks] debe ser ≥ 0.
  GameDate advanceWeeks(int weeks) {
    if (weeks < 0) {
      throw DomainInvariantViolation(
        'advanceWeeks requiere semanas >= 0 (recibido: $weeks)',
      );
    }
    final totalWeeks = (week - 1) + weeks;
    return GameDate(
      season: season + totalWeeks ~/ weeksPerSeason,
      week: totalWeeks % weeksPerSeason + 1,
    );
  }

  /// `true` si esta fecha es anterior a [other].
  bool isBefore(GameDate other) => compareTo(other) < 0;

  /// `true` si esta fecha es posterior a [other].
  bool isAfter(GameDate other) => compareTo(other) > 0;

  @override
  int compareTo(GameDate other) {
    final bySeason = season.compareTo(other.season);
    return bySeason != 0 ? bySeason : week.compareTo(other.week);
  }

  @override
  bool operator ==(Object other) =>
      other is GameDate && other.season == season && other.week == week;

  @override
  int get hashCode => Object.hash(season, week);

  @override
  String toString() => 'T$season-S$week';
}
