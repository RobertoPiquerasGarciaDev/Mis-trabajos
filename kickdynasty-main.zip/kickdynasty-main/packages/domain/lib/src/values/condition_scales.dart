/// Escalas de condición dinámica del jugador (0–100).
///
/// Son estados que cambian partido a partido, a diferencia de los atributos
/// ([Rating]) que evolucionan lentamente por progresión.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Estado físico de un jugador (0 = exhausto, 100 = pleno).
extension type const Fitness._(int value) {
  /// Crea el valor validando el rango 0–100.
  factory Fitness(int value) {
    checkRange(value, min, max, 'Fitness');
    return Fitness._(value);
  }

  /// Crea el valor recortando al rango válido.
  factory Fitness.clamped(int value) => Fitness._(value.clamp(min, max));

  /// Valor mínimo de la escala.
  static const int min = 0;

  /// Valor máximo de la escala.
  static const int max = 100;
}

/// Moral de un jugador (0 = hundido, 100 = eufórico).
extension type const Morale._(int value) {
  /// Crea el valor validando el rango 0–100.
  factory Morale(int value) {
    checkRange(value, min, max, 'Morale');
    return Morale._(value);
  }

  /// Crea el valor recortando al rango válido.
  factory Morale.clamped(int value) => Morale._(value.clamp(min, max));

  /// Valor mínimo de la escala.
  static const int min = 0;

  /// Valor máximo de la escala.
  static const int max = 100;
}

/// Forma reciente de un jugador (0 = pésima, 100 = espléndida).
extension type const Form._(int value) {
  /// Crea el valor validando el rango 0–100.
  factory Form(int value) {
    checkRange(value, min, max, 'Form');
    return Form._(value);
  }

  /// Crea el valor recortando al rango válido.
  factory Form.clamped(int value) => Form._(value.clamp(min, max));

  /// Valor mínimo de la escala.
  static const int min = 0;

  /// Valor máximo de la escala.
  static const int max = 100;
}
