/// Dinero del juego.
library;

/// Cantidad de dinero del juego, en unidades enteras de la divisa virtual.
///
/// Puede ser negativa (deuda de un club). Los importes que por regla de
/// negocio no admiten negativos (salarios, traspasos) se validan en la
/// entidad que los usa, no aquí.
extension type const Money(int amount) {
  /// Cantidad cero.
  static const Money zero = Money(0);

  /// `true` si la cantidad es negativa.
  bool get isNegative => amount < 0;

  /// Suma dos cantidades.
  Money operator +(Money other) => Money(amount + other.amount);

  /// Resta dos cantidades.
  Money operator -(Money other) => Money(amount - other.amount);

  /// Negación (p. ej. para expresar un cargo).
  Money operator -() => Money(-amount);

  /// Escala la cantidad por un factor entero.
  Money operator *(int factor) => Money(amount * factor);

  /// `true` si esta cantidad es menor que [other].
  bool operator <(Money other) => amount < other.amount;

  /// `true` si esta cantidad es menor o igual que [other].
  bool operator <=(Money other) => amount <= other.amount;

  /// `true` si esta cantidad es mayor que [other].
  bool operator >(Money other) => amount > other.amount;

  /// `true` si esta cantidad es mayor o igual que [other].
  bool operator >=(Money other) => amount >= other.amount;
}
