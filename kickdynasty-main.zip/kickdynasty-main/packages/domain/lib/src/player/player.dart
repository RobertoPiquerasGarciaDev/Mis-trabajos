/// Entidad jugador.
library;

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:kickdynasty_domain/src/player/player_attributes.dart';
import 'package:kickdynasty_domain/src/player/position.dart';
import 'package:kickdynasty_domain/src/values/age.dart';
import 'package:kickdynasty_domain/src/values/condition_scales.dart';
import 'package:kickdynasty_domain/src/values/display_name.dart';
import 'package:kickdynasty_domain/src/values/rating.dart';

part 'player.freezed.dart';

/// Pierna dominante de un jugador.
enum PreferredFoot {
  /// Zurdo.
  left,

  /// Diestro.
  right,

  /// Ambidiestro.
  either,
}

/// Un jugador del mundo del juego.
///
/// Los campos de identidad y habilidad ([attributes], [potential]) cambian
/// lentamente por progresión; la condición dinámica ([fitness], [morale],
/// [form]) cambia partido a partido. Todos los campos usan value objects
/// validados: no es posible construir un jugador con datos fuera de rango.
///
/// El jugador no conoce su club: la relación jugador–club la establece
/// `Contract`, y la colección de jugadores de un club es `Squad`.
@freezed
abstract class Player with _$Player {
  /// Crea un jugador.
  const factory Player({
    /// Identificador único.
    required PlayerId id,

    /// Persona asociada (`null` en saves anteriores a PF-1).
    PersonId? personId,

    /// Nombre visible.
    required DisplayName name,

    /// Nacionalidad (ISO 3166-1 alfa-2).
    required CountryCode nationality,

    /// Posición natural.
    required Position position,

    /// Pierna dominante.
    required PreferredFoot preferredFoot,

    /// Edad actual.
    required Age age,

    /// Atributos de habilidad actuales.
    required PlayerAttributes attributes,

    /// Techo de desarrollo estimado (guía del sistema de progresión).
    required Rating potential,

    /// Estado físico actual.
    required Fitness fitness,

    /// Moral actual.
    required Morale morale,

    /// Forma reciente.
    required Form form,
  }) = _Player;
}
