/// Atributos de habilidad de un jugador.
library;

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kickdynasty_domain/src/values/rating.dart';

part 'player_attributes.freezed.dart';

/// Atributos de habilidad de un jugador, todos en la escala [Rating] (1–99).
///
/// El dominio almacena los valores crudos; el peso de cada atributo por
/// posición es dato de balance y vive en la configuración del motor
/// (ADR 0005). Ninguna capa debe calcular aquí "medias" con pesos implícitos.
@freezed
abstract class PlayerAttributes with _$PlayerAttributes {
  /// Crea el conjunto completo de atributos.
  const factory PlayerAttributes({
    /// Velocidad punta y arrancada.
    required Rating pace,

    /// Resistencia física durante el partido.
    required Rating stamina,

    /// Potencia en duelos y juego aéreo.
    required Rating strength,

    /// Calidad de pase corto y largo.
    required Rating passing,

    /// Definición y tiro.
    required Rating shooting,

    /// Regate y conducción.
    required Rating dribbling,

    /// Entrada, corte y marcaje.
    required Rating tackling,

    /// Colocación e inteligencia posicional.
    required Rating positioning,

    /// Visión de juego y último pase.
    required Rating vision,

    /// Sangre fría bajo presión.
    required Rating composure,

    /// Conjunto de habilidades de portero (paradas, salidas, juego de pies).
    required Rating goalkeeping,
  }) = _PlayerAttributes;
}
