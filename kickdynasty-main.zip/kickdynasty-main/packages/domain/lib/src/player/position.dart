/// Posiciones del campo.
library;

/// Línea del campo a la que pertenece una posición.
enum PositionGroup {
  /// Portería.
  goalkeeper,

  /// Defensa.
  defence,

  /// Mediocampo.
  midfield,

  /// Ataque.
  attack,
}

/// Posición específica de un jugador.
///
/// Es el vocabulario único de posiciones del juego: dominio, motor, UI y
/// persistencia usan exactamente estos valores.
enum Position {
  /// Portero.
  gk(PositionGroup.goalkeeper),

  /// Defensa central.
  cb(PositionGroup.defence),

  /// Lateral izquierdo.
  lb(PositionGroup.defence),

  /// Lateral derecho.
  rb(PositionGroup.defence),

  /// Mediocentro defensivo.
  dm(PositionGroup.midfield),

  /// Mediocentro.
  cm(PositionGroup.midfield),

  /// Mediapunta.
  am(PositionGroup.midfield),

  /// Extremo izquierdo.
  lw(PositionGroup.attack),

  /// Extremo derecho.
  rw(PositionGroup.attack),

  /// Delantero centro.
  st(PositionGroup.attack);

  const Position(this.group);

  /// Línea del campo a la que pertenece la posición.
  final PositionGroup group;

  /// `true` si la posición es de portero.
  bool get isGoalkeeper => group == PositionGroup.goalkeeper;
}
