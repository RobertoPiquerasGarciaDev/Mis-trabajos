/// Procedencia de una relación (PF-5).
library;

/// Cómo se formó la relación subjetiva.
enum RelationOrigin {
  /// Rol estructural del club (PF-5).
  structural,

  /// Reforzada por percepción directa.
  perception,

  /// Reforzada por memoria episódica.
  memory,

  /// Interacción interpersonal (PF-5+: stub).
  interaction,
}
