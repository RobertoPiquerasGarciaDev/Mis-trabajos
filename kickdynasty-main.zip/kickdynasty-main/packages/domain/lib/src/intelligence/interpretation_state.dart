/// Contenedor de interpretaciones en [AgentMind] (PF-6).
library;

import 'package:kickdynasty_domain/src/intelligence/interpretation_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_entry.dart';
import 'package:meta/meta.dart';

/// Estado interpretativo — hipótesis subjetivas, no creencias persistentes.
@immutable
final class InterpretationState {
  /// Estado vacío (pre-PF-6).
  const InterpretationState.empty()
    : collection = const InterpretationCollection.empty();

  /// Crea el estado con la colección.
  const InterpretationState({required this.collection});

  /// Colección de interpretaciones.
  final InterpretationCollection collection;

  /// Entradas accesibles.
  List<InterpretationEntry> get entries => collection.entries;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {'v': 1, 'collection': collection.toJson()};

  /// Deserializa desde JSON.
  factory InterpretationState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('InterpretationState JSON v$version no soportada');
    }
    return InterpretationState(
      collection: InterpretationCollection.fromJson(
        Map<String, Object?>.from(json['collection']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is InterpretationState && collection == other.collection;

  @override
  int get hashCode => collection.hashCode;
}
