/// Resultado de deliberación interna (PF-9).
library;

import 'package:kickdynasty_domain/src/intelligence/intention_candidate.dart';
import 'package:meta/meta.dart';

/// Salida provisional — solo candidatos a intención, sin decisión.
@immutable
final class DeliberationResult {
  /// Crea el resultado.
  const DeliberationResult({
    required this.candidates,
    required this.rejectedPaths,
  });

  /// Candidatos a intención formados.
  final List<IntentionCandidate> candidates;

  /// Caminos descartados con razón subjetiva (trazabilidad).
  final List<String> rejectedPaths;

  /// Colección vacía.
  static const empty = DeliberationResult(candidates: [], rejectedPaths: []);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DeliberationResult &&
          _listEquals(candidates, other.candidates) &&
          _listEquals(rejectedPaths, other.rejectedPaths);

  @override
  int get hashCode =>
      Object.hash(Object.hashAll(candidates), Object.hashAll(rejectedPaths));
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
