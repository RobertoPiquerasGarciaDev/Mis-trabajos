/// Confianza subjetiva hacia otra persona (−1.0…+1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Confianza asimétrica del observador hacia el objetivo.
extension type const RelationTrust._(double value) {
  /// Crea la confianza validando el rango −1.0…+1.0.
  factory RelationTrust(double value) {
    if (value < -1 || value > 1) {
      throw DomainInvariantViolation(
        'RelationTrust debe estar en -1.0..1.0 (recibido: $value)',
      );
    }
    return RelationTrust._(value);
  }

  /// Confianza plena (solo relación consigo mismo).
  static RelationTrust get absolute => RelationTrust(1.0);

  /// Neutral estructural (PF-5).
  static RelationTrust get neutral => RelationTrust(0.0);

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static RelationTrust fromJson(num json) => RelationTrust(json.toDouble());
}
