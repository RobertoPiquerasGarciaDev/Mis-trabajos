/// Categoría organizativa de objetivos (PF-8 — sin efecto en gameplay).
library;

/// Ámbito al que pertenece la motivación.
enum GoalCategory {
  /// Motivaciones personales.
  personal,

  /// Motivaciones profesionales.
  professional,

  /// Motivaciones sociales/interpersonales.
  social,

  /// Motivaciones financieras percibidas.
  financial,

  /// Motivaciones deportivas/competitivas.
  sporting,

  /// Motivaciones institucionales.
  institutional,

  /// Motivaciones de legado.
  legacy,

  /// Motivaciones sobre el entorno.
  world,
}
