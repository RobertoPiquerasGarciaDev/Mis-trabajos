/// Identificador estable de una decisión cognitiva (PF-10).
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de una [DecisionEntry].
extension type const DecisionId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory DecisionId(String value) =>
      DecisionId._(checkNotBlank(value, 'DecisionId'));
}
