/// Estado de un objetivo cognitivo (PF-8).
library;

/// Ciclo de vida subjetivo del objetivo — sin ejecución en PF-8.
enum GoalStatus {
  /// Motivación activa.
  active,

  /// Motivación latente.
  dormant,

  /// Considerado cumplido por la persona (subjetivo).
  fulfilled,
}
