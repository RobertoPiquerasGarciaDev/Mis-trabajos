/// Contenedor de intenciones en [AgentMind] (PF-9).
library;

import 'package:kickdynasty_domain/src/intelligence/intention_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_entry.dart';
import 'package:meta/meta.dart';

/// Estado de intenciones provisionales — subjetivas, no Reality.
@immutable
final class IntentionState {
  /// Estado vacío (pre-PF-9).
  const IntentionState.empty() : collection = const IntentionCollection.empty();

  /// Crea el estado con la colección.
  const IntentionState({required this.collection});

  /// Colección de intenciones.
  final IntentionCollection collection;

  /// Entradas accesibles.
  List<IntentionEntry> get entries => collection.entries;

  /// Serializa a JSON (versión 2).
  Map<String, Object?> toJson() => {'v': 2, 'collection': collection.toJson()};

  /// Deserializa desde JSON.
  factory IntentionState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version > 2) {
      throw FormatException('IntentionState JSON v$version no soportada');
    }
    if (version == 1) {
      return const IntentionState.empty();
    }
    return IntentionState(
      collection: IntentionCollection.fromJson(
        Map<String, Object?>.from(json['collection']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is IntentionState && collection == other.collection;

  @override
  int get hashCode => collection.hashCode;
}
