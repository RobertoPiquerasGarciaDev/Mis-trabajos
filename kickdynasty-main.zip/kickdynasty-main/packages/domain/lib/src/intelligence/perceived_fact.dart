/// Hecho individual dentro de una fotografía perceptiva (PF-3).
library;

import 'package:kickdynasty_domain/src/intelligence/knowledge_origin.dart';
import 'package:kickdynasty_domain/src/intelligence/observation_quality.dart';
import 'package:kickdynasty_domain/src/intelligence/perception_age.dart';
import 'package:kickdynasty_domain/src/intelligence/perception_confidence.dart';
import 'package:kickdynasty_domain/src/intelligence/perception_source.dart';
import 'package:kickdynasty_domain/src/intelligence/visibility_level.dart';
import 'package:meta/meta.dart';

/// Un dato que el observador cree haber visto — nunca un hecho de Reality.
@immutable
final class PerceivedFact {
  /// Crea un hecho percibido con metadatos epistémicos.
  const PerceivedFact({
    required this.subjectId,
    required this.factKey,
    required this.value,
    required this.source,
    required this.confidence,
    required this.age,
    required this.visibility,
    required this.quality,
    required this.origin,
    this.ambiguity = '',
  });

  /// Identificador del sujeto (`playerId`, `clubId`, …).
  final String subjectId;

  /// Clave canónica del hecho (`player.fitness`, `club.name`, …).
  final String factKey;

  /// Valor percibido (texto o número serializado).
  final String value;

  /// Fuente del input.
  final PerceptionSource source;

  /// Certeza subjetiva.
  final PerceptionConfidence confidence;

  /// Antigüedad del dato.
  final PerceptionAge age;

  /// Grado de visibilidad.
  final VisibilityLevel visibility;

  /// Calidad de la observación.
  final ObservationQuality quality;

  /// Procedencia epistémica.
  final KnowledgeOrigin origin;

  /// Rango o disyunción legible («72–84») — vacío si preciso.
  final String ambiguity;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'subjectId': subjectId,
    'factKey': factKey,
    'value': value,
    'source': source.name,
    'confidence': confidence.toJson(),
    'age': age.toJson(),
    'visibility': visibility.name,
    'quality': quality.toJson(),
    'origin': origin.name,
    if (ambiguity.isNotEmpty) 'ambiguity': ambiguity,
  };

  /// Deserializa desde JSON.
  factory PerceivedFact.fromJson(Map<String, Object?> json) => PerceivedFact(
    subjectId: json['subjectId']! as String,
    factKey: json['factKey']! as String,
    value: json['value']! as String,
    source: PerceptionSource.values.byName(json['source']! as String),
    confidence: PerceptionConfidence.fromJson(json['confidence']! as num),
    age: PerceptionAge.fromJson(json['age']! as int),
    visibility: VisibilityLevel.values.byName(json['visibility']! as String),
    quality: ObservationQuality.fromJson(json['quality']! as int),
    origin: KnowledgeOrigin.values.byName(json['origin']! as String),
    ambiguity: json['ambiguity'] as String? ?? '',
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PerceivedFact &&
          subjectId == other.subjectId &&
          factKey == other.factKey &&
          value == other.value &&
          source == other.source &&
          confidence == other.confidence &&
          age == other.age &&
          visibility == other.visibility &&
          quality == other.quality &&
          origin == other.origin &&
          ambiguity == other.ambiguity;

  @override
  int get hashCode => Object.hash(
    subjectId,
    factKey,
    value,
    source,
    confidence,
    age,
    visibility,
    quality,
    origin,
    ambiguity,
  );
}
