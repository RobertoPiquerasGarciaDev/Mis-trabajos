/// Convocatoria de protocolo social (PF-10).
library;

import 'package:kickdynasty_domain/src/people_first/deliberation_protocol_type.dart';
import 'package:meta/meta.dart';

/// Resultado de evaluar si una intención requiere protocolo social.
@immutable
final class DeliberationConvocation {
  /// Sin protocolo — consolidación unilateral o diferimiento.
  const DeliberationConvocation({
    required this.requiresSocialProtocol,
    this.protocolType,
    required this.unilateralAllowed,
    required this.deferred,
    required this.reason,
  });

  /// Diferimiento explícito.
  const DeliberationConvocation.deferred({required this.reason})
    : requiresSocialProtocol = false,
      protocolType = null,
      unilateralAllowed = false,
      deferred = true;

  /// Compromiso unilateral permitido.
  const DeliberationConvocation.unilateral({required this.reason})
    : requiresSocialProtocol = false,
      protocolType = null,
      unilateralAllowed = true,
      deferred = false;

  /// Protocolo social requerido.
  const DeliberationConvocation.protocol({
    required DeliberationProtocolType type,
    required this.reason,
  }) : requiresSocialProtocol = true,
       protocolType = type,
       unilateralAllowed = false,
       deferred = false;

  /// `true` si debe convocarse deliberación social.
  final bool requiresSocialProtocol;

  /// Protocolo a convocar, si aplica.
  final DeliberationProtocolType? protocolType;

  /// `true` si el rol permite decisión unilateral.
  final bool unilateralAllowed;

  /// `true` si no hay compromiso suficiente aún.
  final bool deferred;

  /// Motivo subjetivo de la convocatoria.
  final String reason;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DeliberationConvocation &&
          requiresSocialProtocol == other.requiresSocialProtocol &&
          protocolType == other.protocolType &&
          unilateralAllowed == other.unilateralAllowed &&
          deferred == other.deferred &&
          reason == other.reason;

  @override
  int get hashCode => Object.hash(
    requiresSocialProtocol,
    protocolType,
    unilateralAllowed,
    deferred,
    reason,
  );
}
