/// Clasificación de objetivos cognitivos (PF-8).
library;

/// Tipo de motivación derivada de creencias.
enum GoalType {
  /// Mantener o fortalecer confianza percibida.
  maintainTrust,

  /// Recuperar estatus o protagonismo.
  regainStatus,

  /// Mejorar capacidad personal.
  improveSelf,

  /// Buscar protección o respaldo.
  seekProtection,

  /// Ejercer o consolidar liderazgo.
  assertLeadership,

  /// Alinear con la institución.
  alignWithInstitution,

  /// Fortalecer cohesión de grupo.
  strengthenSquad,

  /// Clarificar rol propio.
  clarifyRole,

  /// Comprender el entorno.
  understandWorld,

  /// Legado o trascendencia personal.
  buildLegacy,
}
