/// Informe de scouting — tipo stub para PF-3+ (sin runtime).
library;

import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Informe profesional futuro — PF-3: solo identidad, sin contenido cognitivo.
@immutable
final class ScoutingReport {
  /// Crea la referencia stub.
  const ScoutingReport({
    required this.id,
    required this.scoutPersonId,
    required this.subjectPlayerId,
  });

  /// Identificador del informe.
  final String id;

  /// Scout autor (persona).
  final PersonId scoutPersonId;

  /// Jugador observado.
  final PlayerId subjectPlayerId;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id,
    'scoutPersonId': scoutPersonId.value,
    'subjectPlayerId': subjectPlayerId.value,
  };

  /// Deserializa desde JSON.
  factory ScoutingReport.fromJson(Map<String, Object?> json) => ScoutingReport(
    id: json['id']! as String,
    scoutPersonId: PersonId(json['scoutPersonId']! as String),
    subjectPlayerId: PlayerId(json['subjectPlayerId']! as String),
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ScoutingReport &&
          id == other.id &&
          scoutPersonId == other.scoutPersonId &&
          subjectPlayerId == other.subjectPlayerId;

  @override
  int get hashCode => Object.hash(id, scoutPersonId, subjectPlayerId);
}
