/// Certeza subjetiva en una creencia (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Confianza en que la creencia es cierta.
extension type const BeliefConfidence._(double value) {
  /// Crea la confianza validando el rango 0.0–1.0.
  factory BeliefConfidence(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'BeliefConfidence debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return BeliefConfidence._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static BeliefConfidence fromJson(num json) =>
      BeliefConfidence(json.toDouble());
}
