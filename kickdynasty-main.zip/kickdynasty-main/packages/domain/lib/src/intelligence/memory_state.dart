/// Contenedor de memoria episódica en [AgentMind] (PF-4).
library;

import 'package:kickdynasty_domain/src/intelligence/memory_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_entry.dart';
import 'package:meta/meta.dart';

/// Estado de memoria — recuerdos subjetivos, no Chronicle.
@immutable
final class MemoryState {
  /// Estado vacío (pre-PF-4 / sin recuerdos).
  const MemoryState.empty() : collection = const MemoryCollection.empty();

  /// Crea el estado con la colección de recuerdos.
  const MemoryState({required this.collection});

  /// Colección de recuerdos de la persona.
  final MemoryCollection collection;

  /// Recuerdos accesibles.
  List<MemoryEntry> get entries => collection.entries;

  /// Serializa a JSON (versión 2).
  Map<String, Object?> toJson() => {'v': 2, 'collection': collection.toJson()};

  /// Deserializa desde JSON.
  factory MemoryState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version == 1) {
      return const MemoryState.empty();
    }
    return MemoryState(
      collection: MemoryCollection.fromJson(
        Map<String, Object?>.from(json['collection']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MemoryState && collection == other.collection;

  @override
  int get hashCode => collection.hashCode;
}
