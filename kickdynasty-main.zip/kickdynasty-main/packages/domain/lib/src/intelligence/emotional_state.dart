/// Estado emocional inicial (AGENT_INTELLIGENCE §15.2, PF-2).
library;

import 'package:meta/meta.dart';

/// Vector emocional 0.0–1.0 — PF-2: baseline neutro sin dinámica.
@immutable
final class EmotionalState {
  /// Crea el vector emocional validando rangos.
  const EmotionalState({
    this.fear = 0,
    this.anger = 0,
    this.euphoria = 0,
    this.anxiety = 0,
    this.woundedPride = 0,
    this.relief = 0,
    this.distrust = 0,
  }) : assert(fear >= 0 && fear <= 1),
       assert(anger >= 0 && anger <= 1),
       assert(euphoria >= 0 && euphoria <= 1),
       assert(anxiety >= 0 && anxiety <= 1),
       assert(woundedPride >= 0 && woundedPride <= 1),
       assert(relief >= 0 && relief <= 1),
       assert(distrust >= 0 && distrust <= 1);

  /// Baseline neutro (PF-2).
  static const initial = EmotionalState();

  /// Miedo.
  final double fear;

  /// Ira.
  final double anger;

  /// Euforia.
  final double euphoria;

  /// Ansiedad.
  final double anxiety;

  /// Orgullo herido.
  final double woundedPride;

  /// Alivio.
  final double relief;

  /// Desconfianza.
  final double distrust;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'v': 1,
    'fear': fear,
    'anger': anger,
    'euphoria': euphoria,
    'anxiety': anxiety,
    'woundedPride': woundedPride,
    'relief': relief,
    'distrust': distrust,
  };

  /// Deserializa desde JSON.
  factory EmotionalState.fromJson(Map<String, Object?> json) => EmotionalState(
    fear: (json['fear'] as num?)?.toDouble() ?? 0,
    anger: (json['anger'] as num?)?.toDouble() ?? 0,
    euphoria: (json['euphoria'] as num?)?.toDouble() ?? 0,
    anxiety: (json['anxiety'] as num?)?.toDouble() ?? 0,
    woundedPride: (json['woundedPride'] as num?)?.toDouble() ?? 0,
    relief: (json['relief'] as num?)?.toDouble() ?? 0,
    distrust: (json['distrust'] as num?)?.toDouble() ?? 0,
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is EmotionalState &&
          fear == other.fear &&
          anger == other.anger &&
          euphoria == other.euphoria &&
          anxiety == other.anxiety &&
          woundedPride == other.woundedPride &&
          relief == other.relief &&
          distrust == other.distrust;

  @override
  int get hashCode => Object.hash(
    fear,
    anger,
    euphoria,
    anxiety,
    woundedPride,
    relief,
    distrust,
  );
}
