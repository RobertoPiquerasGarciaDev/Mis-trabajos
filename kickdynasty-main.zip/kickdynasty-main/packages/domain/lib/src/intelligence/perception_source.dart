/// Fuentes de inputs perceptivos (AGENT_INTELLIGENCE §3.2, PF-3).
library;

/// Origen de un hecho percibido — infraestructura para fuentes futuras.
enum PerceptionSource {
  /// Observación directa (única activa en PF-3).
  directObservation,

  /// Informe de scouting (PF-3+: stub).
  scoutingReport,

  /// Medios / prensa.
  media,

  /// Chronicle pública conocida.
  chronicle,

  /// Rumor no verificado.
  rumor,

  /// Conversación interpersonal.
  conversation,

  /// Mandato o señal institucional.
  institution,

  /// Introspección limitada (propio estado).
  introspection,
}
