/// Fuerza subjetiva de una creencia (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Peso cognitivo de la creencia — distinto de confianza epistémica.
extension type const BeliefStrength._(double value) {
  /// Crea la fuerza validando el rango 0.0–1.0.
  factory BeliefStrength(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'BeliefStrength debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return BeliefStrength._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static BeliefStrength fromJson(num json) => BeliefStrength(json.toDouble());
}
