/// Decisión cognitiva individual (PF-10).
library;

import 'package:kickdynasty_domain/src/intelligence/decision_id.dart';
import 'package:kickdynasty_domain/src/intelligence/decision_origin.dart';
import 'package:kickdynasty_domain/src/intelligence/decision_status.dart';
import 'package:kickdynasty_domain/src/intelligence/decision_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/decision_type.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_id.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_id.dart';
import 'package:kickdynasty_domain/src/people_first/deliberation_protocol_type.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Claves prohibidas — decisiones no almacenan Reality ni mandatos.
const forbiddenDecisionKeys = {
  'potential',
  'attributes',
  'overall',
  'ovr',
  'salary',
  'fitness',
  'morale',
  'action',
  'plan',
  'mandate',
  'utility',
  'worldSeed',
  'player',
  'reality',
  'executedMandate',
  'chronicle',
};

/// Compromiso cognitivo — nunca una acción ni un mandato ejecutado.
@immutable
final class DecisionEntry {
  /// Crea la decisión.
  const DecisionEntry({
    required this.id,
    required this.observerPersonId,
    required this.sourceIntentionId,
    required this.type,
    required this.origin,
    required this.status,
    required this.summary,
    required this.rationale,
    required this.strength,
    required this.sourcePriorityIds,
    required this.rejectedAlternatives,
    required this.unknownsAcknowledged,
    required this.createdAt,
    required this.updatedAt,
    this.protocolType,
    this.decisionRecordId,
    this.instanceId,
  });

  /// Identificador estable.
  final DecisionId id;

  /// Persona que sostiene el compromiso.
  final PersonId observerPersonId;

  /// Intención consolidada.
  final IntentionId sourceIntentionId;

  /// Tipo de compromiso.
  final DecisionType type;

  /// Procedencia cognitiva.
  final DecisionOrigin origin;

  /// Estado subjetivo.
  final DecisionStatus status;

  /// Enunciado del compromiso — no acción ejecutada.
  final String summary;

  /// Por qué esta persona lo considera correcto.
  final String rationale;

  /// Intensidad del compromiso.
  final DecisionStrength strength;

  /// Prioridades que dominaron el sopesamiento.
  final List<PriorityId> sourcePriorityIds;

  /// Caminos descartados con razón subjetiva.
  final List<String> rejectedAlternatives;

  /// Información que la persona reconoce no conocer.
  final List<String> unknownsAcknowledged;

  /// Protocolo social, si aplica.
  final DeliberationProtocolType? protocolType;

  /// Enlace al registro social append-only.
  final String? decisionRecordId;

  /// Instancia del protocolo social.
  final String? instanceId;

  /// Momento de creación.
  final MemoryTimestamp createdAt;

  /// Última actualización.
  final MemoryTimestamp updatedAt;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id.value,
    'observerPersonId': observerPersonId.value,
    'sourceIntentionId': sourceIntentionId.value,
    'type': type.name,
    'origin': origin.name,
    'status': status.name,
    'summary': summary,
    'rationale': rationale,
    'strength': strength.toJson(),
    'sourcePriorityIds': [for (final pid in sourcePriorityIds) pid.value],
    'rejectedAlternatives': rejectedAlternatives,
    'unknownsAcknowledged': unknownsAcknowledged,
    if (protocolType != null) 'protocolType': protocolType!.name,
    if (decisionRecordId != null) 'decisionRecordId': decisionRecordId,
    if (instanceId != null) 'instanceId': instanceId,
    'createdAt': createdAt.toJson(),
    'updatedAt': updatedAt.toJson(),
  };

  /// Deserializa desde JSON.
  factory DecisionEntry.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('DecisionEntry JSON v$version no soportada');
    }
    return DecisionEntry(
      id: DecisionId(json['id']! as String),
      observerPersonId: PersonId(json['observerPersonId']! as String),
      sourceIntentionId: IntentionId(json['sourceIntentionId']! as String),
      type: DecisionType.values.byName(json['type']! as String),
      origin: DecisionOrigin.values.byName(json['origin']! as String),
      status: DecisionStatus.values.byName(json['status']! as String),
      summary: json['summary']! as String,
      rationale: json['rationale']! as String,
      strength: DecisionStrength.fromJson(json['strength']! as num),
      sourcePriorityIds: [
        for (final id in json['sourcePriorityIds']! as List)
          PriorityId(id as String),
      ],
      rejectedAlternatives: [
        for (final item in json['rejectedAlternatives']! as List)
          item as String,
      ],
      unknownsAcknowledged: [
        for (final item in json['unknownsAcknowledged']! as List)
          item as String,
      ],
      protocolType: switch (json['protocolType']) {
        null => null,
        final name => DeliberationProtocolType.values.byName(name as String),
      },
      decisionRecordId: json['decisionRecordId'] as String?,
      instanceId: json['instanceId'] as String?,
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
      updatedAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['updatedAt']! as Map),
      ),
    );
  }

  /// `true` si no contiene claves prohibidas.
  bool get passesNonRealityCheck => !containsForbiddenDecisionKeys(toJson());

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DecisionEntry &&
          id == other.id &&
          observerPersonId == other.observerPersonId &&
          sourceIntentionId == other.sourceIntentionId &&
          type == other.type &&
          origin == other.origin &&
          status == other.status &&
          summary == other.summary &&
          rationale == other.rationale &&
          strength == other.strength &&
          _listEquals(sourcePriorityIds, other.sourcePriorityIds) &&
          _listEquals(rejectedAlternatives, other.rejectedAlternatives) &&
          _listEquals(unknownsAcknowledged, other.unknownsAcknowledged) &&
          protocolType == other.protocolType &&
          decisionRecordId == other.decisionRecordId &&
          instanceId == other.instanceId &&
          createdAt == other.createdAt &&
          updatedAt == other.updatedAt;

  @override
  int get hashCode => Object.hash(
    id,
    observerPersonId,
    sourceIntentionId,
    type,
    origin,
    status,
    summary,
    rationale,
    strength,
    Object.hashAll(sourcePriorityIds),
    Object.hashAll(rejectedAlternatives),
    Object.hashAll(unknownsAcknowledged),
    protocolType,
    decisionRecordId,
    instanceId,
    createdAt,
    updatedAt,
  );
}

/// Escanea recursivamente un mapa JSON buscando claves prohibidas.
bool containsForbiddenDecisionKeys(Map<String, Object?> json) {
  for (final entry in json.entries) {
    if (forbiddenDecisionKeys.contains(entry.key)) return true;
    final value = entry.value;
    if (value is Map &&
        containsForbiddenDecisionKeys(Map<String, Object?>.from(value))) {
      return true;
    }
    if (value is List) {
      for (final item in value) {
        if (item is Map &&
            containsForbiddenDecisionKeys(Map<String, Object?>.from(item))) {
          return true;
        }
      }
    }
  }
  return false;
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
