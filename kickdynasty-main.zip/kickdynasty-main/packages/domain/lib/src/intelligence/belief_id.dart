/// Identificador estable de una creencia subjetiva (PF-7).
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de una [BeliefEntry].
extension type const BeliefId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory BeliefId(String value) =>
      BeliefId._(checkNotBlank(value, 'BeliefId'));
}
