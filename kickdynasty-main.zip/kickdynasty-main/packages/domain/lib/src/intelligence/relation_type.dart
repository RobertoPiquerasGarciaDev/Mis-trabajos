/// Clasificación estructural de una relación (PF-5).
library;

/// Tipo de vínculo subjetivo observador → objetivo.
enum RelationType {
  /// Relación consigo mismo.
  self,

  /// Compañero de plantilla / equipo.
  teammate,

  /// Entrenador principal.
  manager,

  /// Director deportivo.
  sportingDirector,

  /// Presidente del club.
  president,

  /// Par de staff del mismo club (PF-5 mínimo).
  staffPeer,
}
