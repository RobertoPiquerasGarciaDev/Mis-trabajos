/// Motivo subjetivo del repunte de atención (PF-9).
library;

/// Por qué este goal merece más foco ahora — sin efecto en gameplay.
enum PriorityReason {
  /// El goal ya era fuerte en abstracto.
  goalStrength,

  /// Presión emocional actual.
  emotionalPressure,

  /// Episodio de memoria resonante.
  memoryResonance,

  /// Tensión o confianza relacional.
  relationInfluence,

  /// Contexto del rol o temporada.
  roleContext,

  /// Rasgo de personalidad enfocado.
  personalityFocus,
}
