/// Prioridad cognitiva individual (PF-9).
library;

import 'package:kickdynasty_domain/src/intelligence/goal_id.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_type.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_id.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_origin.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_rank.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_reason.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_type.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Claves prohibidas — prioridades no almacenan Reality ni decisiones.
const forbiddenPriorityKeys = {
  'potential',
  'attributes',
  'overall',
  'ovr',
  'salary',
  'fitness',
  'morale',
  'decision',
  'action',
  'plan',
  'mandate',
  'utility',
  'worldSeed',
  'player',
  'reality',
  'deliberation',
  'intention',
};

/// Qué objetivo merece más atención ahora — nunca una acción.
@immutable
final class PriorityEntry {
  /// Crea la prioridad.
  const PriorityEntry({
    required this.id,
    required this.observerPersonId,
    required this.sourceGoalId,
    required this.goalType,
    required this.summary,
    required this.strength,
    required this.rank,
    required this.type,
    required this.origin,
    required this.reason,
    required this.createdAt,
    required this.updatedAt,
  });

  /// Identificador estable.
  final PriorityId id;

  /// Persona que sostiene el foco.
  final PersonId observerPersonId;

  /// Goal que alimenta la prioridad.
  final GoalId sourceGoalId;

  /// Tipo del goal fuente.
  final GoalType goalType;

  /// Enunciado de atención — no acción.
  final String summary;

  /// Fuerza de atención temporal.
  final PriorityStrength strength;

  /// Posición ordinal en el ciclo.
  final PriorityRank rank;

  /// Nivel de foco.
  final PriorityType type;

  /// Procedencia del repunte.
  final PriorityOrigin origin;

  /// Motivo subjetivo.
  final PriorityReason reason;

  /// Momento de creación.
  final MemoryTimestamp createdAt;

  /// Última actualización.
  final MemoryTimestamp updatedAt;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id.value,
    'observerPersonId': observerPersonId.value,
    'sourceGoalId': sourceGoalId.value,
    'goalType': goalType.name,
    'summary': summary,
    'strength': strength.toJson(),
    'rank': rank.toJson(),
    'type': type.name,
    'origin': origin.name,
    'reason': reason.name,
    'createdAt': createdAt.toJson(),
    'updatedAt': updatedAt.toJson(),
  };

  /// Deserializa desde JSON.
  factory PriorityEntry.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('PriorityEntry JSON v$version no soportada');
    }
    return PriorityEntry(
      id: PriorityId(json['id']! as String),
      observerPersonId: PersonId(json['observerPersonId']! as String),
      sourceGoalId: GoalId(json['sourceGoalId']! as String),
      goalType: GoalType.values.byName(json['goalType']! as String),
      summary: json['summary']! as String,
      strength: PriorityStrength.fromJson(json['strength']! as num),
      rank: PriorityRank.fromJson(json['rank']! as num),
      type: PriorityType.values.byName(json['type']! as String),
      origin: PriorityOrigin.values.byName(json['origin']! as String),
      reason: PriorityReason.values.byName(json['reason']! as String),
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
      updatedAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['updatedAt']! as Map),
      ),
    );
  }

  /// `true` si no contiene claves prohibidas.
  bool get passesNonRealityCheck => !containsForbiddenPriorityKeys(toJson());

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PriorityEntry &&
          id == other.id &&
          observerPersonId == other.observerPersonId &&
          sourceGoalId == other.sourceGoalId &&
          goalType == other.goalType &&
          summary == other.summary &&
          strength == other.strength &&
          rank == other.rank &&
          type == other.type &&
          origin == other.origin &&
          reason == other.reason &&
          createdAt == other.createdAt &&
          updatedAt == other.updatedAt;

  @override
  int get hashCode => Object.hash(
    id,
    observerPersonId,
    sourceGoalId,
    goalType,
    summary,
    strength,
    rank,
    type,
    origin,
    reason,
    createdAt,
    updatedAt,
  );
}

/// Escanea recursivamente un mapa JSON buscando claves prohibidas.
bool containsForbiddenPriorityKeys(Map<String, Object?> json) {
  for (final entry in json.entries) {
    if (forbiddenPriorityKeys.contains(entry.key)) return true;
    final value = entry.value;
    if (value is Map &&
        containsForbiddenPriorityKeys(Map<String, Object?>.from(value))) {
      return true;
    }
    if (value is List) {
      for (final item in value) {
        if (item is Map &&
            containsForbiddenPriorityKeys(Map<String, Object?>.from(item))) {
          return true;
        }
      }
    }
  }
  return false;
}
