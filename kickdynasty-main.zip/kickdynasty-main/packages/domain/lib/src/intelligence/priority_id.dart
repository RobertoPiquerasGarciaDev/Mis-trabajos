/// Identificador estable de una prioridad cognitiva (PF-9).
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de una [PriorityEntry].
extension type const PriorityId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory PriorityId(String value) =>
      PriorityId._(checkNotBlank(value, 'PriorityId'));
}
