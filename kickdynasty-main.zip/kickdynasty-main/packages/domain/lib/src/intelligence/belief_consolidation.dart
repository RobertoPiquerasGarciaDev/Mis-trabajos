/// Resultado de consolidación Interpretation → Belief (PF-7).
library;

import 'package:kickdynasty_domain/src/intelligence/belief_candidate.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_entry.dart';
import 'package:meta/meta.dart';

/// Infraestructura de consolidación — preparada para refuerzo futuro.
@immutable
final class BeliefConsolidation {
  /// Crea el resultado de consolidación.
  const BeliefConsolidation({
    required this.candidates,
    required this.beliefs,
    required this.isolatedCandidateCount,
    required this.consolidatedGroupCount,
  });

  /// Candidatos evaluados (entrada del pipeline).
  final List<BeliefCandidate> candidates;

  /// Creencias producidas tras consolidar.
  final List<BeliefEntry> beliefs;

  /// Candidatos que quedaron aislados (una sola interpretación).
  final int isolatedCandidateCount;

  /// Grupos con al menos dos interpretaciones coherentes.
  final int consolidatedGroupCount;

  /// Umbral mínimo de apoyo para creencia fuerte (PF-7+).
  static const int minSupportForStrongBelief = 2;

  /// Tope de fuerza para creencias aisladas (PF-7).
  static const double isolatedStrengthCap = 0.45;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'candidates': [for (final c in candidates) c.toJson()],
    'beliefs': [for (final b in beliefs) b.toJson()],
    'isolatedCandidateCount': isolatedCandidateCount,
    'consolidatedGroupCount': consolidatedGroupCount,
  };

  /// Deserializa desde JSON.
  factory BeliefConsolidation.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('BeliefConsolidation JSON v$version no soportada');
    }
    return BeliefConsolidation(
      candidates: [
        for (final item in json['candidates']! as List)
          BeliefCandidate.fromJson(Map<String, Object?>.from(item as Map)),
      ],
      beliefs: [
        for (final item in json['beliefs']! as List)
          BeliefEntry.fromJson(Map<String, Object?>.from(item as Map)),
      ],
      isolatedCandidateCount: json['isolatedCandidateCount']! as int,
      consolidatedGroupCount: json['consolidatedGroupCount']! as int,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BeliefConsolidation &&
          _listEquals(candidates, other.candidates) &&
          _listEquals(beliefs, other.beliefs) &&
          isolatedCandidateCount == other.isolatedCandidateCount &&
          consolidatedGroupCount == other.consolidatedGroupCount;

  @override
  int get hashCode => Object.hash(
    Object.hashAll(candidates),
    Object.hashAll(beliefs),
    isolatedCandidateCount,
    consolidatedGroupCount,
  );
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
