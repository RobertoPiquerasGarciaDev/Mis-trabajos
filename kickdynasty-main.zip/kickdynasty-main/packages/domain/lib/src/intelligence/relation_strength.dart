/// Fuerza actual de una relación (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Peso subjetivo de la relación en la mente del observador.
extension type const RelationStrength._(double value) {
  /// Crea la fuerza validando el rango 0.0–1.0.
  factory RelationStrength(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'RelationStrength debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return RelationStrength._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static RelationStrength fromJson(num json) =>
      RelationStrength(json.toDouble());
}
