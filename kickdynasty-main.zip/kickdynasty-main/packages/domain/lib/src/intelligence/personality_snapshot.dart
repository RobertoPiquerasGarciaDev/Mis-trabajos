/// Instantánea congelada de personalidad al crear [AgentMind] (PF-2).
library;

import 'package:kickdynasty_domain/src/person/person.dart';
import 'package:kickdynasty_domain/src/person/personality_profile.dart';
import 'package:meta/meta.dart';

/// Copia inmutable de rasgos de personalidad en el momento del nacimiento cognitivo.
@immutable
final class PersonalitySnapshot {
  /// Crea la instantánea desde un [PersonalityProfile].
  const PersonalitySnapshot({required this.profile});

  /// Perfil congelado.
  final PersonalityProfile profile;

  /// Construye desde una [Person] existente.
  factory PersonalitySnapshot.fromPerson(Person person) =>
      PersonalitySnapshot(profile: person.personality);

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {'profile': profile.toJson()};

  /// Deserializa desde JSON.
  factory PersonalitySnapshot.fromJson(Map<String, Object?> json) =>
      PersonalitySnapshot(
        profile: PersonalityProfile.fromJson(
          Map<String, Object?>.from(json['profile']! as Map),
        ),
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PersonalitySnapshot && profile == other.profile;

  @override
  int get hashCode => profile.hashCode;
}
