/// Candidato a creencia antes de consolidación (PF-7).
library;

import 'package:kickdynasty_domain/src/intelligence/belief_category.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_confidence.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_type.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_id.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Hipótesis interpretativa aún no consolidada como creencia fuerte.
@immutable
final class BeliefCandidate {
  /// Crea el candidato.
  const BeliefCandidate({
    required this.observerPersonId,
    required this.sourceInterpretationId,
    required this.type,
    required this.category,
    required this.summary,
    required this.tentativeConfidence,
    required this.tentativeStrength,
    required this.consolidationKey,
    required this.createdAt,
  });

  /// Persona que podría adoptar la creencia.
  final PersonId observerPersonId;

  /// Interpretación origen — nunca Reality.
  final InterpretationId sourceInterpretationId;

  /// Tipo proyectado de creencia.
  final BeliefType type;

  /// Categoría organizativa.
  final BeliefCategory category;

  /// Enunciado subjetivo propuesto.
  final String summary;

  /// Confianza tentativa antes de consolidar.
  final BeliefConfidence tentativeConfidence;

  /// Fuerza tentativa antes de consolidar.
  final BeliefStrength tentativeStrength;

  /// Clave de agrupación para consolidación coherente.
  final String consolidationKey;

  /// Momento de creación del candidato.
  final MemoryTimestamp createdAt;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'observerPersonId': observerPersonId.value,
    'sourceInterpretationId': sourceInterpretationId.value,
    'type': type.name,
    'category': category.name,
    'summary': summary,
    'tentativeConfidence': tentativeConfidence.toJson(),
    'tentativeStrength': tentativeStrength.toJson(),
    'consolidationKey': consolidationKey,
    'createdAt': createdAt.toJson(),
  };

  /// Deserializa desde JSON.
  factory BeliefCandidate.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('BeliefCandidate JSON v$version no soportada');
    }
    return BeliefCandidate(
      observerPersonId: PersonId(json['observerPersonId']! as String),
      sourceInterpretationId: InterpretationId(
        json['sourceInterpretationId']! as String,
      ),
      type: BeliefType.values.byName(json['type']! as String),
      category: BeliefCategory.values.byName(json['category']! as String),
      summary: json['summary']! as String,
      tentativeConfidence: BeliefConfidence.fromJson(
        json['tentativeConfidence']! as num,
      ),
      tentativeStrength: BeliefStrength.fromJson(
        json['tentativeStrength']! as num,
      ),
      consolidationKey: json['consolidationKey']! as String,
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BeliefCandidate &&
          observerPersonId == other.observerPersonId &&
          sourceInterpretationId == other.sourceInterpretationId &&
          type == other.type &&
          category == other.category &&
          summary == other.summary &&
          tentativeConfidence == other.tentativeConfidence &&
          tentativeStrength == other.tentativeStrength &&
          consolidationKey == other.consolidationKey &&
          createdAt == other.createdAt;

  @override
  int get hashCode => Object.hash(
    observerPersonId,
    sourceInterpretationId,
    type,
    category,
    summary,
    tentativeConfidence,
    tentativeStrength,
    consolidationKey,
    createdAt,
  );
}
