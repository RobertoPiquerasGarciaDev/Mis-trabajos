/// Fuerza subjetiva de una intención (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Intensidad de la postura provisional.
extension type const IntentionStrength._(double value) {
  /// Crea la fuerza validando el rango 0.0–1.0.
  factory IntentionStrength(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'IntentionStrength debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return IntentionStrength._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static IntentionStrength fromJson(num json) =>
      IntentionStrength(json.toDouble());
}
