/// Estado de una intención cognitiva (PF-9).
library;

/// Ciclo de vida subjetivo de la postura provisional.
enum IntentionStatus {
  /// Postura activa.
  active,

  /// Postura latente.
  dormant,

  /// Diferimiento explícito.
  deferred,
}
