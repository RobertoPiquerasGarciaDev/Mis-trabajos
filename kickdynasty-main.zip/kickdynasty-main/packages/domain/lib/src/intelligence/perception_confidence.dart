/// Certeza subjetiva de un hecho percibido (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Confianza subjetiva en un dato percibido.
extension type const PerceptionConfidence._(double value) {
  /// Crea la confianza validando el rango 0.0–1.0.
  factory PerceptionConfidence(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'PerceptionConfidence debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return PerceptionConfidence._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static PerceptionConfidence fromJson(num json) =>
      PerceptionConfidence(json.toDouble());
}
