/// Hipótesis interpretativa individual (PF-6).
library;

import 'package:kickdynasty_domain/src/intelligence/interpretation_bias.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_confidence.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_id.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_importance.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_source.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_type.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_id.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Claves prohibidas — interpretación no almacena Reality ni decisiones.
const forbiddenInterpretationKeys = {
  'potential',
  'attributes',
  'overall',
  'ovr',
  'salary',
  'fitness',
  'morale',
  'decision',
  'goal',
  'action',
  'mandate',
  'worldSeed',
};

/// Significado subjetivo atribuido a inputs percibidos — nunca un hecho.
@immutable
final class InterpretationEntry {
  /// Crea la interpretación.
  const InterpretationEntry({
    required this.id,
    required this.observerPersonId,
    required this.sourceMemoryIds,
    required this.sourceRelationIds,
    required this.type,
    required this.confidence,
    required this.importance,
    required this.createdAt,
    required this.expiresAt,
    required this.biasApplied,
    required this.summary,
    required this.source,
  });

  /// Identificador estable.
  final InterpretationId id;

  /// Persona que atribuye el significado.
  final PersonId observerPersonId;

  /// Recuerdos que alimentaron la hipótesis.
  final List<MemoryId> sourceMemoryIds;

  /// Objetivos relacionales referenciados (`targetPersonId`).
  final List<String> sourceRelationIds;

  /// Clasificación del significado.
  final InterpretationType type;

  /// Certeza subjetiva.
  final InterpretationConfidence confidence;

  /// Peso subjetivo.
  final InterpretationImportance importance;

  /// Momento de creación.
  final MemoryTimestamp createdAt;

  /// Caducidad (`null` = sin expiración en PF-6).
  final MemoryTimestamp? expiresAt;

  /// Sesgo aplicado al formar la hipótesis.
  final InterpretationBias biasApplied;

  /// Narrativa interna legible — hipótesis, no decisión.
  final String summary;

  /// Procedencia cognitiva.
  final InterpretationSource source;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id.value,
    'observerPersonId': observerPersonId.value,
    'sourceMemoryIds': [for (final mid in sourceMemoryIds) mid.value],
    'sourceRelationIds': sourceRelationIds,
    'type': type.name,
    'confidence': confidence.toJson(),
    'importance': importance.toJson(),
    'createdAt': createdAt.toJson(),
    if (expiresAt != null) 'expiresAt': expiresAt!.toJson(),
    'biasApplied': biasApplied.name,
    'summary': summary,
    'source': source.name,
  };

  /// Deserializa desde JSON.
  factory InterpretationEntry.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('InterpretationEntry JSON v$version no soportada');
    }
    return InterpretationEntry(
      id: InterpretationId(json['id']! as String),
      observerPersonId: PersonId(json['observerPersonId']! as String),
      sourceMemoryIds: [
        for (final id in json['sourceMemoryIds']! as List)
          MemoryId(id as String),
      ],
      sourceRelationIds: [
        for (final id in json['sourceRelationIds']! as List) id as String,
      ],
      type: InterpretationType.values.byName(json['type']! as String),
      confidence: InterpretationConfidence.fromJson(json['confidence']! as num),
      importance: InterpretationImportance.fromJson(json['importance']! as num),
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
      expiresAt: json['expiresAt'] == null
          ? null
          : MemoryTimestamp.fromJson(
              Map<String, Object?>.from(json['expiresAt']! as Map),
            ),
      biasApplied: InterpretationBias.values.byName(
        json['biasApplied']! as String,
      ),
      summary: json['summary']! as String,
      source: InterpretationSource.values.byName(json['source']! as String),
    );
  }

  /// `true` si no contiene claves prohibidas ni lenguaje de decisión.
  bool get passesNonRealityCheck =>
      !containsForbiddenInterpretationKeys(toJson()) &&
      !_looksLikeDecision(summary);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is InterpretationEntry &&
          id == other.id &&
          observerPersonId == other.observerPersonId &&
          _listEquals(sourceMemoryIds, other.sourceMemoryIds) &&
          _listEquals(sourceRelationIds, other.sourceRelationIds) &&
          type == other.type &&
          confidence == other.confidence &&
          importance == other.importance &&
          createdAt == other.createdAt &&
          expiresAt == other.expiresAt &&
          biasApplied == other.biasApplied &&
          summary == other.summary &&
          source == other.source;

  @override
  int get hashCode => Object.hash(
    id,
    observerPersonId,
    Object.hashAll(sourceMemoryIds),
    Object.hashAll(sourceRelationIds),
    type,
    confidence,
    importance,
    createdAt,
    expiresAt,
    biasApplied,
    summary,
    source,
  );
}

/// Escanea recursivamente un mapa JSON buscando claves prohibidas.
bool containsForbiddenInterpretationKeys(Map<String, Object?> json) {
  for (final entry in json.entries) {
    if (forbiddenInterpretationKeys.contains(entry.key)) return true;
    final value = entry.value;
    if (value is Map &&
        containsForbiddenInterpretationKeys(Map<String, Object?>.from(value))) {
      return true;
    }
    if (value is List) {
      for (final item in value) {
        if (item is Map &&
            containsForbiddenInterpretationKeys(
              Map<String, Object?>.from(item),
            )) {
          return true;
        }
      }
    }
  }
  return false;
}

bool _looksLikeDecision(String summary) {
  final lower = summary.toLowerCase();
  return lower.contains('decidir') ||
      lower.contains('fichar') ||
      lower.contains('vender') ||
      lower.contains('execute');
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
