/// Profundidad de tick cognitivo (PF-2: ambos no-op).
library;

/// Profundidad del ciclo cognitivo semanal.
enum AgentMindTickDepth {
  /// Tick superficial — sin procesamiento en PF-2.
  shallow,

  /// Tick profundo — reservado para fases posteriores.
  deep,
}
