/// Prioridad subjetiva de un objetivo (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Peso relativo de la motivación — sin resolución de conflictos en PF-8.
extension type const GoalPriority._(double value) {
  /// Crea la prioridad validando el rango 0.0–1.0.
  factory GoalPriority(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'GoalPriority debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return GoalPriority._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static GoalPriority fromJson(num json) => GoalPriority(json.toDouble());
}
