/// Certeza subjetiva de una interpretación (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Confianza en la hipótesis interpretativa.
extension type const InterpretationConfidence._(double value) {
  /// Crea la confianza validando el rango 0.0–1.0.
  factory InterpretationConfidence(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'InterpretationConfidence debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return InterpretationConfidence._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static InterpretationConfidence fromJson(num json) =>
      InterpretationConfidence(json.toDouble());
}
