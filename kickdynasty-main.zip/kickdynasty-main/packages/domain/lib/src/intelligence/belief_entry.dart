/// Creencia subjetiva individual (PF-7).
library;

import 'package:kickdynasty_domain/src/intelligence/belief_category.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_confidence.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_id.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_origin.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_type.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_id.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Claves prohibidas — creencias no almacenan Reality ni decisiones.
const forbiddenBeliefKeys = {
  'potential',
  'attributes',
  'overall',
  'ovr',
  'salary',
  'fitness',
  'morale',
  'decision',
  'goal',
  'action',
  'mandate',
  'worldSeed',
  'player',
  'reality',
};

/// Lo que una persona cree cierto — nunca un hecho de Reality.
@immutable
final class BeliefEntry {
  /// Crea la creencia.
  const BeliefEntry({
    required this.id,
    required this.observerPersonId,
    required this.type,
    required this.category,
    required this.summary,
    required this.confidence,
    required this.strength,
    required this.origin,
    required this.sourceInterpretationIds,
    required this.createdAt,
    required this.updatedAt,
    required this.lastConfirmed,
    required this.contradictoryBeliefIds,
  });

  /// Identificador estable.
  final BeliefId id;

  /// Persona que sostiene la creencia.
  final PersonId observerPersonId;

  /// Clasificación de la creencia.
  final BeliefType type;

  /// Ámbito organizativo.
  final BeliefCategory category;

  /// Enunciado subjetivo — no acción.
  final String summary;

  /// Certeza subjetiva.
  final BeliefConfidence confidence;

  /// Peso cognitivo.
  final BeliefStrength strength;

  /// Procedencia epistémica.
  final BeliefOrigin origin;

  /// Interpretaciones que alimentaron la creencia.
  final List<InterpretationId> sourceInterpretationIds;

  /// Momento de creación.
  final MemoryTimestamp createdAt;

  /// Última actualización.
  final MemoryTimestamp updatedAt;

  /// Última confirmación subjetiva.
  final MemoryTimestamp lastConfirmed;

  /// Creencias en tensión epistémica.
  final List<BeliefId> contradictoryBeliefIds;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id.value,
    'observerPersonId': observerPersonId.value,
    'type': type.name,
    'category': category.name,
    'summary': summary,
    'confidence': confidence.toJson(),
    'strength': strength.toJson(),
    'origin': origin.name,
    'sourceInterpretationIds': [
      for (final iid in sourceInterpretationIds) iid.value,
    ],
    'createdAt': createdAt.toJson(),
    'updatedAt': updatedAt.toJson(),
    'lastConfirmed': lastConfirmed.toJson(),
    'contradictoryBeliefIds': [
      for (final bid in contradictoryBeliefIds) bid.value,
    ],
  };

  /// Deserializa desde JSON.
  factory BeliefEntry.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('BeliefEntry JSON v$version no soportada');
    }
    return BeliefEntry(
      id: BeliefId(json['id']! as String),
      observerPersonId: PersonId(json['observerPersonId']! as String),
      type: BeliefType.values.byName(json['type']! as String),
      category: BeliefCategory.values.byName(json['category']! as String),
      summary: json['summary']! as String,
      confidence: BeliefConfidence.fromJson(json['confidence']! as num),
      strength: BeliefStrength.fromJson(json['strength']! as num),
      origin: BeliefOrigin.values.byName(json['origin']! as String),
      sourceInterpretationIds: [
        for (final id in json['sourceInterpretationIds']! as List)
          InterpretationId(id as String),
      ],
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
      updatedAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['updatedAt']! as Map),
      ),
      lastConfirmed: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['lastConfirmed']! as Map),
      ),
      contradictoryBeliefIds: [
        for (final id in json['contradictoryBeliefIds']! as List)
          BeliefId(id as String),
      ],
    );
  }

  /// `true` si no contiene claves prohibidas ni lenguaje de acción.
  bool get passesNonRealityCheck =>
      !containsForbiddenBeliefKeys(toJson()) && !_looksLikeAction(summary);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BeliefEntry &&
          id == other.id &&
          observerPersonId == other.observerPersonId &&
          type == other.type &&
          category == other.category &&
          summary == other.summary &&
          confidence == other.confidence &&
          strength == other.strength &&
          origin == other.origin &&
          _listEquals(sourceInterpretationIds, other.sourceInterpretationIds) &&
          createdAt == other.createdAt &&
          updatedAt == other.updatedAt &&
          lastConfirmed == other.lastConfirmed &&
          _listEquals(contradictoryBeliefIds, other.contradictoryBeliefIds);

  @override
  int get hashCode => Object.hash(
    id,
    observerPersonId,
    type,
    category,
    summary,
    confidence,
    strength,
    origin,
    Object.hashAll(sourceInterpretationIds),
    createdAt,
    updatedAt,
    lastConfirmed,
    Object.hashAll(contradictoryBeliefIds),
  );
}

/// Escanea recursivamente un mapa JSON buscando claves prohibidas.
bool containsForbiddenBeliefKeys(Map<String, Object?> json) {
  for (final entry in json.entries) {
    if (forbiddenBeliefKeys.contains(entry.key)) return true;
    final value = entry.value;
    if (value is Map &&
        containsForbiddenBeliefKeys(Map<String, Object?>.from(value))) {
      return true;
    }
    if (value is List) {
      for (final item in value) {
        if (item is Map &&
            containsForbiddenBeliefKeys(Map<String, Object?>.from(item))) {
          return true;
        }
      }
    }
  }
  return false;
}

bool _looksLikeAction(String summary) {
  final lower = summary.toLowerCase();
  return lower.contains('decidir') ||
      lower.contains('fichar') ||
      lower.contains('vender') ||
      lower.contains('execute') ||
      lower.contains('debo ');
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
