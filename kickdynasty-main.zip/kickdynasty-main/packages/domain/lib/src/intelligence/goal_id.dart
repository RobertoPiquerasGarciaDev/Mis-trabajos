/// Identificador estable de un objetivo cognitivo (PF-8).
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de una [GoalEntry].
extension type const GoalId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory GoalId(String value) => GoalId._(checkNotBlank(value, 'GoalId'));
}
