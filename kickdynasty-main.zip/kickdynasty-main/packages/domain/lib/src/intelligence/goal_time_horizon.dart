/// Horizonte temporal de un objetivo (PF-8).
library;

/// Alcance temporal subjetivo — sin planificación en PF-8.
enum GoalTimeHorizon {
  /// Corto plazo.
  shortTerm,

  /// Medio plazo.
  mediumTerm,

  /// Largo plazo.
  longTerm,

  /// Sin horizonte definido.
  permanent,
}
