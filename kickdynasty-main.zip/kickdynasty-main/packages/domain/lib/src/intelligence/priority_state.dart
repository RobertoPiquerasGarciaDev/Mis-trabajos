/// Contenedor de prioridades en [AgentMind] (PF-9).
library;

import 'package:kickdynasty_domain/src/intelligence/priority_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_entry.dart';
import 'package:meta/meta.dart';

/// Estado de prioridades temporales — subjetivas, no Reality.
@immutable
final class PriorityState {
  /// Estado vacío (pre-PF-9).
  const PriorityState.empty() : collection = const PriorityCollection.empty();

  /// Crea el estado con la colección.
  const PriorityState({required this.collection});

  /// Colección de prioridades.
  final PriorityCollection collection;

  /// Entradas accesibles.
  List<PriorityEntry> get entries => collection.entries;

  /// Serializa a JSON (versión 2).
  Map<String, Object?> toJson() => {'v': 2, 'collection': collection.toJson()};

  /// Deserializa desde JSON.
  factory PriorityState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version > 2) {
      throw FormatException('PriorityState JSON v$version no soportada');
    }
    if (version == 1) {
      return const PriorityState.empty();
    }
    return PriorityState(
      collection: PriorityCollection.fromJson(
        Map<String, Object?>.from(json['collection']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PriorityState && collection == other.collection;

  @override
  int get hashCode => collection.hashCode;
}
