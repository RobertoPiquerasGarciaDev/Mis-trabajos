/// Categoría organizativa de creencias (PF-7 — sin efecto en comportamiento).
library;

/// Ámbito cognitivo al que pertenece una creencia.
enum BeliefCategory {
  /// Creencias sobre uno mismo.
  self,

  /// Creencias sobre otra persona.
  otherPerson,

  /// Creencias sobre el club.
  club,

  /// Creencias sobre la competición.
  competition,

  /// Creencias sobre la carrera profesional.
  career,

  /// Creencias sobre el mundo / entorno.
  world,
}
