/// Certeza subjetiva sobre una relación (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Cuánto cree el observador que conoce al objetivo.
extension type const RelationConfidence._(double value) {
  /// Crea la confianza validando el rango 0.0–1.0.
  factory RelationConfidence(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'RelationConfidence debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return RelationConfidence._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static RelationConfidence fromJson(num json) =>
      RelationConfidence(json.toDouble());
}
