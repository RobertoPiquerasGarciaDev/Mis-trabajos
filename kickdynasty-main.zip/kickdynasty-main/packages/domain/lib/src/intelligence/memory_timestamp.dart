/// Marca temporal de un recuerdo (temporada + jornada).
library;

import 'package:meta/meta.dart';

/// Cuándo fue percibido o recordado por última vez.
@immutable
final class MemoryTimestamp {
  /// Crea la marca temporal.
  const MemoryTimestamp({required this.season, required this.week});

  /// Temporada.
  final int season;

  /// Jornada.
  final int week;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {'season': season, 'week': week};

  /// Deserializa desde JSON.
  factory MemoryTimestamp.fromJson(Map<String, Object?> json) =>
      MemoryTimestamp(
        season: json['season']! as int,
        week: json['week']! as int,
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MemoryTimestamp && season == other.season && week == other.week;

  @override
  int get hashCode => Object.hash(season, week);
}
