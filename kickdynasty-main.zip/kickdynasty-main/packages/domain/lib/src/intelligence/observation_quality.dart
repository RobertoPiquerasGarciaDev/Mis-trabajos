/// Calidad de la observación (0–100).
library;

import 'package:kickdynasty_domain/src/person/trait_score.dart';
import 'package:meta/meta.dart';

/// Calidad técnica de la observación — sin lógica de sesgo.
@immutable
final class ObservationQuality {
  /// Crea la calidad a partir de un [TraitScore].
  const ObservationQuality(this.score);

  /// Puntuación 0–100.
  final TraitScore score;

  /// Serializa a JSON.
  int toJson() => score.value;

  /// Deserializa desde JSON.
  factory ObservationQuality.fromJson(int json) =>
      ObservationQuality(TraitScore(json));

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ObservationQuality && score == other.score;

  @override
  int get hashCode => score.hashCode;
}
