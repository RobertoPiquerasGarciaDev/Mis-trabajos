/// Procedencia de una decisión cognitiva (PF-10).
library;

/// Cómo se formó el compromiso.
enum DecisionOrigin {
  /// Consolidación directa desde intención interna.
  internalConsolidation,

  /// Resolución de protocolo social.
  socialProtocol,
}
