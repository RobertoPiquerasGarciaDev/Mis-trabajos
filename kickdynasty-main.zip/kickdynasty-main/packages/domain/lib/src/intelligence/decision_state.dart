/// Contenedor de decisiones en [AgentMind] (PF-10).
library;

import 'package:kickdynasty_domain/src/intelligence/decision_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/decision_entry.dart';
import 'package:meta/meta.dart';

/// Estado de decisiones cognitivas — subjetivas, no Reality.
@immutable
final class DecisionState {
  /// Estado vacío (pre-PF-10).
  const DecisionState.empty() : collection = const DecisionCollection.empty();

  /// Crea el estado con la colección.
  const DecisionState({required this.collection});

  /// Colección de decisiones.
  final DecisionCollection collection;

  /// Entradas accesibles.
  List<DecisionEntry> get entries => collection.entries;

  /// Serializa a JSON (versión 2).
  Map<String, Object?> toJson() => {'v': 2, 'collection': collection.toJson()};

  /// Deserializa desde JSON.
  factory DecisionState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version > 2) {
      throw FormatException('DecisionState JSON v$version no soportada');
    }
    if (version == 1) {
      return const DecisionState.empty();
    }
    return DecisionState(
      collection: DecisionCollection.fromJson(
        Map<String, Object?>.from(json['collection']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DecisionState && collection == other.collection;

  @override
  int get hashCode => collection.hashCode;
}
