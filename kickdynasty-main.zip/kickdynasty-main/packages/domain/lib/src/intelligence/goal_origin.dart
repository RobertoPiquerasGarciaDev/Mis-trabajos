/// Procedencia de un objetivo (PF-8).
library;

/// Cómo se formó la motivación — nunca desde Reality directa.
enum GoalOrigin {
  /// Derivado principalmente de una creencia.
  beliefDerived,

  /// Modulado por rasgos de personalidad.
  personalityModulated,

  /// Modulado por valores personales.
  valuesModulated,

  /// Modulado por filosofía personal.
  philosophyModulated,
}
