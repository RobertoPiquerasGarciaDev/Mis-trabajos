/// Procedencia de una interpretación (PF-6).
library;

/// De qué capa cognitiva se derivó la hipótesis.
enum InterpretationSource {
  /// Solo percepción.
  perception,

  /// Solo memoria episódica.
  memory,

  /// Solo relaciones.
  relation,

  /// Combinación de capas.
  combined,
}
