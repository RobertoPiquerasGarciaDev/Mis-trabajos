/// Contexto de entrada para deliberación social (PF-10).
library;

import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/emotional_state.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/personality_snapshot.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_state.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:kickdynasty_domain/src/person/person.dart';
import 'package:meta/meta.dart';

/// Instantánea de insumos — nunca incluye Reality ni gameplay.
@immutable
final class SocialDeliberationContext {
  /// Crea el contexto de deliberación social.
  const SocialDeliberationContext({
    required this.proponent,
    required this.intentions,
    required this.priorities,
    required this.beliefs,
    required this.memory,
    required this.relations,
    required this.personality,
    required this.emotion,
    required this.clubId,
    required this.clubPersons,
    required this.worldSeed,
    required this.season,
    required this.week,
  });

  /// Persona que impulsa la deliberación.
  final Person proponent;

  /// Intenciones vigentes del proponente.
  final IntentionCollection intentions;

  /// Prioridades del ciclo.
  final PriorityCollection priorities;

  /// Creencias vigentes.
  final BeliefCollection beliefs;

  /// Memoria episódica.
  final MemoryCollection memory;

  /// Relaciones subjetivas.
  final RelationState relations;

  /// Personalidad congelada.
  final PersonalitySnapshot personality;

  /// Estado emocional.
  final EmotionalState emotion;

  /// Club afectado (`null` si no aplica).
  final ClubId? clubId;

  /// Personas del mismo club (para posturas de participantes).
  final List<Person> clubPersons;

  /// Semilla del mundo.
  final int worldSeed;

  /// Temporada del ciclo.
  final int season;

  /// Jornada del ciclo.
  final int week;
}

/// Postura de un participante disponible para protocolo social.
@immutable
final class SocialParticipantProfile {
  /// Crea el perfil mínimo de un participante.
  const SocialParticipantProfile({
    required this.person,
    required this.personality,
    required this.emotion,
  });

  /// Persona participante.
  final Person person;

  /// Personalidad congelada.
  final PersonalitySnapshot personality;

  /// Estado emocional.
  final EmotionalState emotion;
}

/// Perfiles de participantes indexados por persona.
typedef SocialParticipantIndex = Map<PersonId, SocialParticipantProfile>;
