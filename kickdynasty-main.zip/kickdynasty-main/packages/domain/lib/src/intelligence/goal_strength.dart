/// Fuerza subjetiva de un objetivo (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Intensidad de la motivación.
extension type const GoalStrength._(double value) {
  /// Crea la fuerza validando el rango 0.0–1.0.
  factory GoalStrength(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'GoalStrength debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return GoalStrength._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static GoalStrength fromJson(num json) => GoalStrength(json.toDouble());
}
