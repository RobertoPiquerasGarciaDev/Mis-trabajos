/// Identificador estable de una interpretación subjetiva (PF-6).
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de una [InterpretationEntry].
extension type const InterpretationId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory InterpretationId(String value) =>
      InterpretationId._(checkNotBlank(value, 'InterpretationId'));
}
