/// Identificador estable de un recuerdo episódico (PF-4).
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de una [MemoryEntry].
extension type const MemoryId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory MemoryId(String value) =>
      MemoryId._(checkNotBlank(value, 'MemoryId'));
}
