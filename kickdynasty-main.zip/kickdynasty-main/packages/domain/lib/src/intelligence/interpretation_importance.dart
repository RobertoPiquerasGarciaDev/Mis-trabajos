/// Importancia subjetiva de una interpretación (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Cuánto pesa la hipótesis para el observador.
extension type const InterpretationImportance._(double value) {
  /// Crea la importancia validando el rango 0.0–1.0.
  factory InterpretationImportance(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'InterpretationImportance debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return InterpretationImportance._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static InterpretationImportance fromJson(num json) =>
      InterpretationImportance(json.toDouble());
}
