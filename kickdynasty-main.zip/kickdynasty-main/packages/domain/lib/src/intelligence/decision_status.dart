/// Estado de una decisión cognitiva (PF-10).
library;

/// Ciclo de vida del compromiso mental.
enum DecisionStatus {
  /// Compromiso activo.
  committed,

  /// Diferido — sin compromiso firme.
  deferred,

  /// Supersedido por una decisión posterior.
  superseded,
}
