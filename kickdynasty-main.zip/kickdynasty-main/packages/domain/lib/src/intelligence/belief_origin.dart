/// Procedencia epistémica de una creencia (PF-7).
library;

/// Cómo se formó la creencia — nunca desde Reality directa.
enum BeliefOrigin {
  /// Una sola interpretación aislada (confianza limitada).
  isolatedInterpretation,

  /// Varias interpretaciones coherentes consolidadas.
  consolidatedInterpretations,

  /// Reforzada por relaciones subjetivas (PF-7+: infraestructura).
  relationReinforced,

  /// Reforzada por recuerdos alineados (PF-7+: infraestructura).
  memoryReinforced,
}
