/// Colección de decisiones de una persona (PF-10).
library;

import 'package:kickdynasty_domain/src/intelligence/decision_entry.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Conjunto de compromisos cognitivos del ciclo.
@immutable
final class DecisionCollection {
  /// Colección vacía.
  const DecisionCollection.empty({PersonId? ownerId})
    : ownerId = ownerId,
      entries = const [];

  /// Crea la colección con entradas.
  const DecisionCollection({required this.ownerId, required this.entries});

  /// Persona observadora.
  final PersonId? ownerId;

  /// Decisiones activas o diferidas.
  final List<DecisionEntry> entries;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    if (ownerId != null) 'ownerId': ownerId!.value,
    'entries': [for (final entry in entries) entry.toJson()],
  };

  /// Deserializa desde JSON.
  factory DecisionCollection.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('DecisionCollection JSON v$version no soportada');
    }
    return DecisionCollection(
      ownerId: switch (json['ownerId']) {
        null => null,
        final id => PersonId(id as String),
      },
      entries: [
        for (final item in (json['entries'] as List?) ?? const [])
          DecisionEntry.fromJson(Map<String, Object?>.from(item as Map)),
      ],
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DecisionCollection &&
          ownerId == other.ownerId &&
          _listEquals(entries, other.entries);

  @override
  int get hashCode => Object.hash(ownerId, Object.hashAll(entries));
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
