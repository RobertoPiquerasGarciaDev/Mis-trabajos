/// Contenedor de creencias en [AgentMind] (PF-7).
library;

import 'package:kickdynasty_domain/src/intelligence/belief_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/belief_entry.dart';
import 'package:meta/meta.dart';

/// Estado de creencias persistentes — subjetivas, no Reality.
@immutable
final class BeliefState {
  /// Estado vacío (pre-PF-7).
  const BeliefState.empty() : collection = const BeliefCollection.empty();

  /// Crea el estado con la colección.
  const BeliefState({required this.collection});

  /// Colección de creencias.
  final BeliefCollection collection;

  /// Entradas accesibles.
  List<BeliefEntry> get entries => collection.entries;

  /// Serializa a JSON (versión 2).
  Map<String, Object?> toJson() => {'v': 2, 'collection': collection.toJson()};

  /// Deserializa desde JSON.
  factory BeliefState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version > 2) {
      throw FormatException('BeliefState JSON v$version no soportada');
    }
    if (version == 1) {
      return const BeliefState.empty();
    }
    return BeliefState(
      collection: BeliefCollection.fromJson(
        Map<String, Object?>.from(json['collection']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BeliefState && collection == other.collection;

  @override
  int get hashCode => collection.hashCode;
}
