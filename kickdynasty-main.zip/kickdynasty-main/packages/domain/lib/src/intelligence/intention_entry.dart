/// Intención cognitiva individual (PF-9).
library;

import 'package:kickdynasty_domain/src/intelligence/intention_id.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_status.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_type.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_id.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Claves prohibidas — intenciones no almacenan Reality ni decisiones.
const forbiddenIntentionKeys = {
  'potential',
  'attributes',
  'overall',
  'ovr',
  'salary',
  'fitness',
  'morale',
  'decision',
  'action',
  'plan',
  'mandate',
  'utility',
  'worldSeed',
  'player',
  'reality',
  'deliberation',
};

/// Postura provisional — nunca una acción ni una decisión.
@immutable
final class IntentionEntry {
  /// Crea la intención.
  const IntentionEntry({
    required this.id,
    required this.observerPersonId,
    required this.sourcePriorityId,
    required this.type,
    required this.summary,
    required this.strength,
    required this.status,
    required this.createdAt,
    required this.updatedAt,
  });

  /// Identificador estable.
  final IntentionId id;

  /// Persona que sostiene la postura.
  final PersonId observerPersonId;

  /// Prioridad que alimentó la intención.
  final PriorityId sourcePriorityId;

  /// Tipo de postura provisional.
  final IntentionType type;

  /// Enunciado motivacional — no acción.
  final String summary;

  /// Intensidad subjetiva.
  final IntentionStrength strength;

  /// Estado subjetivo.
  final IntentionStatus status;

  /// Momento de creación.
  final MemoryTimestamp createdAt;

  /// Última actualización.
  final MemoryTimestamp updatedAt;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id.value,
    'observerPersonId': observerPersonId.value,
    'sourcePriorityId': sourcePriorityId.value,
    'type': type.name,
    'summary': summary,
    'strength': strength.toJson(),
    'status': status.name,
    'createdAt': createdAt.toJson(),
    'updatedAt': updatedAt.toJson(),
  };

  /// Deserializa desde JSON.
  factory IntentionEntry.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('IntentionEntry JSON v$version no soportada');
    }
    return IntentionEntry(
      id: IntentionId(json['id']! as String),
      observerPersonId: PersonId(json['observerPersonId']! as String),
      sourcePriorityId: PriorityId(json['sourcePriorityId']! as String),
      type: IntentionType.values.byName(json['type']! as String),
      summary: json['summary']! as String,
      strength: IntentionStrength.fromJson(json['strength']! as num),
      status: IntentionStatus.values.byName(json['status']! as String),
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
      updatedAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['updatedAt']! as Map),
      ),
    );
  }

  /// `true` si no contiene claves prohibidas ni lenguaje de acción.
  bool get passesNonRealityCheck =>
      !containsForbiddenIntentionKeys(toJson()) && !_looksLikeAction(summary);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is IntentionEntry &&
          id == other.id &&
          observerPersonId == other.observerPersonId &&
          sourcePriorityId == other.sourcePriorityId &&
          type == other.type &&
          summary == other.summary &&
          strength == other.strength &&
          status == other.status &&
          createdAt == other.createdAt &&
          updatedAt == other.updatedAt;

  @override
  int get hashCode => Object.hash(
    id,
    observerPersonId,
    sourcePriorityId,
    type,
    summary,
    strength,
    status,
    createdAt,
    updatedAt,
  );
}

/// Escanea recursivamente un mapa JSON buscando claves prohibidas.
bool containsForbiddenIntentionKeys(Map<String, Object?> json) {
  for (final entry in json.entries) {
    if (forbiddenIntentionKeys.contains(entry.key)) return true;
    final value = entry.value;
    if (value is Map &&
        containsForbiddenIntentionKeys(Map<String, Object?>.from(value))) {
      return true;
    }
    if (value is List) {
      for (final item in value) {
        if (item is Map &&
            containsForbiddenIntentionKeys(Map<String, Object?>.from(item))) {
          return true;
        }
      }
    }
  }
  return false;
}

bool _looksLikeAction(String summary) {
  final lower = summary.toLowerCase();
  return lower.contains('decidir') ||
      lower.contains('fichar') ||
      lower.contains('vender') ||
      lower.contains('execute') ||
      lower.contains('debo ') ||
      lower.contains('planificar');
}
