/// Infraestructura de decaimiento de recuerdos (PF-4 — sin olvido activo).
library;

import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:meta/meta.dart';

/// Metadatos de olvido futuro — no ejecuta decaimiento en PF-4.
@immutable
final class MemoryDecay {
  /// Crea la infraestructura de decaimiento.
  const MemoryDecay({required this.decayRate, this.lastRecall});

  /// Tasa de decaimiento semanal (0.0–1.0) — reservada para PF-4+.
  final double decayRate;

  /// Última evocación consciente (`null` si nunca).
  final MemoryTimestamp? lastRecall;

  /// Infraestructura por defecto (sin olvido ejecutado).
  static const initial = MemoryDecay(decayRate: 0.0);

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'decayRate': decayRate,
    if (lastRecall != null) 'lastRecall': lastRecall!.toJson(),
  };

  /// Deserializa desde JSON.
  factory MemoryDecay.fromJson(Map<String, Object?> json) => MemoryDecay(
    decayRate: (json['decayRate'] as num?)?.toDouble() ?? 0.0,
    lastRecall: json['lastRecall'] == null
        ? null
        : MemoryTimestamp.fromJson(
            Map<String, Object?>.from(json['lastRecall']! as Map),
          ),
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MemoryDecay &&
          decayRate == other.decayRate &&
          lastRecall == other.lastRecall;

  @override
  int get hashCode => Object.hash(decayRate, lastRecall);
}
