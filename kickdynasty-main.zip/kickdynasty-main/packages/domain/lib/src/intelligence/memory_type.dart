/// Clasificación de recuerdos (PF-4).
library;

/// Tipo de entrada en memoria episódica.
enum MemoryType {
  /// Hecho consolidado desde percepción directa (PF-4).
  perceivedFact,

  /// Episodio narrativo (PF-4+: stub).
  episode,

  /// Señal institucional recordada.
  institutional,

  /// Interacción interpersonal recordada.
  interpersonal,
}
