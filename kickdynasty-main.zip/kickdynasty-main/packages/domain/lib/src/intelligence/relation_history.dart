/// Historial subjetivo de una relación (PF-5 — infraestructura).
library;

import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:meta/meta.dart';

/// Evento en el historial relacional (PF-5+: sin runtime).
@immutable
final class RelationHistoryEvent {
  /// Crea el evento stub.
  const RelationHistoryEvent({
    required this.at,
    required this.kind,
    this.note = '',
  });

  /// Cuándo ocurrió (desde perspectiva del observador).
  final MemoryTimestamp at;

  /// Discriminador del evento (`structural.seed`, …).
  final String kind;

  /// Nota legible sin interpretación.
  final String note;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'at': at.toJson(),
    'kind': kind,
    if (note.isNotEmpty) 'note': note,
  };

  /// Deserializa desde JSON.
  factory RelationHistoryEvent.fromJson(Map<String, Object?> json) =>
      RelationHistoryEvent(
        at: MemoryTimestamp.fromJson(
          Map<String, Object?>.from(json['at']! as Map),
        ),
        kind: json['kind']! as String,
        note: json['note'] as String? ?? '',
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RelationHistoryEvent &&
          at == other.at &&
          kind == other.kind &&
          note == other.note;

  @override
  int get hashCode => Object.hash(at, kind, note);
}

/// Historial append-only de una relación.
@immutable
final class RelationHistory {
  /// Historial vacío.
  const RelationHistory.empty() : events = const [];

  /// Crea el historial con eventos ordenados.
  const RelationHistory({required this.events});

  /// Eventos registrados.
  final List<RelationHistoryEvent> events;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'events': [for (final event in events) event.toJson()],
  };

  /// Deserializa desde JSON.
  factory RelationHistory.fromJson(Map<String, Object?> json) =>
      RelationHistory(
        events: [
          for (final item in (json['events'] as List?) ?? const [])
            RelationHistoryEvent.fromJson(
              Map<String, Object?>.from(item as Map),
            ),
        ],
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RelationHistory && _listEquals(events, other.events);

  @override
  int get hashCode => Object.hashAll(events);
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
