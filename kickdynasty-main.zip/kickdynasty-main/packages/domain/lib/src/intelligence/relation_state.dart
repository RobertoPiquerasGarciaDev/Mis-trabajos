/// Grafo relacional subjetivo de una persona (PF-5).
library;

import 'package:kickdynasty_domain/src/intelligence/relation_entry.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Relaciones dirigidas desde el observador — nunca simétricas ni globales.
@immutable
final class RelationState {
  /// Estado vacío (pre-PF-5).
  const RelationState.empty({PersonId? observerId})
    : observerId = observerId,
      entries = const [];

  /// Crea el estado con entradas ordenadas por objetivo.
  const RelationState({required this.observerId, required this.entries});

  /// Persona observadora dueña del grafo.
  final PersonId? observerId;

  /// Vínculos subjetivos hacia otros agentes.
  final List<RelationEntry> entries;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    if (observerId != null) 'observerId': observerId!.value,
    'entries': [for (final entry in entries) entry.toJson()],
  };

  /// Deserializa desde JSON.
  factory RelationState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('RelationState JSON v$version no soportada');
    }
    return RelationState(
      observerId: switch (json['observerId']) {
        null => null,
        final id => PersonId(id as String),
      },
      entries: [
        for (final item in (json['entries'] as List?) ?? const [])
          RelationEntry.fromJson(Map<String, Object?>.from(item as Map)),
      ],
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RelationState &&
          observerId == other.observerId &&
          _listEquals(entries, other.entries);

  @override
  int get hashCode => Object.hash(observerId, Object.hashAll(entries));
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
