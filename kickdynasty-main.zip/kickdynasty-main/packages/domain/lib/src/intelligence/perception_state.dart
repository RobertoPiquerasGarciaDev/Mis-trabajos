/// Contenedor de fotografías perceptivas en [AgentMind] (PF-3).
library;

import 'package:kickdynasty_domain/src/intelligence/perception_snapshot.dart';
import 'package:meta/meta.dart';

/// Estado de percepción — historial de snapshots (PF-3).
@immutable
final class PerceptionState {
  /// Estado vacío (pre-PF-3 / sin capturas).
  const PerceptionState.empty() : snapshots = const [];

  /// Crea el estado con snapshots ordenados cronológicamente.
  const PerceptionState({required this.snapshots});

  /// Fotografías perceptivas capturadas.
  final List<PerceptionSnapshot> snapshots;

  /// Última fotografía, si existe.
  PerceptionSnapshot? get latest => snapshots.isEmpty ? null : snapshots.last;

  /// Serializa a JSON (versión 2).
  Map<String, Object?> toJson() => {
    'v': 2,
    'snapshots': [for (final s in snapshots) s.toJson()],
  };

  /// Deserializa desde JSON.
  factory PerceptionState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version == 1) {
      return const PerceptionState.empty();
    }
    return PerceptionState(
      snapshots: [
        for (final item in (json['snapshots'] as List?) ?? const [])
          PerceptionSnapshot.fromJson(Map<String, Object?>.from(item as Map)),
      ],
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PerceptionState && _listEquals(snapshots, other.snapshots);

  @override
  int get hashCode => Object.hashAll(snapshots);
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
