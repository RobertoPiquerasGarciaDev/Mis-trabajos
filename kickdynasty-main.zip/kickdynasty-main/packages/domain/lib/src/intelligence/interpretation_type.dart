/// Clasificación de interpretaciones subjetivas (PF-6).
library;

/// Tipo de significado atribuido a un input cognitivo.
enum InterpretationType {
  /// Confianza percibida hacia otro agente.
  trust,

  /// Pérdida de estatus o protagonismo.
  lossOfStatus,

  /// Necesidad de mejora personal.
  needToImprove,

  /// Protección percibida de un superior.
  protection,

  /// Liderazgo reconocido en un par.
  leadership,

  /// Apoyo institucional percibido.
  support,

  /// Cohesión de plantilla.
  squadCohesion,

  /// Claridad de rol propio.
  roleClarity,

  /// Lectura general de un hecho percibido.
  perceivedMeaning,
}
