/// Procedencia epistémica de un hecho percibido (PF-3).
library;

/// Cómo llegó el conocimiento al observador.
enum KnowledgeOrigin {
  /// Experiencia propia directa.
  self,

  /// Informe profesional (scout, médico, analista).
  professional,

  /// Dominio público (resultados, fichajes publicados).
  public,

  /// Señal institucional (directiva, estrategia).
  institutional,

  /// Red social / relacional.
  social,
}
