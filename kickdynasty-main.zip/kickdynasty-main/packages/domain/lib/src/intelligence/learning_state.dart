/// Estado de aprendizaje — inicial vacío en PF-2.
library;

import 'package:meta/meta.dart';

/// Contenedor de aprendizaje acumulado (PF-4+). PF-2: sin experiencia.
@immutable
final class LearningState {
  /// Crea el estado de aprendizaje.
  const LearningState({this.experienceUnits = 0});

  /// Estado inicial PF-2.
  static const initial = LearningState();

  /// Unidades de experiencia acumulada (0 en PF-2).
  final int experienceUnits;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {'v': 1, 'experienceUnits': experienceUnits};

  /// Deserializa desde JSON.
  factory LearningState.fromJson(Map<String, Object?> json) =>
      LearningState(experienceUnits: json['experienceUnits'] as int? ?? 0);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is LearningState && experienceUnits == other.experienceUnits;

  @override
  int get hashCode => experienceUnits.hashCode;
}
