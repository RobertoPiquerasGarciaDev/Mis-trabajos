/// Importancia subjetiva de un recuerdo (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Cuánto importó el hecho en el momento de captura.
extension type const MemoryImportance._(double value) {
  /// Crea la importancia validando el rango 0.0–1.0.
  factory MemoryImportance(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'MemoryImportance debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return MemoryImportance._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static MemoryImportance fromJson(num json) =>
      MemoryImportance(json.toDouble());
}
