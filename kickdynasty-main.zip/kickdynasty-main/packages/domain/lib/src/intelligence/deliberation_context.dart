/// Contexto de entrada para deliberación interna (PF-9).
library;

import 'package:kickdynasty_domain/src/intelligence/belief_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/emotional_state.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/personality_snapshot.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_state.dart';
import 'package:kickdynasty_domain/src/person/person.dart';
import 'package:meta/meta.dart';

/// Instantánea de insumos cognitivos — nunca incluye Reality.
@immutable
final class DeliberationContext {
  /// Crea el contexto de deliberación.
  const DeliberationContext({
    required this.person,
    required this.beliefs,
    required this.goals,
    required this.priorities,
    required this.memory,
    required this.relations,
    required this.personality,
    required this.emotion,
    required this.worldSeed,
    required this.season,
    required this.week,
  });

  /// Persona que delibera.
  final Person person;

  /// Creencias vigentes.
  final BeliefCollection beliefs;

  /// Objetivos persistentes.
  final GoalCollection goals;

  /// Prioridades del ciclo.
  final PriorityCollection priorities;

  /// Memoria episódica.
  final MemoryCollection memory;

  /// Relaciones subjetivas.
  final RelationState relations;

  /// Personalidad congelada.
  final PersonalitySnapshot personality;

  /// Estado emocional.
  final EmotionalState emotion;

  /// Semilla del mundo.
  final int worldSeed;

  /// Temporada del ciclo.
  final int season;

  /// Jornada del ciclo.
  final int week;
}
