/// Fotografía perceptiva de un instante (PF-3).
library;

import 'package:kickdynasty_domain/src/intelligence/perceived_fact.dart';
import 'package:kickdynasty_domain/src/intelligence/perception_source.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Recorte subjetivo del mundo — sin interpretación ni decisión.
@immutable
final class PerceptionSnapshot {
  /// Crea la fotografía perceptiva.
  const PerceptionSnapshot({
    required this.observerId,
    required this.season,
    required this.week,
    required this.facts,
    required this.availableSources,
  });

  /// Persona observadora.
  final PersonId observerId;

  /// Temporada capturada.
  final int season;

  /// Jornada capturada.
  final int week;

  /// Hechos que el observador cree ver.
  final List<PerceivedFact> facts;

  /// Fuentes habilitadas en infraestructura (PF-3: solo directObservation activa).
  final List<PerceptionSource> availableSources;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'observerId': observerId.value,
    'season': season,
    'week': week,
    'facts': [for (final f in facts) f.toJson()],
    'availableSources': [for (final s in availableSources) s.name],
  };

  /// Deserializa desde JSON.
  factory PerceptionSnapshot.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('PerceptionSnapshot JSON v$version no soportada');
    }
    return PerceptionSnapshot(
      observerId: PersonId(json['observerId']! as String),
      season: json['season']! as int,
      week: json['week']! as int,
      facts: [
        for (final item in json['facts']! as List)
          PerceivedFact.fromJson(Map<String, Object?>.from(item as Map)),
      ],
      availableSources: [
        for (final name in json['availableSources']! as List)
          PerceptionSource.values.byName(name as String),
      ],
    );
  }

  /// `true` si el JSON no contiene claves prohibidas de omnisciencia.
  bool get passesNonOmniscienceCheck =>
      !containsForbiddenPerceptionKeys(toJson());

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PerceptionSnapshot &&
          observerId == other.observerId &&
          season == other.season &&
          week == other.week &&
          _listEquals(facts, other.facts) &&
          _listEquals(availableSources, other.availableSources);

  @override
  int get hashCode => Object.hash(
    observerId,
    season,
    week,
    Object.hashAll(facts),
    Object.hashAll(availableSources),
  );
}

/// Claves prohibidas en datos perceptivos (PA real, attrs ocultos, …).
const forbiddenPerceptionKeys = {
  'potential',
  'attributes',
  'worldSeed',
  'personality',
  'belief',
  'memory',
  'thought',
};

/// Escanea recursivamente un mapa JSON buscando claves prohibidas.
bool containsForbiddenPerceptionKeys(Map<String, Object?> json) {
  for (final entry in json.entries) {
    if (forbiddenPerceptionKeys.contains(entry.key)) return true;
    final value = entry.value;
    if (value is Map) {
      if (containsForbiddenPerceptionKeys(Map<String, Object?>.from(value))) {
        return true;
      }
    }
    if (value is List) {
      for (final item in value) {
        if (item is Map &&
            containsForbiddenPerceptionKeys(Map<String, Object?>.from(item))) {
          return true;
        }
      }
    }
  }
  return false;
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
