/// Clasificación de creencias subjetivas (PF-7).
library;

/// Tipo de creencia — lo que la persona considera cierto.
enum BeliefType {
  /// Confianza percibida hacia otro agente.
  trust,

  /// Pérdida de estatus o protagonismo.
  lossOfStatus,

  /// Necesidad de mejora personal.
  selfImprovement,

  /// Protección percibida de un superior.
  protection,

  /// Liderazgo reconocido en un par.
  leadership,

  /// Apoyo institucional percibido.
  institutionalSupport,

  /// Cohesión de plantilla.
  squadCohesion,

  /// Claridad de rol propio.
  roleClarity,

  /// Lectura general del entorno.
  worldView,
}
