/// Identificador estable de una intención cognitiva (PF-9).
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de una [IntentionEntry].
extension type const IntentionId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory IntentionId(String value) =>
      IntentionId._(checkNotBlank(value, 'IntentionId'));
}
