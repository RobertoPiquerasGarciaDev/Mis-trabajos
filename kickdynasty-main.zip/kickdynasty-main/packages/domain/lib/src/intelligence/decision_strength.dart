/// Fuerza subjetiva del compromiso (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Intensidad del compromiso cognitivo.
extension type const DecisionStrength._(double value) {
  /// Crea la fuerza validando el rango 0.0–1.0.
  factory DecisionStrength(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'DecisionStrength debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return DecisionStrength._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static DecisionStrength fromJson(num json) =>
      DecisionStrength(json.toDouble());
}
