/// Clasificación de decisión cognitiva (PF-10).
library;

/// Tipo de compromiso — no acción ejecutada.
enum DecisionType {
  /// Compromiso unilateral sin protocolo social.
  unilateral,

  /// Compromiso tras deliberación social.
  socialResolved,

  /// Diferimiento explícito — sin compromiso firme.
  deferred,
}
