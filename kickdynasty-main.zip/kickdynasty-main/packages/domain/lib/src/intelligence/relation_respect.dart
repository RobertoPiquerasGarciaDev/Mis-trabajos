/// Respeto subjetivo hacia otra persona (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Respeto del observador hacia el objetivo.
extension type const RelationRespect._(double value) {
  /// Crea el respeto validando el rango 0.0–1.0.
  factory RelationRespect(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'RelationRespect debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return RelationRespect._(value);
  }

  /// Respeto pleno (solo relación consigo mismo).
  static RelationRespect get absolute => RelationRespect(1.0);

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static RelationRespect fromJson(num json) => RelationRespect(json.toDouble());
}
