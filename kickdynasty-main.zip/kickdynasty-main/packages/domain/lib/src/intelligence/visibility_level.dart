/// Grado de visibilidad de un sujeto u hecho (PF-3).
library;

/// Cuánto puede ver el observador sobre el sujeto.
enum VisibilityLevel {
  /// No visible / oculto.
  hidden,

  /// Parcialmente visible (datos incompletos).
  partial,

  /// Visible en el ámbito del observador.
  full,
}
