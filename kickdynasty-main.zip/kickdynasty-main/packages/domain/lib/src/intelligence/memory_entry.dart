/// Recuerdo episódico individual (PF-4).
library;

import 'package:kickdynasty_domain/src/intelligence/knowledge_origin.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_decay.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_id.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_importance.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_type.dart';
import 'package:kickdynasty_domain/src/intelligence/perception_confidence.dart';
import 'package:kickdynasty_domain/src/intelligence/perception_source.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Lo que una persona recuerda — nunca un hecho de Reality ni Chronicle.
@immutable
final class MemoryEntry {
  /// Crea una entrada de memoria.
  const MemoryEntry({
    required this.id,
    required this.ownerId,
    required this.type,
    required this.whatHappened,
    required this.subjectId,
    required this.involvedPersonIds,
    required this.perceivedAt,
    required this.source,
    required this.origin,
    required this.confidenceAtCapture,
    required this.importance,
    required this.strength,
    required this.decay,
    required this.factKey,
    required this.perceivedValue,
  });

  /// Identificador estable del recuerdo.
  final MemoryId id;

  /// Persona que posee el recuerdo.
  final PersonId ownerId;

  /// Clasificación del recuerdo.
  final MemoryType type;

  /// Descripción literal de lo recordado (sin interpretación).
  final String whatHappened;

  /// Sujeto principal implicado (`playerId`, `clubId`, …).
  final String subjectId;

  /// Personas implicadas identificables.
  final List<PersonId> involvedPersonIds;

  /// Cuándo fue percibido por primera vez.
  final MemoryTimestamp perceivedAt;

  /// Fuente perceptiva original.
  final PerceptionSource source;

  /// Procedencia epistémica original.
  final KnowledgeOrigin origin;

  /// Confianza subjetiva en el momento de captura.
  final PerceptionConfidence confidenceAtCapture;

  /// Importancia subjetiva en captura.
  final MemoryImportance importance;

  /// Fuerza actual del recuerdo.
  final MemoryStrength strength;

  /// Infraestructura de olvido (sin ejecución en PF-4).
  final MemoryDecay decay;

  /// Clave canónica del hecho percibido origen.
  final String factKey;

  /// Valor percibido origen.
  final String perceivedValue;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id.value,
    'ownerId': ownerId.value,
    'type': type.name,
    'whatHappened': whatHappened,
    'subjectId': subjectId,
    'involvedPersonIds': [for (final p in involvedPersonIds) p.value],
    'perceivedAt': perceivedAt.toJson(),
    'source': source.name,
    'origin': origin.name,
    'confidenceAtCapture': confidenceAtCapture.toJson(),
    'importance': importance.toJson(),
    'strength': strength.toJson(),
    'decay': decay.toJson(),
    'factKey': factKey,
    'perceivedValue': perceivedValue,
  };

  /// Deserializa desde JSON.
  factory MemoryEntry.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('MemoryEntry JSON v$version no soportada');
    }
    return MemoryEntry(
      id: MemoryId(json['id']! as String),
      ownerId: PersonId(json['ownerId']! as String),
      type: MemoryType.values.byName(json['type']! as String),
      whatHappened: json['whatHappened']! as String,
      subjectId: json['subjectId']! as String,
      involvedPersonIds: [
        for (final id in json['involvedPersonIds']! as List)
          PersonId(id as String),
      ],
      perceivedAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['perceivedAt']! as Map),
      ),
      source: PerceptionSource.values.byName(json['source']! as String),
      origin: KnowledgeOrigin.values.byName(json['origin']! as String),
      confidenceAtCapture: PerceptionConfidence.fromJson(
        json['confidenceAtCapture']! as num,
      ),
      importance: MemoryImportance.fromJson(json['importance']! as num),
      strength: MemoryStrength.fromJson(json['strength']! as num),
      decay: MemoryDecay.fromJson(
        Map<String, Object?>.from(json['decay']! as Map),
      ),
      factKey: json['factKey']! as String,
      perceivedValue: json['perceivedValue']! as String,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is MemoryEntry &&
          id == other.id &&
          ownerId == other.ownerId &&
          type == other.type &&
          whatHappened == other.whatHappened &&
          subjectId == other.subjectId &&
          _listEquals(involvedPersonIds, other.involvedPersonIds) &&
          perceivedAt == other.perceivedAt &&
          source == other.source &&
          origin == other.origin &&
          confidenceAtCapture == other.confidenceAtCapture &&
          importance == other.importance &&
          strength == other.strength &&
          decay == other.decay &&
          factKey == other.factKey &&
          perceivedValue == other.perceivedValue;

  @override
  int get hashCode => Object.hash(
    id,
    ownerId,
    type,
    whatHappened,
    subjectId,
    Object.hashAll(involvedPersonIds),
    perceivedAt,
    source,
    origin,
    confidenceAtCapture,
    importance,
    strength,
    decay,
    factKey,
    perceivedValue,
  );
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
