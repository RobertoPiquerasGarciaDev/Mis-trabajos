/// Antigüedad de un dato percibido en semanas.
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Edad del dato en semanas (0 = observación actual).
extension type const PerceptionAge._(int weeks) {
  /// Crea la edad validando que no sea negativa.
  factory PerceptionAge(int weeks) {
    if (weeks < 0) {
      throw DomainInvariantViolation(
        'PerceptionAge.weeks debe ser >= 0 (recibido: $weeks)',
      );
    }
    return PerceptionAge._(weeks);
  }

  /// Dato fresco (PF-3 observación directa).
  static PerceptionAge get fresh => PerceptionAge(0);

  /// Serializa a JSON.
  int toJson() => weeks;

  /// Deserializa desde JSON.
  static PerceptionAge fromJson(int json) => PerceptionAge(json);
}
