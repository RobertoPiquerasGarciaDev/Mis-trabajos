/// Relación subjetiva observador → objetivo (PF-5).
library;

import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_affinity.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_confidence.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_history.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_origin.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_respect.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_tag.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_trust.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_type.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Claves prohibidas en datos relacionales (Reality / attrs ocultos).
const forbiddenRelationKeys = {
  'potential',
  'attributes',
  'overall',
  'ovr',
  'salary',
  'fitness',
  'morale',
  'worldSeed',
};

/// Arista dirigida: cómo [observerPersonId] ve a [targetPersonId].
@immutable
final class RelationEntry {
  /// Crea la relación subjetiva.
  const RelationEntry({
    required this.observerPersonId,
    required this.targetPersonId,
    required this.type,
    required this.trust,
    required this.respect,
    required this.affinity,
    required this.confidence,
    required this.strength,
    required this.history,
    required this.knownSince,
    required this.lastInteraction,
    required this.origin,
    required this.tags,
  });

  /// Observador (dueño subjetivo).
  final PersonId observerPersonId;

  /// Objetivo de la relación.
  final PersonId targetPersonId;

  /// Clasificación estructural.
  final RelationType type;

  /// Confianza asimétrica.
  final RelationTrust trust;

  /// Respeto subjetivo.
  final RelationRespect respect;

  /// Afinidad subjetiva.
  final RelationAffinity affinity;

  /// Certeza sobre el vínculo.
  final RelationConfidence confidence;

  /// Fuerza actual del vínculo.
  final RelationStrength strength;

  /// Historial (infraestructura PF-5).
  final RelationHistory history;

  /// Desde cuándo se conoce al objetivo.
  final MemoryTimestamp knownSince;

  /// Última interacción percibida (`null` si ninguna).
  final MemoryTimestamp? lastInteraction;

  /// Procedencia del vínculo.
  final RelationOrigin origin;

  /// Etiquetas descriptivas.
  final List<RelationTag> tags;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'observerPersonId': observerPersonId.value,
    'targetPersonId': targetPersonId.value,
    'type': type.name,
    'trust': trust.toJson(),
    'respect': respect.toJson(),
    'affinity': affinity.toJson(),
    'confidence': confidence.toJson(),
    'strength': strength.toJson(),
    'history': history.toJson(),
    'knownSince': knownSince.toJson(),
    if (lastInteraction != null) 'lastInteraction': lastInteraction!.toJson(),
    'origin': origin.name,
    'tags': [for (final tag in tags) tag.name],
  };

  /// Deserializa desde JSON.
  factory RelationEntry.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('RelationEntry JSON v$version no soportada');
    }
    return RelationEntry(
      observerPersonId: PersonId(json['observerPersonId']! as String),
      targetPersonId: PersonId(json['targetPersonId']! as String),
      type: RelationType.values.byName(json['type']! as String),
      trust: RelationTrust.fromJson(json['trust']! as num),
      respect: RelationRespect.fromJson(json['respect']! as num),
      affinity: RelationAffinity.fromJson(json['affinity']! as num),
      confidence: RelationConfidence.fromJson(json['confidence']! as num),
      strength: RelationStrength.fromJson(json['strength']! as num),
      history: RelationHistory.fromJson(
        Map<String, Object?>.from(json['history']! as Map),
      ),
      knownSince: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['knownSince']! as Map),
      ),
      lastInteraction: json['lastInteraction'] == null
          ? null
          : MemoryTimestamp.fromJson(
              Map<String, Object?>.from(json['lastInteraction']! as Map),
            ),
      origin: RelationOrigin.values.byName(json['origin']! as String),
      tags: [
        for (final name in json['tags']! as List)
          RelationTag.values.byName(name as String),
      ],
    );
  }

  /// `true` si el JSON no contiene claves prohibidas.
  bool get passesNonRealityCheck => !containsForbiddenRelationKeys(toJson());

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is RelationEntry &&
          observerPersonId == other.observerPersonId &&
          targetPersonId == other.targetPersonId &&
          type == other.type &&
          trust == other.trust &&
          respect == other.respect &&
          affinity == other.affinity &&
          confidence == other.confidence &&
          strength == other.strength &&
          history == other.history &&
          knownSince == other.knownSince &&
          lastInteraction == other.lastInteraction &&
          origin == other.origin &&
          _listEquals(tags, other.tags);

  @override
  int get hashCode => Object.hash(
    observerPersonId,
    targetPersonId,
    type,
    trust,
    respect,
    affinity,
    confidence,
    strength,
    history,
    knownSince,
    lastInteraction,
    origin,
    Object.hashAll(tags),
  );
}

/// Escanea recursivamente un mapa JSON buscando claves prohibidas.
bool containsForbiddenRelationKeys(Map<String, Object?> json) {
  for (final entry in json.entries) {
    if (forbiddenRelationKeys.contains(entry.key)) return true;
    final value = entry.value;
    if (value is Map &&
        containsForbiddenRelationKeys(Map<String, Object?>.from(value))) {
      return true;
    }
    if (value is List) {
      for (final item in value) {
        if (item is Map &&
            containsForbiddenRelationKeys(Map<String, Object?>.from(item))) {
          return true;
        }
      }
    }
  }
  return false;
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
