/// Postura provisional tras deliberación interna (PF-9).
library;

/// Tipo de intención — no acción ni decisión.
enum IntentionType {
  /// Quiero salir del club.
  wantToLeaveClub,

  /// Quiero renovar o permanecer.
  wantToRenew,

  /// Quiero confiar en alguien.
  wantToTrustPerson,

  /// Quiero vender a un futbolista.
  wantToSellPlayer,

  /// Quiero apostar por cantera.
  wantToBetOnYouth,

  /// Quiero mantener la confianza percibida.
  wantToMaintainTrust,

  /// Quiero recuperar estatus.
  wantToRegainStatus,

  /// Quiero mejorar personalmente.
  wantToImproveSelf,

  /// Quiero buscar protección.
  wantToSeekProtection,

  /// Quiero ejercer liderazgo.
  wantToAssertLeadership,

  /// Quiero alinearme con la institución.
  wantToAlignWithInstitution,

  /// Quiero fortalecer el grupo.
  wantToStrengthenSquad,

  /// Quiero clarificar mi rol.
  wantToClarifyRole,

  /// Quiero comprender el entorno.
  wantToUnderstandWorld,

  /// Quiero dejar huella.
  wantToBuildLegacy,

  /// Quiero esperar — postura de diferimiento.
  wantToDefer,
}
