/// Resultado de deliberación social (PF-10).
library;

import 'package:kickdynasty_domain/src/intelligence/deliberation_convocation.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_id.dart';
import 'package:kickdynasty_domain/src/people_first/decision_record.dart';
import 'package:kickdynasty_domain/src/people_first/deliberation_participant.dart';
import 'package:kickdynasty_domain/src/people_first/deliberation_protocol_type.dart';
import 'package:kickdynasty_domain/src/people_first/mandate_outcome.dart';
import 'package:meta/meta.dart';

/// Salida de protocolo — sin ejecución ni mandato.
@immutable
final class SocialDeliberationResult {
  /// Crea el resultado.
  const SocialDeliberationResult({
    required this.convocation,
    required this.sourceIntentionId,
    required this.outcome,
    required this.participants,
    required this.proposalSummary,
    required this.dissent,
    required this.rejectedPaths,
    this.protocolType,
    this.instanceId,
    this.decisionRecord,
  });

  /// Diferimiento sin protocolo.
  factory SocialDeliberationResult.deferred({
    required DeliberationConvocation convocation,
    required IntentionId sourceIntentionId,
    required List<String> rejectedPaths,
  }) {
    return SocialDeliberationResult(
      convocation: convocation,
      sourceIntentionId: sourceIntentionId,
      outcome: MandateOutcome.defer,
      participants: const [],
      proposalSummary: '',
      dissent: const [],
      rejectedPaths: rejectedPaths,
    );
  }

  /// Convocatoria evaluada.
  final DeliberationConvocation convocation;

  /// Intención que originó la deliberación.
  final IntentionId sourceIntentionId;

  /// Desenlace del protocolo (sin ejecución).
  final MandateOutcome outcome;

  /// Actores y posturas registradas.
  final List<DeliberationParticipant> participants;

  /// Resumen legible de la propuesta.
  final String proposalSummary;

  /// Oposiciones registradas.
  final List<String> dissent;

  /// Caminos descartados (trazabilidad).
  final List<String> rejectedPaths;

  /// Protocolo convocado, si hubo deliberación social.
  final DeliberationProtocolType? protocolType;

  /// Identificador de instancia del protocolo.
  final String? instanceId;

  /// Registro social append-only, si aplica.
  final DecisionRecord? decisionRecord;

  /// Colección vacía (solo tests).
  static SocialDeliberationResult get empty =>
      SocialDeliberationResult.deferred(
        convocation: const DeliberationConvocation.deferred(
          reason: 'Sin intenciones',
        ),
        sourceIntentionId: IntentionId('intention-none'),
        rejectedPaths: const [],
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is SocialDeliberationResult &&
          convocation == other.convocation &&
          sourceIntentionId == other.sourceIntentionId &&
          outcome == other.outcome &&
          _listEquals(participants, other.participants) &&
          proposalSummary == other.proposalSummary &&
          _listEquals(dissent, other.dissent) &&
          _listEquals(rejectedPaths, other.rejectedPaths) &&
          protocolType == other.protocolType &&
          instanceId == other.instanceId &&
          decisionRecord == other.decisionRecord;

  @override
  int get hashCode => Object.hash(
    convocation,
    sourceIntentionId,
    outcome,
    Object.hashAll(participants),
    proposalSummary,
    Object.hashAll(dissent),
    Object.hashAll(rejectedPaths),
    protocolType,
    instanceId,
    decisionRecord,
  );
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
