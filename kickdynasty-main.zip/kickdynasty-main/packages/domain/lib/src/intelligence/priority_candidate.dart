/// Candidato a prioridad antes de ranking (PF-9).
library;

import 'package:kickdynasty_domain/src/intelligence/goal_id.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_type.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_origin.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_reason.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_strength.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Hipótesis de foco temporal derivada de un goal — aún sin rango.
@immutable
final class PriorityCandidate {
  /// Crea el candidato.
  const PriorityCandidate({
    required this.observerPersonId,
    required this.sourceGoalId,
    required this.goalType,
    required this.summary,
    required this.tentativeStrength,
    required this.origin,
    required this.reason,
    required this.createdAt,
  });

  /// Persona que podría elevar la prioridad.
  final PersonId observerPersonId;

  /// Goal origen — nunca Reality.
  final GoalId sourceGoalId;

  /// Tipo del goal fuente.
  final GoalType goalType;

  /// Enunciado de atención propuesto.
  final String summary;

  /// Fuerza tentativa antes de ranking.
  final PriorityStrength tentativeStrength;

  /// Procedencia del repunte.
  final PriorityOrigin origin;

  /// Motivo subjetivo del repunte.
  final PriorityReason reason;

  /// Momento de creación del candidato.
  final MemoryTimestamp createdAt;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'observerPersonId': observerPersonId.value,
    'sourceGoalId': sourceGoalId.value,
    'goalType': goalType.name,
    'summary': summary,
    'tentativeStrength': tentativeStrength.toJson(),
    'origin': origin.name,
    'reason': reason.name,
    'createdAt': createdAt.toJson(),
  };

  /// Deserializa desde JSON.
  factory PriorityCandidate.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('PriorityCandidate JSON v$version no soportada');
    }
    return PriorityCandidate(
      observerPersonId: PersonId(json['observerPersonId']! as String),
      sourceGoalId: GoalId(json['sourceGoalId']! as String),
      goalType: GoalType.values.byName(json['goalType']! as String),
      summary: json['summary']! as String,
      tentativeStrength: PriorityStrength.fromJson(
        json['tentativeStrength']! as num,
      ),
      origin: PriorityOrigin.values.byName(json['origin']! as String),
      reason: PriorityReason.values.byName(json['reason']! as String),
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PriorityCandidate &&
          observerPersonId == other.observerPersonId &&
          sourceGoalId == other.sourceGoalId &&
          goalType == other.goalType &&
          summary == other.summary &&
          tentativeStrength == other.tentativeStrength &&
          origin == other.origin &&
          reason == other.reason &&
          createdAt == other.createdAt;

  @override
  int get hashCode => Object.hash(
    observerPersonId,
    sourceGoalId,
    goalType,
    summary,
    tentativeStrength,
    origin,
    reason,
    createdAt,
  );
}
