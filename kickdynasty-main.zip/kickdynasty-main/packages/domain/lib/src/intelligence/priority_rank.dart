/// Posición ordinal en el foco de atención (PF-9).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Rango 1 = máxima atención en el ciclo.
extension type const PriorityRank._(int value) {
  /// Crea el rango validando que sea ≥ 1.
  factory PriorityRank(int value) {
    if (value < 1) {
      throw DomainInvariantViolation(
        'PriorityRank debe ser ≥ 1 (recibido: $value)',
      );
    }
    return PriorityRank._(value);
  }

  /// Serializa a JSON.
  int toJson() => value;

  /// Deserializa desde JSON.
  static PriorityRank fromJson(num json) => PriorityRank(json.toInt());
}
