/// Sesgo aplicado al formar una interpretación (PF-6).
library;

/// Filtro subjetivo que deforma el significado — sin lógica de gameplay.
enum InterpretationBias {
  /// Sin sesgo explícito.
  none,

  /// Prioriza inputs que confirman expectativas previas.
  confirmation,

  /// Sobrepesa lo reciente.
  recency,

  /// Infla aliados / protegidos.
  protection,

  /// Deflaciona rivales personales.
  rivalry,

  /// Favorece perfiles familiares.
  familiarity,
}
