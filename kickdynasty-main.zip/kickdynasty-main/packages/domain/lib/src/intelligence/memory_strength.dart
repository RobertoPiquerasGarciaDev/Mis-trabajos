/// Fuerza actual de un recuerdo (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Cuánto peso conserva el recuerdo en la mente del agente.
extension type const MemoryStrength._(double value) {
  /// Crea la fuerza validando el rango 0.0–1.0.
  factory MemoryStrength(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'MemoryStrength debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return MemoryStrength._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static MemoryStrength fromJson(num json) => MemoryStrength(json.toDouble());
}
