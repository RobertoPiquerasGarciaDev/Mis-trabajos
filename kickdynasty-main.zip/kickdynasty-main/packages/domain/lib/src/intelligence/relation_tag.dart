/// Etiquetas descriptivas de una relación (PF-5).
library;

/// Marcadores subjetivos sin semántica de gameplay.
enum RelationTag {
  /// Mismo club afiliado.
  sameClub,

  /// Vínculo estructural por rol.
  structural,

  /// Reforzada por percepción.
  perceived,

  /// Reforzada por memoria.
  remembered,

  /// Jerarquía staff.
  staffHierarchy,
}
