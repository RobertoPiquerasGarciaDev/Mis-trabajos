/// Procedencia de una prioridad (PF-9).
library;

/// Cómo se elevó la atención — siempre desde un Goal.
enum PriorityOrigin {
  /// Derivada principalmente del goal subyacente.
  goalDerived,

  /// Modulada por personalidad.
  personalityModulated,

  /// Modulada por emoción.
  emotionModulated,

  /// Modulada por memoria episódica.
  memoryModulated,

  /// Modulada por relaciones.
  relationModulated,
}
