/// Objetivo cognitivo individual (PF-8).
library;

import 'package:kickdynasty_domain/src/intelligence/belief_id.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_category.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_id.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_origin.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_priority.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_status.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_time_horizon.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_type.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Claves prohibidas — objetivos no almacenan Reality ni decisiones.
const forbiddenGoalKeys = {
  'potential',
  'attributes',
  'overall',
  'ovr',
  'salary',
  'fitness',
  'morale',
  'decision',
  'action',
  'plan',
  'mandate',
  'utility',
  'worldSeed',
  'player',
  'reality',
  'deliberation',
};

/// Lo que una persona desea conseguir — nunca una acción ni un plan.
@immutable
final class GoalEntry {
  /// Crea el objetivo.
  const GoalEntry({
    required this.id,
    required this.observerPersonId,
    required this.type,
    required this.category,
    required this.summary,
    required this.priority,
    required this.strength,
    required this.origin,
    required this.status,
    required this.timeHorizon,
    required this.sourceBeliefIds,
    required this.createdAt,
    required this.updatedAt,
    required this.lastReviewed,
  });

  /// Identificador estable.
  final GoalId id;

  /// Persona que sostiene la motivación.
  final PersonId observerPersonId;

  /// Clasificación del objetivo.
  final GoalType type;

  /// Ámbito organizativo.
  final GoalCategory category;

  /// Enunciado motivacional — no acción.
  final String summary;

  /// Peso relativo subjetivo.
  final GoalPriority priority;

  /// Intensidad de la motivación.
  final GoalStrength strength;

  /// Procedencia cognitiva.
  final GoalOrigin origin;

  /// Estado subjetivo del objetivo.
  final GoalStatus status;

  /// Horizonte temporal percibido.
  final GoalTimeHorizon timeHorizon;

  /// Creencias que alimentaron el objetivo.
  final List<BeliefId> sourceBeliefIds;

  /// Momento de creación.
  final MemoryTimestamp createdAt;

  /// Última actualización.
  final MemoryTimestamp updatedAt;

  /// Última revisión subjetiva.
  final MemoryTimestamp lastReviewed;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id.value,
    'observerPersonId': observerPersonId.value,
    'type': type.name,
    'category': category.name,
    'summary': summary,
    'priority': priority.toJson(),
    'strength': strength.toJson(),
    'origin': origin.name,
    'status': status.name,
    'timeHorizon': timeHorizon.name,
    'sourceBeliefIds': [for (final bid in sourceBeliefIds) bid.value],
    'createdAt': createdAt.toJson(),
    'updatedAt': updatedAt.toJson(),
    'lastReviewed': lastReviewed.toJson(),
  };

  /// Deserializa desde JSON.
  factory GoalEntry.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('GoalEntry JSON v$version no soportada');
    }
    return GoalEntry(
      id: GoalId(json['id']! as String),
      observerPersonId: PersonId(json['observerPersonId']! as String),
      type: GoalType.values.byName(json['type']! as String),
      category: GoalCategory.values.byName(json['category']! as String),
      summary: json['summary']! as String,
      priority: GoalPriority.fromJson(json['priority']! as num),
      strength: GoalStrength.fromJson(json['strength']! as num),
      origin: GoalOrigin.values.byName(json['origin']! as String),
      status: GoalStatus.values.byName(json['status']! as String),
      timeHorizon: GoalTimeHorizon.values.byName(
        json['timeHorizon']! as String,
      ),
      sourceBeliefIds: [
        for (final id in json['sourceBeliefIds']! as List)
          BeliefId(id as String),
      ],
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
      updatedAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['updatedAt']! as Map),
      ),
      lastReviewed: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['lastReviewed']! as Map),
      ),
    );
  }

  /// `true` si no contiene claves prohibidas ni lenguaje de acción.
  bool get passesNonRealityCheck =>
      !containsForbiddenGoalKeys(toJson()) && !_looksLikeAction(summary);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is GoalEntry &&
          id == other.id &&
          observerPersonId == other.observerPersonId &&
          type == other.type &&
          category == other.category &&
          summary == other.summary &&
          priority == other.priority &&
          strength == other.strength &&
          origin == other.origin &&
          status == other.status &&
          timeHorizon == other.timeHorizon &&
          _listEquals(sourceBeliefIds, other.sourceBeliefIds) &&
          createdAt == other.createdAt &&
          updatedAt == other.updatedAt &&
          lastReviewed == other.lastReviewed;

  @override
  int get hashCode => Object.hash(
    id,
    observerPersonId,
    type,
    category,
    summary,
    priority,
    strength,
    origin,
    status,
    timeHorizon,
    Object.hashAll(sourceBeliefIds),
    createdAt,
    updatedAt,
    lastReviewed,
  );
}

/// Escanea recursivamente un mapa JSON buscando claves prohibidas.
bool containsForbiddenGoalKeys(Map<String, Object?> json) {
  for (final entry in json.entries) {
    if (forbiddenGoalKeys.contains(entry.key)) return true;
    final value = entry.value;
    if (value is Map &&
        containsForbiddenGoalKeys(Map<String, Object?>.from(value))) {
      return true;
    }
    if (value is List) {
      for (final item in value) {
        if (item is Map &&
            containsForbiddenGoalKeys(Map<String, Object?>.from(item))) {
          return true;
        }
      }
    }
  }
  return false;
}

bool _looksLikeAction(String summary) {
  final lower = summary.toLowerCase();
  return lower.contains('decidir') ||
      lower.contains('fichar') ||
      lower.contains('vender') ||
      lower.contains('execute') ||
      lower.contains('debo ') ||
      lower.contains('planificar');
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}
