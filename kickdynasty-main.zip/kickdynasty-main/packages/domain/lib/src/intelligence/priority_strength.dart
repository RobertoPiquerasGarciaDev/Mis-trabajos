/// Fuerza subjetiva de atención (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Peso de atención temporal — sin efecto en gameplay en PF-9.
extension type const PriorityStrength._(double value) {
  /// Crea la fuerza validando el rango 0.0–1.0.
  factory PriorityStrength(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'PriorityStrength debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return PriorityStrength._(value);
  }

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static PriorityStrength fromJson(num json) =>
      PriorityStrength(json.toDouble());
}
