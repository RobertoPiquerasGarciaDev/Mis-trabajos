/// Contenedor universal del estado cognitivo (PF-2 — estructura únicamente).
library;

import 'package:kickdynasty_domain/src/intelligence/belief_state.dart';
import 'package:kickdynasty_domain/src/intelligence/decision_state.dart';
import 'package:kickdynasty_domain/src/intelligence/emotional_state.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_state.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_state.dart';
import 'package:kickdynasty_domain/src/intelligence/interpretation_state.dart';
import 'package:kickdynasty_domain/src/intelligence/learning_state.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_state.dart';
import 'package:kickdynasty_domain/src/intelligence/perception_state.dart';
import 'package:kickdynasty_domain/src/intelligence/personality_snapshot.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_state.dart';
import 'package:kickdynasty_domain/src/intelligence/relation_state.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Estado cognitivo de una [Person] — PF-2: contenedores vacíos, sin razonamiento.
@immutable
final class AgentMind {
  /// Crea la mente con todos los contenedores.
  const AgentMind({
    required this.personId,
    required this.personality,
    required this.memory,
    required this.beliefs,
    required this.goals,
    required this.priorities,
    required this.intentions,
    required this.decisions,
    required this.perception,
    required this.relations,
    required this.interpretation,
    required this.emotion,
    required this.learning,
  });

  /// Persona dueña de esta mente.
  final PersonId personId;

  /// Instantánea de personalidad al nacer la mente.
  final PersonalitySnapshot personality;

  /// Memoria episódica (PF-4 — recuerdos subjetivos, sin efecto en simulación).
  final MemoryState memory;

  /// Creencias (vacías en PF-2).
  final BeliefState beliefs;

  /// Objetivos (vacíos en PF-2).
  final GoalState goals;

  /// Prioridades temporales (PF-9 — foco derivado de goals).
  final PriorityState priorities;

  /// Intenciones provisionales (PF-9 — postura tras deliberación interna).
  final IntentionState intentions;

  /// Decisiones cognitivas (PF-10 — compromiso tras deliberación).
  final DecisionState decisions;

  /// Percepción (PF-3 — fotografías subjetivas, sin efecto en simulación).
  final PerceptionState perception;

  /// Relaciones subjetivas (PF-5 — grafo dirigido, sin efecto en simulación).
  final RelationState relations;

  /// Interpretaciones subjetivas (PF-6 — hipótesis, sin efecto en simulación).
  final InterpretationState interpretation;

  /// Estado emocional inicial.
  final EmotionalState emotion;

  /// Aprendizaje acumulado (inicial en PF-2).
  final LearningState learning;

  /// Serializa a JSON (versión 7).
  Map<String, Object?> toJson() => {
    'v': 7,
    'personId': personId.value,
    'personality': personality.toJson(),
    'memory': memory.toJson(),
    'beliefs': beliefs.toJson(),
    'goals': goals.toJson(),
    'priorities': priorities.toJson(),
    'intentions': intentions.toJson(),
    'decisions': decisions.toJson(),
    'perception': perception.toJson(),
    'relations': relations.toJson(),
    'interpretation': interpretation.toJson(),
    'emotion': emotion.toJson(),
    'learning': learning.toJson(),
  };

  /// Deserializa desde JSON.
  factory AgentMind.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version > 7) {
      throw FormatException('AgentMind JSON v$version no soportada');
    }
    return AgentMind(
      personId: PersonId(json['personId']! as String),
      personality: PersonalitySnapshot.fromJson(
        Map<String, Object?>.from(json['personality']! as Map),
      ),
      memory: MemoryState.fromJson(
        Map<String, Object?>.from(json['memory']! as Map),
      ),
      beliefs: BeliefState.fromJson(
        Map<String, Object?>.from(json['beliefs']! as Map),
      ),
      goals: GoalState.fromJson(
        Map<String, Object?>.from(json['goals']! as Map),
      ),
      priorities: version >= 6
          ? PriorityState.fromJson(
              Map<String, Object?>.from(json['priorities']! as Map),
            )
          : const PriorityState.empty(),
      intentions: version >= 6
          ? IntentionState.fromJson(
              Map<String, Object?>.from(json['intentions']! as Map),
            )
          : const IntentionState.empty(),
      decisions: version >= 7
          ? DecisionState.fromJson(
              Map<String, Object?>.from(json['decisions']! as Map),
            )
          : const DecisionState.empty(),
      perception: PerceptionState.fromJson(
        Map<String, Object?>.from(json['perception']! as Map),
      ),
      relations: version >= 2
          ? RelationState.fromJson(
              Map<String, Object?>.from(json['relations']! as Map),
            )
          : const RelationState.empty(),
      interpretation: version >= 3
          ? InterpretationState.fromJson(
              Map<String, Object?>.from(json['interpretation']! as Map),
            )
          : const InterpretationState.empty(),
      emotion: EmotionalState.fromJson(
        Map<String, Object?>.from(json['emotion']! as Map),
      ),
      learning: LearningState.fromJson(
        Map<String, Object?>.from(json['learning']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AgentMind &&
          personId == other.personId &&
          personality == other.personality &&
          memory == other.memory &&
          beliefs == other.beliefs &&
          goals == other.goals &&
          priorities == other.priorities &&
          intentions == other.intentions &&
          decisions == other.decisions &&
          perception == other.perception &&
          relations == other.relations &&
          interpretation == other.interpretation &&
          emotion == other.emotion &&
          learning == other.learning;

  @override
  int get hashCode => Object.hash(
    personId,
    personality,
    memory,
    beliefs,
    goals,
    priorities,
    intentions,
    decisions,
    perception,
    relations,
    interpretation,
    emotion,
    learning,
  );
}
