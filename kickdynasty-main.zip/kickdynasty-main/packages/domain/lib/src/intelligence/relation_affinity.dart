/// Afinidad subjetiva hacia otra persona (0.0–1.0).
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Afinidad / compatibilidad percibida del observador hacia el objetivo.
extension type const RelationAffinity._(double value) {
  /// Crea la afinidad validando el rango 0.0–1.0.
  factory RelationAffinity(double value) {
    if (value < 0 || value > 1) {
      throw DomainInvariantViolation(
        'RelationAffinity debe estar en 0.0..1.0 (recibido: $value)',
      );
    }
    return RelationAffinity._(value);
  }

  /// Afinidad plena (solo relación consigo mismo).
  static RelationAffinity get absolute => RelationAffinity(1.0);

  /// Serializa a JSON.
  double toJson() => value;

  /// Deserializa desde JSON.
  static RelationAffinity fromJson(num json) =>
      RelationAffinity(json.toDouble());
}
