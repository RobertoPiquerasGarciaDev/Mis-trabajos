/// Candidato a intención antes de consolidación (PF-9).
library;

import 'package:kickdynasty_domain/src/intelligence/intention_status.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/intention_type.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/intelligence/priority_id.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Hipótesis de postura provisional — aún sin identidad estable.
@immutable
final class IntentionCandidate {
  /// Crea el candidato.
  const IntentionCandidate({
    required this.observerPersonId,
    required this.sourcePriorityId,
    required this.type,
    required this.summary,
    required this.tentativeStrength,
    required this.status,
    required this.createdAt,
  });

  /// Persona que sostiene la postura.
  final PersonId observerPersonId;

  /// Prioridad que alimentó la intención.
  final PriorityId sourcePriorityId;

  /// Tipo de postura provisional.
  final IntentionType type;

  /// Enunciado motivacional — no acción.
  final String summary;

  /// Fuerza tentativa.
  final IntentionStrength tentativeStrength;

  /// Estado subjetivo propuesto.
  final IntentionStatus status;

  /// Momento de creación.
  final MemoryTimestamp createdAt;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'observerPersonId': observerPersonId.value,
    'sourcePriorityId': sourcePriorityId.value,
    'type': type.name,
    'summary': summary,
    'tentativeStrength': tentativeStrength.toJson(),
    'status': status.name,
    'createdAt': createdAt.toJson(),
  };

  /// Deserializa desde JSON.
  factory IntentionCandidate.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('IntentionCandidate JSON v$version no soportada');
    }
    return IntentionCandidate(
      observerPersonId: PersonId(json['observerPersonId']! as String),
      sourcePriorityId: PriorityId(json['sourcePriorityId']! as String),
      type: IntentionType.values.byName(json['type']! as String),
      summary: json['summary']! as String,
      tentativeStrength: IntentionStrength.fromJson(
        json['tentativeStrength']! as num,
      ),
      status: IntentionStatus.values.byName(json['status']! as String),
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is IntentionCandidate &&
          observerPersonId == other.observerPersonId &&
          sourcePriorityId == other.sourcePriorityId &&
          type == other.type &&
          summary == other.summary &&
          tentativeStrength == other.tentativeStrength &&
          status == other.status &&
          createdAt == other.createdAt;

  @override
  int get hashCode => Object.hash(
    observerPersonId,
    sourcePriorityId,
    type,
    summary,
    tentativeStrength,
    status,
    createdAt,
  );
}
