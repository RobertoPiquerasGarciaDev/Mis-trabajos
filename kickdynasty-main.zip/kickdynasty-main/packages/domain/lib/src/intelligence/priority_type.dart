/// Estado de atención temporal de una prioridad (PF-9).
library;

/// Nivel de foco subjetivo en el ciclo actual.
enum PriorityType {
  /// Prioridad dominante — máxima atención.
  dominant,

  /// Prioridad activa — atención significativa.
  active,

  /// Prioridad latente — viva pero en segundo plano.
  latent,
}
