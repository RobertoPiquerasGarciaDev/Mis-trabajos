/// Contenedor de objetivos en [AgentMind] (PF-8).
library;

import 'package:kickdynasty_domain/src/intelligence/goal_collection.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_entry.dart';
import 'package:meta/meta.dart';

/// Estado de objetivos persistentes — subjetivos, no Reality.
@immutable
final class GoalState {
  /// Estado vacío (pre-PF-8).
  const GoalState.empty() : collection = const GoalCollection.empty();

  /// Crea el estado con la colección.
  const GoalState({required this.collection});

  /// Colección de objetivos.
  final GoalCollection collection;

  /// Entradas accesibles.
  List<GoalEntry> get entries => collection.entries;

  /// Serializa a JSON (versión 2).
  Map<String, Object?> toJson() => {'v': 2, 'collection': collection.toJson()};

  /// Deserializa desde JSON.
  factory GoalState.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version > 2) {
      throw FormatException('GoalState JSON v$version no soportada');
    }
    if (version == 1) {
      return const GoalState.empty();
    }
    return GoalState(
      collection: GoalCollection.fromJson(
        Map<String, Object?>.from(json['collection']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is GoalState && collection == other.collection;

  @override
  int get hashCode => collection.hashCode;
}
