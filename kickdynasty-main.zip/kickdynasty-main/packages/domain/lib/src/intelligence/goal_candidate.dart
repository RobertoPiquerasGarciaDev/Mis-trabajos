/// Candidato a objetivo antes de materialización (PF-8).
library;

import 'package:kickdynasty_domain/src/intelligence/belief_id.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_category.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_priority.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_strength.dart';
import 'package:kickdynasty_domain/src/intelligence/goal_type.dart';
import 'package:kickdynasty_domain/src/intelligence/memory_timestamp.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Motivación tentativa derivada de una creencia — aún no persistida como Goal.
@immutable
final class GoalCandidate {
  /// Crea el candidato.
  const GoalCandidate({
    required this.observerPersonId,
    required this.sourceBeliefId,
    required this.type,
    required this.category,
    required this.summary,
    required this.tentativePriority,
    required this.tentativeStrength,
    required this.createdAt,
  });

  /// Persona que podría adoptar el objetivo.
  final PersonId observerPersonId;

  /// Creencia origen — nunca Reality.
  final BeliefId sourceBeliefId;

  /// Tipo proyectado de objetivo.
  final GoalType type;

  /// Categoría organizativa.
  final GoalCategory category;

  /// Enunciado motivacional propuesto.
  final String summary;

  /// Prioridad tentativa antes de modular.
  final GoalPriority tentativePriority;

  /// Fuerza tentativa antes de modular.
  final GoalStrength tentativeStrength;

  /// Momento de creación del candidato.
  final MemoryTimestamp createdAt;

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'observerPersonId': observerPersonId.value,
    'sourceBeliefId': sourceBeliefId.value,
    'type': type.name,
    'category': category.name,
    'summary': summary,
    'tentativePriority': tentativePriority.toJson(),
    'tentativeStrength': tentativeStrength.toJson(),
    'createdAt': createdAt.toJson(),
  };

  /// Deserializa desde JSON.
  factory GoalCandidate.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('GoalCandidate JSON v$version no soportada');
    }
    return GoalCandidate(
      observerPersonId: PersonId(json['observerPersonId']! as String),
      sourceBeliefId: BeliefId(json['sourceBeliefId']! as String),
      type: GoalType.values.byName(json['type']! as String),
      category: GoalCategory.values.byName(json['category']! as String),
      summary: json['summary']! as String,
      tentativePriority: GoalPriority.fromJson(
        json['tentativePriority']! as num,
      ),
      tentativeStrength: GoalStrength.fromJson(
        json['tentativeStrength']! as num,
      ),
      createdAt: MemoryTimestamp.fromJson(
        Map<String, Object?>.from(json['createdAt']! as Map),
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is GoalCandidate &&
          observerPersonId == other.observerPersonId &&
          sourceBeliefId == other.sourceBeliefId &&
          type == other.type &&
          category == other.category &&
          summary == other.summary &&
          tentativePriority == other.tentativePriority &&
          tentativeStrength == other.tentativeStrength &&
          createdAt == other.createdAt;

  @override
  int get hashCode => Object.hash(
    observerPersonId,
    sourceBeliefId,
    type,
    category,
    summary,
    tentativePriority,
    tentativeStrength,
    createdAt,
  );
}
