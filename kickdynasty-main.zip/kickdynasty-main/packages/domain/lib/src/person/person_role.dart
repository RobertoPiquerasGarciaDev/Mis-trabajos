/// Clasificación de rol de una persona — **sin comportamiento** (PF-1).
library;

/// Rol canónico de clasificación; la persona existe antes que el rol activo.
enum PersonRole {
  /// Futbolista.
  player,

  /// Entrenador principal.
  manager,

  /// Director deportivo.
  sportingDirector,

  /// Presidente del club.
  president,

  /// Scout / ojeador.
  scout,

  /// Responsable de cantera.
  youthDirector,

  /// Jefe de scouting.
  scoutingLead,

  /// Jefe médico.
  medicalLead,
}
