/// Filosofía profesional inicial (AGENT_WORLD_GENERATION §5.5).
library;

import 'package:kickdynasty_domain/src/person/trait_score.dart';
import 'package:meta/meta.dart';

/// Ejes de filosofía al nacer — sin efecto en gameplay PF-1.
@immutable
final class PersonPhilosophy {
  /// Crea la filosofía inicial.
  const PersonPhilosophy({
    required this.pragmatism,
    required this.youthFocus,
    required this.attackingStyle,
    required this.financialPrudence,
    required this.institutionalLoyalty,
  });

  /// Pragmatismo táctico/institucional.
  final TraitScore pragmatism;

  /// Apuesta por cantera.
  final TraitScore youthFocus;

  /// Estilo ofensivo.
  final TraitScore attackingStyle;

  /// Prudencia financiera.
  final TraitScore financialPrudence;

  /// Lealtad institucional.
  final TraitScore institutionalLoyalty;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'pragmatism': pragmatism.value,
    'youthFocus': youthFocus.value,
    'attackingStyle': attackingStyle.value,
    'financialPrudence': financialPrudence.value,
    'institutionalLoyalty': institutionalLoyalty.value,
  };

  /// Deserializa desde JSON.
  factory PersonPhilosophy.fromJson(Map<String, Object?> json) =>
      PersonPhilosophy(
        pragmatism: TraitScore(json['pragmatism']! as int),
        youthFocus: TraitScore(json['youthFocus']! as int),
        attackingStyle: TraitScore(json['attackingStyle']! as int),
        financialPrudence: TraitScore(json['financialPrudence']! as int),
        institutionalLoyalty: TraitScore(json['institutionalLoyalty']! as int),
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PersonPhilosophy &&
          pragmatism == other.pragmatism &&
          youthFocus == other.youthFocus &&
          attackingStyle == other.attackingStyle &&
          financialPrudence == other.financialPrudence &&
          institutionalLoyalty == other.institutionalLoyalty;

  @override
  int get hashCode => Object.hash(
    pragmatism,
    youthFocus,
    attackingStyle,
    financialPrudence,
    institutionalLoyalty,
  );
}
