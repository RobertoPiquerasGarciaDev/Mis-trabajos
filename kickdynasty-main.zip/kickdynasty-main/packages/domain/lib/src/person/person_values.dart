/// Valores personales (AGENT_WORLD_GENERATION §5.2) — prioridades morales.
library;

import 'package:kickdynasty_domain/src/person/trait_score.dart';
import 'package:meta/meta.dart';

/// Vector de valores — qué prioriza moralmente la persona.
@immutable
final class PersonValues {
  /// Crea el vector de valores.
  const PersonValues({
    required this.loyalty,
    required this.meritocracy,
    required this.family,
    required this.prestige,
    required this.security,
  });

  /// Lealtad institucional.
  final TraitScore loyalty;

  /// Meritocracia.
  final TraitScore meritocracy;

  /// Familia / arraigo.
  final TraitScore family;

  /// Prestigio público.
  final TraitScore prestige;

  /// Seguridad económica.
  final TraitScore security;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'loyalty': loyalty.value,
    'meritocracy': meritocracy.value,
    'family': family.value,
    'prestige': prestige.value,
    'security': security.value,
  };

  /// Deserializa desde JSON.
  factory PersonValues.fromJson(Map<String, Object?> json) => PersonValues(
    loyalty: TraitScore(json['loyalty']! as int),
    meritocracy: TraitScore(json['meritocracy']! as int),
    family: TraitScore(json['family']! as int),
    prestige: TraitScore(json['prestige']! as int),
    security: TraitScore(json['security']! as int),
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PersonValues &&
          loyalty == other.loyalty &&
          meritocracy == other.meritocracy &&
          family == other.family &&
          prestige == other.prestige &&
          security == other.security;

  @override
  int get hashCode =>
      Object.hash(loyalty, meritocracy, family, prestige, security);
}
