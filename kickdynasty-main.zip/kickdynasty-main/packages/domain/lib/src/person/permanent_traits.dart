/// Rasgos permanentes adicionales a la personalidad base.
library;

import 'package:kickdynasty_domain/src/person/trait_score.dart';
import 'package:meta/meta.dart';

/// Rasgos estables que complementan [PersonalityProfile].
@immutable
final class PermanentTraits {
  /// Crea los rasgos permanentes.
  const PermanentTraits({
    required this.charisma,
    required this.workEthic,
    required this.resilience,
    required this.creativity,
    required this.discipline,
  });

  /// Carisma social.
  final TraitScore charisma;

  /// Ética de trabajo.
  final TraitScore workEthic;

  /// Resiliencia ante adversidad.
  final TraitScore resilience;

  /// Creatividad.
  final TraitScore creativity;

  /// Disciplina.
  final TraitScore discipline;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'charisma': charisma.value,
    'workEthic': workEthic.value,
    'resilience': resilience.value,
    'creativity': creativity.value,
    'discipline': discipline.value,
  };

  /// Deserializa desde JSON.
  factory PermanentTraits.fromJson(Map<String, Object?> json) =>
      PermanentTraits(
        charisma: TraitScore(json['charisma']! as int),
        workEthic: TraitScore(json['workEthic']! as int),
        resilience: TraitScore(json['resilience']! as int),
        creativity: TraitScore(json['creativity']! as int),
        discipline: TraitScore(json['discipline']! as int),
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PermanentTraits &&
          charisma == other.charisma &&
          workEthic == other.workEthic &&
          resilience == other.resilience &&
          creativity == other.creativity &&
          discipline == other.discipline;

  @override
  int get hashCode =>
      Object.hash(charisma, workEthic, resilience, creativity, discipline);
}
