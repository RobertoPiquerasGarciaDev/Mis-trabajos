/// Derivación determinista de rasgos de persona (AGENT_WORLD_GENERATION §4.1).
library;

import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:kickdynasty_domain/src/person/trait_score.dart';

/// Mezcla SplitMix64 — paridad con `kickdynasty_core` / `protocol_seed`.
int _splitMix64(int x) {
  var z = x + 0x9E3779B97F4A7C15;
  z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9;
  z = (z ^ (z >>> 27)) * 0x94D049BB133111EB;
  return z ^ (z >>> 31);
}

int _mix(int value) => _splitMix64(_splitMix64(value));

/// Deriva un entero determinista para un dominio de rasgo.
///
/// Contrato: mismos `(personId, worldSeed, domain, index)` → mismo valor.
int personDerive({
  required PersonId personId,
  required int worldSeed,
  required String domain,
  int index = 0,
}) {
  var seed = _mix(worldSeed);
  seed = _mix(seed ^ personId.value.hashCode);
  seed = _mix(seed ^ domain.hashCode);
  seed = _mix(seed ^ index);
  return seed;
}

/// Normaliza [raw] a escala 0–100.
TraitScore personDeriveTraitScore({
  required PersonId personId,
  required int worldSeed,
  required String domain,
  int index = 0,
}) {
  final raw = personDerive(
    personId: personId,
    worldSeed: worldSeed,
    domain: domain,
    index: index,
  );
  return TraitScore(raw.abs() % (TraitScore.max + 1));
}

/// Hash estable de contexto de nacimiento.
int personBirthContextHash({
  required int worldSeed,
  required String country,
  required String city,
  required String cohort,
  required int generation,
}) {
  var seed = _mix(worldSeed);
  seed = _mix(seed ^ country.hashCode);
  seed = _mix(seed ^ city.hashCode);
  seed = _mix(seed ^ cohort.hashCode);
  seed = _mix(seed ^ generation);
  return seed;
}
