/// Escala 0–100 para rasgos de personalidad People First.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Valor en escala continua 0–100 (rasgos, valores, filosofía).
extension type const TraitScore._(int value) {
  /// Crea el valor validando el rango 0..100.
  factory TraitScore(int value) {
    checkRange(value, 0, max, 'TraitScore');
    return TraitScore._(value);
  }

  /// Valor máximo de la escala.
  static const int max = 100;
}
