/// Competencias generales permanentes (AGENT_WORLD_GENERATION §5.3–5.4).
library;

import 'package:kickdynasty_domain/src/person/trait_score.dart';
import 'package:meta/meta.dart';

/// Habilidades profesionales transversales — no específicas de rol activo.
@immutable
final class GeneralCompetencies {
  /// Crea las competencias generales.
  const GeneralCompetencies({
    required this.intelligence,
    required this.negotiation,
    required this.analysis,
    required this.communication,
    required this.adaptability,
  });

  /// Inteligencia general.
  final TraitScore intelligence;

  /// Capacidad de negociación.
  final TraitScore negotiation;

  /// Análisis e interpretación.
  final TraitScore analysis;

  /// Comunicación interpersonal.
  final TraitScore communication;

  /// Adaptabilidad.
  final TraitScore adaptability;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'intelligence': intelligence.value,
    'negotiation': negotiation.value,
    'analysis': analysis.value,
    'communication': communication.value,
    'adaptability': adaptability.value,
  };

  /// Deserializa desde JSON.
  factory GeneralCompetencies.fromJson(Map<String, Object?> json) =>
      GeneralCompetencies(
        intelligence: TraitScore(json['intelligence']! as int),
        negotiation: TraitScore(json['negotiation']! as int),
        analysis: TraitScore(json['analysis']! as int),
        communication: TraitScore(json['communication']! as int),
        adaptability: TraitScore(json['adaptability']! as int),
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is GeneralCompetencies &&
          intelligence == other.intelligence &&
          negotiation == other.negotiation &&
          analysis == other.analysis &&
          communication == other.communication &&
          adaptability == other.adaptability;

  @override
  int get hashCode => Object.hash(
    intelligence,
    negotiation,
    analysis,
    communication,
    adaptability,
  );
}
