/// Identificadores sintéticos deterministas para migración v6 (PF-1).
library;

import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:kickdynasty_domain/src/person/person_derive.dart';
import 'package:kickdynasty_domain/src/person/person_role.dart';

/// Deriva un [PersonId] estable para un jugador existente.
PersonId syntheticPlayerPersonId({
  required int worldSeed,
  required PlayerId playerId,
}) {
  final raw = personDerive(
    personId: PersonId('_synthetic_player_'),
    worldSeed: worldSeed,
    domain: 'synthetic.player',
    index: playerId.value.hashCode,
  );
  return PersonId('person-${raw.toRadixString(16).padLeft(16, '0')}');
}

/// Deriva un [PersonId] estable para staff mínimo por club.
PersonId syntheticStaffPersonId({
  required int worldSeed,
  required ClubId clubId,
  required PersonRole role,
}) {
  final raw = personDerive(
    personId: PersonId('_synthetic_staff_'),
    worldSeed: worldSeed,
    domain: 'synthetic.staff.${role.name}',
    index: clubId.value.hashCode,
  );
  return PersonId('person-${raw.toRadixString(16).padLeft(16, '0')}');
}
