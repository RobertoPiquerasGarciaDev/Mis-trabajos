/// Fecha de nacimiento civil de una persona.
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:meta/meta.dart';

/// Fecha de nacimiento (calendario civil, no [GameDate]).
@immutable
final class BirthDate {
  /// Crea la fecha validando rangos.
  BirthDate({required this.year, required this.month, required this.day}) {
    if (year < 1950 || year > 2015) {
      throw DomainInvariantViolation(
        'BirthDate.year fuera de rango (recibido: $year)',
      );
    }
    if (month < 1 || month > 12) {
      throw DomainInvariantViolation(
        'BirthDate.month debe ser 1..12 (recibido: $month)',
      );
    }
    if (day < 1 || day > 31) {
      throw DomainInvariantViolation(
        'BirthDate.day debe ser 1..31 (recibido: $day)',
      );
    }
  }

  /// Año de nacimiento.
  final int year;

  /// Mes de nacimiento (1–12).
  final int month;

  /// Día de nacimiento (1–31).
  final int day;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {'year': year, 'month': month, 'day': day};

  /// Deserializa desde JSON.
  factory BirthDate.fromJson(Map<String, Object?> json) => BirthDate(
    year: json['year']! as int,
    month: json['month']! as int,
    day: json['day']! as int,
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is BirthDate &&
          year == other.year &&
          month == other.month &&
          day == other.day;

  @override
  int get hashCode => Object.hash(year, month, day);
}
