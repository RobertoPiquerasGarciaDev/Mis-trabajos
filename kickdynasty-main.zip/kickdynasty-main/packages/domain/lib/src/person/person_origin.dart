/// Origen biográfico de una persona (AGENT_WORLD_GENERATION §3–4).
library;

import 'package:kickdynasty_domain/src/values/display_name.dart';
import 'package:meta/meta.dart';

/// Contexto de nacimiento — solo datos permanentes, sin lógica cognitiva.
@immutable
final class PersonOrigin {
  /// Crea el origen validando campos obligatorios.
  const PersonOrigin({
    required this.country,
    required this.city,
    required this.generation,
    required this.economicContext,
    required this.appearanceYear,
    required this.cohort,
    required this.derivedWorldSeed,
    required this.birthContextHash,
    this.academy,
    this.sportingFamily = false,
  });

  /// País de origen (ISO 3166-1 alfa-2).
  final CountryCode country;

  /// Ciudad o localidad de origen.
  final String city;

  /// Academia formativa (`null` si no aplica).
  final String? academy;

  /// Familia con tradición deportiva.
  final bool sportingFamily;

  /// Generación / cohorte generacional.
  final int generation;

  /// Contexto económico (`humble`, `middle`, `affluent`, …).
  final String economicContext;

  /// Año de aparición en el mundo simulado.
  final int appearanceYear;

  /// Identificador de cohorte.
  final String cohort;

  /// Semilla de mundo usada en la derivación.
  final int derivedWorldSeed;

  /// Resumen hash del contexto de nacimiento.
  final int birthContextHash;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'country': country.value,
    'city': city,
    if (academy != null) 'academy': academy,
    'sportingFamily': sportingFamily,
    'generation': generation,
    'economicContext': economicContext,
    'appearanceYear': appearanceYear,
    'cohort': cohort,
    'derivedWorldSeed': derivedWorldSeed,
    'birthContextHash': birthContextHash,
  };

  /// Deserializa desde JSON.
  factory PersonOrigin.fromJson(Map<String, Object?> json) => PersonOrigin(
    country: CountryCode(json['country']! as String),
    city: json['city']! as String,
    academy: json['academy'] as String?,
    sportingFamily: json['sportingFamily'] as bool? ?? false,
    generation: json['generation']! as int,
    economicContext: json['economicContext']! as String,
    appearanceYear: json['appearanceYear']! as int,
    cohort: json['cohort']! as String,
    derivedWorldSeed: json['derivedWorldSeed']! as int,
    birthContextHash: json['birthContextHash']! as int,
  );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PersonOrigin &&
          country == other.country &&
          city == other.city &&
          academy == other.academy &&
          sportingFamily == other.sportingFamily &&
          generation == other.generation &&
          economicContext == other.economicContext &&
          appearanceYear == other.appearanceYear &&
          cohort == other.cohort &&
          derivedWorldSeed == other.derivedWorldSeed &&
          birthContextHash == other.birthContextHash;

  @override
  int get hashCode => Object.hash(
    country,
    city,
    academy,
    sportingFamily,
    generation,
    economicContext,
    appearanceYear,
    cohort,
    derivedWorldSeed,
    birthContextHash,
  );
}
