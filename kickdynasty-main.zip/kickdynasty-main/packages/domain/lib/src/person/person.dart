/// Entidad universal Person — identidad permanente (People First §3.3, PF-1).
library;

import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:kickdynasty_domain/src/person/birth_date.dart';
import 'package:kickdynasty_domain/src/person/general_competencies.dart';
import 'package:kickdynasty_domain/src/person/permanent_traits.dart';
import 'package:kickdynasty_domain/src/person/person_gender.dart';
import 'package:kickdynasty_domain/src/person/person_origin.dart';
import 'package:kickdynasty_domain/src/person/person_philosophy.dart';
import 'package:kickdynasty_domain/src/person/person_role.dart';
import 'package:kickdynasty_domain/src/person/person_values.dart';
import 'package:kickdynasty_domain/src/person/personality_profile.dart';
import 'package:kickdynasty_domain/src/person/trait_score.dart';
import 'package:kickdynasty_domain/src/values/display_name.dart';
import 'package:kickdynasty_domain/src/values/rating.dart';
import 'package:meta/meta.dart';

/// Persona — agente universal antes que cualquier rol activo.
///
/// PF-1: solo identidad y origen. Sin cognición, deliberación ni comportamiento.
@immutable
final class Person {
  /// Crea una persona con datos permanentes validados.
  const Person({
    required this.id,
    required this.firstName,
    required this.lastName,
    required this.birthDate,
    required this.nationality,
    required this.primaryLanguage,
    required this.gender,
    required this.origin,
    required this.personality,
    required this.values,
    required this.philosophy,
    required this.competencies,
    required this.traits,
    required this.cognitivePotential,
    required this.initialReputation,
    required this.role,
  });

  /// Identificador estable.
  final PersonId id;

  /// Nombre de pila.
  final DisplayName firstName;

  /// Apellidos.
  final DisplayName lastName;

  /// Fecha de nacimiento civil.
  final BirthDate birthDate;

  /// Nacionalidad (ISO 3166-1 alfa-2).
  final CountryCode nationality;

  /// Idioma principal (ISO 639-1).
  final String primaryLanguage;

  /// Género biográfico.
  final PersonGender gender;

  /// Origen y contexto de nacimiento.
  final PersonOrigin origin;

  /// Personalidad base.
  final PersonalityProfile personality;

  /// Valores personales.
  final PersonValues values;

  /// Filosofía profesional inicial.
  final PersonPhilosophy philosophy;

  /// Competencias generales.
  final GeneralCompetencies competencies;

  /// Rasgos permanentes.
  final PermanentTraits traits;

  /// Potencial cognitivo (0–100).
  final TraitScore cognitivePotential;

  /// Reputación inicial pública (escala Rating 1–99).
  final Rating initialReputation;

  /// Clasificación de rol — sin comportamiento asociado en PF-1.
  final PersonRole role;

  /// Nombre completo visible.
  DisplayName get displayName =>
      DisplayName('${firstName.value} ${lastName.value}');

  /// Serializa a JSON (versión 1).
  Map<String, Object?> toJson() => {
    'v': 1,
    'id': id.value,
    'firstName': firstName.value,
    'lastName': lastName.value,
    'birthDate': birthDate.toJson(),
    'nationality': nationality.value,
    'primaryLanguage': primaryLanguage,
    'gender': gender.name,
    'origin': origin.toJson(),
    'personality': personality.toJson(),
    'values': values.toJson(),
    'philosophy': philosophy.toJson(),
    'competencies': competencies.toJson(),
    'traits': traits.toJson(),
    'cognitivePotential': cognitivePotential.value,
    'initialReputation': initialReputation.value,
    'role': role.name,
  };

  /// Deserializa desde JSON.
  factory Person.fromJson(Map<String, Object?> json) {
    final version = json['v'] as int? ?? 1;
    if (version != 1) {
      throw FormatException('Person JSON v$version no soportada');
    }
    return Person(
      id: PersonId(json['id']! as String),
      firstName: DisplayName(json['firstName']! as String),
      lastName: DisplayName(json['lastName']! as String),
      birthDate: BirthDate.fromJson(
        Map<String, Object?>.from(json['birthDate']! as Map),
      ),
      nationality: CountryCode(json['nationality']! as String),
      primaryLanguage: json['primaryLanguage']! as String,
      gender: PersonGender.values.byName(json['gender']! as String),
      origin: PersonOrigin.fromJson(
        Map<String, Object?>.from(json['origin']! as Map),
      ),
      personality: PersonalityProfile.fromJson(
        Map<String, Object?>.from(json['personality']! as Map),
      ),
      values: PersonValues.fromJson(
        Map<String, Object?>.from(json['values']! as Map),
      ),
      philosophy: PersonPhilosophy.fromJson(
        Map<String, Object?>.from(json['philosophy']! as Map),
      ),
      competencies: GeneralCompetencies.fromJson(
        Map<String, Object?>.from(json['competencies']! as Map),
      ),
      traits: PermanentTraits.fromJson(
        Map<String, Object?>.from(json['traits']! as Map),
      ),
      cognitivePotential: TraitScore(json['cognitivePotential']! as int),
      initialReputation: Rating(json['initialReputation']! as int),
      role: PersonRole.values.byName(json['role']! as String),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is Person &&
          id == other.id &&
          firstName == other.firstName &&
          lastName == other.lastName &&
          birthDate == other.birthDate &&
          nationality == other.nationality &&
          primaryLanguage == other.primaryLanguage &&
          gender == other.gender &&
          origin == other.origin &&
          personality == other.personality &&
          values == other.values &&
          philosophy == other.philosophy &&
          competencies == other.competencies &&
          traits == other.traits &&
          cognitivePotential == other.cognitivePotential &&
          initialReputation == other.initialReputation &&
          role == other.role;

  @override
  int get hashCode => Object.hashAll([
    id,
    firstName,
    lastName,
    birthDate,
    nationality,
    primaryLanguage,
    gender,
    origin,
    personality,
    values,
    philosophy,
    competencies,
    traits,
    cognitivePotential,
    initialReputation,
    role,
  ]);
}
