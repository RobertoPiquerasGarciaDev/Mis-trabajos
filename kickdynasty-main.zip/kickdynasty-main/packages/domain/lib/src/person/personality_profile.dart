/// Perfil de personalidad base (PEOPLE_FIRST §4.1) — solo datos.
library;

import 'package:kickdynasty_domain/src/person/trait_score.dart';
import 'package:meta/meta.dart';

/// Rasgos continuos 0–100 compartidos por staff y jugadores.
@immutable
final class PersonalityProfile {
  /// Crea el perfil con todos los rasgos.
  const PersonalityProfile({
    required this.ambition,
    required this.patience,
    required this.prudence,
    required this.aggressiveness,
    required this.pride,
    required this.ego,
    required this.professionalism,
    required this.empathy,
    required this.emotionalStability,
    required this.leadership,
    required this.memoryTrait,
    required this.pressureTolerance,
  });

  /// Ambición.
  final TraitScore ambition;

  /// Paciencia.
  final TraitScore patience;

  /// Prudencia.
  final TraitScore prudence;

  /// Agresividad.
  final TraitScore aggressiveness;

  /// Orgullo.
  final TraitScore pride;

  /// Ego.
  final TraitScore ego;

  /// Profesionalidad.
  final TraitScore professionalism;

  /// Empatía.
  final TraitScore empathy;

  /// Estabilidad emocional.
  final TraitScore emotionalStability;

  /// Liderazgo.
  final TraitScore leadership;

  /// Memoria (rasgo).
  final TraitScore memoryTrait;

  /// Presión soportada.
  final TraitScore pressureTolerance;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'ambition': ambition.value,
    'patience': patience.value,
    'prudence': prudence.value,
    'aggressiveness': aggressiveness.value,
    'pride': pride.value,
    'ego': ego.value,
    'professionalism': professionalism.value,
    'empathy': empathy.value,
    'emotionalStability': emotionalStability.value,
    'leadership': leadership.value,
    'memoryTrait': memoryTrait.value,
    'pressureTolerance': pressureTolerance.value,
  };

  /// Deserializa desde JSON.
  factory PersonalityProfile.fromJson(Map<String, Object?> json) =>
      PersonalityProfile(
        ambition: TraitScore(json['ambition']! as int),
        patience: TraitScore(json['patience']! as int),
        prudence: TraitScore(json['prudence']! as int),
        aggressiveness: TraitScore(json['aggressiveness']! as int),
        pride: TraitScore(json['pride']! as int),
        ego: TraitScore(json['ego']! as int),
        professionalism: TraitScore(json['professionalism']! as int),
        empathy: TraitScore(json['empathy']! as int),
        emotionalStability: TraitScore(json['emotionalStability']! as int),
        leadership: TraitScore(json['leadership']! as int),
        memoryTrait: TraitScore(json['memoryTrait']! as int),
        pressureTolerance: TraitScore(json['pressureTolerance']! as int),
      );

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PersonalityProfile &&
          ambition == other.ambition &&
          patience == other.patience &&
          prudence == other.prudence &&
          aggressiveness == other.aggressiveness &&
          pride == other.pride &&
          ego == other.ego &&
          professionalism == other.professionalism &&
          empathy == other.empathy &&
          emotionalStability == other.emotionalStability &&
          leadership == other.leadership &&
          memoryTrait == other.memoryTrait &&
          pressureTolerance == other.pressureTolerance;

  @override
  int get hashCode => Object.hashAll([
    ambition,
    patience,
    prudence,
    aggressiveness,
    pride,
    ego,
    professionalism,
    empathy,
    emotionalStability,
    leadership,
    memoryTrait,
    pressureTolerance,
  ]);
}
