/// Género declarado de una persona.
library;

/// Género biográfico (derivación determinista; no afecta gameplay PF-1).
enum PersonGender {
  /// Masculino.
  male,

  /// Femenino.
  female,

  /// No especificado en origen.
  undisclosed,
}
