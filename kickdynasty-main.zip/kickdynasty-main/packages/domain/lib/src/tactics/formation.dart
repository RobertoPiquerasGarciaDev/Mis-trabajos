/// Formaciones tácticas.
library;

import 'package:collection/collection.dart';
import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/player/position.dart';
import 'package:meta/meta.dart';

/// Disposición táctica de los 11 titulares sobre el campo.
///
/// Una formación es una lista ordenada de 11 posiciones ([slots]) con
/// exactamente un portero en el primer puesto. El orden de los slots es
/// significativo: `MatchLineup` asigna jugadores a slots por índice.
@immutable
final class Formation {
  /// Crea una formación validando sus invariantes.
  Formation({required this.label, required List<Position> slots})
    : slots = List.unmodifiable(slots) {
    final violations = validate(label: label, slots: slots);
    if (violations.isNotEmpty) {
      throw DomainInvariantViolation(
        'Formación inválida',
        violations: violations,
      );
    }
  }

  /// Etiqueta visible (p. ej. `4-3-3`).
  final String label;

  /// Las 11 posiciones, con el portero en el índice 0.
  final List<Position> slots;

  /// Número de titulares de una alineación.
  static const int squadSize = 11;

  /// Comprueba los invariantes y devuelve los incumplimientos (vacío si es
  /// válida): 11 slots, exactamente un portero y portero en el índice 0.
  static List<String> validate({
    required String label,
    required List<Position> slots,
  }) {
    final violations = <String>[];

    if (label.trim().isEmpty) {
      violations.add('La etiqueta de la formación no puede estar vacía');
    }
    if (slots.length != squadSize) {
      violations.add(
        'Una formación tiene exactamente $squadSize posiciones '
        '(tiene ${slots.length})',
      );
    }
    final goalkeepers = slots.where((s) => s.isGoalkeeper).length;
    if (goalkeepers != 1) {
      violations.add(
        'Una formación tiene exactamente 1 portero (tiene $goalkeepers)',
      );
    }
    if (slots.isNotEmpty && !slots.first.isGoalkeeper && goalkeepers == 1) {
      violations.add('El portero debe ocupar el primer puesto (índice 0)');
    }

    return violations;
  }

  /// 4-4-2 clásico.
  static final Formation f442 = Formation(
    label: '4-4-2',
    slots: const [
      Position.gk,
      Position.rb,
      Position.cb,
      Position.cb,
      Position.lb,
      Position.rw,
      Position.cm,
      Position.cm,
      Position.lw,
      Position.st,
      Position.st,
    ],
  );

  /// 4-3-3 con extremos.
  static final Formation f433 = Formation(
    label: '4-3-3',
    slots: const [
      Position.gk,
      Position.rb,
      Position.cb,
      Position.cb,
      Position.lb,
      Position.dm,
      Position.cm,
      Position.cm,
      Position.rw,
      Position.st,
      Position.lw,
    ],
  );

  /// 4-2-3-1 con doble pivote y mediapunta.
  static final Formation f4231 = Formation(
    label: '4-2-3-1',
    slots: const [
      Position.gk,
      Position.rb,
      Position.cb,
      Position.cb,
      Position.lb,
      Position.dm,
      Position.dm,
      Position.rw,
      Position.am,
      Position.lw,
      Position.st,
    ],
  );

  /// 3-5-2 con carrileros.
  static final Formation f352 = Formation(
    label: '3-5-2',
    slots: const [
      Position.gk,
      Position.cb,
      Position.cb,
      Position.cb,
      Position.rb,
      Position.dm,
      Position.cm,
      Position.cm,
      Position.lb,
      Position.st,
      Position.st,
    ],
  );

  /// 5-3-2 defensivo.
  static final Formation f532 = Formation(
    label: '5-3-2',
    slots: const [
      Position.gk,
      Position.rb,
      Position.cb,
      Position.cb,
      Position.cb,
      Position.lb,
      Position.dm,
      Position.cm,
      Position.cm,
      Position.st,
      Position.st,
    ],
  );

  /// Catálogo de formaciones estándar del juego.
  static final List<Formation> standard = List.unmodifiable([
    f442,
    f433,
    f4231,
    f352,
    f532,
  ]);

  @override
  bool operator ==(Object other) =>
      other is Formation &&
      other.label == label &&
      const ListEquality<Position>().equals(other.slots, slots);

  @override
  int get hashCode =>
      Object.hash(label, const ListEquality<Position>().hash(slots));

  @override
  String toString() => 'Formation($label)';
}
