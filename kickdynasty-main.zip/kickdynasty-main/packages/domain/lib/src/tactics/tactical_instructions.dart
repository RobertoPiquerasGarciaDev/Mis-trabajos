/// Instrucciones tácticas.
///
/// Este archivo define el vocabulario táctico ÚNICO del juego. El motor
/// consume exactamente estos valores; la UI presenta exactamente estos
/// valores. No existen sinónimos ni traducciones intermedias entre capas.
library;

import 'package:freezed_annotation/freezed_annotation.dart';

part 'tactical_instructions.freezed.dart';

/// Mentalidad global del equipo.
enum Mentality {
  /// Ultradefensiva.
  veryDefensive,

  /// Defensiva.
  defensive,

  /// Equilibrada.
  balanced,

  /// Ofensiva.
  attacking,

  /// Ultraofensiva.
  veryAttacking,
}

/// Velocidad de circulación del balón.
enum Tempo {
  /// Lento, pausado.
  slow,

  /// Estándar.
  standard,

  /// Rápido, vertical.
  fast,
}

/// Amplitud del juego.
enum Width {
  /// Juego por dentro.
  narrow,

  /// Estándar.
  standard,

  /// Juego a banda.
  wide,
}

/// Intensidad de la presión sin balón.
enum PressingIntensity {
  /// Repliegue.
  low,

  /// Presión media.
  medium,

  /// Presión alta.
  high,
}

/// Altura de la línea defensiva.
enum DefensiveLine {
  /// Línea baja.
  deep,

  /// Línea media.
  standard,

  /// Línea alta.
  high,
}

/// Estilo de pase predominante.
enum PassingStyle {
  /// Combinativo, pase corto.
  short,

  /// Mixto.
  mixed,

  /// Directo, pase largo.
  direct,
}

/// Conjunto completo de instrucciones tácticas de un equipo.
///
/// Todos los campos tienen un valor por defecto neutro: unas instrucciones
/// recién creadas son jugables y no penalizan.
@freezed
abstract class TacticalInstructions with _$TacticalInstructions {
  /// Crea las instrucciones; los campos omitidos toman el valor neutro.
  const factory TacticalInstructions({
    /// Mentalidad global.
    @Default(Mentality.balanced) Mentality mentality,

    /// Velocidad de circulación.
    @Default(Tempo.standard) Tempo tempo,

    /// Amplitud del juego.
    @Default(Width.standard) Width width,

    /// Intensidad de presión.
    @Default(PressingIntensity.medium) PressingIntensity pressing,

    /// Altura de la línea defensiva.
    @Default(DefensiveLine.standard) DefensiveLine defensiveLine,

    /// Estilo de pase.
    @Default(PassingStyle.mixed) PassingStyle passingStyle,
  }) = _TacticalInstructions;
}
