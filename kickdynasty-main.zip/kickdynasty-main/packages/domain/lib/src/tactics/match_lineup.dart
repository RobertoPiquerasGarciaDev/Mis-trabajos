/// Alineación de partido.
library;

import 'package:collection/collection.dart';
import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/tactics/formation.dart';
import 'package:kickdynasty_domain/src/tactics/tactical_instructions.dart';
import 'package:meta/meta.dart';

/// Alineación confirmada de un equipo para un partido.
///
/// Los [starters] se asignan a los slots de la [formation] por índice: el
/// jugador en `starters[i]` ocupa `formation.slots[i]`. Jugar fuera de la
/// posición natural es legal (el motor aplica la penalización); lo que la
/// estructura garantiza es que hay 11 titulares únicos, un banquillo sin
/// solapes y un capitán que juega de inicio.
@immutable
final class MatchLineup {
  /// Crea la alineación validando todos los invariantes.
  MatchLineup({
    required this.formation,
    required List<PlayerId> starters,
    required List<PlayerId> bench,
    required this.captainId,
    this.instructions = const TacticalInstructions(),
  }) : starters = List.unmodifiable(starters),
       bench = List.unmodifiable(bench) {
    final violations = validate(
      starters: starters,
      bench: bench,
      captainId: captainId,
    );
    if (violations.isNotEmpty) {
      throw DomainInvariantViolation(
        'Alineación inválida',
        violations: violations,
      );
    }
  }

  /// Formación empleada.
  final Formation formation;

  /// Los 11 titulares, alineados por índice con `formation.slots`.
  final List<PlayerId> starters;

  /// Suplentes convocados (hasta [maxBench]).
  final List<PlayerId> bench;

  /// Capitán; debe ser titular.
  final PlayerId captainId;

  /// Instrucciones tácticas del equipo.
  final TacticalInstructions instructions;

  /// Máximo de suplentes convocables.
  static const int maxBench = 9;

  /// Comprueba los invariantes y devuelve los incumplimientos encontrados
  /// (vacío si la alineación es válida).
  static List<String> validate({
    required List<PlayerId> starters,
    required List<PlayerId> bench,
    required PlayerId captainId,
  }) {
    final violations = <String>[];

    if (starters.length != Formation.squadSize) {
      violations.add(
        'Una alineación tiene exactamente ${Formation.squadSize} titulares '
        '(tiene ${starters.length})',
      );
    }
    if (starters.toSet().length != starters.length) {
      violations.add('Hay jugadores repetidos entre los titulares');
    }
    if (bench.length > maxBench) {
      violations.add(
        'El banquillo admite como máximo $maxBench suplentes '
        '(tiene ${bench.length})',
      );
    }
    if (bench.toSet().length != bench.length) {
      violations.add('Hay jugadores repetidos en el banquillo');
    }
    final overlap = starters.toSet().intersection(bench.toSet());
    if (overlap.isNotEmpty) {
      violations.add(
        'Jugadores a la vez titulares y suplentes: '
        '${overlap.map((id) => id.value).join(', ')}',
      );
    }
    if (!starters.contains(captainId)) {
      violations.add('El capitán debe ser titular');
    }

    return violations;
  }

  @override
  bool operator ==(Object other) =>
      other is MatchLineup &&
      other.formation == formation &&
      const ListEquality<PlayerId>().equals(other.starters, starters) &&
      const ListEquality<PlayerId>().equals(other.bench, bench) &&
      other.captainId == captainId &&
      other.instructions == instructions;

  @override
  int get hashCode => Object.hash(
    formation,
    const ListEquality<PlayerId>().hash(starters),
    const ListEquality<PlayerId>().hash(bench),
    captainId,
    instructions,
  );

  @override
  String toString() =>
      'MatchLineup(${formation.label}, capitán: ${captainId.value})';
}
