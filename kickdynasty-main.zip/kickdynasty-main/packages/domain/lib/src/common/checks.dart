/// Utilidades internas de validación para value objects y entidades.
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';

/// Valida que [value] esté en el rango cerrado [min]..[max].
///
/// Lanza [DomainInvariantViolation] si no lo está. [what] identifica el
/// concepto validado en el mensaje de error (p. ej. `'Rating'`).
void checkRange(int value, int min, int max, String what) {
  if (value < min || value > max) {
    throw DomainInvariantViolation(
      '$what debe estar entre $min y $max (recibido: $value)',
    );
  }
}

/// Valida que [value] no sea vacío ni solo espacios.
///
/// Lanza [DomainInvariantViolation] si lo es. Devuelve el valor recortado.
String checkNotBlank(String value, String what) {
  final trimmed = value.trim();
  if (trimmed.isEmpty) {
    throw DomainInvariantViolation('$what no puede estar vacío');
  }
  return trimmed;
}
