/// Identificadores tipados de las entidades del dominio.
///
/// Cada entidad tiene su propio tipo de id (coste cero en runtime gracias a
/// extension types) para que el compilador impida cruzar identificadores,
/// p. ej. pasar un id de club donde se espera un id de jugador.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de un jugador.
extension type const PlayerId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory PlayerId(String value) =>
      PlayerId._(checkNotBlank(value, 'PlayerId'));
}

/// Identificador único de un club.
extension type const ClubId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory ClubId(String value) => ClubId._(checkNotBlank(value, 'ClubId'));
}

/// Identificador único de una liga.
extension type const LeagueId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory LeagueId(String value) =>
      LeagueId._(checkNotBlank(value, 'LeagueId'));
}

/// Identificador único de un partido programado.
extension type const FixtureId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory FixtureId(String value) =>
      FixtureId._(checkNotBlank(value, 'FixtureId'));
}

/// Identificador único de un contrato.
extension type const ContractId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory ContractId(String value) =>
      ContractId._(checkNotBlank(value, 'ContractId'));
}
