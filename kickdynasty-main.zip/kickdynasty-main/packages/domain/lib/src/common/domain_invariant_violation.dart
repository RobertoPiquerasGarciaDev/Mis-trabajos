/// Excepción única para violaciones de invariantes del dominio.
///
/// Se lanza cuando un constructor o factory recibe datos que romperían una
/// regla del juego (p. ej. una alineación sin 11 titulares). Los flujos que
/// pueden fallar legítimamente durante la partida (p. ej. fichar sin fondos)
/// NO usan excepciones: devuelven tipos de resultado explícitos.
library;

/// Violación de un invariante del dominio.
///
/// Lleva un [message] general y, opcionalmente, la lista detallada de
/// [violations] individuales (útil cuando una validación agrega varios
/// incumplimientos, como en `MatchLineup`).
final class DomainInvariantViolation implements Exception {
  /// Crea la excepción con un [message] y las [violations] detalladas.
  DomainInvariantViolation(this.message, {this.violations = const []});

  /// Descripción general de la violación.
  final String message;

  /// Incumplimientos individuales detectados, si la validación agrega varios.
  final List<String> violations;

  @override
  String toString() {
    if (violations.isEmpty) return 'DomainInvariantViolation: $message';
    return 'DomainInvariantViolation: $message\n'
        '${violations.map((v) => '  - $v').join('\n')}';
  }
}
