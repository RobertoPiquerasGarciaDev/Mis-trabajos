/// Postura de un participante en una deliberación.
library;

/// Postura registrada en [DecisionRecord].
enum ParticipantStance {
  /// Quien impulsa la propuesta.
  proponent,

  /// Apoya sin liderar.
  support,

  /// Se opone.
  oppose,

  /// No interviene.
  abstain,

  /// Bloquea la resolución.
  veto,

  /// Aporta información sin postura.
  inform,
}
