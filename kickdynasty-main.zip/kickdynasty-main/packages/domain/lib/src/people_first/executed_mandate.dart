/// Mandato ejecutado en Reality tras una deliberación aprobada.
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/people_first/decision_record.dart';
import 'package:kickdynasty_domain/src/people_first/deliberation_protocol_type.dart';
import 'package:kickdynasty_domain/src/people_first/mandate_outcome.dart';
import 'package:meta/meta.dart';

/// Puente entre deliberación People First y motores atómicos (mercado, contratos).
@immutable
final class ExecutedMandate {
  /// Crea un mandato listo para ejecutor atómico.
  factory ExecutedMandate({
    required String decisionRecordId,
    required DeliberationProtocolType protocolType,
    required ClubId clubId,
    required MandateOutcome outcome,
    String? executionFactRef,
  }) {
    if (outcome != MandateOutcome.proceed) {
      throw DomainInvariantViolation(
        'ExecutedMandate exige outcome proceed; recibido: ${outcome.name}',
      );
    }
    return ExecutedMandate._(
      decisionRecordId: decisionRecordId,
      protocolType: protocolType,
      clubId: clubId,
      outcome: outcome,
      executionFactRef: executionFactRef,
    );
  }

  /// Crea un mandato desde un [DecisionRecord] aprobado.
  factory ExecutedMandate.fromDecisionRecord(
    DecisionRecord record, {
    String? executionFactRef,
  }) {
    return ExecutedMandate(
      decisionRecordId: record.id,
      protocolType: record.protocolType,
      clubId: record.clubId,
      outcome: record.outcome,
      executionFactRef: executionFactRef,
    );
  }

  const ExecutedMandate._({
    required this.decisionRecordId,
    required this.protocolType,
    required this.clubId,
    required this.outcome,
    this.executionFactRef,
  });

  /// Registro de deliberación origen.
  final String decisionRecordId;

  /// Protocolo ejecutado.
  final DeliberationProtocolType protocolType;

  /// Club afectado.
  final ClubId clubId;

  /// Siempre [MandateOutcome.proceed].
  final MandateOutcome outcome;

  /// Referencia al hecho en Reality post-ejecución (transferId, …).
  final String? executionFactRef;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'decisionRecordId': decisionRecordId,
    'protocolType': protocolType.name,
    'clubId': clubId.value,
    'outcome': outcome.name,
    if (executionFactRef != null) 'executionFactRef': executionFactRef,
  };

  /// Deserializa desde JSON.
  factory ExecutedMandate.fromJson(Map<String, Object?> json) {
    return ExecutedMandate(
      decisionRecordId: json['decisionRecordId']! as String,
      protocolType: DeliberationProtocolType.values.byName(
        json['protocolType']! as String,
      ),
      clubId: ClubId(json['clubId']! as String),
      outcome: MandateOutcome.values.byName(json['outcome']! as String),
      executionFactRef: json['executionFactRef'] as String?,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is ExecutedMandate &&
          decisionRecordId == other.decisionRecordId &&
          protocolType == other.protocolType &&
          clubId == other.clubId &&
          outcome == other.outcome &&
          executionFactRef == other.executionFactRef;

  @override
  int get hashCode => Object.hash(
    decisionRecordId,
    protocolType,
    clubId,
    outcome,
    executionFactRef,
  );
}
