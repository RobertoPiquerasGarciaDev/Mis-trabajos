/// Semilla determinista para instancias de protocolo (People First §10.4).
library;

import 'package:kickdynasty_domain/src/people_first/deliberation_protocol_type.dart';

/// Mezcla SplitMix64 — paridad con `kickdynasty_core` / `kickdynasty_engine`.
int _splitMix64(int x) {
  var z = x + 0x9E3779B97F4A7C15;
  z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9;
  z = (z ^ (z >>> 27)) * 0x94D049BB133111EB;
  return z ^ (z >>> 31);
}

int _mix(int value) => _splitMix64(_splitMix64(value));

/// Deriva la semilla de una instancia de protocolo.
///
/// Contrato People First: mismos inputs → misma semilla → mismo desenlace CPU.
int deliberationProtocolSeed({
  required int worldSeed,
  required int season,
  required int week,
  required String clubId,
  required DeliberationProtocolType protocolType,
  required String instanceId,
}) {
  var seed = _mix(worldSeed);
  seed = _mix(seed ^ season);
  seed = _mix(seed ^ week);
  seed = _mix(seed ^ clubId.hashCode);
  seed = _mix(seed ^ protocolType.index);
  seed = _mix(seed ^ instanceId.hashCode);
  return seed;
}
