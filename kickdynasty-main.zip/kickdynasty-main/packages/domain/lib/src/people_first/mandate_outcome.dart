/// Resultado de la fase de resolución de un protocolo.
library;

/// Desenlace de una deliberación antes de ejecutar en Reality.
enum MandateOutcome {
  /// Mandato aprobado — puede ejecutarse.
  proceed,

  /// Aplazado — sin acción esta semana.
  defer,

  /// Rechazado — sin ejecución.
  reject,
}
