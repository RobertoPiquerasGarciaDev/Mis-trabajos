/// Tipos de protocolo institucional (catálogo v1 People First).
library;

/// Identificador de protocolo de deliberación.
enum DeliberationProtocolType {
  /// Venta de jugador propuesto por el DD.
  transferOutDeliberation,

  /// Fichaje propuesto por el DD.
  transferInDeliberation,

  /// Préstamo.
  loanDeliberation,

  /// Renovación contractual.
  renewalDeliberation,

  /// Dejar expirar contrato.
  letExpireDeliberation,

  /// Promoción canterano.
  promotionDeliberation,

  /// Destitución de staff.
  dismissalDeliberation,

  /// Mandato de alineación del entrenador.
  lineupMandate,

  /// Revisión de estrategia institucional.
  strategyReviewDeliberation,
}
