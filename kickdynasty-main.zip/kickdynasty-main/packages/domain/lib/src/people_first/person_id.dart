/// Identificador estable de una persona (agente) en People First.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';

/// Identificador único de una persona — distinto de [PlayerId] (rol deportivo).
extension type const PersonId._(String value) {
  /// Crea el id validando que no esté vacío.
  factory PersonId(String value) =>
      PersonId._(checkNotBlank(value, 'PersonId'));
}
