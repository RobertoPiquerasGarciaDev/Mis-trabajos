/// Participante en una deliberación institucional.
library;

import 'package:kickdynasty_domain/src/people_first/participant_stance.dart';
import 'package:kickdynasty_domain/src/people_first/person_id.dart';
import 'package:meta/meta.dart';

/// Actor que intervino (o debía intervenir) en un protocolo.
@immutable
final class DeliberationParticipant {
  /// Crea un participante con postura registrada.
  const DeliberationParticipant({
    required this.personId,
    required this.roleId,
    required this.stance,
    this.summary = '',
  });

  /// Persona responsable.
  final PersonId personId;

  /// Rol canónico (p. ej. `sportingDirector`, `president`).
  final String roleId;

  /// Postura en la deliberación.
  final ParticipantStance stance;

  /// Resumen legible opcional de su intervención.
  final String summary;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'personId': personId.value,
    'roleId': roleId,
    'stance': stance.name,
    if (summary.isNotEmpty) 'summary': summary,
  };

  /// Deserializa desde JSON.
  factory DeliberationParticipant.fromJson(Map<String, Object?> json) {
    return DeliberationParticipant(
      personId: PersonId(json['personId']! as String),
      roleId: json['roleId']! as String,
      stance: ParticipantStance.values.byName(json['stance']! as String),
      summary: json['summary'] as String? ?? '',
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DeliberationParticipant &&
          personId == other.personId &&
          roleId == other.roleId &&
          stance == other.stance &&
          summary == other.summary;

  @override
  int get hashCode => Object.hash(personId, roleId, stance, summary);
}
