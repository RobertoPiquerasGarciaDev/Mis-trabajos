/// Contrato de protocolos de deliberación People First.
library;

import 'package:kickdynasty_domain/src/people_first/deliberation_phase.dart';
import 'package:kickdynasty_domain/src/people_first/deliberation_protocol_type.dart';
import 'package:meta/meta.dart';

/// Metadatos de un protocolo acotado (People First §10).
abstract interface class DeliberationProtocol {
  /// Tipo canónico del protocolo.
  DeliberationProtocolType get type;

  /// Fases en orden determinista de ejecución.
  List<DeliberationPhase> get phases;
}

/// Definición inmutable de un protocolo — catálogo v1.
@immutable
final class DeliberationProtocolDefinition implements DeliberationProtocol {
  /// Crea la definición con fases ordenadas.
  const DeliberationProtocolDefinition({
    required this.type,
    required this.phases,
  });

  @override
  final DeliberationProtocolType type;

  @override
  final List<DeliberationPhase> phases;

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DeliberationProtocolDefinition &&
          type == other.type &&
          _listEquals(phases, other.phases);

  @override
  int get hashCode => Object.hash(type, Object.hashAll(phases));
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}

/// Catálogo estático de protocolos v1 (People First §10.3).
abstract final class DeliberationProtocols {
  /// Venta de jugador.
  static const transferOut = DeliberationProtocolDefinition(
    type: DeliberationProtocolType.transferOutDeliberation,
    phases: [
      DeliberationPhase.needDetected,
      DeliberationPhase.proposal,
      DeliberationPhase.preference,
      DeliberationPhase.constraint,
      DeliberationPhase.dissent,
      DeliberationPhase.resolution,
      DeliberationPhase.execution,
      DeliberationPhase.chronicle,
      DeliberationPhase.memory,
    ],
  );

  /// Fichaje.
  static const transferIn = DeliberationProtocolDefinition(
    type: DeliberationProtocolType.transferInDeliberation,
    phases: [
      DeliberationPhase.needDetected,
      DeliberationPhase.proposal,
      DeliberationPhase.report,
      DeliberationPhase.preference,
      DeliberationPhase.constraint,
      DeliberationPhase.dissent,
      DeliberationPhase.resolution,
      DeliberationPhase.execution,
      DeliberationPhase.chronicle,
      DeliberationPhase.memory,
    ],
  );

  /// Renovación contractual.
  static const renewal = DeliberationProtocolDefinition(
    type: DeliberationProtocolType.renewalDeliberation,
    phases: [
      DeliberationPhase.needDetected,
      DeliberationPhase.proposal,
      DeliberationPhase.constraint,
      DeliberationPhase.dissent,
      DeliberationPhase.resolution,
      DeliberationPhase.execution,
      DeliberationPhase.chronicle,
      DeliberationPhase.memory,
    ],
  );

  /// Mandato de alineación semanal.
  static const lineup = DeliberationProtocolDefinition(
    type: DeliberationProtocolType.lineupMandate,
    phases: [
      DeliberationPhase.proposal,
      DeliberationPhase.resolution,
      DeliberationPhase.execution,
      DeliberationPhase.chronicle,
    ],
  );

  /// Todas las definiciones conocidas en PF-0.
  static const all = [transferOut, transferIn, renewal, lineup];
}

/// Busca la definición de un [type] en el catálogo v1.
DeliberationProtocolDefinition? deliberationProtocolForType(
  DeliberationProtocolType type,
) {
  for (final definition in DeliberationProtocols.all) {
    if (definition.type == type) return definition;
  }
  return null;
}
