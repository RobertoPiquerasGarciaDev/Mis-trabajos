/// Registro trazable de una deliberación institucional.
library;

import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/people_first/deliberation_participant.dart';
import 'package:kickdynasty_domain/src/people_first/deliberation_protocol_type.dart';
import 'package:kickdynasty_domain/src/people_first/mandate_outcome.dart';
import 'package:meta/meta.dart';

/// Entrada append-only que responde la regla de oro People First.
@immutable
final class DecisionRecord {
  /// Crea un registro de decisión.
  const DecisionRecord({
    required this.id,
    required this.protocolType,
    required this.clubId,
    required this.season,
    required this.week,
    required this.instanceId,
    required this.outcome,
    required this.participants,
    this.proposalSummary = '',
    this.dissent = const [],
    this.refs = const {},
  });

  /// Identificador estable del registro (único en el save).
  final String id;

  /// Protocolo que produjo este registro.
  final DeliberationProtocolType protocolType;

  /// Club afectado.
  final ClubId clubId;

  /// Temporada en curso al registrar.
  final int season;

  /// Jornada en curso al registrar.
  final int week;

  /// Identificador de instancia del protocolo (para semilla determinista).
  final String instanceId;

  /// Desenlace de la deliberación.
  final MandateOutcome outcome;

  /// Actores y posturas.
  final List<DeliberationParticipant> participants;

  /// Resumen legible de la propuesta o decisión.
  final String proposalSummary;

  /// Oposiciones registradas (texto legible).
  final List<String> dissent;

  /// Referencias verificables (`playerId`, `fee`, …).
  final Map<String, String> refs;

  /// Serializa a JSON.
  Map<String, Object?> toJson() => {
    'id': id,
    'protocolType': protocolType.name,
    'clubId': clubId.value,
    'season': season,
    'week': week,
    'instanceId': instanceId,
    'outcome': outcome.name,
    'participants': [for (final p in participants) p.toJson()],
    if (proposalSummary.isNotEmpty) 'proposalSummary': proposalSummary,
    if (dissent.isNotEmpty) 'dissent': dissent,
    if (refs.isNotEmpty) 'refs': refs,
  };

  /// Deserializa desde JSON.
  factory DecisionRecord.fromJson(Map<String, Object?> json) {
    return DecisionRecord(
      id: json['id']! as String,
      protocolType: DeliberationProtocolType.values.byName(
        json['protocolType']! as String,
      ),
      clubId: ClubId(json['clubId']! as String),
      season: json['season']! as int,
      week: json['week']! as int,
      instanceId: json['instanceId']! as String,
      outcome: MandateOutcome.values.byName(json['outcome']! as String),
      participants: [
        for (final item in json['participants']! as List)
          DeliberationParticipant.fromJson(
            Map<String, Object?>.from(item as Map),
          ),
      ],
      proposalSummary: json['proposalSummary'] as String? ?? '',
      dissent: [
        for (final item in (json['dissent'] as List?) ?? const [])
          item as String,
      ],
      refs: Map<String, String>.from(
        (json['refs'] as Map?)?.cast<String, String>() ?? const {},
      ),
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is DecisionRecord &&
          id == other.id &&
          protocolType == other.protocolType &&
          clubId == other.clubId &&
          season == other.season &&
          week == other.week &&
          instanceId == other.instanceId &&
          outcome == other.outcome &&
          _listEquals(participants, other.participants) &&
          proposalSummary == other.proposalSummary &&
          _listEquals(dissent, other.dissent) &&
          _mapEquals(refs, other.refs);

  @override
  int get hashCode => Object.hash(
    id,
    protocolType,
    clubId,
    season,
    week,
    instanceId,
    outcome,
    Object.hashAll(participants),
    proposalSummary,
    Object.hashAll(dissent),
    Object.hashAll(refs.entries),
  );
}

bool _listEquals<T>(List<T> a, List<T> b) {
  if (a.length != b.length) return false;
  for (var i = 0; i < a.length; i++) {
    if (a[i] != b[i]) return false;
  }
  return true;
}

bool _mapEquals(Map<String, String> a, Map<String, String> b) {
  if (a.length != b.length) return false;
  for (final entry in a.entries) {
    if (b[entry.key] != entry.value) return false;
  }
  return true;
}
