/// Fases del patrón universal de deliberación (People First §10).
library;

/// Fase procesal dentro de un [DeliberationProtocol].
enum DeliberationPhase {
  /// Necesidad detectada por un actor.
  needDetected,

  /// Propuesta formal al protocolo.
  proposal,

  /// Informe (p. ej. scouting).
  report,

  /// Preferencias declaradas.
  preference,

  /// Restricciones institucionales.
  constraint,

  /// Disenso registrado.
  dissent,

  /// Resolución del mandato.
  resolution,

  /// Ejecución en Reality.
  execution,

  /// Entrada en Chronicle.
  chronicle,

  /// Consolidación en memoria del agente.
  memory,
}
