/// Resultado de un partido.
library;

import 'package:collection/collection.dart';
import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/competition/match_event.dart';
import 'package:meta/meta.dart';

/// Resultado de un partido ya disputado.
///
/// Invariantes:
/// - goles ≥ 0 en ambos lados;
/// - los eventos están ordenados por minuto no decreciente;
/// - si hay eventos, los goles del marcador coinciden exactamente con los
///   eventos [GoalScored] de cada lado.
///
/// La lista de eventos puede estar vacía (p. ej. resultados antiguos cuyos
/// detalles se han purgado del almacenamiento); en ese caso el marcador es
/// la única información. El motor siempre produce el detalle completo:
/// para eso está [MatchResult.fromEvents], que deriva el marcador de los
/// eventos y hace la inconsistencia imposible por construcción.
@immutable
final class MatchResult {
  /// Crea un resultado validando todos los invariantes.
  MatchResult({
    required this.fixtureId,
    required this.homeGoals,
    required this.awayGoals,
    List<MatchEvent> events = const [],
  }) : events = List.unmodifiable(events) {
    final violations = validate(
      homeGoals: homeGoals,
      awayGoals: awayGoals,
      events: events,
    );
    if (violations.isNotEmpty) {
      throw DomainInvariantViolation(
        'Resultado inválido para el fixture ${fixtureId.value}',
        violations: violations,
      );
    }
  }

  /// Crea un resultado derivando el marcador de los [events].
  ///
  /// Es la vía que usa el motor: el marcador no puede contradecir a los
  /// eventos porque se calcula a partir de ellos.
  factory MatchResult.fromEvents({
    required FixtureId fixtureId,
    required List<MatchEvent> events,
  }) {
    final goals = events.whereType<GoalScored>();
    return MatchResult(
      fixtureId: fixtureId,
      homeGoals: goals.where((g) => g.side == TeamSide.home).length,
      awayGoals: goals.where((g) => g.side == TeamSide.away).length,
      events: events,
    );
  }

  /// Partido al que corresponde el resultado.
  final FixtureId fixtureId;

  /// Goles del equipo local.
  final int homeGoals;

  /// Goles del equipo visitante.
  final int awayGoals;

  /// Cronología de eventos del partido (lista inmutable, puede estar vacía).
  final List<MatchEvent> events;

  /// Comprueba los invariantes y devuelve los incumplimientos (vacío si el
  /// resultado es válido).
  static List<String> validate({
    required int homeGoals,
    required int awayGoals,
    required List<MatchEvent> events,
  }) {
    final violations = <String>[];

    if (homeGoals < 0) {
      violations.add('Los goles locales no pueden ser negativos ($homeGoals)');
    }
    if (awayGoals < 0) {
      violations.add(
        'Los goles visitantes no pueden ser negativos ($awayGoals)',
      );
    }

    for (var i = 1; i < events.length; i++) {
      if (events[i].minute.value < events[i - 1].minute.value) {
        violations.add(
          'Los eventos deben estar ordenados por minuto '
          '(evento $i en min ${events[i].minute.value} tras '
          'min ${events[i - 1].minute.value})',
        );
        break;
      }
    }

    if (events.isNotEmpty) {
      final goals = events.whereType<GoalScored>();
      final homeFromEvents = goals.where((g) => g.side == TeamSide.home).length;
      final awayFromEvents = goals.where((g) => g.side == TeamSide.away).length;
      if (homeFromEvents != homeGoals || awayFromEvents != awayGoals) {
        violations.add(
          'El marcador ($homeGoals-$awayGoals) no coincide con los eventos '
          'de gol ($homeFromEvents-$awayFromEvents)',
        );
      }
    }

    return violations;
  }

  /// Lado ganador, o `null` si hubo empate.
  TeamSide? get winner {
    if (homeGoals > awayGoals) return TeamSide.home;
    if (awayGoals > homeGoals) return TeamSide.away;
    return null;
  }

  /// `true` si el partido acabó en empate.
  bool get isDraw => homeGoals == awayGoals;

  @override
  bool operator ==(Object other) =>
      other is MatchResult &&
      other.fixtureId == fixtureId &&
      other.homeGoals == homeGoals &&
      other.awayGoals == awayGoals &&
      const ListEquality<MatchEvent>().equals(other.events, events);

  @override
  int get hashCode => Object.hash(
    fixtureId,
    homeGoals,
    awayGoals,
    const ListEquality<MatchEvent>().hash(events),
  );

  @override
  String toString() => 'MatchResult(${fixtureId.value}: $homeGoals-$awayGoals)';
}
