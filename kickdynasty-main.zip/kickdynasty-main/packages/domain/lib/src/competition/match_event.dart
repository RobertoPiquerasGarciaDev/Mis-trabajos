/// Eventos de partido.
///
/// Todos los eventos referencian jugadores reales del estado de la partida
/// por su [PlayerId]. No existen eventos "decorativos" con nombres
/// inventados: si el motor emite un gol, el goleador existe.
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/values/match_minute.dart';
import 'package:meta/meta.dart';

/// Lado de un equipo en un partido.
enum TeamSide {
  /// Equipo local.
  home,

  /// Equipo visitante.
  away,
}

/// Tipo de tarjeta.
enum CardType {
  /// Amarilla.
  yellow,

  /// Segunda amarilla (implica expulsión).
  secondYellow,

  /// Roja directa.
  red,
}

/// Evento ocurrido durante un partido, con el minuto y el lado al que se
/// atribuye.
@immutable
sealed class MatchEvent {
  const MatchEvent({required this.minute, required this.side});

  /// Minuto del evento.
  final MatchMinute minute;

  /// Lado al que se atribuye el evento.
  final TeamSide side;
}

/// Gol anotado.
///
/// [side] es el equipo al que se le suma el gol en el marcador. En un gol en
/// propia puerta ([ownGoal]), el goleador pertenece al equipo contrario.
final class GoalScored extends MatchEvent {
  /// Crea un gol validando que el goleador no se asista a sí mismo y que un
  /// gol en propia puerta no lleve asistencia.
  GoalScored({
    required super.minute,
    required super.side,
    required this.scorerId,
    this.assistantId,
    this.ownGoal = false,
  }) {
    if (assistantId == scorerId) {
      throw DomainInvariantViolation(
        'Un jugador no puede asistirse a sí mismo (${scorerId.value})',
      );
    }
    if (ownGoal && assistantId != null) {
      throw DomainInvariantViolation(
        'Un gol en propia puerta no puede tener asistencia',
      );
    }
  }

  /// Autor del gol.
  final PlayerId scorerId;

  /// Autor de la asistencia, si la hubo.
  final PlayerId? assistantId;

  /// `true` si es gol en propia puerta.
  final bool ownGoal;

  @override
  bool operator ==(Object other) =>
      other is GoalScored &&
      other.minute == minute &&
      other.side == side &&
      other.scorerId == scorerId &&
      other.assistantId == assistantId &&
      other.ownGoal == ownGoal;

  @override
  int get hashCode => Object.hash(minute, side, scorerId, assistantId, ownGoal);

  @override
  String toString() =>
      "GoalScored(min $minute, $side, ${scorerId.value}${ownGoal ? ', p.p.' : ''})";
}

/// Tarjeta mostrada a un jugador.
final class CardIssued extends MatchEvent {
  /// Crea el evento de tarjeta.
  CardIssued({
    required super.minute,
    required super.side,
    required this.playerId,
    required this.cardType,
  });

  /// Jugador amonestado o expulsado.
  final PlayerId playerId;

  /// Tipo de tarjeta.
  final CardType cardType;

  /// `true` si la tarjeta implica expulsión.
  bool get isSendingOff => cardType != CardType.yellow;

  @override
  bool operator ==(Object other) =>
      other is CardIssued &&
      other.minute == minute &&
      other.side == side &&
      other.playerId == playerId &&
      other.cardType == cardType;

  @override
  int get hashCode => Object.hash(minute, side, playerId, cardType);

  @override
  String toString() =>
      'CardIssued(min $minute, $side, ${playerId.value}, $cardType)';
}

/// Lesión de un jugador durante el partido.
final class PlayerInjured extends MatchEvent {
  /// Crea el evento de lesión.
  PlayerInjured({
    required super.minute,
    required super.side,
    required this.playerId,
  });

  /// Jugador lesionado.
  final PlayerId playerId;

  @override
  bool operator ==(Object other) =>
      other is PlayerInjured &&
      other.minute == minute &&
      other.side == side &&
      other.playerId == playerId;

  @override
  int get hashCode => Object.hash(minute, side, playerId);

  @override
  String toString() => 'PlayerInjured(min $minute, $side, ${playerId.value})';
}

/// Sustitución de un jugador por otro.
final class Substitution extends MatchEvent {
  /// Crea la sustitución validando que entra y sale no sean el mismo jugador.
  Substitution({
    required super.minute,
    required super.side,
    required this.playerOutId,
    required this.playerInId,
  }) {
    if (playerOutId == playerInId) {
      throw DomainInvariantViolation(
        'Un jugador no puede sustituirse a sí mismo (${playerOutId.value})',
      );
    }
  }

  /// Jugador que abandona el campo.
  final PlayerId playerOutId;

  /// Jugador que entra al campo.
  final PlayerId playerInId;

  @override
  bool operator ==(Object other) =>
      other is Substitution &&
      other.minute == minute &&
      other.side == side &&
      other.playerOutId == playerOutId &&
      other.playerInId == playerInId;

  @override
  int get hashCode => Object.hash(minute, side, playerOutId, playerInId);

  @override
  String toString() =>
      'Substitution(min $minute, $side, '
      '${playerOutId.value} → ${playerInId.value})';
}
