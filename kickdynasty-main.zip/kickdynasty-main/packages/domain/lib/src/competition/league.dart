/// Entidad liga.
library;

import 'package:collection/collection.dart';
import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/values/display_name.dart';
import 'package:meta/meta.dart';

/// Una liga: competición de todos contra todos a doble vuelta.
///
/// Invariantes: entre [minClubs] y [maxClubs] clubes, número par (el
/// calendario round-robin no admite descansos en v1) y sin clubes repetidos.
@immutable
final class League {
  /// Crea una liga validando sus invariantes.
  League({
    required this.id,
    required this.name,
    required this.country,
    required List<ClubId> clubIds,
  }) : clubIds = List.unmodifiable(clubIds) {
    final violations = validate(clubIds);
    if (violations.isNotEmpty) {
      throw DomainInvariantViolation(
        'Liga inválida: ${name.value}',
        violations: violations,
      );
    }
  }

  /// Identificador único.
  final LeagueId id;

  /// Nombre de la competición.
  final DisplayName name;

  /// País de la competición (ISO 3166-1 alfa-2).
  final CountryCode country;

  /// Clubes participantes (lista inmutable).
  final List<ClubId> clubIds;

  /// Mínimo de clubes.
  static const int minClubs = 4;

  /// Máximo de clubes.
  static const int maxClubs = 32;

  /// Comprueba los invariantes y devuelve los incumplimientos (vacío si es
  /// válida).
  static List<String> validate(List<ClubId> clubIds) {
    final violations = <String>[];

    if (clubIds.length < minClubs || clubIds.length > maxClubs) {
      violations.add(
        'Una liga tiene entre $minClubs y $maxClubs clubes '
        '(tiene ${clubIds.length})',
      );
    }
    if (clubIds.length.isOdd) {
      violations.add(
        'El número de clubes debe ser par para el calendario round-robin '
        '(tiene ${clubIds.length})',
      );
    }
    if (clubIds.toSet().length != clubIds.length) {
      violations.add('Hay clubes repetidos en la liga');
    }

    return violations;
  }

  /// Número de jornadas de una temporada (doble vuelta).
  int get roundsPerSeason => (clubIds.length - 1) * 2;

  /// Partidos por jornada.
  int get matchesPerRound => clubIds.length ~/ 2;

  @override
  bool operator ==(Object other) =>
      other is League &&
      other.id == id &&
      other.name == name &&
      other.country == country &&
      const ListEquality<ClubId>().equals(other.clubIds, clubIds);

  @override
  int get hashCode => Object.hash(
    id,
    name,
    country,
    const ListEquality<ClubId>().hash(clubIds),
  );

  @override
  String toString() => 'League(${name.value}, ${clubIds.length} clubes)';
}
