/// Partido programado.
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:meta/meta.dart';

/// Un partido programado de una competición.
///
/// El resultado, si ya se ha jugado, vive en `MatchResult` (separado: un
/// fixture existe desde que se genera el calendario, el resultado solo
/// desde que el motor lo simula).
@immutable
final class Fixture {
  /// Crea un fixture validando temporada ≥ 1, jornada ≥ 1 y que un club no
  /// juegue contra sí mismo.
  Fixture({
    required this.id,
    required this.leagueId,
    required this.season,
    required this.round,
    required this.homeClubId,
    required this.awayClubId,
  }) {
    if (season < 1) {
      throw DomainInvariantViolation(
        'Fixture.season debe ser >= 1 (recibido: $season)',
      );
    }
    if (round < 1) {
      throw DomainInvariantViolation(
        'Fixture.round debe ser >= 1 (recibido: $round)',
      );
    }
    if (homeClubId == awayClubId) {
      throw DomainInvariantViolation(
        'Un club no puede jugar contra sí mismo (${homeClubId.value})',
      );
    }
  }

  /// Identificador único.
  final FixtureId id;

  /// Liga a la que pertenece.
  final LeagueId leagueId;

  /// Temporada (≥ 1).
  final int season;

  /// Jornada dentro de la temporada (≥ 1).
  final int round;

  /// Club local.
  final ClubId homeClubId;

  /// Club visitante.
  final ClubId awayClubId;

  @override
  bool operator ==(Object other) =>
      other is Fixture &&
      other.id == id &&
      other.leagueId == leagueId &&
      other.season == season &&
      other.round == round &&
      other.homeClubId == homeClubId &&
      other.awayClubId == awayClubId;

  @override
  int get hashCode =>
      Object.hash(id, leagueId, season, round, homeClubId, awayClubId);

  @override
  String toString() =>
      'Fixture(J$round: ${homeClubId.value} vs ${awayClubId.value})';
}
