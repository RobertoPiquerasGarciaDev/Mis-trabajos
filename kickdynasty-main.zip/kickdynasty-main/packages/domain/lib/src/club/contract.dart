/// Contrato entre un jugador y un club.
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/values/game_date.dart';
import 'package:kickdynasty_domain/src/values/money.dart';
import 'package:meta/meta.dart';

/// Vínculo contractual entre un jugador y un club.
///
/// Es la única fuente de verdad de la relación jugador–club. Un contrato es
/// inmutable: una renovación o un traspaso crean un contrato nuevo (la
/// transacción que lo garantiza llega con el sistema de mercado, Fase 7).
@immutable
final class Contract {
  /// Crea un contrato validando que el salario no sea negativo.
  Contract({
    required this.id,
    required this.playerId,
    required this.clubId,
    required this.weeklyWage,
    required this.expiry,
  }) {
    if (weeklyWage.isNegative) {
      throw DomainInvariantViolation(
        'Contract.weeklyWage no puede ser negativo '
        '(recibido: ${weeklyWage.amount})',
      );
    }
  }

  /// Identificador único del contrato.
  final ContractId id;

  /// Jugador contratado.
  final PlayerId playerId;

  /// Club contratante.
  final ClubId clubId;

  /// Salario semanal (≥ 0).
  final Money weeklyWage;

  /// Fecha de expiración: el contrato deja de estar vigente a partir de
  /// esta semana inclusive.
  final GameDate expiry;

  /// `true` si el contrato ya no está vigente en la fecha [date].
  bool isExpiredAt(GameDate date) => !date.isBefore(expiry);

  @override
  bool operator ==(Object other) =>
      other is Contract &&
      other.id == id &&
      other.playerId == playerId &&
      other.clubId == clubId &&
      other.weeklyWage == weeklyWage &&
      other.expiry == expiry;

  @override
  int get hashCode => Object.hash(id, playerId, clubId, weeklyWage, expiry);

  @override
  String toString() =>
      'Contract(${id.value}: ${playerId.value} → ${clubId.value}, '
      '${weeklyWage.amount}/sem hasta $expiry)';
}
