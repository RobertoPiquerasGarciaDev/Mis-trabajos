/// Estadio de un club.
library;

import 'package:kickdynasty_domain/src/common/checks.dart';
import 'package:kickdynasty_domain/src/values/display_name.dart';
import 'package:meta/meta.dart';

/// Estadio de un club: nombre y aforo.
@immutable
final class Stadium {
  /// Crea un estadio validando que el aforo esté en
  /// [minCapacity]..[maxCapacity].
  Stadium({required this.name, required this.capacity}) {
    checkRange(capacity, minCapacity, maxCapacity, 'Stadium.capacity');
  }

  /// Nombre del estadio.
  final DisplayName name;

  /// Aforo en espectadores.
  final int capacity;

  /// Aforo mínimo admitido en el juego.
  static const int minCapacity = 500;

  /// Aforo máximo admitido en el juego.
  static const int maxCapacity = 150000;

  @override
  bool operator ==(Object other) =>
      other is Stadium && other.name == name && other.capacity == capacity;

  @override
  int get hashCode => Object.hash(name, capacity);

  @override
  String toString() => 'Stadium(${name.value}, $capacity)';
}
