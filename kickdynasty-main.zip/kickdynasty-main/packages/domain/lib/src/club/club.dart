/// Entidad club.
library;

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:kickdynasty_domain/src/club/stadium.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/values/display_name.dart';
import 'package:kickdynasty_domain/src/values/money.dart';
import 'package:kickdynasty_domain/src/values/rating.dart';

part 'club.freezed.dart';

/// Un club del mundo del juego.
///
/// El saldo ([balance]) puede ser negativo (deuda); las reglas de juego
/// limpio financiero son lógica del motor, no del dato. La plantilla del
/// club es `Squad` y los vínculos con jugadores son `Contract`.
@freezed
abstract class Club with _$Club {
  /// Crea un club.
  const factory Club({
    /// Identificador único.
    required ClubId id,

    /// Nombre completo.
    required DisplayName name,

    /// Código corto para marcadores (p. ej. `FCB`).
    required ClubCode code,

    /// País del club (ISO 3166-1 alfa-2).
    required CountryCode country,

    /// Reputación deportiva en la escala única 1–99.
    required Rating reputation,

    /// Estadio propio.
    required Stadium stadium,

    /// Saldo de tesorería actual.
    required Money balance,
  }) = _Club;
}
