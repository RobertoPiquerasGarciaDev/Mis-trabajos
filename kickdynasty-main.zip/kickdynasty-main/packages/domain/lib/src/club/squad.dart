/// Plantilla de un club.
library;

import 'package:kickdynasty_domain/src/common/domain_invariant_violation.dart';
import 'package:kickdynasty_domain/src/common/ids.dart';
import 'package:kickdynasty_domain/src/player/player.dart';
import 'package:kickdynasty_domain/src/player/position.dart';
import 'package:meta/meta.dart';

/// Plantilla de un club: la colección validada de sus jugadores.
///
/// Invariantes (todos verificados en construcción):
/// - entre [minSize] y [maxSize] jugadores;
/// - sin jugadores duplicados;
/// - al menos [minGoalkeepers] porteros de posición natural, para que una
///   lesión no deje al club sin portería.
@immutable
final class Squad {
  /// Crea la plantilla validando todos los invariantes.
  Squad({required this.clubId, required List<Player> players})
    : players = List.unmodifiable(players) {
    final violations = validate(players);
    if (violations.isNotEmpty) {
      throw DomainInvariantViolation(
        'Plantilla inválida para el club ${clubId.value}',
        violations: violations,
      );
    }
  }

  /// Club al que pertenece la plantilla.
  final ClubId clubId;

  /// Jugadores de la plantilla (lista inmutable).
  final List<Player> players;

  /// Tamaño mínimo de plantilla.
  static const int minSize = 16;

  /// Tamaño máximo de plantilla.
  static const int maxSize = 40;

  /// Mínimo de porteros de posición natural.
  static const int minGoalkeepers = 2;

  /// Comprueba los invariantes de una lista de jugadores y devuelve los
  /// incumplimientos encontrados (vacío si es válida).
  ///
  /// Útil para que la UI o el motor evalúen una plantilla hipotética sin
  /// capturar excepciones.
  static List<String> validate(List<Player> players) {
    final violations = <String>[];

    if (players.length < minSize || players.length > maxSize) {
      violations.add(
        'La plantilla debe tener entre $minSize y $maxSize jugadores '
        '(tiene ${players.length})',
      );
    }

    final ids = <PlayerId>{};
    for (final player in players) {
      if (!ids.add(player.id)) {
        violations.add('Jugador duplicado: ${player.id.value}');
      }
    }

    final goalkeepers = players.where((p) => p.position.isGoalkeeper).length;
    if (goalkeepers < minGoalkeepers) {
      violations.add(
        'La plantilla debe tener al menos $minGoalkeepers porteros '
        '(tiene $goalkeepers)',
      );
    }

    return violations;
  }

  /// Número de jugadores de la plantilla.
  int get size => players.length;

  /// Jugadores cuya posición natural pertenece a [group].
  List<Player> byGroup(PositionGroup group) =>
      players.where((p) => p.position.group == group).toList();

  /// Busca un jugador por [id]; `null` si no está en la plantilla.
  Player? byId(PlayerId id) {
    for (final player in players) {
      if (player.id == id) return player;
    }
    return null;
  }

  /// `true` si el jugador [id] pertenece a la plantilla.
  bool contains(PlayerId id) => byId(id) != null;
}
