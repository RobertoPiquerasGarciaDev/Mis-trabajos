# Changelog — kickdynasty_domain

## 0.1.0

Primera versión del dominio (cierre de la Fase 1 del roadmap).

- Ids tipados con extension types: `PlayerId`, `ClubId`, `LeagueId`,
  `FixtureId`, `ContractId`.
- Value objects validados: `Money`, `Rating` (1–99), `Fitness`/`Morale`/`Form`
  (0–100), `Age` (14–50), `MatchMinute` (1–120), `DisplayName`, `ClubCode`,
  `CountryCode`, `GameDate` (temporada/semana, comparable).
- Jugador: `Player`, `PlayerAttributes` (11 atributos en escala única),
  `Position` (10 posiciones en 4 líneas), `PreferredFoot`.
- Club: `Club`, `Stadium`, `Contract` (salario ≥ 0, expiración por fecha de
  juego), `Squad` (16–40 jugadores, sin duplicados, ≥ 2 porteros).
- Táctica: `Formation` (11 slots, 1 portero, catálogo estándar),
  `TacticalInstructions` (6 ejes con valores neutros por defecto),
  `MatchLineup` (11 titulares únicos, banquillo ≤ 9 sin solapes, capitán
  titular).
- Competición: `League` (4–32 clubes, par, sin repetidos), `Fixture`,
  `MatchEvent` sellado (gol, tarjeta, lesión, sustitución) y `MatchResult`
  con coherencia marcador–eventos garantizada por `fromEvents`.
- `DomainInvariantViolation` como excepción única de invariantes, con lista
  de incumplimientos.
- 94 tests; cobertura de líneas 100 %.
