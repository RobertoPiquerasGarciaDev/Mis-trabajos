# kickdynasty_domain

Entidades, value objects e invariantes del dominio de KickDynasty. Es el
**vocabulario único del juego**: motor, persistencia, aplicación y UI usan
exactamente estos tipos. Ninguna capa redefine posiciones, escalas ni nombres
de conceptos.

## Contrato del paquete

- **Puro** (ADR 0002): sin I/O, sin Flutter, sin estado global. Verificado en
  CI por `tool/check_purity.dart`.
- **Imposible construir datos inválidos**: los invariantes de un solo campo
  viven en value objects (p. ej. `Rating` solo existe entre 1 y 99); los
  invariantes entre campos viven en constructores que lanzan
  `DomainInvariantViolation` con el detalle de los incumplimientos.
- **Sin lógica de juego**: cuánto pesa cada atributo, cómo progresa un
  jugador o qué produce una táctica es asunto del motor y su configuración de
  balance (ADR 0005).

## Mapa del paquete

| Área | Tipos | Notas |
|---|---|---|
| Identidad | `PlayerId`, `ClubId`, `LeagueId`, `FixtureId`, `ContractId` | Extension types: el compilador impide cruzar ids |
| Escalas | `Rating` (1–99), `Fitness`/`Morale`/`Form` (0–100), `Age` (14–50) | `*.clamped()` satura para cálculos de progresión |
| Valores | `Money`, `DisplayName`, `ClubCode`, `CountryCode`, `MatchMinute`, `GameDate` | `Money` admite negativos (deuda) |
| Jugador | `Player`, `PlayerAttributes`, `Position`, `PreferredFoot` | El jugador no conoce su club |
| Club | `Club`, `Stadium`, `Contract`, `Squad` | `Contract` es la única fuente de la relación jugador–club |
| Táctica | `Formation`, `TacticalInstructions`, `MatchLineup` | Vocabulario táctico único; catálogo `Formation.standard` |
| Competición | `League`, `Fixture`, `MatchResult`, `MatchEvent` (+`TeamSide`, `CardType`) | `MatchResult.fromEvents` hace imposible un marcador incoherente |

## Decisiones de diseño que conviene conocer

1. **Validar vs. saturar.** `Rating(120)` lanza; `Rating.clamped(120)` devuelve
   99. La primera protege fronteras (persistencia, generación); la segunda es
   para aritmética de progresión donde saturar es la regla del juego.
2. **Excepciones solo para invariantes.** `DomainInvariantViolation` señala un
   bug o datos corruptos. Los fallos legítimos de juego (fichar sin fondos)
   se modelarán como tipos de resultado cuando llegue el mercado (Fase 7).
3. **`validate(...)` estáticos.** `Squad`, `Formation`, `MatchLineup`,
   `League` y `MatchResult` exponen la validación como función pura que
   devuelve la lista de incumplimientos, para que la UI evalúe estados
   hipotéticos sin capturar excepciones.
4. **Eventos con jugadores reales.** Todo `MatchEvent` referencia `PlayerId`
   existentes; no hay eventos decorativos.

## Tests

```bash
cd packages/domain
dart test          # 94 tests: cada invariante tiene el suyo
make coverage      # desde la raíz: gate de cobertura (umbral 90 %)
```
