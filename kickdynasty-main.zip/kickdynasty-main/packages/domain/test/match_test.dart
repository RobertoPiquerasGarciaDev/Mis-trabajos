import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  GoalScored goal({
    int minute = 10,
    TeamSide side = TeamSide.home,
    String scorer = 'p9',
    String? assistant,
    bool ownGoal = false,
  }) => GoalScored(
    minute: MatchMinute(minute),
    side: side,
    scorerId: PlayerId(scorer),
    assistantId: assistant == null ? null : PlayerId(assistant),
    ownGoal: ownGoal,
  );

  group('GoalScored', () {
    test('acepta goles con y sin asistencia', () {
      expect(goal().assistantId, isNull);
      expect(goal(assistant: 'p8').assistantId, PlayerId('p8'));
    });

    test('rechaza autoasistencia', () {
      expect(
        () => goal(scorer: 'p9', assistant: 'p9'),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('rechaza asistencia en gol en propia puerta', () {
      expect(
        () => goal(ownGoal: true, assistant: 'p8'),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(goal(ownGoal: true).ownGoal, isTrue);
    });

    test('igualdad, hashCode y toString', () {
      expect(goal(), goal());
      expect(goal().hashCode, goal().hashCode);
      expect(goal(), isNot(goal(minute: 11)));
      expect(goal(ownGoal: true).toString(), contains('p.p.'));
    });
  });

  group('CardIssued', () {
    CardIssued card({CardType type = CardType.yellow}) => CardIssued(
      minute: MatchMinute(30),
      side: TeamSide.away,
      playerId: PlayerId('p4'),
      cardType: type,
    );

    test('solo la amarilla simple no expulsa', () {
      expect(card().isSendingOff, isFalse);
      expect(card(type: CardType.secondYellow).isSendingOff, isTrue);
      expect(card(type: CardType.red).isSendingOff, isTrue);
    });

    test('igualdad, hashCode y toString', () {
      expect(card(), card());
      expect(card().hashCode, card().hashCode);
      expect(card(), isNot(card(type: CardType.red)));
      expect(card().toString(), contains('p4'));
    });
  });

  group('PlayerInjured', () {
    PlayerInjured injury() => PlayerInjured(
      minute: MatchMinute(55),
      side: TeamSide.home,
      playerId: PlayerId('p6'),
    );

    test('igualdad, hashCode y toString', () {
      expect(injury(), injury());
      expect(injury().hashCode, injury().hashCode);
      expect(injury().toString(), contains('p6'));
    });
  });

  group('Substitution', () {
    Substitution substitution({String out = 'p7', String into = 'b1'}) =>
        Substitution(
          minute: MatchMinute(60),
          side: TeamSide.home,
          playerOutId: PlayerId(out),
          playerInId: PlayerId(into),
        );

    test('rechaza que un jugador se sustituya a sí mismo', () {
      expect(
        () => substitution(out: 'p7', into: 'p7'),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('igualdad, hashCode y toString', () {
      expect(substitution(), substitution());
      expect(substitution().hashCode, substitution().hashCode);
      expect(substitution(), isNot(substitution(into: 'b2')));
      expect(substitution().toString(), contains('→'));
    });
  });

  group('MatchResult', () {
    final fixtureId = FixtureId('f1');

    test('acepta un resultado sin eventos (detalle purgado)', () {
      final result = MatchResult(
        fixtureId: fixtureId,
        homeGoals: 2,
        awayGoals: 1,
      );
      expect(result.winner, TeamSide.home);
      expect(result.isDraw, isFalse);
      expect(result.events, isEmpty);
    });

    test('winner y isDraw cubren los tres desenlaces', () {
      expect(
        MatchResult(fixtureId: fixtureId, homeGoals: 0, awayGoals: 2).winner,
        TeamSide.away,
      );
      final draw = MatchResult(
        fixtureId: fixtureId,
        homeGoals: 1,
        awayGoals: 1,
      );
      expect(draw.winner, isNull);
      expect(draw.isDraw, isTrue);
    });

    test('rechaza goles negativos', () {
      expect(
        MatchResult.validate(homeGoals: -1, awayGoals: 0, events: const []),
        isNotEmpty,
      );
      expect(
        MatchResult.validate(homeGoals: 0, awayGoals: -1, events: const []),
        isNotEmpty,
      );
    });

    test('rechaza eventos desordenados por minuto', () {
      final violations = MatchResult.validate(
        homeGoals: 2,
        awayGoals: 0,
        events: [goal(minute: 50), goal(minute: 10)],
      );
      expect(violations, contains(contains('ordenados')));
    });

    test('rechaza marcador incoherente con los eventos de gol', () {
      expect(
        () => MatchResult(
          fixtureId: fixtureId,
          homeGoals: 3,
          awayGoals: 0,
          events: [goal(minute: 10)],
        ),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('fromEvents deriva el marcador y es coherente por construcción', () {
      final result = MatchResult.fromEvents(
        fixtureId: fixtureId,
        events: [
          goal(minute: 12),
          CardIssued(
            minute: MatchMinute(30),
            side: TeamSide.away,
            playerId: PlayerId('p4'),
            cardType: CardType.yellow,
          ),
          goal(minute: 44, side: TeamSide.away, scorer: 'q9'),
          goal(minute: 78, scorer: 'p10', assistant: 'p8'),
        ],
      );
      expect(result.homeGoals, 2);
      expect(result.awayGoals, 1);
      expect(result.events, hasLength(4));
    });

    test('igualdad, hashCode y toString', () {
      MatchResult result() => MatchResult(
        fixtureId: fixtureId,
        homeGoals: 1,
        awayGoals: 1,
        events: [
          goal(minute: 5),
          goal(minute: 80, side: TeamSide.away),
        ],
      );
      expect(result(), result());
      expect(result().hashCode, result().hashCode);
      expect(result().toString(), contains('1-1'));
    });

    test('la lista de eventos es inmutable', () {
      final result = MatchResult(
        fixtureId: fixtureId,
        homeGoals: 0,
        awayGoals: 0,
      );
      expect(() => result.events.add(goal()), throwsUnsupportedError);
    });
  });
}
