import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  group('GameDate', () {
    test('acepta los límites de semana', () {
      expect(GameDate(season: 1, week: 1).week, 1);
      expect(
        GameDate(season: 1, week: GameDate.weeksPerSeason).week,
        GameDate.weeksPerSeason,
      );
    });

    test('rechaza temporada o semana inválidas', () {
      expect(
        () => GameDate(season: 0, week: 1),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(
        () => GameDate(season: 1, week: 0),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(
        () => GameDate(season: 1, week: GameDate.weeksPerSeason + 1),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('advanceWeeks dentro de la temporada', () {
      final date = GameDate(season: 1, week: 10).advanceWeeks(5);
      expect(date, GameDate(season: 1, week: 15));
    });

    test('advanceWeeks cruza temporadas', () {
      final date = GameDate(season: 1, week: 50).advanceWeeks(4);
      expect(date, GameDate(season: 2, week: 2));

      final farFuture = GameDate(
        season: 1,
        week: 1,
      ).advanceWeeks(GameDate.weeksPerSeason * 3);
      expect(farFuture, GameDate(season: 4, week: 1));
    });

    test('advanceWeeks(0) es identidad', () {
      final date = GameDate(season: 2, week: 7);
      expect(date.advanceWeeks(0), date);
    });

    test('advanceWeeks rechaza negativos', () {
      expect(
        () => GameDate(season: 1, week: 1).advanceWeeks(-1),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('orden y comparación', () {
      final early = GameDate(season: 1, week: 30);
      final late = GameDate(season: 2, week: 1);
      expect(early.isBefore(late), isTrue);
      expect(late.isAfter(early), isTrue);
      expect(early.compareTo(early), 0);
      expect(
        GameDate(season: 1, week: 2).compareTo(GameDate(season: 1, week: 3)),
        lessThan(0),
      );
    });

    test('igualdad, hashCode y toString', () {
      expect(GameDate(season: 1, week: 5), GameDate(season: 1, week: 5));
      expect(
        GameDate(season: 1, week: 5).hashCode,
        GameDate(season: 1, week: 5).hashCode,
      );
      expect(GameDate(season: 1, week: 5), isNot(GameDate(season: 2, week: 5)));
      expect(GameDate(season: 3, week: 12).toString(), 'T3-S12');
    });
  });
}
