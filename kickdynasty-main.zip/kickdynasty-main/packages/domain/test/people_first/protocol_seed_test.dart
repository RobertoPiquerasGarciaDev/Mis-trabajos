@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  group('deliberationProtocolSeed', () {
    test('mismos inputs producen la misma semilla', () {
      const args = (
        worldSeed: 42,
        season: 3,
        week: 12,
        clubId: 'club-1-1',
        protocolType: DeliberationProtocolType.transferInDeliberation,
        instanceId: 'buy-st-1',
      );

      final a = deliberationProtocolSeed(
        worldSeed: args.worldSeed,
        season: args.season,
        week: args.week,
        clubId: args.clubId,
        protocolType: args.protocolType,
        instanceId: args.instanceId,
      );
      final b = deliberationProtocolSeed(
        worldSeed: args.worldSeed,
        season: args.season,
        week: args.week,
        clubId: args.clubId,
        protocolType: args.protocolType,
        instanceId: args.instanceId,
      );

      expect(a, b);
    });

    test('inputs distintos producen semillas distintas', () {
      final base = deliberationProtocolSeed(
        worldSeed: 42,
        season: 1,
        week: 1,
        clubId: 'club-1-1',
        protocolType: DeliberationProtocolType.transferOutDeliberation,
        instanceId: 'a',
      );
      final otherClub = deliberationProtocolSeed(
        worldSeed: 42,
        season: 1,
        week: 1,
        clubId: 'club-1-2',
        protocolType: DeliberationProtocolType.transferOutDeliberation,
        instanceId: 'a',
      );
      expect(base, isNot(otherClub));
    });
  });
}
