@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  group('DecisionRecord', () {
    test('roundtrip JSON', () {
      final original = DecisionRecord(
        id: 'dr-1',
        protocolType: DeliberationProtocolType.transferOutDeliberation,
        clubId: ClubId('club-1-1'),
        season: 2,
        week: 5,
        instanceId: 'sell-player-9',
        outcome: MandateOutcome.proceed,
        participants: [
          DeliberationParticipant(
            personId: PersonId('person-dd-1'),
            roleId: 'sportingDirector',
            stance: ParticipantStance.proponent,
            summary: 'Propone venta',
          ),
          DeliberationParticipant(
            personId: PersonId('person-president-1'),
            roleId: 'president',
            stance: ParticipantStance.support,
          ),
        ],
        proposalSummary: 'Vender delantero por deuda salarial',
        dissent: ['Entrenador prefiere mantener'],
        refs: {'playerId': 'player-1-1-9'},
      );

      final decoded = DecisionRecord.fromJson(original.toJson());
      expect(decoded, original);
    });
  });

  group('ExecutedMandate', () {
    test('exige outcome proceed', () {
      expect(
        () => ExecutedMandate(
          decisionRecordId: 'dr-1',
          protocolType: DeliberationProtocolType.transferOutDeliberation,
          clubId: ClubId('club-1-1'),
          outcome: MandateOutcome.reject,
        ),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('fromDecisionRecord aprobado', () {
      final record = DecisionRecord(
        id: 'dr-2',
        protocolType: DeliberationProtocolType.renewalDeliberation,
        clubId: ClubId('club-1-1'),
        season: 1,
        week: 10,
        instanceId: 'renew-7',
        outcome: MandateOutcome.proceed,
        participants: const [],
      );

      final mandate = ExecutedMandate.fromDecisionRecord(
        record,
        executionFactRef: 'contract-7',
      );
      expect(mandate.decisionRecordId, 'dr-2');
      expect(mandate.executionFactRef, 'contract-7');

      final roundtrip = ExecutedMandate.fromJson(mandate.toJson());
      expect(roundtrip, mandate);
    });
  });

  group('DeliberationProtocols', () {
    test('catálogo v1 incluye transferOut e transferIn', () {
      expect(
        deliberationProtocolForType(
          DeliberationProtocolType.transferOutDeliberation,
        ),
        DeliberationProtocols.transferOut,
      );
      expect(
        DeliberationProtocols.transferIn.phases,
        contains(DeliberationPhase.report),
      );
    });
  });
}
