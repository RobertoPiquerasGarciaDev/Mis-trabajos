import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  group('Money', () {
    test('admite cantidades negativas (deuda)', () {
      expect(const Money(-500).isNegative, isTrue);
      expect(const Money(500).isNegative, isFalse);
      expect(Money.zero.amount, 0);
    });

    test('aritmética y comparaciones', () {
      expect(const Money(100) + const Money(50), const Money(150));
      expect(const Money(100) - const Money(150), const Money(-50));
      expect(-const Money(100), const Money(-100));
      expect(const Money(100) * 3, const Money(300));
      expect(const Money(100) < const Money(200), isTrue);
      expect(const Money(100) <= const Money(100), isTrue);
      expect(const Money(200) > const Money(100), isTrue);
      expect(const Money(200) >= const Money(200), isTrue);
    });
  });

  group('Rating', () {
    test('acepta los límites 1 y 99', () {
      expect(Rating(Rating.min).value, 1);
      expect(Rating(Rating.max).value, 99);
    });

    test('rechaza valores fuera de rango', () {
      expect(() => Rating(0), throwsA(isA<DomainInvariantViolation>()));
      expect(() => Rating(100), throwsA(isA<DomainInvariantViolation>()));
    });

    test('clamped satura en lugar de fallar', () {
      expect(Rating.clamped(-10).value, Rating.min);
      expect(Rating.clamped(500).value, Rating.max);
      expect(Rating.clamped(70).value, 70);
    });
  });

  group('escalas de condición (0-100)', () {
    test('aceptan los límites', () {
      expect(Fitness(0).value, 0);
      expect(Fitness(100).value, 100);
      expect(Morale(0).value, 0);
      expect(Morale(100).value, 100);
      expect(Form(0).value, 0);
      expect(Form(100).value, 100);
    });

    test('rechazan valores fuera de rango', () {
      expect(() => Fitness(-1), throwsA(isA<DomainInvariantViolation>()));
      expect(() => Fitness(101), throwsA(isA<DomainInvariantViolation>()));
      expect(() => Morale(-1), throwsA(isA<DomainInvariantViolation>()));
      expect(() => Morale(101), throwsA(isA<DomainInvariantViolation>()));
      expect(() => Form(-1), throwsA(isA<DomainInvariantViolation>()));
      expect(() => Form(101), throwsA(isA<DomainInvariantViolation>()));
    });

    test('clamped satura en lugar de fallar', () {
      expect(Fitness.clamped(150).value, 100);
      expect(Morale.clamped(-5).value, 0);
      expect(Form.clamped(50).value, 50);
    });
  });

  group('Age', () {
    test('acepta los límites 14 y 50', () {
      expect(Age(Age.min).years, 14);
      expect(Age(Age.max).years, 50);
    });

    test('rechaza valores fuera de rango', () {
      expect(() => Age(13), throwsA(isA<DomainInvariantViolation>()));
      expect(() => Age(51), throwsA(isA<DomainInvariantViolation>()));
    });

    test('nextYear incrementa y protege el límite superior', () {
      expect(Age(20).nextYear().years, 21);
      expect(Age(49).canGrowOlder, isTrue);
      expect(Age(50).canGrowOlder, isFalse);
      expect(
        () => Age(50).nextYear(),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });
  });

  group('MatchMinute', () {
    test('acepta los límites 1 y 120', () {
      expect(MatchMinute(1).value, 1);
      expect(MatchMinute(120).value, 120);
    });

    test('rechaza valores fuera de rango', () {
      expect(() => MatchMinute(0), throwsA(isA<DomainInvariantViolation>()));
      expect(() => MatchMinute(121), throwsA(isA<DomainInvariantViolation>()));
    });
  });

  group('DisplayName', () {
    test('recorta espacios y acepta nombres válidos', () {
      expect(DisplayName('  Atlético Norte  ').value, 'Atlético Norte');
    });

    test('rechaza vacío y exceso de longitud', () {
      expect(
        () => DisplayName('   '),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(
        () => DisplayName('a' * (DisplayName.maxLength + 1)),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(
        DisplayName('a' * DisplayName.maxLength).value.length,
        DisplayName.maxLength,
      );
    });
  });

  group('ClubCode', () {
    test('acepta 2-4 mayúsculas', () {
      expect(ClubCode('FC').value, 'FC');
      expect(ClubCode('ATLN').value, 'ATLN');
    });

    test('rechaza formato inválido', () {
      expect(() => ClubCode('f'), throwsA(isA<DomainInvariantViolation>()));
      expect(() => ClubCode('fcb'), throwsA(isA<DomainInvariantViolation>()));
      expect(() => ClubCode('ABCDE'), throwsA(isA<DomainInvariantViolation>()));
      expect(() => ClubCode('AB1'), throwsA(isA<DomainInvariantViolation>()));
    });
  });

  group('CountryCode', () {
    test('acepta dos mayúsculas', () {
      expect(CountryCode('ES').value, 'ES');
    });

    test('rechaza formato inválido', () {
      expect(() => CountryCode('es'), throwsA(isA<DomainInvariantViolation>()));
      expect(
        () => CountryCode('ESP'),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(() => CountryCode(''), throwsA(isA<DomainInvariantViolation>()));
    });
  });

  group('ids tipados', () {
    test('aceptan valores no vacíos', () {
      expect(PlayerId('p1').value, 'p1');
      expect(ClubId('c1').value, 'c1');
      expect(LeagueId('l1').value, 'l1');
      expect(FixtureId('f1').value, 'f1');
      expect(ContractId('k1').value, 'k1');
    });

    test('rechazan valores vacíos', () {
      expect(() => PlayerId(' '), throwsA(isA<DomainInvariantViolation>()));
      expect(() => ClubId(''), throwsA(isA<DomainInvariantViolation>()));
      expect(() => LeagueId(''), throwsA(isA<DomainInvariantViolation>()));
      expect(() => FixtureId(''), throwsA(isA<DomainInvariantViolation>()));
      expect(() => ContractId(''), throwsA(isA<DomainInvariantViolation>()));
    });
  });

  group('DomainInvariantViolation', () {
    test('toString sin y con violaciones detalladas', () {
      expect(
        DomainInvariantViolation('mensaje').toString(),
        contains('mensaje'),
      );
      final withDetails = DomainInvariantViolation(
        'agregada',
        violations: ['a', 'b'],
      );
      expect(withDetails.toString(), contains('- a'));
      expect(withDetails.toString(), contains('- b'));
    });
  });
}
