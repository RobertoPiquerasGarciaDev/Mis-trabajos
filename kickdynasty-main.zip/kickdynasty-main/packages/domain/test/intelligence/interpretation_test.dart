@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

InterpretationEntry _sampleEntry() => InterpretationEntry(
  id: InterpretationId('interpret-sample-001'),
  observerPersonId: PersonId('person-interp-1'),
  sourceMemoryIds: [MemoryId('memory-1')],
  sourceRelationIds: const ['person-manager-1'],
  type: InterpretationType.trust,
  confidence: InterpretationConfidence(0.72),
  importance: InterpretationImportance(0.55),
  createdAt: const MemoryTimestamp(season: 1, week: 3),
  expiresAt: const MemoryTimestamp(season: 1, week: 7),
  biasApplied: InterpretationBias.confirmation,
  summary: 'Confía en mí',
  source: InterpretationSource.combined,
);

void main() {
  group('InterpretationEntry', () {
    test('igualdad y JSON roundtrip', () {
      final original = _sampleEntry();
      final decoded = InterpretationEntry.fromJson(original.toJson());
      expect(decoded, original);
    });

    test('pasa comprobación non-reality', () {
      expect(_sampleEntry().passesNonRealityCheck, isTrue);
    });

    test('rechaza claves prohibidas', () {
      final json = _sampleEntry().toJson()..['ovr'] = 85;
      expect(containsForbiddenInterpretationKeys(json), isTrue);
    });

    test('rechaza lenguaje de decisión', () {
      final entry = InterpretationEntry(
        id: InterpretationId('interpret-decision'),
        observerPersonId: PersonId('person-interp-2'),
        sourceMemoryIds: const [],
        sourceRelationIds: const [],
        type: InterpretationType.perceivedMeaning,
        confidence: InterpretationConfidence(0.5),
        importance: InterpretationImportance(0.5),
        createdAt: const MemoryTimestamp(season: 1, week: 1),
        expiresAt: null,
        biasApplied: InterpretationBias.none,
        summary: 'Debo decidir fichar a este jugador',
        source: InterpretationSource.perception,
      );
      expect(entry.passesNonRealityCheck, isFalse);
    });
  });

  group('InterpretationState', () {
    test('igualdad y JSON roundtrip', () {
      final state = InterpretationState(
        collection: InterpretationCollection(
          ownerId: PersonId('person-interp-1'),
          entries: [_sampleEntry()],
        ),
      );
      expect(InterpretationState.fromJson(state.toJson()), state);
    });

    test('estado vacío', () {
      const empty = InterpretationState.empty();
      expect(empty.entries, isEmpty);
      expect(InterpretationState.fromJson(empty.toJson()), empty);
    });
  });

  group('InterpretationCollection', () {
    test('serialización con entradas ordenadas', () {
      final collection = InterpretationCollection(
        ownerId: PersonId('person-interp-3'),
        entries: [_sampleEntry()],
      );
      final decoded = InterpretationCollection.fromJson(collection.toJson());
      expect(decoded, collection);
    });
  });
}
