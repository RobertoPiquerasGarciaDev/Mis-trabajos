@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

PriorityEntry _sampleEntry() => PriorityEntry(
  id: PriorityId('priority-1'),
  observerPersonId: PersonId('person-priority-1'),
  sourceGoalId: GoalId('goal-1'),
  goalType: GoalType.maintainTrust,
  summary: 'Atención hacia: Quiero mantener la confianza',
  strength: PriorityStrength(0.72),
  rank: PriorityRank(1),
  type: PriorityType.dominant,
  origin: PriorityOrigin.goalDerived,
  reason: PriorityReason.goalStrength,
  createdAt: const MemoryTimestamp(season: 1, week: 2),
  updatedAt: const MemoryTimestamp(season: 1, week: 2),
);

void main() {
  group('PriorityEntry', () {
    test('igualdad y JSON roundtrip', () {
      final entry = _sampleEntry();
      expect(PriorityEntry.fromJson(entry.toJson()), entry);
    });

    test('passesNonRealityCheck rechaza claves prohibidas', () {
      final entry = _sampleEntry();
      expect(entry.passesNonRealityCheck, isTrue);
      expect(containsForbiddenPriorityKeys({'v': 1, 'player': 'x'}), isTrue);
    });
  });

  group('PriorityCollection', () {
    test('colección vacía e igualdad', () {
      const empty = PriorityCollection.empty();
      expect(empty.entries, isEmpty);
      expect(PriorityCollection.fromJson(empty.toJson()), empty);
    });

    test('roundtrip con entradas', () {
      final collection = PriorityCollection(
        ownerId: PersonId('person-priority-1'),
        entries: [_sampleEntry()],
      );
      expect(PriorityCollection.fromJson(collection.toJson()), collection);
    });
  });

  group('PriorityState', () {
    test('estado vacío migra desde v1', () {
      expect(
        PriorityState.fromJson(const {'v': 1}),
        const PriorityState.empty(),
      );
    });

    test('roundtrip v2', () {
      final state = PriorityState(
        collection: PriorityCollection(
          ownerId: PersonId('person-priority-1'),
          entries: [_sampleEntry()],
        ),
      );
      expect(PriorityState.fromJson(state.toJson()), state);
    });
  });
}
