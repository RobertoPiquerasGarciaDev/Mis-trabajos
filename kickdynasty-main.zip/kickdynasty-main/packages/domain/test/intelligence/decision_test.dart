@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

DecisionEntry _sampleEntry() => DecisionEntry(
  id: DecisionId('decision-1'),
  observerPersonId: PersonId('person-decision-1'),
  sourceIntentionId: IntentionId('intention-1'),
  type: DecisionType.socialResolved,
  origin: DecisionOrigin.socialProtocol,
  status: DecisionStatus.committed,
  summary: 'Me comprometo con la postura: quiero vender',
  rationale: 'Tras deliberación social, considero correcto sostener la postura',
  strength: DecisionStrength(0.72),
  sourcePriorityIds: [PriorityId('priority-1')],
  rejectedAlternatives: const [],
  unknownsAcknowledged: const ['No conozco todas las consecuencias futuras'],
  protocolType: DeliberationProtocolType.transferOutDeliberation,
  decisionRecordId: 'dr-abc',
  instanceId: 'protocol-instance-1',
  createdAt: const MemoryTimestamp(season: 1, week: 2),
  updatedAt: const MemoryTimestamp(season: 1, week: 2),
);

void main() {
  group('DecisionEntry', () {
    test('igualdad y JSON roundtrip', () {
      final entry = _sampleEntry();
      expect(DecisionEntry.fromJson(entry.toJson()), entry);
    });

    test('passesNonRealityCheck rechaza claves prohibidas', () {
      final entry = _sampleEntry();
      expect(entry.passesNonRealityCheck, isTrue);
      expect(
        containsForbiddenDecisionKeys({'v': 1, 'executedMandate': 'x'}),
        isTrue,
      );
    });
  });

  group('DecisionCollection', () {
    test('colección vacía e igualdad', () {
      const empty = DecisionCollection.empty();
      expect(empty.entries, isEmpty);
      expect(DecisionCollection.fromJson(empty.toJson()), empty);
    });

    test('roundtrip con entradas', () {
      final collection = DecisionCollection(
        ownerId: PersonId('person-decision-1'),
        entries: [_sampleEntry()],
      );
      expect(DecisionCollection.fromJson(collection.toJson()), collection);
    });
  });

  group('DecisionState', () {
    test('estado vacío migra desde v1', () {
      expect(
        DecisionState.fromJson(const {'v': 1}),
        const DecisionState.empty(),
      );
    });

    test('roundtrip v2', () {
      final state = DecisionState(
        collection: DecisionCollection(
          ownerId: PersonId('person-decision-1'),
          entries: [_sampleEntry()],
        ),
      );
      expect(DecisionState.fromJson(state.toJson()), state);
    });
  });

  group('DeliberationConvocation', () {
    test('variantes de convocatoria', () {
      const deferred = DeliberationConvocation.deferred(reason: 'diferido');
      const unilateral = DeliberationConvocation.unilateral(
        reason: 'unilateral',
      );
      const protocol = DeliberationConvocation.protocol(
        type: DeliberationProtocolType.renewalDeliberation,
        reason: 'protocolo',
      );
      expect(deferred.deferred, isTrue);
      expect(unilateral.unilateralAllowed, isTrue);
      expect(protocol.requiresSocialProtocol, isTrue);
    });
  });

  group('AgentMind v7', () {
    test('incluye decisions en JSON v7', () {
      final trait = TraitScore(50);
      final mind = AgentMind(
        personId: PersonId('person-mind-v7'),
        personality: PersonalitySnapshot(
          profile: PersonalityProfile(
            ambition: trait,
            patience: trait,
            prudence: trait,
            aggressiveness: trait,
            pride: trait,
            ego: trait,
            professionalism: trait,
            empathy: trait,
            emotionalStability: trait,
            leadership: trait,
            memoryTrait: trait,
            pressureTolerance: trait,
          ),
        ),
        memory: const MemoryState.empty(),
        beliefs: const BeliefState.empty(),
        goals: const GoalState.empty(),
        priorities: const PriorityState.empty(),
        intentions: const IntentionState.empty(),
        decisions: DecisionState(
          collection: DecisionCollection(
            ownerId: PersonId('person-mind-v7'),
            entries: [_sampleEntry()],
          ),
        ),
        perception: const PerceptionState.empty(),
        relations: const RelationState.empty(),
        interpretation: const InterpretationState.empty(),
        emotion: EmotionalState.initial,
        learning: LearningState.initial,
      );
      final json = mind.toJson();
      expect(json['v'], 7);
      expect(AgentMind.fromJson(json), mind);
    });

    test('v6 migra con decisions vacías', () {
      final trait = TraitScore(50);
      final v6 = {
        'v': 6,
        'personId': 'person-v6',
        'personality': PersonalitySnapshot(
          profile: PersonalityProfile(
            ambition: trait,
            patience: trait,
            prudence: trait,
            aggressiveness: trait,
            pride: trait,
            ego: trait,
            professionalism: trait,
            empathy: trait,
            emotionalStability: trait,
            leadership: trait,
            memoryTrait: trait,
            pressureTolerance: trait,
          ),
        ).toJson(),
        'memory': const MemoryState.empty().toJson(),
        'beliefs': const BeliefState.empty().toJson(),
        'goals': const GoalState.empty().toJson(),
        'priorities': const PriorityState.empty().toJson(),
        'intentions': const IntentionState.empty().toJson(),
        'perception': const PerceptionState.empty().toJson(),
        'relations': const RelationState.empty().toJson(),
        'interpretation': const InterpretationState.empty().toJson(),
        'emotion': EmotionalState.initial.toJson(),
        'learning': LearningState.initial.toJson(),
      };
      final mind = AgentMind.fromJson(v6);
      expect(mind.decisions, const DecisionState.empty());
    });
  });
}
