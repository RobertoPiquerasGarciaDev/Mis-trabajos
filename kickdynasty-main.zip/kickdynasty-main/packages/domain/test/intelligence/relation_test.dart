@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

RelationEntry _sampleEntry() => RelationEntry(
  observerPersonId: PersonId('person-rel-obs'),
  targetPersonId: PersonId('person-rel-tgt'),
  type: RelationType.manager,
  trust: RelationTrust(0.4),
  respect: RelationRespect(0.6),
  affinity: RelationAffinity(0.5),
  confidence: RelationConfidence(0.7),
  strength: RelationStrength(0.55),
  history: const RelationHistory.empty(),
  knownSince: const MemoryTimestamp(season: 1, week: 1),
  lastInteraction: null,
  origin: RelationOrigin.structural,
  tags: const [RelationTag.sameClub, RelationTag.structural],
);

void main() {
  group('RelationEntry', () {
    test('igualdad y serialización', () {
      final entry = _sampleEntry();
      expect(RelationEntry.fromJson(entry.toJson()), entry);
    });

    test('no contiene claves de Reality', () {
      expect(_sampleEntry().passesNonRealityCheck, isTrue);
      expect(containsForbiddenRelationKeys({'potential': 90}), isTrue);
    });
  });

  group('RelationState', () {
    test('roundtrip JSON', () {
      final state = RelationState(
        observerId: PersonId('person-rel-obs'),
        entries: [_sampleEntry()],
      );
      expect(RelationState.fromJson(state.toJson()), state);
    });
  });

  group('asimetría', () {
    test('observer y target son independientes', () {
      final aToB = _sampleEntry();
      final bToA = RelationEntry(
        observerPersonId: PersonId('person-rel-tgt'),
        targetPersonId: PersonId('person-rel-obs'),
        type: RelationType.staffPeer,
        trust: RelationTrust(-0.2),
        respect: RelationRespect(0.3),
        affinity: RelationAffinity(0.2),
        confidence: RelationConfidence(0.4),
        strength: RelationStrength(0.35),
        history: const RelationHistory.empty(),
        knownSince: const MemoryTimestamp(season: 1, week: 1),
        lastInteraction: null,
        origin: RelationOrigin.structural,
        tags: const [RelationTag.structural],
      );
      expect(aToB.trust, isNot(bToA.trust));
    });
  });
}
