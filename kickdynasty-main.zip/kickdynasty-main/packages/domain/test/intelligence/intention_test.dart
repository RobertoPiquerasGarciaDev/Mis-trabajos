@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

IntentionEntry _sampleEntry() => IntentionEntry(
  id: IntentionId('intention-1'),
  observerPersonId: PersonId('person-intention-1'),
  sourcePriorityId: PriorityId('priority-1'),
  type: IntentionType.wantToMaintainTrust,
  summary: 'Quiero mantener la confianza que percibo',
  strength: IntentionStrength(0.65),
  status: IntentionStatus.active,
  createdAt: const MemoryTimestamp(season: 1, week: 2),
  updatedAt: const MemoryTimestamp(season: 1, week: 2),
);

void main() {
  group('IntentionEntry', () {
    test('igualdad y JSON roundtrip', () {
      final entry = _sampleEntry();
      expect(IntentionEntry.fromJson(entry.toJson()), entry);
    });

    test('passesNonRealityCheck rechaza claves prohibidas', () {
      final entry = _sampleEntry();
      expect(entry.passesNonRealityCheck, isTrue);
      expect(containsForbiddenIntentionKeys({'v': 1, 'decision': 'x'}), isTrue);
    });
  });

  group('IntentionCollection', () {
    test('colección vacía e igualdad', () {
      const empty = IntentionCollection.empty();
      expect(empty.entries, isEmpty);
      expect(IntentionCollection.fromJson(empty.toJson()), empty);
    });

    test('roundtrip con entradas', () {
      final collection = IntentionCollection(
        ownerId: PersonId('person-intention-1'),
        entries: [_sampleEntry()],
      );
      expect(IntentionCollection.fromJson(collection.toJson()), collection);
    });
  });

  group('IntentionState', () {
    test('estado vacío migra desde v1', () {
      expect(
        IntentionState.fromJson(const {'v': 1}),
        const IntentionState.empty(),
      );
    });

    test('roundtrip v2', () {
      final state = IntentionState(
        collection: IntentionCollection(
          ownerId: PersonId('person-intention-1'),
          entries: [_sampleEntry()],
        ),
      );
      expect(IntentionState.fromJson(state.toJson()), state);
    });
  });
}
