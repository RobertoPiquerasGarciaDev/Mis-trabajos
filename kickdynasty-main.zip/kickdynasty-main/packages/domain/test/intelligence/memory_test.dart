@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

MemoryEntry _sampleEntry() => MemoryEntry(
  id: MemoryId('memory-test-1'),
  ownerId: PersonId('person-mem-1'),
  type: MemoryType.perceivedFact,
  whatHappened: 'player.fitness=80',
  subjectId: 'player-1',
  involvedPersonIds: const [],
  perceivedAt: const MemoryTimestamp(season: 1, week: 3),
  source: PerceptionSource.directObservation,
  origin: KnowledgeOrigin.self,
  confidenceAtCapture: PerceptionConfidence(0.8),
  importance: MemoryImportance(0.6),
  strength: MemoryStrength(0.8),
  decay: const MemoryDecay(decayRate: 0.01, lastRecall: null),
  factKey: 'player.fitness',
  perceivedValue: '80',
);

void main() {
  group('MemoryEntry', () {
    test('igualdad y serialización', () {
      final entry = _sampleEntry();
      expect(MemoryEntry.fromJson(entry.toJson()), entry);
    });
  });

  group('MemoryCollection', () {
    test('igualdad y serialización', () {
      final collection = MemoryCollection(
        ownerId: PersonId('person-mem-1'),
        entries: [_sampleEntry()],
      );
      expect(MemoryCollection.fromJson(collection.toJson()), collection);
    });
  });

  group('MemoryState', () {
    test('migra v1 vacío a colección vacía', () {
      expect(
        MemoryState.fromJson(const {'v': 1, 'episodes': []}),
        const MemoryState.empty(),
      );
    });

    test('roundtrip v2 con colección', () {
      final state = MemoryState(
        collection: MemoryCollection(
          ownerId: PersonId('person-mem-2'),
          entries: [_sampleEntry()],
        ),
      );
      expect(MemoryState.fromJson(state.toJson()), state);
    });
  });

  group('MemoryDecay', () {
    test('infraestructura de olvido sin ejecución', () {
      const decay = MemoryDecay.initial;
      expect(decay.decayRate, 0.0);
      expect(decay.lastRecall, isNull);
      expect(MemoryDecay.fromJson(decay.toJson()), decay);
    });
  });
}
