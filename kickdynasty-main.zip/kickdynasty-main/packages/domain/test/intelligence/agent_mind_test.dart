@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  AgentMind sampleMind() {
    final trait = TraitScore(50);
    final profile = PersonalityProfile(
      ambition: trait,
      patience: trait,
      prudence: trait,
      aggressiveness: trait,
      pride: trait,
      ego: trait,
      professionalism: trait,
      empathy: trait,
      emotionalStability: trait,
      leadership: trait,
      memoryTrait: trait,
      pressureTolerance: trait,
    );
    return AgentMind(
      personId: PersonId('person-mind-1'),
      personality: PersonalitySnapshot(profile: profile),
      memory: const MemoryState.empty(),
      beliefs: const BeliefState.empty(),
      goals: const GoalState.empty(),
      priorities: const PriorityState.empty(),
      intentions: const IntentionState.empty(),
      decisions: const DecisionState.empty(),
      perception: const PerceptionState.empty(),
      relations: const RelationState.empty(),
      interpretation: const InterpretationState.empty(),
      emotion: EmotionalState.initial,
      learning: LearningState.initial,
    );
  }

  group('AgentMind', () {
    test('igualdad y JSON roundtrip', () {
      final original = sampleMind();
      final decoded = AgentMind.fromJson(original.toJson());
      expect(decoded, original);
    });

    test('contenedores vacíos en PF-2', () {
      final mind = sampleMind();
      expect(mind.memory.entries, isEmpty);
      expect(mind.relations.entries, isEmpty);
      expect(mind.interpretation.entries, isEmpty);
      expect(mind.beliefs.entries, isEmpty);
      expect(mind.goals.entries, isEmpty);
      expect(mind.priorities.entries, isEmpty);
      expect(mind.intentions.entries, isEmpty);
      expect(mind.decisions.entries, isEmpty);
      expect(mind.perception.snapshots, isEmpty);
      expect(mind.learning.experienceUnits, 0);
    });
  });
}
