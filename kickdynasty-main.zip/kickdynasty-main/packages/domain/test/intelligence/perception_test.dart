@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

PerceivedFact _sampleFact() => PerceivedFact(
  subjectId: 'player-1',
  factKey: 'player.fitness',
  value: '80',
  source: PerceptionSource.directObservation,
  confidence: PerceptionConfidence(0.82),
  age: PerceptionAge.fresh,
  visibility: VisibilityLevel.full,
  quality: ObservationQuality(TraitScore(70)),
  origin: KnowledgeOrigin.self,
);

void main() {
  group('PerceivedFact', () {
    test('igualdad y serialización', () {
      final a = _sampleFact();
      final b = PerceivedFact.fromJson(a.toJson());
      expect(b, a);
    });
  });

  group('PerceptionSnapshot', () {
    test('igualdad y serialización', () {
      final snapshot = PerceptionSnapshot(
        observerId: PersonId('person-obs-1'),
        season: 1,
        week: 3,
        facts: [_sampleFact()],
        availableSources: [PerceptionSource.directObservation],
      );
      final decoded = PerceptionSnapshot.fromJson(snapshot.toJson());
      expect(decoded, snapshot);
    });

    test('no contiene claves prohibidas de omnisciencia', () {
      final snapshot = PerceptionSnapshot(
        observerId: PersonId('person-obs-2'),
        season: 1,
        week: 1,
        facts: [_sampleFact()],
        availableSources: perceptionInfrastructureSources,
      );
      expect(snapshot.passesNonOmniscienceCheck, isTrue);
      expect(containsForbiddenPerceptionKeys({'potential': 99}), isTrue);
    });
  });

  group('PerceptionState', () {
    test('migra v1 vacío a snapshots vacíos', () {
      final state = PerceptionState.fromJson(const {'v': 1, 'frames': []});
      expect(state, const PerceptionState.empty());
    });

    test('roundtrip v2 con snapshots', () {
      final state = PerceptionState(
        snapshots: [
          PerceptionSnapshot(
            observerId: PersonId('person-obs-3'),
            season: 2,
            week: 5,
            facts: [],
            availableSources: [PerceptionSource.directObservation],
          ),
        ],
      );
      expect(PerceptionState.fromJson(state.toJson()), state);
    });
  });

  group('ScoutingReport stub', () {
    test('serialización', () {
      final report = ScoutingReport(
        id: 'report-1',
        scoutPersonId: PersonId('scout-1'),
        subjectPlayerId: PlayerId('player-1'),
      );
      expect(ScoutingReport.fromJson(report.toJson()), report);
    });
  });
}

const perceptionInfrastructureSources = [
  PerceptionSource.directObservation,
  PerceptionSource.scoutingReport,
  PerceptionSource.media,
  PerceptionSource.chronicle,
  PerceptionSource.rumor,
  PerceptionSource.conversation,
  PerceptionSource.institution,
  PerceptionSource.introspection,
];
