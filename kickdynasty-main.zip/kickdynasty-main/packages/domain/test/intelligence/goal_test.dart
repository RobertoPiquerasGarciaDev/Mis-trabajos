@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

GoalEntry _sampleEntry() => GoalEntry(
  id: GoalId('goal-sample-001'),
  observerPersonId: PersonId('person-goal-1'),
  type: GoalType.maintainTrust,
  category: GoalCategory.social,
  summary: 'Quiero mantener la confianza que percibo',
  priority: GoalPriority(0.72),
  strength: GoalStrength(0.55),
  origin: GoalOrigin.beliefDerived,
  status: GoalStatus.active,
  timeHorizon: GoalTimeHorizon.shortTerm,
  sourceBeliefIds: [BeliefId('belief-1')],
  createdAt: const MemoryTimestamp(season: 1, week: 3),
  updatedAt: const MemoryTimestamp(season: 1, week: 3),
  lastReviewed: const MemoryTimestamp(season: 1, week: 3),
);

void main() {
  group('GoalEntry', () {
    test('igualdad y JSON roundtrip', () {
      final original = _sampleEntry();
      expect(GoalEntry.fromJson(original.toJson()), original);
    });

    test('pasa comprobación non-reality', () {
      expect(_sampleEntry().passesNonRealityCheck, isTrue);
    });

    test('rechaza claves prohibidas', () {
      final json = _sampleEntry().toJson()..['ovr'] = 85;
      expect(containsForbiddenGoalKeys(json), isTrue);
    });

    test('rechaza lenguaje de acción', () {
      final entry = GoalEntry(
        id: GoalId('goal-action'),
        observerPersonId: PersonId('person-goal-2'),
        type: GoalType.regainStatus,
        category: GoalCategory.professional,
        summary: 'Debo fichar a este jugador',
        priority: GoalPriority(0.5),
        strength: GoalStrength(0.5),
        origin: GoalOrigin.beliefDerived,
        status: GoalStatus.active,
        timeHorizon: GoalTimeHorizon.mediumTerm,
        sourceBeliefIds: const [],
        createdAt: const MemoryTimestamp(season: 1, week: 1),
        updatedAt: const MemoryTimestamp(season: 1, week: 1),
        lastReviewed: const MemoryTimestamp(season: 1, week: 1),
      );
      expect(entry.passesNonRealityCheck, isFalse);
    });
  });

  group('GoalState', () {
    test('igualdad y JSON roundtrip', () {
      final state = GoalState(
        collection: GoalCollection(
          ownerId: PersonId('person-goal-1'),
          entries: [_sampleEntry()],
        ),
      );
      expect(GoalState.fromJson(state.toJson()), state);
    });

    test('migra v1 vacío a colección vacía', () {
      expect(
        GoalState.fromJson(const {'v': 1, 'goals': []}),
        const GoalState.empty(),
      );
    });
  });

  group('GoalCollection', () {
    test('serialización roundtrip', () {
      final collection = GoalCollection(
        ownerId: PersonId('person-goal-1'),
        entries: [_sampleEntry()],
      );
      expect(GoalCollection.fromJson(collection.toJson()), collection);
    });
  });

  group('GoalCandidate', () {
    test('serialización roundtrip', () {
      final candidate = GoalCandidate(
        observerPersonId: PersonId('person-candidate'),
        sourceBeliefId: BeliefId('belief-c-1'),
        type: GoalType.seekProtection,
        category: GoalCategory.personal,
        summary: 'Quiero sentirme protegido',
        tentativePriority: GoalPriority(0.6),
        tentativeStrength: GoalStrength(0.4),
        createdAt: const MemoryTimestamp(season: 1, week: 2),
      );
      expect(GoalCandidate.fromJson(candidate.toJson()), candidate);
    });
  });
}
