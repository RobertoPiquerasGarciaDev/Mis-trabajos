@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

BeliefEntry _sampleEntry() => BeliefEntry(
  id: BeliefId('belief-sample-001'),
  observerPersonId: PersonId('person-belief-1'),
  type: BeliefType.trust,
  category: BeliefCategory.otherPerson,
  summary: 'Creo que confía en mí',
  confidence: BeliefConfidence(0.72),
  strength: BeliefStrength(0.55),
  origin: BeliefOrigin.consolidatedInterpretations,
  sourceInterpretationIds: [InterpretationId('interpret-1')],
  createdAt: const MemoryTimestamp(season: 1, week: 3),
  updatedAt: const MemoryTimestamp(season: 1, week: 3),
  lastConfirmed: const MemoryTimestamp(season: 1, week: 3),
  contradictoryBeliefIds: const [],
);

void main() {
  group('BeliefEntry', () {
    test('igualdad y JSON roundtrip', () {
      final original = _sampleEntry();
      expect(BeliefEntry.fromJson(original.toJson()), original);
    });

    test('pasa comprobación non-reality', () {
      expect(_sampleEntry().passesNonRealityCheck, isTrue);
    });

    test('rechaza claves prohibidas', () {
      final json = _sampleEntry().toJson()..['ovr'] = 85;
      expect(containsForbiddenBeliefKeys(json), isTrue);
    });

    test('rechaza lenguaje de acción', () {
      final entry = BeliefEntry(
        id: BeliefId('belief-action'),
        observerPersonId: PersonId('person-belief-2'),
        type: BeliefType.worldView,
        category: BeliefCategory.world,
        summary: 'Debo fichar a este jugador',
        confidence: BeliefConfidence(0.5),
        strength: BeliefStrength(0.5),
        origin: BeliefOrigin.isolatedInterpretation,
        sourceInterpretationIds: const [],
        createdAt: const MemoryTimestamp(season: 1, week: 1),
        updatedAt: const MemoryTimestamp(season: 1, week: 1),
        lastConfirmed: const MemoryTimestamp(season: 1, week: 1),
        contradictoryBeliefIds: const [],
      );
      expect(entry.passesNonRealityCheck, isFalse);
    });
  });

  group('BeliefState', () {
    test('igualdad y JSON roundtrip', () {
      final state = BeliefState(
        collection: BeliefCollection(
          ownerId: PersonId('person-belief-1'),
          entries: [_sampleEntry()],
        ),
      );
      expect(BeliefState.fromJson(state.toJson()), state);
    });

    test('migra v1 vacío a colección vacía', () {
      expect(
        BeliefState.fromJson(const {'v': 1, 'beliefs': []}),
        const BeliefState.empty(),
      );
    });
  });

  group('BeliefCandidate', () {
    test('serialización roundtrip', () {
      final candidate = BeliefCandidate(
        observerPersonId: PersonId('person-candidate'),
        sourceInterpretationId: InterpretationId('interpret-c-1'),
        type: BeliefType.protection,
        category: BeliefCategory.otherPerson,
        summary: 'Mi entrenador me protege',
        tentativeConfidence: BeliefConfidence(0.6),
        tentativeStrength: BeliefStrength(0.4),
        consolidationKey: 'protection|otherPerson|rel:mgr|summary',
        createdAt: const MemoryTimestamp(season: 1, week: 2),
      );
      expect(BeliefCandidate.fromJson(candidate.toJson()), candidate);
    });
  });

  group('BeliefConsolidation', () {
    test('serialización roundtrip', () {
      final consolidation = BeliefConsolidation(
        candidates: const [],
        beliefs: [_sampleEntry()],
        isolatedCandidateCount: 1,
        consolidatedGroupCount: 0,
      );
      expect(
        BeliefConsolidation.fromJson(consolidation.toJson()),
        consolidation,
      );
    });
  });
}
