import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

import 'support/builders.dart' as build;

void main() {
  group('Stadium', () {
    test('acepta aforos en los límites', () {
      expect(
        Stadium(
          name: DisplayName('Mini'),
          capacity: Stadium.minCapacity,
        ).capacity,
        Stadium.minCapacity,
      );
      expect(
        Stadium(
          name: DisplayName('Coloso'),
          capacity: Stadium.maxCapacity,
        ).capacity,
        Stadium.maxCapacity,
      );
    });

    test('rechaza aforos fuera de rango', () {
      expect(
        () => Stadium(name: DisplayName('X'), capacity: 499),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(
        () => Stadium(name: DisplayName('X'), capacity: 150001),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('igualdad, hashCode y toString', () {
      final a = Stadium(name: DisplayName('Norte'), capacity: 20000);
      final b = Stadium(name: DisplayName('Norte'), capacity: 20000);
      expect(a, b);
      expect(a.hashCode, b.hashCode);
      expect(a, isNot(Stadium(name: DisplayName('Sur'), capacity: 20000)));
      expect(a.toString(), contains('Norte'));
    });
  });

  group('Club', () {
    test('se construye y admite saldo negativo (deuda)', () {
      final club = build.club();
      expect(club.balance.isNegative, isFalse);
      final indebted = club.copyWith(balance: const Money(-200000));
      expect(indebted.balance.isNegative, isTrue);
    });

    test('igualdad estructural', () {
      expect(build.club(), build.club());
      expect(build.club(id: 'c1'), isNot(build.club(id: 'c2')));
    });
  });

  group('Contract', () {
    test('rechaza salario negativo', () {
      expect(
        () => build.contract(wage: -1),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(build.contract(wage: 0).weeklyWage, Money.zero);
    });

    test('isExpiredAt: vigente antes de expiry, expirado desde expiry', () {
      final contract = build.contract(); // expira en T3-S1
      expect(contract.isExpiredAt(GameDate(season: 2, week: 52)), isFalse);
      expect(contract.isExpiredAt(GameDate(season: 3, week: 1)), isTrue);
      expect(contract.isExpiredAt(GameDate(season: 3, week: 2)), isTrue);
    });

    test('igualdad, hashCode y toString', () {
      expect(build.contract(), build.contract());
      expect(build.contract().hashCode, build.contract().hashCode);
      expect(build.contract(id: 'k1'), isNot(build.contract(id: 'k2')));
      expect(build.contract().toString(), contains('k1'));
    });
  });

  group('Squad', () {
    test('acepta una plantilla válida y expone consultas', () {
      final players = build.squadPlayers();
      final squad = Squad(clubId: ClubId('c1'), players: players);

      expect(squad.size, players.length);
      expect(squad.byGroup(PositionGroup.goalkeeper).length, 2);
      expect(squad.byId(PlayerId('p0'))?.position, Position.gk);
      expect(squad.byId(PlayerId('desconocido')), isNull);
      expect(squad.contains(PlayerId('p5')), isTrue);
      expect(squad.contains(PlayerId('nadie')), isFalse);
    });

    test('rechaza plantillas por debajo del mínimo', () {
      final tooFew = build.squadPlayers().sublist(0, Squad.minSize - 1);
      expect(Squad.validate(tooFew), isNotEmpty);
      expect(
        () => Squad(clubId: ClubId('c1'), players: tooFew),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('rechaza plantillas por encima del máximo', () {
      final tooMany = [
        for (var i = 0; i <= Squad.maxSize; i++)
          build.player(id: 'x$i', position: i < 2 ? Position.gk : Position.cm),
      ];
      expect(Squad.validate(tooMany), isNotEmpty);
    });

    test('rechaza jugadores duplicados', () {
      final players = build.squadPlayers();
      final withDuplicate = [
        ...players.sublist(0, players.length - 1),
        players.first,
      ];
      final violations = Squad.validate(withDuplicate);
      expect(violations.any((v) => v.contains('duplicado')), isTrue);
    });

    test('exige al menos dos porteros', () {
      final players = build
          .squadPlayers()
          .map(
            (p) =>
                p.position.isGoalkeeper ? p.copyWith(position: Position.cb) : p,
          )
          .toList();
      final violations = Squad.validate(players);
      expect(violations.any((v) => v.contains('porteros')), isTrue);
    });

    test('la lista de jugadores es inmutable', () {
      final squad = Squad(clubId: ClubId('c1'), players: build.squadPlayers());
      expect(
        () => squad.players.add(build.player(id: 'nuevo')),
        throwsUnsupportedError,
      );
    });
  });
}
