import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  List<ClubId> clubIds(int count) => [
    for (var i = 0; i < count; i++) ClubId('c$i'),
  ];

  League league({int clubs = 20}) => League(
    id: LeagueId('l1'),
    name: DisplayName('Primera División'),
    country: CountryCode('ES'),
    clubIds: clubIds(clubs),
  );

  Fixture fixture({
    String home = 'c1',
    String away = 'c2',
    int season = 1,
    int round = 1,
  }) => Fixture(
    id: FixtureId('f1'),
    leagueId: LeagueId('l1'),
    season: season,
    round: round,
    homeClubId: ClubId(home),
    awayClubId: ClubId(away),
  );

  group('League', () {
    test('acepta ligas válidas y calcula jornadas y partidos', () {
      final competition = league();
      expect(competition.roundsPerSeason, 38);
      expect(competition.matchesPerRound, 10);

      final small = league(clubs: 4);
      expect(small.roundsPerSeason, 6);
      expect(small.matchesPerRound, 2);
    });

    test('rechaza tamaños fuera de rango', () {
      expect(League.validate(clubIds(2)), isNotEmpty);
      expect(League.validate(clubIds(34)), isNotEmpty);
    });

    test('rechaza número impar de clubes', () {
      expect(League.validate(clubIds(5)), contains(contains('par')));
    });

    test('rechaza clubes repetidos', () {
      final duplicated = [...clubIds(19), ClubId('c0')];
      expect(League.validate(duplicated), contains(contains('repetidos')));
      expect(
        () => League(
          id: LeagueId('l1'),
          name: DisplayName('Liga'),
          country: CountryCode('ES'),
          clubIds: duplicated,
        ),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('igualdad, hashCode y toString', () {
      expect(league(), league());
      expect(league().hashCode, league().hashCode);
      expect(league(), isNot(league(clubs: 18)));
      expect(league().toString(), contains('Primera División'));
    });

    test('la lista de clubes es inmutable', () {
      expect(() => league().clubIds.add(ClubId('cx')), throwsUnsupportedError);
    });
  });

  group('Fixture', () {
    test('acepta fixtures válidos', () {
      final match = fixture();
      expect(match.homeClubId, ClubId('c1'));
      expect(match.awayClubId, ClubId('c2'));
    });

    test('rechaza que un club juegue contra sí mismo', () {
      expect(
        () => fixture(home: 'c1', away: 'c1'),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('rechaza temporada o jornada inválidas', () {
      expect(
        () => fixture(season: 0),
        throwsA(isA<DomainInvariantViolation>()),
      );
      expect(() => fixture(round: 0), throwsA(isA<DomainInvariantViolation>()));
    });

    test('igualdad, hashCode y toString', () {
      expect(fixture(), fixture());
      expect(fixture().hashCode, fixture().hashCode);
      expect(fixture(), isNot(fixture(round: 2)));
      expect(fixture().toString(), contains('c1'));
    });
  });
}
