import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

import 'support/builders.dart' as build;

void main() {
  group('Position', () {
    test('cada posición pertenece a su línea', () {
      expect(Position.gk.group, PositionGroup.goalkeeper);
      expect(Position.cb.group, PositionGroup.defence);
      expect(Position.lb.group, PositionGroup.defence);
      expect(Position.rb.group, PositionGroup.defence);
      expect(Position.dm.group, PositionGroup.midfield);
      expect(Position.cm.group, PositionGroup.midfield);
      expect(Position.am.group, PositionGroup.midfield);
      expect(Position.lw.group, PositionGroup.attack);
      expect(Position.rw.group, PositionGroup.attack);
      expect(Position.st.group, PositionGroup.attack);
    });

    test('solo el portero es isGoalkeeper', () {
      expect(Position.gk.isGoalkeeper, isTrue);
      for (final position in Position.values.where((p) => p != Position.gk)) {
        expect(position.isGoalkeeper, isFalse);
      }
    });
  });

  group('Player', () {
    test('se construye con value objects validados', () {
      final player = build.player(skill: 75);
      expect(player.attributes.passing.value, 75);
      expect(player.potential.value, 85);
      expect(player.nationality.value, 'ES');
    });

    test('copyWith actualiza la condición dinámica sin tocar la identidad', () {
      final player = build.player();
      final tired = player.copyWith(fitness: Fitness(40), morale: Morale(30));
      expect(tired.fitness.value, 40);
      expect(tired.morale.value, 30);
      expect(tired.id, player.id);
      expect(tired.attributes, player.attributes);
    });

    test('igualdad estructural (freezed)', () {
      expect(build.player(), build.player());
      expect(build.player(id: 'p1'), isNot(build.player(id: 'p2')));
    });

    test('los campos validados rechazan datos inválidos en la frontera', () {
      // La validación vive en los value objects: construir un jugador con
      // datos fuera de rango es imposible porque los VOs fallan antes.
      expect(() => Age(10), throwsA(isA<DomainInvariantViolation>()));
      expect(() => Rating(150), throwsA(isA<DomainInvariantViolation>()));
      expect(() => DisplayName(''), throwsA(isA<DomainInvariantViolation>()));
    });
  });

  group('PlayerAttributes', () {
    test('igualdad estructural y copyWith', () {
      expect(build.attributes(), build.attributes());
      final upgraded = build.attributes().copyWith(shooting: Rating(90));
      expect(upgraded.shooting.value, 90);
      expect(upgraded.passing.value, 60);
    });
  });
}
