@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  group('Person', () {
    Person sample() {
      final origin = PersonOrigin(
        country: CountryCode('ES'),
        city: 'Valencia',
        generation: 1,
        economicContext: 'middle',
        appearanceYear: 2024,
        cohort: 'test',
        derivedWorldSeed: 42,
        birthContextHash: 1234,
      );
      final trait = TraitScore(50);
      return Person(
        id: PersonId('person-test-1'),
        firstName: DisplayName('Carlos'),
        lastName: DisplayName('Ruiz'),
        birthDate: BirthDate(year: 1995, month: 6, day: 12),
        nationality: CountryCode('ES'),
        primaryLanguage: 'es',
        gender: PersonGender.male,
        origin: origin,
        personality: PersonalityProfile(
          ambition: trait,
          patience: trait,
          prudence: trait,
          aggressiveness: trait,
          pride: trait,
          ego: trait,
          professionalism: trait,
          empathy: trait,
          emotionalStability: trait,
          leadership: trait,
          memoryTrait: trait,
          pressureTolerance: trait,
        ),
        values: PersonValues(
          loyalty: trait,
          meritocracy: trait,
          family: trait,
          prestige: trait,
          security: trait,
        ),
        philosophy: PersonPhilosophy(
          pragmatism: trait,
          youthFocus: trait,
          attackingStyle: trait,
          financialPrudence: trait,
          institutionalLoyalty: trait,
        ),
        competencies: GeneralCompetencies(
          intelligence: trait,
          negotiation: trait,
          analysis: trait,
          communication: trait,
          adaptability: trait,
        ),
        traits: PermanentTraits(
          charisma: trait,
          workEthic: trait,
          resilience: trait,
          creativity: trait,
          discipline: trait,
        ),
        cognitivePotential: trait,
        initialReputation: Rating(55),
        role: PersonRole.player,
      );
    }

    test('igualdad y JSON roundtrip', () {
      final original = sample();
      final decoded = Person.fromJson(original.toJson());
      expect(decoded, original);
    });

    test('displayName compone nombre completo', () {
      final person = sample();
      expect(person.displayName.value, 'Carlos Ruiz');
    });
  });

  group('syntheticPersonId', () {
    test('misma semilla produce mismo id de jugador', () {
      final a = syntheticPlayerPersonId(
        worldSeed: 99,
        playerId: PlayerId('club-1-1-p0'),
      );
      final b = syntheticPlayerPersonId(
        worldSeed: 99,
        playerId: PlayerId('club-1-1-p0'),
      );
      expect(a, b);
    });

    test('staff distinto por club y rol', () {
      final president = syntheticStaffPersonId(
        worldSeed: 1,
        clubId: ClubId('club-1-1'),
        role: PersonRole.president,
      );
      final manager = syntheticStaffPersonId(
        worldSeed: 1,
        clubId: ClubId('club-1-1'),
        role: PersonRole.manager,
      );
      expect(president, isNot(manager));
    });
  });
}
