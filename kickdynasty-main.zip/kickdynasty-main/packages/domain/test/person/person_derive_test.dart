@Tags(['people-first'])
import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

void main() {
  group('personDerive', () {
    test('determinista para mismos inputs', () {
      final id = PersonId('person-abc');
      final a = personDerive(
        personId: id,
        worldSeed: 42,
        domain: 'personality.ambition',
      );
      final b = personDerive(
        personId: id,
        worldSeed: 42,
        domain: 'personality.ambition',
      );
      expect(a, b);
    });

    test('dominios distintos producen valores distintos', () {
      final id = PersonId('person-abc');
      final ambition = personDeriveTraitScore(
        personId: id,
        worldSeed: 42,
        domain: 'personality.ambition',
      );
      final patience = personDeriveTraitScore(
        personId: id,
        worldSeed: 42,
        domain: 'personality.patience',
      );
      expect(ambition, isNot(equals(patience)));
    });
  });
}
