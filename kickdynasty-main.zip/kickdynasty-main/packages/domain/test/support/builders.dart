/// Constructores de objetos de prueba con valores válidos por defecto.
///
/// Cada builder crea una instancia correcta; los tests sobreescriben solo el
/// campo que quieren violar o verificar.
library;

import 'package:kickdynasty_domain/kickdynasty_domain.dart';

/// Atributos uniformes al valor [value].
PlayerAttributes attributes({int value = 60}) {
  final rating = Rating(value);
  return PlayerAttributes(
    pace: rating,
    stamina: rating,
    strength: rating,
    passing: rating,
    shooting: rating,
    dribbling: rating,
    tackling: rating,
    positioning: rating,
    vision: rating,
    composure: rating,
    goalkeeping: rating,
  );
}

/// Jugador válido con posición y datos configurables.
Player player({
  String id = 'p1',
  String name = 'Jugador Uno',
  Position position = Position.cm,
  int age = 24,
  int skill = 60,
}) {
  return Player(
    id: PlayerId(id),
    name: DisplayName(name),
    nationality: CountryCode('ES'),
    position: position,
    preferredFoot: PreferredFoot.right,
    age: Age(age),
    attributes: attributes(value: skill),
    potential: Rating.clamped(skill + 10),
    fitness: Fitness(90),
    morale: Morale(70),
    form: Form(50),
  );
}

/// Plantilla válida: 2 porteros, 6 defensas, 5 medios, 5 delanteros (18).
List<Player> squadPlayers({String prefix = 'p'}) {
  final positions = <Position>[
    Position.gk,
    Position.gk,
    Position.cb,
    Position.cb,
    Position.cb,
    Position.lb,
    Position.rb,
    Position.cb,
    Position.dm,
    Position.cm,
    Position.cm,
    Position.am,
    Position.cm,
    Position.st,
    Position.st,
    Position.lw,
    Position.rw,
    Position.st,
  ];
  return [
    for (var i = 0; i < positions.length; i++)
      player(id: '$prefix$i', name: 'Jugador ${i + 1}', position: positions[i]),
  ];
}

/// Club válido.
Club club({String id = 'c1', String name = 'Atlético Norte'}) {
  return Club(
    id: ClubId(id),
    name: DisplayName(name),
    code: ClubCode('ATN'),
    country: CountryCode('ES'),
    reputation: Rating(60),
    stadium: Stadium(name: DisplayName('Estadio Norte'), capacity: 25000),
    balance: const Money(1000000),
  );
}

/// Contrato válido.
Contract contract({
  String id = 'k1',
  String playerId = 'p1',
  String clubId = 'c1',
  int wage = 5000,
}) {
  return Contract(
    id: ContractId(id),
    playerId: PlayerId(playerId),
    clubId: ClubId(clubId),
    weeklyWage: Money(wage),
    expiry: GameDate(season: 3, week: 1),
  );
}

/// Ids de jugadores `p0..p{count-1}`.
List<PlayerId> playerIds(int count, {String prefix = 'p'}) => [
  for (var i = 0; i < count; i++) PlayerId('$prefix$i'),
];

/// Alineación válida de 11 titulares y 5 suplentes.
MatchLineup lineup({Formation? formation}) {
  final starters = playerIds(11);
  return MatchLineup(
    formation: formation ?? Formation.f433,
    starters: starters,
    bench: playerIds(5, prefix: 'b'),
    captainId: starters.first,
  );
}
