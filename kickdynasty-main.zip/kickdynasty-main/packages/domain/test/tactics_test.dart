import 'package:kickdynasty_domain/kickdynasty_domain.dart';
import 'package:test/test.dart';

import 'support/builders.dart' as build;

void main() {
  group('Formation', () {
    test('las formaciones estándar son válidas', () {
      expect(Formation.standard, hasLength(5));
      for (final formation in Formation.standard) {
        expect(formation.slots, hasLength(Formation.squadSize));
        expect(formation.slots.first.isGoalkeeper, isTrue);
        expect(formation.slots.where((s) => s.isGoalkeeper).length, 1);
      }
    });

    test('rechaza formaciones sin 11 posiciones', () {
      expect(
        () => Formation(label: 'corta', slots: const [Position.gk]),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('rechaza formaciones sin portero o con más de uno', () {
      final noGk = List<Position>.filled(11, Position.cm);
      expect(
        Formation.validate(label: 'x', slots: noGk),
        contains(contains('portero')),
      );

      final twoGk = [Position.gk, Position.gk, ...List.filled(9, Position.cm)];
      expect(
        Formation.validate(label: 'x', slots: twoGk),
        contains(contains('portero')),
      );
    });

    test('rechaza el portero fuera del índice 0', () {
      final gkInMiddle = [
        Position.cb,
        Position.gk,
        ...List.filled(9, Position.cm),
      ];
      expect(
        Formation.validate(label: 'x', slots: gkInMiddle),
        contains(contains('índice 0')),
      );
    });

    test('rechaza etiqueta vacía', () {
      expect(
        Formation.validate(label: '  ', slots: Formation.f442.slots),
        contains(contains('etiqueta')),
      );
    });

    test('igualdad, hashCode y toString', () {
      final custom = Formation(label: '4-3-3', slots: Formation.f433.slots);
      expect(custom, Formation.f433);
      expect(custom.hashCode, Formation.f433.hashCode);
      expect(Formation.f442, isNot(Formation.f433));
      expect(Formation.f4231.toString(), contains('4-2-3-1'));
    });

    test('los slots son inmutables', () {
      expect(
        () => Formation.f442.slots.add(Position.st),
        throwsUnsupportedError,
      );
    });
  });

  group('TacticalInstructions', () {
    test('los valores por defecto son neutros', () {
      const instructions = TacticalInstructions();
      expect(instructions.mentality, Mentality.balanced);
      expect(instructions.tempo, Tempo.standard);
      expect(instructions.width, Width.standard);
      expect(instructions.pressing, PressingIntensity.medium);
      expect(instructions.defensiveLine, DefensiveLine.standard);
      expect(instructions.passingStyle, PassingStyle.mixed);
    });

    test('copyWith e igualdad estructural', () {
      const base = TacticalInstructions();
      final aggressive = base.copyWith(
        mentality: Mentality.veryAttacking,
        pressing: PressingIntensity.high,
      );
      expect(aggressive.mentality, Mentality.veryAttacking);
      expect(aggressive.tempo, Tempo.standard);
      expect(base, const TacticalInstructions());
      expect(aggressive, isNot(base));
    });
  });

  group('MatchLineup', () {
    test('acepta una alineación válida', () {
      final lineup = build.lineup();
      expect(lineup.starters, hasLength(11));
      expect(lineup.bench, hasLength(5));
      expect(lineup.captainId, lineup.starters.first);
      expect(lineup.instructions, const TacticalInstructions());
    });

    test('rechaza un número de titulares distinto de 11', () {
      expect(
        MatchLineup.validate(
          starters: build.playerIds(10),
          bench: const [],
          captainId: PlayerId('p0'),
        ),
        contains(contains('titulares')),
      );
    });

    test('rechaza titulares repetidos', () {
      final repeated = [...build.playerIds(10), PlayerId('p0')];
      expect(
        MatchLineup.validate(
          starters: repeated,
          bench: const [],
          captainId: PlayerId('p0'),
        ),
        contains(contains('repetidos entre los titulares')),
      );
    });

    test('rechaza banquillo con más de 9 o con repetidos', () {
      expect(
        MatchLineup.validate(
          starters: build.playerIds(11),
          bench: build.playerIds(10, prefix: 'b'),
          captainId: PlayerId('p0'),
        ),
        contains(contains('máximo')),
      );
      expect(
        MatchLineup.validate(
          starters: build.playerIds(11),
          bench: [PlayerId('b0'), PlayerId('b0')],
          captainId: PlayerId('p0'),
        ),
        contains(contains('repetidos en el banquillo')),
      );
    });

    test('rechaza solape entre titulares y banquillo', () {
      expect(
        MatchLineup.validate(
          starters: build.playerIds(11),
          bench: [PlayerId('p3')],
          captainId: PlayerId('p0'),
        ),
        contains(contains('a la vez titulares y suplentes')),
      );
    });

    test('rechaza capitán no titular', () {
      final violations = MatchLineup.validate(
        starters: build.playerIds(11),
        bench: const [],
        captainId: PlayerId('fuera'),
      );
      expect(violations, contains(contains('capitán')));
      expect(
        () => MatchLineup(
          formation: Formation.f442,
          starters: build.playerIds(11),
          bench: const [],
          captainId: PlayerId('fuera'),
        ),
        throwsA(isA<DomainInvariantViolation>()),
      );
    });

    test('igualdad, hashCode y toString', () {
      expect(build.lineup(), build.lineup());
      expect(build.lineup().hashCode, build.lineup().hashCode);
      expect(build.lineup(), isNot(build.lineup(formation: Formation.f442)));
      expect(build.lineup().toString(), contains('4-3-3'));
    });
  });
}
