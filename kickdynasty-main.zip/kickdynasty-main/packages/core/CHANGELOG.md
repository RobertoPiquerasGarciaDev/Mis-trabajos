# Changelog — kickdynasty_core

## 0.1.1 — 2026-07-05

### Fixed (revisión Staff Engineer)

- `DebugTrace` usa `Clock` inyectado (determinismo en tests).
- `EventBus.dispose` cierra streams de `on()`.
- `Logger` retorna temprano sin sinks (producción silenciosa explícita).
- `CoreModule.seedManager` / `featureFlags` derivados de config activa.
- Eliminada dependencia `collection` no usada.
- Documentado contrato de `ConfigManager.replace` vs Riverpod.

## 0.1.0 — 2026-07-05

### Added (Módulo 0)

- Paquete `kickdynasty_core`: configuración global, logging, reloj, semillas,
  event bus, feature flags, debug, benchmarks y DI Riverpod.
- `CoreModule` con factories production / development / testing.
- Tests de paridad `derivedSeed` ↔ `kickdynasty_engine`.
- Benchmarks base: `derived_seed_10k`, `event_bus_publish_1k`, `config_replace_1k`.
- ADR 0010.
