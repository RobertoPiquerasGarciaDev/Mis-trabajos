/// Infraestructura base de KickDynasty (Módulo 0).
///
/// Sin mecánicas de juego: configuración, logging, tiempo, semillas, DI,
/// event bus, feature flags, herramientas de debug y benchmarks.
library;

export 'src/benchmark/benchmark_result.dart';
export 'src/benchmark/benchmark_runner.dart';
export 'src/benchmark/benchmark_suite.dart';
export 'src/config/app_config.dart';
export 'src/config/config_manager.dart';
export 'src/config/environment.dart';
export 'src/debug/debug_options.dart';
export 'src/debug/debug_session.dart';
export 'src/debug/debug_trace.dart';
export 'src/di/core_module.dart';
export 'src/di/core_providers.dart';
export 'src/events/app_event.dart';
export 'src/events/event_bus.dart';
export 'src/features/feature_flag.dart';
export 'src/features/feature_flags.dart';
export 'src/features/people_first_feature_flags.dart';
export 'src/logging/console_log_sink.dart';
export 'src/logging/log_level.dart';
export 'src/logging/log_record.dart';
export 'src/logging/log_sink.dart';
export 'src/logging/logger.dart';
export 'src/logging/memory_log_sink.dart';
export 'src/seed/derived_seed.dart';
export 'src/seed/seed_manager.dart';
export 'src/time/clock.dart';
export 'src/time/fake_clock.dart';
export 'src/time/system_clock.dart';
export 'src/utils/disposable.dart';
export 'src/utils/timing.dart';
