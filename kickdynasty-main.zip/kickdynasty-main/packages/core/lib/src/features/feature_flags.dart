import 'package:kickdynasty_core/src/features/feature_flag.dart';
import 'package:meta/meta.dart';

/// Conjunto inmutable de feature flags.
@immutable
final class FeatureFlags {
  /// Crea las banderas desde un mapa.
  const FeatureFlags(this._flags);

  /// Sin banderas activas.
  static const empty = FeatureFlags({});

  /// Desarrollo: verbose + debug overlay + benchmarks.
  static final development = FeatureFlags({
    CoreFeatureFlags.verboseLogging.key: true,
    CoreFeatureFlags.benchmarksEnabled.key: true,
    CoreFeatureFlags.debugOverlay.key: true,
  });

  /// Producción: todo desactivado salvo lo explícitamente activado externamente.
  static const production = FeatureFlags({});

  /// Tests: strict mode + benchmarks.
  static final testing = FeatureFlags({
    CoreFeatureFlags.eventBusStrictMode.key: true,
    CoreFeatureFlags.benchmarksEnabled.key: true,
  });

  final Map<String, bool> _flags;

  /// `true` si [flag] está activa.
  bool isEnabled(FeatureFlag flag, {bool defaultValue = false}) =>
      _flags[flag.key] ?? defaultValue;

  /// `true` si [key] está activa.
  bool isEnabledKey(String key, {bool defaultValue = false}) =>
      _flags[key] ?? defaultValue;

  /// Lanza [StateError] si [flag] no está activa.
  void require(FeatureFlag flag) {
    if (!isEnabled(flag)) {
      throw StateError('Feature flag requerida desactivada: ${flag.key}');
    }
  }

  /// Copia con [flag] activada o desactivada.
  FeatureFlags withFlag(FeatureFlag flag, {required bool enabled}) {
    return FeatureFlags({..._flags, flag.key: enabled});
  }

  /// Mapa de solo lectura.
  Map<String, bool> get asMap => Map.unmodifiable(_flags);

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is FeatureFlags && _mapsEqual(_flags, other._flags);

  @override
  int get hashCode =>
      Object.hashAll(_flags.entries.map((e) => Object.hash(e.key, e.value)));

  static bool _mapsEqual(Map<String, bool> a, Map<String, bool> b) {
    if (a.length != b.length) return false;
    for (final entry in a.entries) {
      if (b[entry.key] != entry.value) return false;
    }
    return true;
  }
}
