import 'package:meta/meta.dart';

/// Identificador tipado de feature flag de infraestructura.
@immutable
final class FeatureFlag {
  /// Crea la bandera con [key] único.
  const FeatureFlag(this.key, {this.description = ''});

  /// Clave estable (snake_case).
  final String key;

  /// Descripción para documentación.
  final String description;
}

/// Banderas predefinidas del Módulo 0 (infraestructura, no gameplay).
abstract final class CoreFeatureFlags {
  /// Logging verboso en consola.
  static const verboseLogging = FeatureFlag(
    'verbose_logging',
    description: 'Emite logs trace/debug adicionales',
  );

  /// Modo estricto del event bus (propaga errores de handlers).
  static const eventBusStrictMode = FeatureFlag(
    'event_bus_strict_mode',
    description: 'Los handlers que fallen interrumpen la publicación',
  );

  /// Habilita suites de benchmark en runtime.
  static const benchmarksEnabled = FeatureFlag(
    'benchmarks_enabled',
    description: 'Permite ejecutar BenchmarkRunner en la app',
  );

  /// Overlay de debug en UI (futuro).
  static const debugOverlay = FeatureFlag(
    'debug_overlay',
    description: 'Muestra panel de debug en pantalla',
  );

  /// Todas las banderas de infraestructura conocidas.
  static const all = [
    verboseLogging,
    eventBusStrictMode,
    benchmarksEnabled,
    debugOverlay,
  ];
}
