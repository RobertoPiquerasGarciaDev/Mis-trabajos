/// Feature flags del eje People First (PF-0).
library;

import 'package:kickdynasty_core/src/features/feature_flag.dart';

/// Banderas de infraestructura People First — **off por defecto** en producción.
abstract final class PeopleFirstFeatureFlags {
  /// Interruptor maestro: habilita el eje People First en runtime.
  static const enabled = FeatureFlag(
    'people_first_enabled',
    description: 'Activa deliberaciones y actores People First',
  );

  /// Modo sombra: registra DecisionRecord sin cambiar IA legacy (Fase 6+).
  static const shadowMode = FeatureFlag(
    'people_first_shadow_mode',
    description: 'Registra deliberaciones en paralelo a ClubAiDirector',
  );

  /// Sub-flag: orquestador de deliberación (Fase 6+).
  static const deliberation = FeatureFlag(
    'people_first_deliberation',
    description: 'Ejecuta DeliberationOrchestrator',
  );

  /// Todas las banderas People First conocidas.
  static const all = [enabled, shadowMode, deliberation];
}
