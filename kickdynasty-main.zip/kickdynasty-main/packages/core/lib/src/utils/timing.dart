/// Utilidades de medición de tiempo de pared.
library;

/// Convierte nanosegundos a milisegundos con 3 decimales.
double nanosToMillis(int nanos) => nanos / 1e6;

/// Formatea [duration] como cadena legible para benchmarks.
String formatDuration(Duration duration) {
  final ms = duration.inMicroseconds / 1000;
  if (ms < 1000) return '${ms.toStringAsFixed(2)} ms';
  return '${(ms / 1000).toStringAsFixed(2)} s';
}

/// Calcula mediana de [values] (lista no vacía).
Duration medianDuration(List<Duration> values) {
  if (values.isEmpty) {
    throw ArgumentError('medianDuration requiere al menos un valor');
  }
  final sorted = [...values]..sort((a, b) => a.compareTo(b));
  final mid = sorted.length ~/ 2;
  if (sorted.length.isOdd) return sorted[mid];
  return Duration(
    microseconds:
        (sorted[mid - 1].inMicroseconds + sorted[mid].inMicroseconds) ~/ 2,
  );
}

/// Calcula media de [values].
Duration meanDuration(List<Duration> values) {
  if (values.isEmpty) {
    throw ArgumentError('meanDuration requiere al menos un valor');
  }
  final total = values.fold<int>(0, (sum, d) => sum + d.inMicroseconds);
  return Duration(microseconds: total ~/ values.length);
}
