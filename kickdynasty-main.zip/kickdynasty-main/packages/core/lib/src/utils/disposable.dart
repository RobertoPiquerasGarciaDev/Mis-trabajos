/// Recurso que puede liberarse explícitamente.
abstract interface class Disposable {
  /// Libera recursos.
  void dispose();
}

/// Ejecuta [action] y garantiza [dispose] en un bloque finally.
R using<T extends Disposable, R>(T resource, R Function(T resource) action) {
  try {
    return action(resource);
  } finally {
    resource.dispose();
  }
}
