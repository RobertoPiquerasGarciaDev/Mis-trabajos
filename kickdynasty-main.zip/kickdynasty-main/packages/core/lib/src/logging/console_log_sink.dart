import 'package:kickdynasty_core/src/logging/log_level.dart';
import 'package:kickdynasty_core/src/logging/log_record.dart';
import 'package:kickdynasty_core/src/logging/log_sink.dart';

/// Escribe registros en la consola (`print`).
final class ConsoleLogSink implements LogSink {
  /// Crea el sink con formato opcional personalizado.
  ConsoleLogSink({this.formatter});

  /// Si es null, se usa [LogRecord.toString].
  final String Function(LogRecord record)? formatter;

  @override
  void write(LogRecord record) {
    // ignore: avoid_print — destino explícito de este sink
    print(formatter?.call(record) ?? record.toString());
  }

  @override
  void dispose() {}
}

/// Sink que solo emite a partir de [minLevel].
final class FilteredLogSink implements LogSink {
  /// Crea el filtro sobre [inner].
  FilteredLogSink({required this.inner, required this.minLevel});

  /// Sink destino.
  final LogSink inner;

  /// Nivel mínimo.
  final LogLevel minLevel;

  @override
  void write(LogRecord record) {
    if (record.level.isEnabledAt(minLevel)) {
      inner.write(record);
    }
  }

  @override
  void dispose() => inner.dispose();
}
