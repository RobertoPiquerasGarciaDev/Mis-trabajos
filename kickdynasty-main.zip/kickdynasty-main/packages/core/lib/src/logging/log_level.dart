/// Niveles de severidad del log, ordenados de menor a mayor prioridad.
enum LogLevel implements Comparable<LogLevel> {
  /// Traza detallada (solo desarrollo).
  trace(0),

  /// Depuración.
  debug(1),

  /// Información operativa.
  info(2),

  /// Situaciones recuperables anómalas.
  warning(3),

  /// Fallos que impiden una operación concreta.
  error(4),

  /// Fallos críticos de la aplicación.
  fatal(5);

  const LogLevel(this.priority);

  /// Prioridad numérica (mayor = más severo).
  final int priority;

  @override
  int compareTo(LogLevel other) => priority.compareTo(other.priority);

  /// `true` si este nivel debe emitirse dado [minLevel].
  bool isEnabledAt(LogLevel minLevel) => priority >= minLevel.priority;
}
