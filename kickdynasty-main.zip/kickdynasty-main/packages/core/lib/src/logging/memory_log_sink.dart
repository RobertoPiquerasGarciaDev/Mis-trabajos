import 'package:kickdynasty_core/src/logging/log_record.dart';
import 'package:kickdynasty_core/src/logging/log_sink.dart';

/// Acumula registros en memoria (tests y debugging).
final class MemoryLogSink implements LogSink {
  final _records = <LogRecord>[];

  /// Registros capturados (solo lectura).
  List<LogRecord> get records => List.unmodifiable(_records);

  @override
  void write(LogRecord record) {
    _records.add(record);
  }

  /// Vacía el buffer.
  void clear() => _records.clear();

  @override
  void dispose() {
    _records.clear();
  }
}
