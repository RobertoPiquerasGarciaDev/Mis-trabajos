import 'package:kickdynasty_core/src/logging/log_level.dart';
import 'package:meta/meta.dart';

/// Registro estructurado de un evento de log.
@immutable
final class LogRecord {
  /// Crea un registro de log.
  const LogRecord({
    required this.timestamp,
    required this.level,
    required this.loggerName,
    required this.message,
    this.context = const {},
    this.error,
    this.stackTrace,
  });

  /// Instante de emisión (proporcionado por [Clock], nunca `DateTime.now()` directo).
  final DateTime timestamp;

  /// Severidad.
  final LogLevel level;

  /// Nombre del logger emisor (jerárquico, p. ej. `core.event_bus`).
  final String loggerName;

  /// Mensaje principal.
  final String message;

  /// Metadatos estructurados adicionales.
  final Map<String, Object?> context;

  /// Excepción asociada, si la hay.
  final Object? error;

  /// Stack trace asociado.
  final StackTrace? stackTrace;

  @override
  String toString() {
    final buffer = StringBuffer()
      ..write(timestamp.toIso8601String())
      ..write(' [${level.name.toUpperCase()}] ')
      ..write('$loggerName: $message');
    if (context.isNotEmpty) {
      buffer.write(' $context');
    }
    if (error != null) {
      buffer.write(' error=$error');
    }
    return buffer.toString();
  }
}
