import 'package:kickdynasty_core/src/logging/log_record.dart';

/// Destino de registros de log (consola, memoria, agregador externo…).
abstract interface class LogSink {
  /// Escribe [record]. Implementaciones deben ser no bloqueantes si es posible.
  void write(LogRecord record);

  /// Libera recursos del sink.
  void dispose() {}
}
