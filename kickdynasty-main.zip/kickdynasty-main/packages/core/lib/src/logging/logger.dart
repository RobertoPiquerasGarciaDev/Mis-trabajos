import 'package:kickdynasty_core/src/logging/log_level.dart';
import 'package:kickdynasty_core/src/logging/log_record.dart';
import 'package:kickdynasty_core/src/logging/log_sink.dart';
import 'package:kickdynasty_core/src/time/clock.dart';
import 'package:kickdynasty_core/src/time/system_clock.dart';

/// Logger estructurado con niveles, contexto y sinks configurables.
final class Logger {
  /// Crea un logger raíz.
  Logger({
    required this.name,
    required Clock clock,
    required LogLevel minLevel,
    required List<LogSink> sinks,
    Map<String, Object?> context = const {},
  }) : _clock = clock,
       _minLevel = minLevel,
       _sinks = List.unmodifiable(sinks),
       _context = Map.unmodifiable(context);

  /// Nombre jerárquico del logger.
  final String name;

  final Clock _clock;
  final LogLevel _minLevel;
  final List<LogSink> _sinks;
  final Map<String, Object?> _context;

  /// Crea un logger hijo con [name] como sufijo y contexto adicional.
  Logger child(String suffix, {Map<String, Object?> context = const {}}) {
    return Logger(
      name: '$name.$suffix',
      clock: _clock,
      minLevel: _minLevel,
      sinks: _sinks,
      context: {..._context, ...context},
    );
  }

  /// Log de traza detallada.
  void trace(String message, {Map<String, Object?> context = const {}}) =>
      _log(LogLevel.trace, message, context: context);

  /// Log de depuración.
  void debug(String message, {Map<String, Object?> context = const {}}) =>
      _log(LogLevel.debug, message, context: context);

  /// Log informativo.
  void info(String message, {Map<String, Object?> context = const {}}) =>
      _log(LogLevel.info, message, context: context);

  /// Log de advertencia.
  void warning(String message, {Map<String, Object?> context = const {}}) =>
      _log(LogLevel.warning, message, context: context);

  /// Log de error recuperable.
  void error(
    String message, {
    Map<String, Object?> context = const {},
    Object? error,
    StackTrace? stackTrace,
  }) => _log(
    LogLevel.error,
    message,
    context: context,
    error: error,
    stackTrace: stackTrace,
  );

  /// Log de error fatal.
  void fatal(
    String message, {
    Map<String, Object?> context = const {},
    Object? error,
    StackTrace? stackTrace,
  }) => _log(
    LogLevel.fatal,
    message,
    context: context,
    error: error,
    stackTrace: stackTrace,
  );

  void _log(
    LogLevel level,
    String message, {
    required Map<String, Object?> context,
    Object? error,
    StackTrace? stackTrace,
  }) {
    if (!level.isEnabledAt(_minLevel)) return;
    if (_sinks.isEmpty) return;

    final record = LogRecord(
      timestamp: _clock.now(),
      level: level,
      loggerName: name,
      message: message,
      context: {..._context, ...context},
      error: error,
      stackTrace: stackTrace,
    );

    for (final sink in _sinks) {
      sink.write(record);
    }
  }
}

/// Logger que descarta todas las entradas.
final class NoOpLogger extends Logger {
  /// Crea un logger silencioso.
  NoOpLogger()
    : super(
        name: 'noop',
        clock: const SystemClock(),
        minLevel: LogLevel.fatal,
        sinks: const [],
      );

  @override
  void trace(String message, {Map<String, Object?> context = const {}}) {}

  @override
  void debug(String message, {Map<String, Object?> context = const {}}) {}

  @override
  void info(String message, {Map<String, Object?> context = const {}}) {}

  @override
  void warning(String message, {Map<String, Object?> context = const {}}) {}

  @override
  void error(
    String message, {
    Map<String, Object?> context = const {},
    Object? error,
    StackTrace? stackTrace,
  }) {}

  @override
  void fatal(
    String message, {
    Map<String, Object?> context = const {},
    Object? error,
    StackTrace? stackTrace,
  }) {}
}
