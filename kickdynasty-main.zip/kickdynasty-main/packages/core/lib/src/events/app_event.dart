import 'package:meta/meta.dart';

/// Evento de infraestructura publicado en el [EventBus].
///
/// Los módulos de gameplay extenderán esta base en el futuro; Módulo 0 solo
/// define el contrato y eventos de plataforma.
@immutable
abstract base class AppEvent {
  /// Crea el evento con metadatos opcionales.
  const AppEvent({this.name = 'AppEvent'});

  /// Nombre legible del tipo de evento.
  final String name;
}

/// La configuración global ha cambiado.
final class ConfigChangedEvent extends AppEvent {
  /// Crea el evento.
  const ConfigChangedEvent({required this.versionLabel});

  /// Etiqueta de versión o entorno tras el cambio.
  final String versionLabel;

  @override
  String get name => 'ConfigChanged';
}

/// Evento de traza de debug (no gameplay).
final class DebugTraceEvent extends AppEvent {
  /// Crea el evento.
  const DebugTraceEvent({required this.span, required this.message});

  /// Nombre del span.
  final String span;

  /// Mensaje de traza.
  final String message;

  @override
  String get name => 'DebugTrace';
}

/// Evento emitido al arrancar la infraestructura core.
final class CoreInitializedEvent extends AppEvent {
  /// Crea el evento.
  const CoreInitializedEvent({required this.environment});

  /// Entorno activo.
  final String environment;

  @override
  String get name => 'CoreInitialized';
}
