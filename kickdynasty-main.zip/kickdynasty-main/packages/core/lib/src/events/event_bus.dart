import 'dart:async';

// Los StreamControllers de [on] se cierran en [EventBus.dispose].
// ignore_for_file: close_sinks

import 'package:kickdynasty_core/src/events/app_event.dart';
import 'package:kickdynasty_core/src/logging/logger.dart';
import 'package:kickdynasty_core/src/time/clock.dart';
import 'package:kickdynasty_core/src/utils/disposable.dart';

/// Suscripción cancelable a eventos.
abstract interface class EventSubscription implements Disposable {
  @override
  void dispose();
}

/// Bus de eventos tipado in-process (Módulo 0).
///
/// No persiste eventos ni los mezcla con Chronicle (WORLD_DESIGN §2).
final class EventBus {
  /// Crea el bus.
  EventBus({required Clock clock, Logger? logger, this.strictMode = false})
    : _clock = clock,
      _logger = logger?.child('event_bus');

  final Clock _clock;
  final Logger? _logger;
  final _handlers = <Type, List<_HandlerEntry>>{};
  final _streamControllers = <StreamController<Object?>>[];

  /// Si es `true`, los errores en handlers se propagan; si no, se registran.
  final bool strictMode;

  /// Publica [event] a todos los suscriptores del tipo concreto y de [AppEvent].
  void publish(AppEvent event) {
    _logger?.debug(
      'publish ${event.name}',
      context: {'at': _clock.now().toIso8601String()},
    );
    _invoke(event.runtimeType, event);
    if (event.runtimeType != AppEvent) {
      _invoke(AppEvent, event);
    }
  }

  void _invoke(Type type, AppEvent event) {
    final entries = _handlers[type];
    if (entries == null) return;
    for (final entry in List<_HandlerEntry>.from(entries)) {
      try {
        entry.handler(event);
      } on Object catch (error, stackTrace) {
        _logger?.error(
          'handler error for ${event.name}',
          error: error,
          stackTrace: stackTrace,
        );
        if (strictMode) {
          rethrow;
        }
      }
    }
  }

  /// Suscribe [handler] a eventos de tipo [T].
  EventSubscription subscribe<T extends AppEvent>(
    void Function(T event) handler,
  ) {
    void wrapper(AppEvent event) => handler(event as T);
    final entry = _HandlerEntry(wrapper);
    _handlers.putIfAbsent(T, () => []).add(entry);
    return _HandlerSubscription(_handlers[T]!, entry);
  }

  /// Stream de eventos de tipo [T]. Cancelar con [StreamSubscription.cancel].
  Stream<T> on<T extends AppEvent>() {
    final controller = StreamController<T>();
    _streamControllers.add(controller);
    final subscription = subscribe<T>((event) {
      if (!controller.isClosed) {
        controller.add(event);
      }
    });
    controller.onCancel = () {
      subscription.dispose();
      _streamControllers.remove(controller);
      if (!controller.isClosed) {
        controller.close();
      }
    };
    return controller.stream;
  }

  /// Elimina todos los handlers y cierra streams abiertos de [on].
  void dispose() {
    for (final controller in _streamControllers) {
      if (!controller.isClosed) {
        controller.close();
      }
    }
    _streamControllers.clear();
    _handlers.clear();
  }
}

final class _HandlerEntry {
  _HandlerEntry(this.handler);

  final void Function(AppEvent event) handler;
}

final class _HandlerSubscription implements EventSubscription {
  _HandlerSubscription(this._list, this._entry);

  final List<_HandlerEntry> _list;
  final _HandlerEntry _entry;

  @override
  void dispose() {
    _list.remove(_entry);
  }
}
