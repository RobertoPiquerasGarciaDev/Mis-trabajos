import 'package:kickdynasty_core/src/benchmark/benchmark_runner.dart';
import 'package:kickdynasty_core/src/config/app_config.dart';
import 'package:kickdynasty_core/src/config/config_manager.dart';
import 'package:kickdynasty_core/src/debug/debug_session.dart';
import 'package:kickdynasty_core/src/debug/debug_trace.dart';
import 'package:kickdynasty_core/src/events/app_event.dart';
import 'package:kickdynasty_core/src/events/event_bus.dart';
import 'package:kickdynasty_core/src/features/feature_flag.dart';
import 'package:kickdynasty_core/src/features/feature_flags.dart';
import 'package:kickdynasty_core/src/logging/console_log_sink.dart';
import 'package:kickdynasty_core/src/logging/log_sink.dart';
import 'package:kickdynasty_core/src/logging/logger.dart';
import 'package:kickdynasty_core/src/logging/memory_log_sink.dart';
import 'package:kickdynasty_core/src/seed/seed_manager.dart';
import 'package:kickdynasty_core/src/time/clock.dart';
import 'package:kickdynasty_core/src/time/fake_clock.dart';
import 'package:kickdynasty_core/src/time/system_clock.dart';
import 'package:kickdynasty_core/src/utils/disposable.dart';

/// Contenedor de infraestructura (Módulo 0) listo para inyección.
///
/// Agrupa todos los servicios transversales sin mecánicas de juego.
final class CoreModule implements Disposable {
  CoreModule._({
    required this.clock,
    required this.configManager,
    required this.logger,
    required this.eventBus,
    required this.debugTrace,
    required this.debugSession,
    required this.benchmarkRunner,
    required List<LogSink> sinks,
    this.memorySink,
  }) : _sinks = sinks;

  /// Infraestructura de producción.
  ///
  /// Sin [extraSinks], los logs no se emiten a ningún destino (silencioso).
  /// Añadir un sink de telemetría/crash reporting cuando corresponda.
  factory CoreModule.production({
    AppConfig? config,
    List<LogSink>? extraSinks,
  }) {
    final appConfig = config ?? AppConfig.production();
    return _build(
      clock: const SystemClock(),
      config: appConfig,
      extraSinks: extraSinks,
    );
  }

  /// Infraestructura de desarrollo.
  factory CoreModule.development({
    int masterSeed = 42,
    List<LogSink>? extraSinks,
  }) {
    return _build(
      clock: const SystemClock(),
      config: AppConfig.development(masterSeed: masterSeed),
      extraSinks: extraSinks,
    );
  }

  /// Infraestructura para tests (reloj y semillas controlables).
  factory CoreModule.testing({
    FakeClock? clock,
    int masterSeed = 42,
    MemoryLogSink? memorySink,
  }) {
    final fakeClock = clock ?? FakeClock(DateTime.utc(2026, 7, 5));
    final sink = memorySink ?? MemoryLogSink();
    return _build(
      clock: fakeClock,
      config: AppConfig.testing(masterSeed: masterSeed),
      extraSinks: [sink],
      memorySink: sink,
    );
  }

  static CoreModule _build({
    required Clock clock,
    required AppConfig config,
    List<LogSink>? extraSinks,
    MemoryLogSink? memorySink,
  }) {
    final sinks = <LogSink>[
      if (config.environment.isNonProduction) ConsoleLogSink(),
      ...?extraSinks,
    ];

    final configManager = ConfigManager(config);
    final logger = Logger(
      name: config.appName,
      clock: clock,
      minLevel: config.minLogLevel,
      sinks: sinks,
      context: {'env': config.environment.label, 'version': config.appVersion},
    );

    final strict = config.featureFlags.isEnabled(
      CoreFeatureFlags.eventBusStrictMode,
    );
    final eventBus = EventBus(clock: clock, logger: logger, strictMode: strict);

    final debugTrace = DebugTrace(config.debug, clock: clock);
    final debugSession = DebugSession(
      options: config.debug,
      trace: debugTrace,
      logger: logger,
      eventBus: eventBus,
    );

    final module = CoreModule._(
      clock: clock,
      configManager: configManager,
      logger: logger,
      eventBus: eventBus,
      debugTrace: debugTrace,
      debugSession: debugSession,
      benchmarkRunner: BenchmarkRunner(clock: clock),
      sinks: sinks,
      memorySink: memorySink,
    );

    eventBus.publish(
      CoreInitializedEvent(environment: config.environment.label),
    );

    return module;
  }

  /// Reloj de pared activo.
  final Clock clock;

  /// Gestor de configuración global.
  final ConfigManager configManager;

  /// Logger raíz.
  final Logger logger;

  /// Bus de eventos in-process.
  final EventBus eventBus;

  /// Trazas de debug.
  final DebugTrace debugTrace;

  /// Sesión de depuración.
  final DebugSession debugSession;

  /// Runner de benchmarks.
  final BenchmarkRunner benchmarkRunner;

  final List<LogSink> _sinks;

  /// Sink de memoria si se creó en modo testing.
  final MemoryLogSink? memorySink;

  /// Configuración activa (siempre lee de [configManager]).
  AppConfig get config => configManager.current;

  /// Semilla maestra actual (derivada de [config]).
  SeedManager get seedManager => SeedManager(masterSeed: config.masterSeed);

  /// Feature flags activas (derivadas de [config]).
  FeatureFlags get featureFlags => config.featureFlags;

  @override
  void dispose() {
    eventBus.dispose();
    configManager.dispose();
    for (final sink in _sinks) {
      sink.dispose();
    }
  }
}
