import 'package:kickdynasty_core/src/benchmark/benchmark_runner.dart';
import 'package:kickdynasty_core/src/config/app_config.dart';
import 'package:kickdynasty_core/src/config/config_manager.dart';
import 'package:kickdynasty_core/src/debug/debug_session.dart';
import 'package:kickdynasty_core/src/debug/debug_trace.dart';
import 'package:kickdynasty_core/src/di/core_module.dart';
import 'package:kickdynasty_core/src/events/event_bus.dart';
import 'package:kickdynasty_core/src/features/feature_flags.dart';
import 'package:kickdynasty_core/src/logging/logger.dart';
import 'package:kickdynasty_core/src/seed/seed_manager.dart';
import 'package:kickdynasty_core/src/time/clock.dart';
import 'package:riverpod/misc.dart';
import 'package:riverpod/riverpod.dart';

/// Módulo core activo. Debe sobreescribirse en el arranque de la app.
final coreModuleProvider = Provider<CoreModule>(
  (ref) => throw UnimplementedError(
    'coreModuleProvider debe sobreescribirse en main.dart',
  ),
);

/// Reloj de pared inyectado.
final clockProvider = Provider<Clock>(
  (ref) => ref.watch(coreModuleProvider).clock,
);

/// Configuración activa (lectura directa; no reacciona a [ConfigManager.replace]).
final appConfigProvider = Provider<AppConfig>(
  (ref) => ref.watch(coreModuleProvider).config,
);

/// Gestor de configuración.
final configManagerProvider = Provider<ConfigManager>(
  (ref) => ref.watch(coreModuleProvider).configManager,
);

/// Logger raíz.
final loggerProvider = Provider<Logger>(
  (ref) => ref.watch(coreModuleProvider).logger,
);

/// Gestor de semillas (derivado de la config activa del módulo).
final seedManagerProvider = Provider<SeedManager>(
  (ref) => ref.watch(coreModuleProvider).seedManager,
);

/// Bus de eventos.
final eventBusProvider = Provider<EventBus>(
  (ref) => ref.watch(coreModuleProvider).eventBus,
);

/// Feature flags activas (derivadas de la config activa del módulo).
final featureFlagsProvider = Provider<FeatureFlags>(
  (ref) => ref.watch(coreModuleProvider).featureFlags,
);

/// Sesión de debug.
final debugSessionProvider = Provider<DebugSession>(
  (ref) => ref.watch(coreModuleProvider).debugSession,
);

/// Trazas de debug.
final debugTraceProvider = Provider<DebugTrace>(
  (ref) => ref.watch(coreModuleProvider).debugTrace,
);

/// Runner de benchmarks.
final benchmarkRunnerProvider = Provider<BenchmarkRunner>(
  (ref) => ref.watch(coreModuleProvider).benchmarkRunner,
);

/// Overrides Riverpod listos para [ProviderScope].
List<Override> coreModuleOverrides(CoreModule module) => [
  coreModuleProvider.overrideWithValue(module),
];
