import 'package:kickdynasty_core/src/config/environment.dart';
import 'package:kickdynasty_core/src/debug/debug_options.dart';
import 'package:kickdynasty_core/src/features/feature_flags.dart';
import 'package:kickdynasty_core/src/logging/log_level.dart';
import 'package:meta/meta.dart';

/// Configuración global inmutable de la aplicación (Módulo 0).
@immutable
final class AppConfig {
  /// Crea la configuración validando invariantes.
  const AppConfig({
    required this.environment,
    this.minLogLevel = LogLevel.info,
    this.masterSeed = 0,
    this.featureFlags = FeatureFlags.empty,
    this.debug = DebugOptions.disabled,
    this.appName = 'KickDynasty',
    this.appVersion = '0.0.0',
  }) : assert(masterSeed >= 0, 'masterSeed debe ser >= 0');

  /// Configuración por defecto para desarrollo.
  factory AppConfig.development({int masterSeed = 42}) => AppConfig(
    environment: Environment.development,
    minLogLevel: LogLevel.debug,
    masterSeed: masterSeed,
    featureFlags: FeatureFlags.development,
    debug: DebugOptions.development,
    appVersion: 'dev',
  );

  /// Configuración por defecto para producción.
  factory AppConfig.production({int masterSeed = 0}) => AppConfig(
    environment: Environment.production,
    minLogLevel: LogLevel.warning,
    masterSeed: masterSeed,
    featureFlags: FeatureFlags.production,
    debug: DebugOptions.disabled,
  );

  /// Configuración por defecto para tests.
  factory AppConfig.testing({int masterSeed = 42}) => AppConfig(
    environment: Environment.test,
    minLogLevel: LogLevel.debug,
    masterSeed: masterSeed,
    featureFlags: FeatureFlags.testing,
    debug: DebugOptions.testing,
    appVersion: 'test',
  );

  /// Entorno de ejecución.
  final Environment environment;

  /// Nivel mínimo emitido por el [Logger] raíz.
  final LogLevel minLogLevel;

  /// Semilla maestra de la sesión de aplicación (no confundir con semilla de
  /// partida, gestionada por [SeedManager]).
  final int masterSeed;

  /// Banderas de infraestructura y features futuras.
  final FeatureFlags featureFlags;

  /// Opciones de depuración.
  final DebugOptions debug;

  /// Nombre de la app para logs.
  final String appName;

  /// Versión de la app para logs y diagnóstico.
  final String appVersion;

  /// Copia con campos sustituidos.
  AppConfig copyWith({
    Environment? environment,
    LogLevel? minLogLevel,
    int? masterSeed,
    FeatureFlags? featureFlags,
    DebugOptions? debug,
    String? appName,
    String? appVersion,
  }) {
    return AppConfig(
      environment: environment ?? this.environment,
      minLogLevel: minLogLevel ?? this.minLogLevel,
      masterSeed: masterSeed ?? this.masterSeed,
      featureFlags: featureFlags ?? this.featureFlags,
      debug: debug ?? this.debug,
      appName: appName ?? this.appName,
      appVersion: appVersion ?? this.appVersion,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is AppConfig &&
          environment == other.environment &&
          minLogLevel == other.minLogLevel &&
          masterSeed == other.masterSeed &&
          featureFlags == other.featureFlags &&
          debug == other.debug &&
          appName == other.appName &&
          appVersion == other.appVersion;

  @override
  int get hashCode => Object.hash(
    environment,
    minLogLevel,
    masterSeed,
    featureFlags,
    debug,
    appName,
    appVersion,
  );

  @override
  String toString() =>
      'AppConfig(env: ${environment.label}, log: $minLogLevel, seed: $masterSeed)';
}
