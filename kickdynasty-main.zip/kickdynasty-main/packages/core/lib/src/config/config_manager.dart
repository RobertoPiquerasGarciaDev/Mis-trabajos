import 'dart:async';

import 'package:kickdynasty_core/src/config/app_config.dart';

/// Gestor de configuración global con notificación de cambios.
///
/// **Contrato M0:** en producción la configuración se fija al arrancar
/// ([CoreModule]). [replace] y [update] existen para tests; los providers
/// Riverpod no se re-evalúan automáticamente tras un cambio — usar
/// [CoreModule.config] para lectura directa o reconstruir el módulo.
final class ConfigManager {
  /// Crea el gestor con [initial] como configuración activa.
  ConfigManager(this._current);

  AppConfig _current;
  final _changes = StreamController<AppConfig>.broadcast(sync: true);

  /// Configuración activa.
  AppConfig get current => _current;

  /// Emite cada vez que [replace] o [update] cambian la configuración.
  Stream<AppConfig> get changes => _changes.stream;

  /// Sustituye la configuración completa.
  void replace(AppConfig config) {
    _current = config;
    if (!_changes.isClosed) {
      _changes.add(_current);
    }
  }

  /// Aplica [transform] sobre la configuración actual.
  void update(AppConfig Function(AppConfig current) transform) {
    replace(transform(_current));
  }

  /// Libera el stream de cambios.
  void dispose() {
    _changes.close();
  }
}
