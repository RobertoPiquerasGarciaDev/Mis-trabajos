/// Entorno de ejecución de la aplicación.
enum Environment {
  /// Desarrollo local con logging verboso y debug habilitado.
  development,

  /// Preproducción: logging moderado, flags de staging.
  staging,

  /// Producción: logging mínimo, debug desactivado.
  production,

  /// Tests automatizados: reloj y semillas controlables.
  test;

  /// `true` en [development] o [test].
  bool get isNonProduction =>
      this == Environment.development || this == Environment.test;

  /// Nombre corto para logs y telemetría.
  String get label => name;
}
