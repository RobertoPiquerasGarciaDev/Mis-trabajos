import 'package:meta/meta.dart';

/// Opciones de depuración de infraestructura.
@immutable
final class DebugOptions {
  /// Crea las opciones.
  const DebugOptions({
    required this.enabled,
    this.captureTraces = false,
    this.logPublishEvents = false,
    this.maxTraceEntries = 256,
  }) : assert(maxTraceEntries > 0);

  /// Desactivado (producción).
  static const disabled = DebugOptions(enabled: false);

  /// Desarrollo: trazas + log de eventos.
  static const development = DebugOptions(
    enabled: true,
    captureTraces: true,
    logPublishEvents: true,
  );

  /// Tests: trazas sin ruido de eventos.
  static const testing = DebugOptions(enabled: true, captureTraces: true);

  /// Si el modo debug está activo.
  final bool enabled;

  /// Si [DebugTrace] debe registrar spans.
  final bool captureTraces;

  /// Si el event bus debe loguear cada publicación (vía logger externo).
  final bool logPublishEvents;

  /// Límite de entradas en el buffer de trazas.
  final int maxTraceEntries;
}
