import 'package:kickdynasty_core/src/debug/debug_options.dart';
import 'package:kickdynasty_core/src/debug/debug_trace.dart';
import 'package:kickdynasty_core/src/events/app_event.dart';
import 'package:kickdynasty_core/src/events/event_bus.dart';
import 'package:kickdynasty_core/src/logging/logger.dart';

/// Sesión de depuración con trazas y publicación opcional en el bus.
final class DebugSession {
  /// Crea la sesión.
  DebugSession({
    required this.options,
    required this.trace,
    required Logger logger,
    EventBus? eventBus,
  }) : _logger = logger.child('debug'),
       _eventBus = eventBus;

  /// Opciones activas.
  final DebugOptions options;

  /// Trazas acumuladas.
  final DebugTrace trace;

  final Logger _logger;
  final EventBus? _eventBus;

  /// `true` si debug está habilitado.
  bool get enabled => options.enabled;

  /// Registra [message] en log y traza.
  void log(String message, {Map<String, Object?> context = const {}}) {
    if (!enabled) return;
    _logger.debug(message, context: context);
    trace.mark(message, metadata: context);
    _eventBus?.publish(DebugTraceEvent(span: 'debug', message: message));
  }

  /// Ejecuta [action] dentro de un span [name].
  T span<T>(String name, T Function() action) {
    if (!enabled) return action();
    trace.begin(name);
    try {
      return action();
    } finally {
      trace.end(name);
    }
  }

  /// Ejecuta [action] async dentro de un span [name].
  Future<T> spanAsync<T>(String name, Future<T> Function() action) async {
    if (!enabled) return action();
    trace.begin(name);
    try {
      return await action();
    } finally {
      trace.end(name);
    }
  }
}
