import 'package:kickdynasty_core/src/debug/debug_options.dart';
import 'package:kickdynasty_core/src/time/clock.dart';
import 'package:meta/meta.dart';

/// Span de traza de depuración.
@immutable
final class DebugSpan {
  /// Crea el span.
  const DebugSpan({
    required this.name,
    required this.startedAt,
    this.endedAt,
    this.metadata = const {},
  });

  /// Nombre del span.
  final String name;

  /// Inicio (UTC).
  final DateTime startedAt;

  /// Fin (UTC), null si aún abierto.
  final DateTime? endedAt;

  /// Metadatos opcionales.
  final Map<String, Object?> metadata;

  /// Duración si el span está cerrado.
  Duration? get duration =>
      endedAt == null ? null : endedAt!.difference(startedAt);

  /// Devuelve una copia del span con [endedAt] fijado.
  DebugSpan close(DateTime endedAt) => DebugSpan(
    name: name,
    startedAt: startedAt,
    endedAt: endedAt,
    metadata: metadata,
  );
}

/// Buffer circular de spans para diagnóstico.
final class DebugTrace {
  /// Crea la traza con [options] y [clock] inyectado (nunca `DateTime.now()`).
  DebugTrace(this.options, {required Clock clock}) : _clock = clock;

  /// Opciones activas.
  final DebugOptions options;

  final Clock _clock;
  final _spans = <DebugSpan>[];
  final _open = <String, DebugSpan>{};

  /// Spans cerrados (solo lectura).
  List<DebugSpan> get spans => List.unmodifiable(_spans);

  /// Abre un span con [name].
  void begin(String name, {Map<String, Object?> metadata = const {}}) {
    if (!options.captureTraces) return;
    _open[name] = DebugSpan(
      name: name,
      startedAt: _clock.now(),
      metadata: metadata,
    );
  }

  /// Cierra el span [name].
  void end(String name, {DateTime? at}) {
    if (!options.captureTraces) return;
    final open = _open.remove(name);
    if (open == null) return;
    _spans.add(open.close(at ?? _clock.now()));
    _trim();
  }

  /// Registra un mensaje puntual (span instantáneo).
  void mark(String name, {Map<String, Object?> metadata = const {}}) {
    if (!options.captureTraces) return;
    final now = _clock.now();
    _spans.add(
      DebugSpan(name: name, startedAt: now, endedAt: now, metadata: metadata),
    );
    _trim();
  }

  /// Vacía el historial.
  void clear() {
    _spans.clear();
    _open.clear();
  }

  void _trim() {
    while (_spans.length > options.maxTraceEntries) {
      _spans.removeAt(0);
    }
  }
}
