import 'package:kickdynasty_core/src/seed/derived_seed.dart';
import 'package:meta/meta.dart';

/// Gestor de semillas de sesión y flujos derivados.
///
/// Centraliza la política de derivación usada por el motor (ADR 0002) sin
/// acoplar `core` a `engine` en tiempo de compilación de producción.
@immutable
final class SeedManager {
  /// Crea el gestor con [masterSeed] como raíz.
  const SeedManager({required this.masterSeed}) : assert(masterSeed >= 0);

  /// Semilla raíz de la sesión.
  final int masterSeed;

  /// Deriva semilla para un flujo numérico (club, jornada, subsistema…).
  int derived(int stream) => derivedSeed(masterSeed, stream);

  /// Deriva semilla estable a partir de un identificador textual (p. ej. saveId).
  int derivedFromKey(String key, {int salt = 0}) {
    final hash = _fnv1a(key);
    return derivedSeed(masterSeed, hash ^ salt);
  }

  /// Crea un gestor hijo con nueva semilla maestra (nueva partida).
  SeedManager fork(int newMasterSeed) => SeedManager(masterSeed: newMasterSeed);

  /// Combina [masterSeed] con [campaignSeed] para una partida concreta.
  SeedManager forCampaign(int campaignSeed) =>
      SeedManager(masterSeed: derivedSeed(masterSeed, campaignSeed));

  static int _fnv1a(String input) {
    const fnvPrime = 0x01000193;
    const fnvOffset = 0x811C9DC5;
    var hash = fnvOffset;
    for (final unit in input.codeUnits) {
      hash ^= unit;
      hash = (hash * fnvPrime) & 0xFFFFFFFF;
    }
    return hash;
  }
}
