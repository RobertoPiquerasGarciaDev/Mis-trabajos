/// Derivación de semillas compatible con el motor (`engine` `derivedSeed`).
///
/// Duplicado intencionalmente para que `core` no dependa de `engine` en
/// compilación de producción. **Contrato:** debe mantener paridad byte a byte;
/// ver `packages/core/test/seed_test.dart` y `packages/engine/.../xoshiro.dart`.
library;

/// Mezcla SplitMix64 (idéntica a `packages/engine/.../xoshiro.dart`).
int splitMix64(int x) {
  var z = x + 0x9E3779B97F4A7C15;
  z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9;
  z = (z ^ (z >>> 27)) * 0x94D049BB133111EB;
  return z ^ (z >>> 31);
}

/// Deriva una semilla independiente para el flujo [stream] a partir de [seed].
int derivedSeed(int seed, int stream) =>
    splitMix64(splitMix64(seed) ^ splitMix64(stream));
