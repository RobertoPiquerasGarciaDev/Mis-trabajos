/// Abstracción de tiempo de pared (ADR 0002: el motor no la usa).
abstract interface class Clock {
  /// Instante actual.
  DateTime now();
}

/// Duración transcurrida desde un punto del [Clock].
extension ClockTiming on Clock {
  /// Mide la duración de [action] usando este reloj.
  Duration measure(void Function() action) {
    final start = now();
    action();
    return now().difference(start);
  }
}
