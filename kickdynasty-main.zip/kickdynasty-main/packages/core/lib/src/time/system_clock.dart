import 'package:kickdynasty_core/src/time/clock.dart';

/// Reloj de sistema (producción).
final class SystemClock implements Clock {
  /// Singleton de producción.
  const SystemClock();

  @override
  DateTime now() => DateTime.now().toUtc();
}
