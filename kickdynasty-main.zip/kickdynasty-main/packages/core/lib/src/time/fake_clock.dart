import 'package:kickdynasty_core/src/time/clock.dart';

/// Reloj controlado para tests y depuración determinista.
final class FakeClock implements Clock {
  /// Crea el reloj en [initialTime] (UTC por defecto).
  FakeClock([DateTime? initialTime])
    : _now = (initialTime ?? DateTime.utc(2026)).toUtc();

  DateTime _now;

  @override
  DateTime now() => _now;

  /// Fija el instante actual.
  void set(DateTime time) {
    _now = time.toUtc();
  }

  /// Avanza [duration].
  void advance(Duration duration) {
    _now = _now.add(duration);
  }

  /// Avanza un tick de [milliseconds].
  void tick([int milliseconds = 1]) {
    advance(Duration(milliseconds: milliseconds));
  }
}
