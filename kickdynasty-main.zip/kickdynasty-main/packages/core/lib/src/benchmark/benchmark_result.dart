import 'package:kickdynasty_core/src/utils/timing.dart';
import 'package:meta/meta.dart';

/// Resultado de una ejecución de benchmark.
@immutable
final class BenchmarkResult {
  /// Crea el resultado.
  const BenchmarkResult({
    required this.name,
    required this.iterations,
    required this.warmup,
    required this.mean,
    required this.median,
    required this.min,
    required this.max,
    required this.samples,
  });

  /// Nombre del benchmark.
  final String name;

  /// Iteraciones medidas (sin warmup).
  final int iterations;

  /// Iteraciones de calentamiento descartadas.
  final int warmup;

  /// Media de duración.
  final Duration mean;

  /// Mediana de duración.
  final Duration median;

  /// Mínimo observado.
  final Duration min;

  /// Máximo observado.
  final Duration max;

  /// Muestras individuales.
  final List<Duration> samples;

  @override
  String toString() =>
      '$name: median=${formatDuration(median)} mean=${formatDuration(mean)} '
      'min=${formatDuration(min)} max=${formatDuration(max)} '
      '(n=$iterations warmup=$warmup)';

  /// Informe multilínea para logs.
  String toReport() {
    final buffer = StringBuffer()
      ..writeln('Benchmark: $name')
      ..writeln('  iterations: $iterations (warmup: $warmup)')
      ..writeln('  median: ${formatDuration(median)}')
      ..writeln('  mean:   ${formatDuration(mean)}')
      ..writeln('  min:    ${formatDuration(min)}')
      ..writeln('  max:    ${formatDuration(max)}');
    return buffer.toString();
  }
}
