import 'dart:async';

import 'package:kickdynasty_core/src/benchmark/benchmark_result.dart';
import 'package:kickdynasty_core/src/benchmark/benchmark_runner.dart';
import 'package:kickdynasty_core/src/config/app_config.dart';
import 'package:kickdynasty_core/src/config/config_manager.dart';
import 'package:kickdynasty_core/src/events/app_event.dart';
import 'package:kickdynasty_core/src/events/event_bus.dart';
import 'package:kickdynasty_core/src/seed/derived_seed.dart';
import 'package:kickdynasty_core/src/time/fake_clock.dart';

/// Benchmark síncrono registrable.
typedef SyncBenchmark = void Function();

/// Benchmark asíncrono registrable.
typedef AsyncBenchmark = Future<void> Function();

/// Suite de benchmarks base del Módulo 0.
final class BenchmarkSuite {
  /// Crea la suite con [runner] opcional.
  BenchmarkSuite({BenchmarkRunner? runner})
    : _runner = runner ?? BenchmarkRunner();

  final BenchmarkRunner _runner;
  final _sync = <String, SyncBenchmark>{};
  final _async = <String, AsyncBenchmark>{};

  /// Registra benchmark síncrono [fn] con [name].
  void addSync(String name, SyncBenchmark fn) {
    _sync[name] = fn;
  }

  /// Registra benchmark async [fn] con [name].
  void addAsync(String name, AsyncBenchmark fn) {
    _async[name] = fn;
  }

  /// Nombres registrados.
  Iterable<String> get names => {..._sync.keys, ..._async.keys};

  /// Ejecuta todos los benchmarks registrados.
  Future<List<BenchmarkResult>> runAll({
    int warmup = 1,
    int iterations = 5,
  }) async {
    final results = <BenchmarkResult>[];
    for (final entry in _sync.entries) {
      results.add(
        _runner.measureSync(
          entry.key,
          entry.value,
          warmup: warmup,
          iterations: iterations,
        ),
      );
    }
    for (final entry in _async.entries) {
      results.add(
        await _runner.measure(
          entry.key,
          entry.value,
          warmup: warmup,
          iterations: iterations,
        ),
      );
    }
    return results;
  }
}

/// Registra los benchmarks base de infraestructura en [suite].
void registerBaselineBenchmarks(BenchmarkSuite suite) {
  suite.addSync('derived_seed_10k', () {
    var acc = 0;
    for (var i = 0; i < 10000; i++) {
      acc ^= derivedSeed(42, i);
    }
    if (acc == 0) {
      throw StateError('benchmark guard');
    }
  });

  suite.addSync('event_bus_publish_1k', () {
    final bus = EventBus(clock: FakeClock());
    bus.subscribe<DebugTraceEvent>((_) {});
    for (var i = 0; i < 1000; i++) {
      bus.publish(const DebugTraceEvent(span: 'bench', message: 'ping'));
    }
    bus.dispose();
  });

  suite.addSync('config_replace_1k', () {
    final manager = ConfigManager(AppConfig.testing());
    for (var i = 0; i < 1000; i++) {
      manager.replace(manager.current.copyWith(masterSeed: i));
    }
    manager.dispose();
  });
}
