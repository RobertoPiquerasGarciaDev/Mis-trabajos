import 'dart:async';

import 'package:kickdynasty_core/src/benchmark/benchmark_result.dart';
import 'package:kickdynasty_core/src/time/clock.dart';
import 'package:kickdynasty_core/src/utils/timing.dart';

/// Ejecutor de benchmarks de infraestructura (Módulo 0).
final class BenchmarkRunner {
  /// Crea el runner con [clock] para mediciones de pared.
  BenchmarkRunner({Clock? clock}) : _clock = clock ?? _StopwatchClock();

  final Clock _clock;

  /// Mide [fn] de forma síncrona.
  BenchmarkResult measureSync(
    String name,
    void Function() fn, {
    int warmup = 1,
    int iterations = 5,
  }) {
    _assertPositive(warmup, 'warmup');
    _assertPositive(iterations, 'iterations');

    for (var i = 0; i < warmup; i++) {
      fn();
    }

    final samples = <Duration>[];
    for (var i = 0; i < iterations; i++) {
      final start = _clock.now();
      fn();
      samples.add(_clock.now().difference(start));
    }

    return _result(name, warmup, iterations, samples);
  }

  /// Mide [fn] de forma asíncrona.
  Future<BenchmarkResult> measure(
    String name,
    FutureOr<void> Function() fn, {
    int warmup = 1,
    int iterations = 5,
  }) async {
    _assertPositive(warmup, 'warmup');
    _assertPositive(iterations, 'iterations');

    for (var i = 0; i < warmup; i++) {
      await fn();
    }

    final samples = <Duration>[];
    for (var i = 0; i < iterations; i++) {
      final start = _clock.now();
      await fn();
      samples.add(_clock.now().difference(start));
    }

    return _result(name, warmup, iterations, samples);
  }

  BenchmarkResult _result(
    String name,
    int warmup,
    int iterations,
    List<Duration> samples,
  ) {
    final sorted = [...samples]..sort((a, b) => a.compareTo(b));
    return BenchmarkResult(
      name: name,
      iterations: iterations,
      warmup: warmup,
      mean: meanDuration(samples),
      median: medianDuration(samples),
      min: sorted.first,
      max: sorted.last,
      samples: samples,
    );
  }

  void _assertPositive(int value, String label) {
    if (value <= 0) {
      throw ArgumentError.value(value, label, 'debe ser > 0');
    }
  }
}

/// Reloj basado en [Stopwatch] para mediciones de alta resolución.
final class _StopwatchClock implements Clock {
  final _stopwatch = Stopwatch()..start();
  final _origin = DateTime.utc(2026);

  @override
  DateTime now() => _origin.add(_stopwatch.elapsed);
}
