@Tags(['people-first'])
import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('PeopleFirstFeatureFlags', () {
    test('desactivadas por defecto en producción', () {
      const flags = FeatureFlags.production;
      for (final flag in PeopleFirstFeatureFlags.all) {
        expect(flags.isEnabled(flag), isFalse);
      }
    });

    test('withFlag activa banderas individualmente', () {
      var flags = FeatureFlags.empty;
      flags = flags.withFlag(PeopleFirstFeatureFlags.enabled, enabled: true);
      expect(flags.isEnabled(PeopleFirstFeatureFlags.enabled), isTrue);
      expect(flags.isEnabled(PeopleFirstFeatureFlags.shadowMode), isFalse);
    });
  });
}
