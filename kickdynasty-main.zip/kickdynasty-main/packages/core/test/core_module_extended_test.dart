import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('CoreModule factories', () {
    test('development crea logger en consola', () {
      final module = CoreModule.development();
      addTearDown(module.dispose);
      expect(module.config.environment, Environment.development);
      expect(
        module.featureFlags.isEnabled(CoreFeatureFlags.verboseLogging),
        isTrue,
      );
    });

    test('production sin memory sink', () {
      final module = CoreModule.production();
      addTearDown(module.dispose);
      expect(module.config.environment, Environment.production);
      expect(module.memorySink, isNull);
    });
  });

  group('AppConfig factories', () {
    test('production usa warning como nivel mínimo', () {
      final config = AppConfig.production();
      expect(config.minLogLevel, LogLevel.warning);
    });

    test('testing usa entorno test', () {
      final config = AppConfig.testing();
      expect(config.environment, Environment.test);
    });
  });

  group('Log sinks', () {
    test('FilteredLogSink respeta nivel', () {
      final inner = MemoryLogSink();
      final sink = FilteredLogSink(inner: inner, minLevel: LogLevel.warning);
      sink.write(
        LogRecord(
          timestamp: DateTime.utc(2026),
          level: LogLevel.info,
          loggerName: 't',
          message: 'skip',
        ),
      );
      sink.write(
        LogRecord(
          timestamp: DateTime.utc(2026),
          level: LogLevel.error,
          loggerName: 't',
          message: 'keep',
        ),
      );
      expect(inner.records, hasLength(1));
      sink.dispose();
    });

    test('ConsoleLogSink custom formatter', () {
      final sink = ConsoleLogSink(formatter: (r) => 'X:${r.message}');
      expect(
        () => sink.write(
          LogRecord(
            timestamp: DateTime.utc(2026),
            level: LogLevel.info,
            loggerName: 't',
            message: 'hi',
          ),
        ),
        returnsNormally,
      );
      sink.dispose();
    });
  });

  group('EventBus stream API', () {
    test('on emite eventos', () async {
      final bus = EventBus(clock: FakeClock());
      addTearDown(bus.dispose);
      final events = <DebugTraceEvent>[];
      final sub = bus.on<DebugTraceEvent>().listen(events.add);
      bus.publish(const DebugTraceEvent(span: 'a', message: 'b'));
      await Future<void>.delayed(Duration.zero);
      expect(events, hasLength(1));
      await sub.cancel();
    });
  });

  group('DebugTrace', () {
    test('mark y clear', () {
      final trace = DebugTrace(
        DebugOptions.testing,
        clock: FakeClock(DateTime.utc(2026)),
      );
      trace.mark('x');
      expect(trace.spans, hasLength(1));
      trace.clear();
      expect(trace.spans, isEmpty);
    });
  });

  group('disposable using', () {
    test('libera recurso tras action', () {
      var disposed = false;
      final resource = _TestDisposable(() => disposed = true);
      final result = using(resource, (r) => r.value);
      expect(result, 7);
      expect(disposed, isTrue);
    });
  });

  group('NoOpLogger', () {
    test('no lanza al loguear', () {
      final log = NoOpLogger();
      expect(() => log.info('silent'), returnsNormally);
    });
  });
}

final class _TestDisposable implements Disposable {
  _TestDisposable(this._onDispose);

  final void Function() _onDispose;
  int get value => 7;

  @override
  void dispose() => _onDispose();
}
