import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:riverpod/riverpod.dart';
import 'package:test/test.dart';

void main() {
  group('core providers', () {
    test('overrides exponen servicios del módulo', () {
      final module = CoreModule.testing();
      addTearDown(module.dispose);

      final container = ProviderContainer(
        overrides: coreModuleOverrides(module),
      );
      addTearDown(container.dispose);

      expect(container.read(clockProvider), same(module.clock));
      expect(container.read(loggerProvider), same(module.logger));
      expect(
        container.read(seedManagerProvider).masterSeed,
        module.config.masterSeed,
      );
      expect(container.read(featureFlagsProvider), same(module.featureFlags));
    });
  });
}
