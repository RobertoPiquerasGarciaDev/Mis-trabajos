import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('AppConfig equality', () {
    test('== hashCode y toString', () {
      final a = AppConfig.testing(masterSeed: 1);
      final b = AppConfig.testing(masterSeed: 1);
      final c = AppConfig.testing(masterSeed: 2);
      expect(a, equals(b));
      expect(a.hashCode, b.hashCode);
      expect(a, isNot(c));
      expect(a.toString(), contains('test'));
    });
  });

  group('ConfigManager update', () {
    test('transforma configuración', () {
      final manager = ConfigManager(AppConfig.testing());
      manager.update((c) => c.copyWith(appName: 'KD'));
      expect(manager.current.appName, 'KD');
      manager.dispose();
    });
  });

  group('Logger levels', () {
    test('trace warning fatal', () {
      final sink = MemoryLogSink();
      final logger = Logger(
        name: 't',
        clock: FakeClock(),
        minLevel: LogLevel.trace,
        sinks: [sink],
      );
      logger.trace('t');
      logger.warning('w');
      logger.fatal('f', error: StateError('x'));
      expect(sink.records.length, 3);
    });
  });

  group('LogRecord formatting', () {
    test('toString con contexto y error', () {
      final record = LogRecord(
        timestamp: DateTime.utc(2026, 7, 5),
        level: LogLevel.error,
        loggerName: 'x',
        message: 'fail',
        context: {'k': 'v'},
        error: StateError('boom'),
      );
      expect(record.toString(), contains('fail'));
      expect(record.toString(), contains('boom'));
    });
  });

  group('Clock measure', () {
    test('mide duración', () {
      final clock = FakeClock();
      final duration = clock.measure(
        () => clock.advance(const Duration(seconds: 1)),
      );
      expect(duration.inSeconds, 1);
    });
  });

  group('Environment staging', () {
    test('no es nonProduction', () {
      expect(Environment.staging.isNonProduction, isFalse);
      expect(Environment.staging.label, 'staging');
    });
  });

  group('FeatureFlags extended', () {
    test('isEnabledKey y asMap', () {
      final flags = FeatureFlags.development;
      expect(flags.isEnabledKey('verbose_logging'), isTrue);
      expect(flags.asMap, isNotEmpty);
      expect(flags, equals(FeatureFlags.development));
    });
  });

  group('DebugSession async span', () {
    test('spanAsync', () async {
      final module = CoreModule.testing();
      addTearDown(module.dispose);
      final value = await module.debugSession.spanAsync(
        'async',
        () async => 99,
      );
      expect(value, 99);
    });
  });

  group('DebugTrace begin end', () {
    test('begin y end registran span', () {
      final clock = FakeClock(DateTime.utc(2026, 7, 5));
      final trace = DebugTrace(DebugOptions.testing, clock: clock);
      trace.begin('job');
      trace.end('job', at: DateTime.utc(2026, 7, 5, 1));
      expect(trace.spans.single.duration, isNotNull);
    });
  });

  group('SeedManager fork', () {
    test('fork crea nueva raíz', () {
      const manager = SeedManager(masterSeed: 5);
      final forked = manager.fork(9);
      expect(forked.masterSeed, 9);
    });
  });

  group('BenchmarkResult report', () {
    test('toReport incluye estadísticas', () {
      const result = BenchmarkResult(
        name: 'bench',
        iterations: 3,
        warmup: 1,
        mean: Duration(milliseconds: 2),
        median: Duration(milliseconds: 2),
        min: Duration(milliseconds: 1),
        max: Duration(milliseconds: 3),
        samples: [Duration(milliseconds: 2)],
      );
      expect(result.toReport(), contains('bench'));
      expect(result.toString(), contains('median'));
    });
  });

  group('BenchmarkSuite async', () {
    test('addAsync ejecuta', () async {
      final suite = BenchmarkSuite();
      suite.addAsync('async_noop', () async {});
      final results = await suite.runAll(iterations: 2);
      expect(results.single.name, 'async_noop');
    });
  });

  group('BenchmarkRunner validation', () {
    test('rechaza iterations inválidas', () {
      final runner = BenchmarkRunner();
      expect(
        () => runner.measureSync('x', () {}, iterations: 0),
        throwsArgumentError,
      );
    });
  });

  group('nanosToMillis', () {
    test('convierte', () {
      expect(nanosToMillis(1000000), closeTo(1, 0.001));
    });
  });

  group('meanDuration empty', () {
    test('lanza si vacío', () {
      expect(() => meanDuration([]), throwsArgumentError);
    });
  });
}
