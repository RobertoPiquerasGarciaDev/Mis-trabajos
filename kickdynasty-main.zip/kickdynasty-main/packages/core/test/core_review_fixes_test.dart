import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('DebugTrace clock injection', () {
    test('begin/end usan FakeClock, no wall clock', () {
      final clock = FakeClock(DateTime.utc(2026, 1, 1));
      final trace = DebugTrace(DebugOptions.testing, clock: clock);
      trace.begin('job');
      clock.advance(const Duration(hours: 2));
      trace.end('job');
      expect(trace.spans.single.startedAt, DateTime.utc(2026, 1, 1));
      expect(trace.spans.single.endedAt, DateTime.utc(2026, 1, 1, 2));
    });
  });

  group('ConfigManager contract', () {
    test('CoreModule.config refleja replace', () {
      final module = CoreModule.testing();
      addTearDown(module.dispose);
      module.configManager.replace(module.config.copyWith(appName: 'KD'));
      expect(module.config.appName, 'KD');
    });
  });

  group('EventBus lifecycle', () {
    test('dispose cierra stream de on() sin eventos pendientes', () async {
      final bus = EventBus(clock: FakeClock());
      final stream = bus.on<DebugTraceEvent>();
      bus.dispose();
      await expectLater(stream.toList(), completion(isEmpty));
    });
  });

  group('Logger production path', () {
    test('sin sinks no construye registros', () {
      final logger = Logger(
        name: 'silent',
        clock: FakeClock(),
        minLevel: LogLevel.trace,
        sinks: const [],
      );
      expect(() => logger.info('noop'), returnsNormally);
    });
  });
}
