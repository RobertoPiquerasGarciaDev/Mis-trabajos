import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('DebugSession', () {
    test('span registra traza cuando debug habilitado', () {
      final module = CoreModule.testing();
      addTearDown(module.dispose);

      final result = module.debugSession.span('work', () => 42);
      expect(result, 42);
      expect(module.debugTrace.spans, isNotEmpty);
      expect(module.debugTrace.spans.last.name, 'work');
    });

    test('log publica DebugTraceEvent', () {
      final module = CoreModule.testing();
      addTearDown(module.dispose);

      var received = 0;
      final sub = module.eventBus.subscribe<DebugTraceEvent>((_) => received++);
      module.debugSession.log('ping');
      expect(received, 1);
      sub.dispose();
    });
  });

  group('CoreModule', () {
    test('testing expone memory sink con logs', () {
      final module = CoreModule.testing();
      addTearDown(module.dispose);
      module.logger.info('hello');
      expect(module.memorySink!.records, isNotEmpty);
    });

    test('production no crea memory sink', () {
      final module = CoreModule.production();
      addTearDown(module.dispose);
      expect(module.memorySink, isNull);
    });

    test('CoreInitializedEvent al crear módulo', () {
      final module = CoreModule.testing();
      addTearDown(module.dispose);
      var init = 0;
      final sub = module.eventBus.subscribe<CoreInitializedEvent>(
        (_) => init++,
      );
      // Segundo publish manual para verificar suscripción post-creación
      module.eventBus.publish(const CoreInitializedEvent(environment: 'test'));
      expect(init, 1);
      sub.dispose();
    });
  });
}
