import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('EventBus', () {
    late FakeClock clock;
    late EventBus bus;

    setUp(() {
      clock = FakeClock();
      bus = EventBus(clock: clock);
    });

    tearDown(() => bus.dispose());

    test('subscribe recibe eventos tipados', () {
      var count = 0;
      bus.subscribe<CoreInitializedEvent>((_) => count++);
      bus.publish(const CoreInitializedEvent(environment: 'test'));
      expect(count, 1);
    });

    test('strictMode propaga errores', () {
      final strict = EventBus(clock: clock, strictMode: true);
      strict.subscribe<DebugTraceEvent>((_) => throw StateError('boom'));
      expect(
        () => strict.publish(const DebugTraceEvent(span: 'x', message: 'y')),
        throwsStateError,
      );
      strict.dispose();
    });

    test('modo no estricto captura errores', () {
      bus.subscribe<DebugTraceEvent>((_) => throw StateError('boom'));
      expect(
        () => bus.publish(const DebugTraceEvent(span: 'x', message: 'y')),
        returnsNormally,
      );
    });
  });

  group('FeatureFlags', () {
    test('require lanza si desactivada', () {
      const flags = FeatureFlags.empty;
      expect(
        () => flags.require(CoreFeatureFlags.benchmarksEnabled),
        throwsStateError,
      );
    });

    test('withFlag activa bandera', () {
      const flags = FeatureFlags.empty;
      final updated = flags.withFlag(
        CoreFeatureFlags.benchmarksEnabled,
        enabled: true,
      );
      expect(updated.isEnabled(CoreFeatureFlags.benchmarksEnabled), isTrue);
    });
  });
}
