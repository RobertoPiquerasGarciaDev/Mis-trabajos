import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('BenchmarkRunner', () {
    test('measureSync produce estadísticas', () {
      final runner = BenchmarkRunner();
      final result = runner.measureSync(
        'noop',
        () {},
        warmup: 1,
        iterations: 3,
      );
      expect(result.name, 'noop');
      expect(result.samples, hasLength(3));
      expect(result.median, isNotNull);
    });

    test('measure async', () async {
      final runner = BenchmarkRunner();
      final result = await runner.measure('delay', () async {}, iterations: 2);
      expect(result.iterations, 2);
    });
  });

  group('BenchmarkSuite baseline', () {
    test('registerBaselineBenchmarks ejecuta sin error', () async {
      final suite = BenchmarkSuite();
      registerBaselineBenchmarks(suite);
      expect(suite.names, contains('derived_seed_10k'));

      final results = await suite.runAll(warmup: 1, iterations: 3);
      expect(results, hasLength(3));
      for (final result in results) {
        expect(result.mean.inMicroseconds, greaterThanOrEqualTo(0));
      }
    });
  });

  group('timing utils', () {
    test('medianDuration', () {
      final median = medianDuration([
        const Duration(milliseconds: 1),
        const Duration(milliseconds: 3),
        const Duration(milliseconds: 2),
      ]);
      expect(median.inMilliseconds, 2);
    });
  });
}
