import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:kickdynasty_engine/kickdynasty_engine.dart' as engine;
import 'package:test/test.dart';

void main() {
  group('derivedSeed', () {
    test('paridad con kickdynasty_engine', () {
      for (final seed in [0, 1, 42, 999999]) {
        for (final stream in [0, 1, 100, 500000]) {
          expect(
            derivedSeed(seed, stream),
            engine.derivedSeed(seed, stream),
            reason: 'seed=$seed stream=$stream',
          );
        }
      }
    });

    test('determinista', () {
      expect(derivedSeed(42, 1), derivedSeed(42, 1));
      expect(derivedSeed(42, 1), isNot(derivedSeed(42, 2)));
    });
  });

  group('SeedManager', () {
    test('derivedFromKey es estable', () {
      const a = SeedManager(masterSeed: 10);
      const b = SeedManager(masterSeed: 10);
      expect(a.derivedFromKey('save-1'), b.derivedFromKey('save-1'));
    });

    test('forCampaign cambia semilla efectiva', () {
      const manager = SeedManager(masterSeed: 1);
      final campaign = manager.forCampaign(99);
      expect(campaign.masterSeed, isNot(1));
      expect(campaign.derived(1), isNot(manager.derived(1)));
    });
  });
}
