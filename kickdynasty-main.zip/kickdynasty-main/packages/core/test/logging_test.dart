import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('Logger', () {
    late MemoryLogSink sink;
    late FakeClock clock;
    late Logger logger;

    setUp(() {
      sink = MemoryLogSink();
      clock = FakeClock(DateTime.utc(2026, 1, 1));
      logger = Logger(
        name: 'test',
        clock: clock,
        minLevel: LogLevel.debug,
        sinks: [sink],
      );
    });

    test('filtra por nivel mínimo', () {
      logger.debug('visible');
      logger.trace('hidden');
      expect(sink.records, hasLength(1));
      expect(sink.records.single.message, 'visible');
    });

    test('child añade contexto', () {
      logger.child('child', context: {'k': 'v'}).info('msg');
      expect(sink.records.single.context['k'], 'v');
      expect(sink.records.single.loggerName, 'test.child');
    });

    test('error captura excepción', () {
      logger.error('fail', error: StateError('x'));
      expect(sink.records.single.error, isA<StateError>());
    });
  });
}
