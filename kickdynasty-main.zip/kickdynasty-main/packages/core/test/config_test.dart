import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('AppConfig', () {
    test('development tiene flags de infraestructura', () {
      final config = AppConfig.development();
      expect(config.environment, Environment.development);
      expect(
        config.featureFlags.isEnabled(CoreFeatureFlags.verboseLogging),
        isTrue,
      );
    });

    test('copyWith sustituye campos', () {
      final base = AppConfig.testing();
      final copy = base.copyWith(masterSeed: 99);
      expect(copy.masterSeed, 99);
      expect(copy.environment, base.environment);
    });
  });

  group('ConfigManager', () {
    test('replace notifica cambios', () {
      final manager = ConfigManager(AppConfig.testing());
      final values = <AppConfig>[];
      manager.changes.listen(values.add);

      manager.replace(AppConfig.testing(masterSeed: 7));
      expect(values, hasLength(1));
      expect(values.single.masterSeed, 7);
      manager.dispose();
    });
  });
}
