import 'package:kickdynasty_core/kickdynasty_core.dart';
import 'package:test/test.dart';

void main() {
  group('FakeClock', () {
    test('advance mueve el tiempo', () {
      final clock = FakeClock(DateTime.utc(2026));
      clock.advance(const Duration(hours: 1));
      expect(clock.now(), DateTime.utc(2026, 1, 1, 1));
    });
  });

  group('SystemClock', () {
    test('now es UTC', () {
      const clock = SystemClock();
      expect(clock.now().isUtc, isTrue);
    });
  });
}
