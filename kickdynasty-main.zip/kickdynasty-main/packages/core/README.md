# kickdynasty_core

Infraestructura transversal de KickDynasty (**Módulo 0**). Sin mecánicas de
juego: prepara el terreno para M1+ (Chronicle, DNA, agentes…).

## Contrato del paquete

- **No gameplay:** no importa `domain`, `engine` ni `persistence`.
- **No pureza de motor:** puede usar Riverpod para DI; no aplica ADR 0002.
- **Producción:** factories `CoreModule.production()` / `development()` /
  `testing()` listas para `ProviderScope`.

## Componentes

| Área | Tipos | Uso |
|------|-------|-----|
| Config | `AppConfig`, `ConfigManager`, `Environment` | Configuración global |
| Logging | `Logger`, `LogLevel`, `LogSink`, `ConsoleLogSink`, `MemoryLogSink` | Logs estructurados |
| Tiempo | `Clock`, `SystemClock`, `FakeClock` | Pared (no usado por el motor) |
| Semillas | `SeedManager`, `derivedSeed` | Sesión y paridad con `engine` |
| Eventos | `EventBus`, `AppEvent` | Bus in-process (≠ Chronicle) |
| Features | `FeatureFlags`, `CoreFeatureFlags` | Banderas de infraestructura |
| Debug | `DebugSession`, `DebugTrace`, `DebugOptions` | Trazas y spans |
| Benchmarks | `BenchmarkRunner`, `BenchmarkSuite` | Mediciones base |
| DI | `CoreModule`, `coreModuleProvider`, `coreModuleOverrides` | Riverpod |

## Arranque (mobile / application)

```dart
final core = CoreModule.development();
runApp(
  ProviderScope(
    overrides: [
      ...coreModuleOverrides(core),
      saveDatabaseProvider.overrideWithValue(database),
    ],
    child: const KickDynastyApp(),
  ),
);
```

## Tests

```bash
cd packages/core
dart test
make coverage   # desde la raíz; umbral 90 %
```

## Benchmarks

```bash
cd packages/core && dart run bin/run_benchmarks.dart
# o desde la raíz:
make benchmark
```

## ADR

Ver [docs/adr/0010-core-infrastructure.md](../../docs/adr/0010-core-infrastructure.md).

## Limitaciones conocidas (M0)

| Tema | Comportamiento | Acción futura |
|------|----------------|---------------|
| **Logs en producción** | Sin `extraSinks`, el logger es silencioso (by design) | Sink de crash/telemetría en integración mobile |
| **`ConfigManager.replace`** | No invalida providers Riverpod | Reconstruir `CoreModule` o usar `config` directo |
| **`derivedSeed` duplicado** | Paridad testeada vs `engine`; riesgo de drift | Mantener test en CI |
| **Event bus** | In-process, single isolate | Suficiente hasta M15 Media |
| **Riverpod en core** | Acopla DI a Riverpod (ADR 0010) | Aceptado para M0 |

## Estado

**Módulo 0 cerrado** (2026-07-05, revisión Staff Engineer).
