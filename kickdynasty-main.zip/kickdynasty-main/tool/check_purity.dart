/// Gate de pureza de capas (ADR 0001, ADR 0002).
///
/// Verifica que los paquetes puros (`domain`, `engine`) no importan nada que
/// rompa su contrato: ni Flutter, ni I/O, ni red, ni paquetes de capas
/// superiores. Se ejecuta en CI (`make purity`) y falla el build
/// ante la primera violación.
///
/// Uso: dart run tool/check_purity.dart
library;

import 'dart:io';

/// Paquetes que deben ser puros y sus dependencias permitidas.
const purePackages = <String, Set<String>>{
  'packages/domain': {
    // Solo utilidades de datos inmutables y colecciones.
    'freezed_annotation',
    'collection',
    'meta',
  },
  'packages/engine': {
    'freezed_annotation',
    'collection',
    'meta',
    // La única dependencia de capa permitida: el dominio.
    'kickdynasty_domain',
  },
  'packages/economy': {'meta'},
  'packages/contracts': {'meta'},
  'packages/market': {'meta', 'kickdynasty_economy', 'kickdynasty_contracts'},
};

/// Imports de SDK prohibidos en paquetes puros (I/O, red, UI).
const forbiddenDartLibs = <String>{
  'dart:io',
  'dart:html',
  'dart:ffi',
  'dart:isolate',
};

/// Prefijos de import prohibidos siempre en paquetes puros.
const forbiddenPrefixes = <String>[
  'package:flutter',
  'package:http',
  'package:dio',
  'package:drift',
  'package:sqlite',
  'package:riverpod',
  'package:flutter_riverpod',
  'package:shared_preferences',
  'package:path_provider',
];

final importPattern = RegExp(
  '''^\\s*(import|export)\\s+['"]([^'"]+)['"]''',
  multiLine: true,
);

void main() {
  final violations = <String>[];

  for (final entry in purePackages.entries) {
    final packagePath = entry.key;
    final allowedPackages = entry.value;
    final libDir = Directory('$packagePath/lib');
    if (!libDir.existsSync()) {
      // El paquete aún no existe: no es una violación, la fase no ha llegado.
      continue;
    }

    final dartFiles = libDir
        .listSync(recursive: true)
        .whereType<File>()
        .where((f) => f.path.endsWith('.dart'))
        // El código generado hereda los imports del fuente; no lo re-chequeamos.
        .where(
          (f) =>
              !f.path.endsWith('.g.dart') && !f.path.endsWith('.freezed.dart'),
        );

    for (final file in dartFiles) {
      final content = file.readAsStringSync();
      for (final match in importPattern.allMatches(content)) {
        final uri = match.group(2)!;

        if (forbiddenDartLibs.contains(uri)) {
          violations.add('${file.path}: import prohibido "$uri" (SDK impuro)');
          continue;
        }

        for (final prefix in forbiddenPrefixes) {
          if (uri.startsWith(prefix)) {
            violations.add('${file.path}: import prohibido "$uri"');
          }
        }

        if (uri.startsWith('package:')) {
          final packageName = uri.substring('package:'.length).split('/').first;
          final selfName = 'kickdynasty_${packagePath.split('/').last}';
          if (packageName != selfName &&
              !allowedPackages.contains(packageName)) {
            violations.add(
              '${file.path}: dependencia no permitida "$packageName" '
              '(permitidas: ${allowedPackages.join(', ')})',
            );
          }
        }
      }
    }
  }

  if (violations.isEmpty) {
    stdout.writeln('✓ Pureza de capas verificada: sin violaciones.');
    exit(0);
  }

  stderr.writeln('✗ Violaciones del contrato de pureza (ADR 0001/0002):\n');
  for (final violation in violations) {
    stderr.writeln('  - $violation');
  }
  exit(1);
}
