# KickDynasty (nombre de trabajo)

Simulador original de gestión futbolística para Android e iOS, desarrollado con Flutter.

Single-player, offline-first, con un motor de simulación determinista escrito en Dart puro.

## Estado

🚧 Fase 0 — Fundación de arquitectura. Ver [docs/architecture.md](docs/architecture.md) y los
[ADRs](docs/adr/) para las decisiones vigentes.

## Estructura del monorepo

```
kickdynasty/
├── apps/
│   └── mobile/            # Aplicación Flutter (UI, navegación, plataforma)
├── packages/
│   ├── domain/            # Entidades, value objects e invariantes del juego
│   ├── engine/            # Motor de simulación determinista (Dart puro)
│   ├── application/       # Casos de uso y orquestación de estado
│   └── persistence/       # Almacenamiento local (Drift/SQLite)
├── docs/
│   ├── architecture.md    # Visión de arquitectura
│   ├── roadmap.md         # Fases y criterios de cierre
│   └── adr/               # Architecture Decision Records
├── tool/check_purity.dart # Gate de pureza de capas (CI)
└── Makefile               # Tareas del monorepo (analyze, test, gates)
```

## Principios innegociables

1. **El motor es Dart puro.** `packages/engine` no importa Flutter, red ni disco. Se
   verifica con lint en CI.
2. **Determinismo.** `(estado, semilla) → resultado` es reproducible siempre. Toda
   aleatoriedad entra por un `Rng` inyectado.
3. **Un solo modelo de dominio.** Las capas se comunican con tipos de `domain`,
   nunca con JSON libre ni mapas sin tipar.
4. **Sin código provisional.** Cada módulo se cierra documentado y testeado antes
   de empezar el siguiente.
5. **Balance como datos.** Las curvas de juego viven en configuración versionada y
   se validan con tests estadísticos en CI.

## Desarrollo

Requisitos: Flutter estable (≥ 3.44) con Dart ≥ 3.12. El monorepo usa
[pub workspaces](https://dart.dev/tools/pub/workspaces) nativos; no hace falta
ninguna herramienta adicional.

```bash
make bootstrap   # resuelve dependencias de todo el workspace
make gen         # genera código (freezed, drift)
make check       # todos los gates de calidad, como en CI
make test        # solo tests unitarios de paquetes puros
```

## Historial de decisiones

| ADR | Decisión |
|-----|----------|
| [0001](docs/adr/0001-monorepo-dart-packages.md) | Monorepo con paquetes Dart separados por capa |
| [0002](docs/adr/0002-deterministic-pure-engine.md) | Motor de simulación determinista y puro |
| [0003](docs/adr/0003-offline-first-sqlite.md) | Offline-first con SQLite (Drift) |
| [0004](docs/adr/0004-riverpod-immutable-state.md) | Estado con Riverpod y entidades inmutables |
| [0005](docs/adr/0005-balance-as-data.md) | Balance del juego como datos versionados |
| [0006](docs/adr/0006-fictional-database.md) | Base de datos de jugadores ficticia y procedural |
