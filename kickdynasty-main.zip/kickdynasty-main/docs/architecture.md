# Arquitectura — KickDynasty

> Documento vivo. Cada cambio estructural exige actualizar este documento y, si
> altera una decisión previa, un ADR nuevo que la sustituya.

## 1. Visión

Simulador de gestión futbolística premium para Android e iOS. Single-player,
offline-first. El valor del producto es la **credibilidad de la simulación**: el
jugador debe sentir que sus decisiones (táctica, mercado, cantera, finanzas)
tienen consecuencias coherentes y explicables.

## 2. Forma del sistema

```
┌──────────────────────────────────────────────────────────┐
│ apps/mobile — Flutter                                    │
│ Pantallas, navegación (go_router), theming, plataforma   │
│ Depende de: application, domain                          │
├──────────────────────────────────────────────────────────┤
│ packages/application — Dart                              │
│ Casos de uso (AdvanceMatchday, MakeTransferOffer…)       │
│ Providers Riverpod, mapeo dominio ↔ vista                │
│ Depende de: domain, engine, persistence                  │
├──────────────────────────────────────────────────────────┤
│ packages/engine — Dart PURO                              │
│ simulateMatch, progresión, finanzas, IA, mercado         │
│ Depende de: domain. Nada más. Verificado por CI.         │
├──────────────────────────────────────────────────────────┤
│ packages/domain — Dart PURO                              │
│ Entidades (Player, Club, Fixture…), value objects,       │
│ invariantes, eventos de dominio                          │
│ Depende de: nada (solo freezed/collection)               │
├──────────────────────────────────────────────────────────┤
│ packages/persistence — Dart                              │
│ Drift (SQLite), repositorios, migraciones, snapshots     │
│ Depende de: domain                                       │
└──────────────────────────────────────────────────────────┘
```

Regla de dependencias: **las flechas solo apuntan hacia abajo**. `engine` jamás
conoce `persistence`; `domain` no conoce a nadie. La violación de esta regla
rompe el build (lint `depend_on_referenced_packages` + import allowlist en CI).

## 3. El motor (`packages/engine`)

### 3.1 Contrato de determinismo

Toda función del motor es de la forma:

```dart
Result f(State state, GameConfig config, Rng rng)
```

- `Rng` es una interfaz inyectada; la implementación de producción es un
  xoshiro256** semiado. Los tests usan semillas fijas.
- Mismo `(state, config, seed)` → mismo resultado, byte a byte. Esto se
  verifica con tests de regresión (golden results).
- Prohibido: `DateTime.now()`, `Random()` sin semilla, I/O, estado global.

### 3.2 Por qué determinista

| Capacidad | Cómo la habilita |
|---|---|
| Replays y "match highlights" | Re-simular con la misma semilla |
| Depurar bugs de usuarios | El save + semilla reproducen el fallo exacto |
| Tests de balance estadístico | 10.000 simulaciones reproducibles en CI |
| Multijugador futuro (lockstep) | Los clientes convergen sin servidor autoritativo |

### 3.3 Simulación de partido

Modelo de fases (no minuto-a-minuto uniforme): el partido se divide en
posesiones; cada posesión resuelve una cadena `construcción → ocasión →
definición` donde cada eslabón depende de atributos agregados de las unidades
implicadas (defensa rival vs mediocampo propio, etc.), moduladas por táctica,
forma, moral, fatiga y contexto (marcador, minuto, expulsiones).

Los eventos siempre referencian **jugadores reales del estado** (goleador,
asistente, amonestado, lesionado). No existen pools de nombres decorativos:
la lección número uno del proyecto anterior.

### 3.4 Balance como datos

`GameConfig` agrupa todas las constantes de balance (curvas de progresión por
edad, economía, probabilidades base). Vive en `packages/engine/lib/src/config/`
como datos versionados. La suite `balance_test` valida propiedades
estadísticas, p. ej.:

- El equipo con +15 de rating medio gana ≥ 70 % y ≤ 90 % de 10.000 partidos.
- La media de goles por partido queda en 2,4–3,0.
- Ningún club IA quiebra en 5 temporadas simuladas con decisiones por defecto.

Un cambio de balance que rompa una propiedad falla el CI.

## 4. Dominio (`packages/domain`)

Entidades inmutables con `freezed`. Las invariantes viven en constructores y
métodos de dominio, no en validaciones dispersas:

- Un `Transfer` no puede construirse si el comprador no tiene fondos: la
  operación devuelve `Either<TransferFailure, Transfer>`.
- Un `MatchLineup` exige exactamente 11 titulares con un portero.
- `Money`, `Rating`, `Age`, `Fitness` son value objects con rangos validados,
  no `int` sueltos.

Un solo vocabulario: los nombres de campos tácticos, posiciones y atributos se
definen aquí una vez y se usan en todas las capas. (Lección dos del proyecto
anterior: el desajuste `playStyle`/`style` que silenciaba las tácticas.)

## 5. Persistencia (`packages/persistence`)

- **Drift sobre SQLite**: relacional, migraciones tipadas, consultas
  verificadas en compilación.
- La partida se guarda como estado normalizado (tablas), no como blob JSON,
  para permitir consultas (historiales, estadísticas de temporada) sin cargar
  todo en memoria.
- Snapshots automáticos por jornada con retención limitada → deshacer/replay.
- Los repositorios exponen interfaces definidas en `application`; `persistence`
  las implementa. La UI nunca ve SQL.

## 6. Aplicación y UI

- **Riverpod** para inyección y estado observable. Cada caso de uso es una
  clase con un solo método público, testeable sin UI.
- La UI es función del estado: pantallas declarativas sin lógica de juego.
- **go_router** con rutas declarativas → deep links y restauración de estado
  de navegación gratis.
- Sin datos mock en producción: el "modo demo" (si se necesita para tiendas o
  tests) es una implementación alternativa de los repositorios con una partida
  pregenerada, detrás de la misma interfaz.

## 7. Contenido: base de datos ficticia

Jugadores, clubes y ligas generados proceduralmente (nombres por locale,
distribución de atributos por posición/edad, curvas de potencial). Sin nombres
reales — riesgo legal fuera desde el diseño. La generación es parte del motor
(determinista, semiada por partida), lo que además da rejugabilidad.

## 8. Calidad y CI

| Gate | Herramienta | Umbral |
|---|---|---|
| Análisis estático | `very_good_analysis` estricto | 0 warnings |
| Pureza del engine | script de allowlist de imports | sin excepciones |
| Tests unitarios | `make test` | engine/domain ≥ 90 % cobertura |
| Balance estadístico | `balance_test` (tagged) | propiedades definidas |
| Golden tests UI | `flutter_test` goldens | pantallas clave |
| Formato | `dart format --set-exit-if-changed` | limpio |

Ninguna feature se mergea sin pasar los gates. Ningún módulo se considera
terminado sin README de paquete + tests + entrada en CHANGELOG.

## 9. Hoja de ruta de construcción (orden por dependencia y riesgo)

| Fase | Entregable | Criterio de cierre |
|---|---|---|
| 0 | Fundación: monorepo, CI, lint, docs | `make bootstrap` + gates verdes |
| 1 | `domain`: entidades y invariantes núcleo | 100 % invariantes testeadas |
| 2 | `engine`: generación procedural de mundo | Mundo de 2 ligas × 20 clubes reproducible |
| 3 | `engine`: simulación de partido | Balance tests estadísticos verdes |
| 4 | `engine`: temporada (calendario round-robin, clasificación, progresión) | Temporada completa simulada en test |
| 5 | `persistence`: guardado/carga/migraciones | Roundtrip de partida sin pérdida |
| 6 | `application` + primer vertical UI (continuar partida → jornada → resultado) | Jugable end-to-end en Android |
| 7 | Mercado y finanzas | Transacciones atómicas, IA compradora |
| 8 | Cantera, staff, moral, lesiones | Sistemas interconectados con la simulación |
| 9 | Pulido, onboarding, retención | Métricas de sesión, tutorial |

El motor se construye **antes** que la UI (fases 2-4) porque concentra el
riesgo de producto: si la simulación no es creíble, la UI da igual.
