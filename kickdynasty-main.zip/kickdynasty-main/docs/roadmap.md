# Hoja de ruta — KickDynasty

> Regla de avance: una fase no empieza hasta que la anterior cumple su
> criterio de cierre (código + tests + docs + gates de CI verdes).
> Referencia de sistemas: [architecture.md](architecture.md).

## Fase 0 — Fundación ✅ cerrada

Infraestructura del monorepo y gates de calidad.

- [x] Repo, charter y ADRs 0001-0006
- [x] Pub workspace nativo + `Makefile` (analyze, format, test, balance, purity)
- [x] Gate de pureza de capas (`tool/check_purity.dart`)
- [x] CI GitHub Actions (quality / test / balance)
- [x] Flutter SDK instalado y `flutter doctor` sano (Android ✓; Xcode pendiente
      de instalación completa para iOS)
- [x] `make bootstrap` + `make analyze` verdes con el esqueleto de paquetes

**Cierre:** CI verde en main con el esqueleto completo.

## Fase 1 — Dominio ✅ cerrada

Entidades e invariantes núcleo en `packages/domain`.

- [x] Value objects: `Money`, `Rating`, `Age`, `Fitness`, `Morale`, `Form`,
      `MatchMinute`, `GameDate`, ids tipados, nombres y códigos
- [x] Entidades: `Player` + `PlayerAttributes`, `Club` + `Stadium`, `Squad`,
      `Contract`, `League`, `Fixture`, `MatchResult`
- [x] Táctica: `Formation` (catálogo estándar), `TacticalInstructions`,
      `MatchLineup` (vocabulario único del juego)
- [x] Eventos de partido: `GoalScored`, `CardIssued`, `PlayerInjured`,
      `Substitution` (los eventos de mercado llegan con la Fase 7)

**Cierre cumplido:** 94 tests (cada invariante tiene el suyo), cobertura de
líneas 100 % (gate `make coverage`, umbral 90 %), README y CHANGELOG del
paquete.

## Fase 2 — Generación procedural de mundo ✅ cerrada

En `packages/engine` (ADR 0006).

- [x] `Rng` inyectable + `Xoshiro256StarStar` determinista con flujos
      derivados por subsistema (`derivedSeed`)
- [x] Pools de nombres por país (ES, GB, DE, FR, IT, PT): personas, ciudades
      ficticias, patrones de club y estadio
- [x] `WorldGenConfig` como datos de balance: plantilla tipo, edades, bandas
      de calidad/reputación por nivel, salarios, contratos, estadios
- [x] Mundo reproducible: 2 ligas × 20 clubes × 26 jugadores por semilla,
      con invariantes de dominio garantizados en construcción

**Cierre cumplido:** 33 tests (determinismo del PRNG, propiedades de
distribución, robustez de generadores) + golden con la huella exacta del
mundo de la semilla 42. Cobertura del paquete 96 % (gate ≥ 90 %).

## Fase 3 — Simulación de partido ✅

El corazón del producto. Completada.

- ✅ Modelo de posesiones minuto a minuto: la batalla de mediocampos reparte
  la posesión, cada ocasión enfrenta ataque contra defensa
  (`MatchSimulator`, `computeUnitScores`)
- ✅ Modificadores: táctica completa, forma, moral, fatiga en juego, jugar
  fuera de posición, localía, urgencia por marcador y expulsiones
- ✅ Eventos con jugadores reales: goleador y asistente por pesos, propia
  puerta, tarjetas (amarilla/doble/roja), lesiones con cambio forzoso y
  sustituciones de IA
- ✅ Valoraciones 4–10 por participante + estadísticas de equipo (posesión,
  disparos, xG)
- ✅ Todo el balance como datos en `MatchEngineConfig.standard()` (ADR 0005)
- ✅ `TeamSheet` + `LineupSelector` (auto-alineación determinista para la IA
  y el avance de jornadas)

**Cierre cumplido:** suite `--tags balance` verde sobre >10 000 partidos —
goles/partido 2.2–3.2, victorias locales 40–52 % entre iguales, +15 de
calidad gana 70–92 %, tarjetas y lesiones en bandas realistas, tácticas con
efecto en la dirección correcta. Golden del partido de la semilla 42.
Cobertura del paquete 97.9 % (gate ≥ 90 %).

## Fase 4 — Temporada ✅

Completada.

- ✅ Calendario round-robin a doble vuelta (método del círculo, barajado por
  semilla, vuelta espejada) con propiedades verificadas en test
- ✅ Clasificación con desempates: puntos, diferencia, goles a favor,
  mini-liga de enfrentamientos directos por grupo empatado y fallback
  determinista (`LeagueTable`)
- ✅ Progresión/regresión por edad (declive físico más rápido), retiros
  probabilísticos y regens 1:1 por posición con contrato
  (`PlayerDevelopment`)
- ✅ Rotación de fatiga: fatiga post-partido + recuperación semanal parcial;
  el selector de alineaciones pondera el físico y la rotación emerge sola
  (`ConditionCycle`); moral por resultados y forma por valoración
- ✅ `SeasonSimulator`: temporada completa + `advanceSeason` (desarrollo,
  retiros, regens, ascensos/descensos entre niveles)
- ✅ Todo el balance en `SeasonConfig.standard()` (ADR 0005)

**Cierre cumplido:** temporada completa (38 jornadas × 2 ligas, 760
partidos) simulada en test con cierre contable de las tablas y golden de la
semilla 42; suite `balance` a 4 temporadas encadenadas con población
estable (tamaño, ≥2 porteros por club), calidad y edad medias sin deriva,
goles/partido en banda todas las temporadas, rotación real (≥15 jugadores
usados por club) y debut de canteranos. Cobertura del paquete 98.2 %.

## Fase 5 — Persistencia

Completada.

- ✅ `CampaignState` en el engine: el agregado que se guarda/carga y sobre el
  que la app avanzará jornadas (mundo actual + calendario + resultados +
  estadísticas + club del jugador)
- ✅ Esquema Drift normalizado (11 tablas, sin blobs JSON) claveado por
  `(saveId, slot)`: slot 0 = estado vivo, slots ≥ 1 = snapshots; un único
  mapeador y las migraciones cubren también el histórico
- ✅ `SaveRepository`: crear/sobrescribir/cargar/listar/borrar guardados y
  snapshots por jornada con retención configurable; todo transaccional
- ✅ Migración v1→v2 versionada (columna `player_club_id` + tabla
  `snapshots`) con test sobre una BD real fabricada en formato v1

**Cierre cumplido:** roundtrip de una temporada completa simulada por el
motor real (1040 jugadores, 760 resultados con eventos, +1000 estadísticas)
con test de igualdad profunda campo a campo, incluido el orden de las
listas; test de migración v1→v2 sobre fichero SQLite real conservando los
datos. Cobertura del paquete 99.8 % (excluido el código generado).

## Fase 6 — Vertical jugable

Completada.

- ✅ Casos de uso en `application`: nueva partida, cargar, listar, avanzar
  jornada (con snapshot automático) y guardar manualmente; providers
  Riverpod (`activeCampaignProvider`, `savedGamesProvider`,
  `playerLeagueTableProvider`)
- ✅ Motor: `bootstrapCampaign`, `playRound` y `tableFor` en
  `SeasonSimulator` (jornada a jornada ≡ temporada completa, testeado)
- ✅ Flujo end-to-end en `apps/mobile`: nueva partida → elegir club → hub
  de campaña → plantilla → avanzar jornada → resultados → clasificación →
  guardar/continuar
- ✅ Golden tests de las 5 pantallas del vertical

**Cierre cumplido:** APK debug jugable; golden tests del vertical en verde;
cobertura application 91.2 %.

## Fase 7 — Mercado y finanzas

- Ventanas de mercado, ofertas, negociación, cláusulas
- Transacciones atómicas (dinero + plantilla + masa salarial), `Either` de dominio
- IA de clubes compradora/vendedora según necesidades de plantilla
- Economía semanal (taquilla, TV, salarios, premios) sobre el modelo de Fase 4

**Cierre:** balance tests de economía a 5 temporadas; sin fugas de dinero
(suma global conservada salvo fuentes/sumideros definidos).

## Fase 8 — Sistemas de profundidad

- Cantera y juveniles; staff con efectos reales en simulación
- Moral por jugador con causas (minutos, resultados, mercado)
- Lesiones con tipos y plazos; interacción con fatiga y staff médico

**Cierre:** cada sistema con efecto medible y testeado en la simulación.

## Fase 9 — Pulido y lanzamiento

- Onboarding, tutorial contextual, ajustes, accesibilidad
- Rendimiento (simulación de jornada < 1 s en gama media)
- Preparación de tiendas (iconos, screenshots, ficha)

**Cierre:** release candidate en TestFlight / Play Internal Testing.
