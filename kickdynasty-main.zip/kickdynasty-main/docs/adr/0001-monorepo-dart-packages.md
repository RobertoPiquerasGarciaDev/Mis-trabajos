# ADR 0001 — Monorepo con paquetes Dart separados por capa

- Estado: **Aceptada** (2026-07-05)
- Decisores: Dirección técnica

## Contexto

El proyecto anterior (football-manager-ui) mezcló lógica de juego, UI y acceso a
datos en los mismos módulos. Resultado: dos motores de simulación duplicados
(cliente muerto + servidor pobre), 1.589 líneas de datos mock alimentando la UI
de producción y un desajuste de contratos entre capas que silenciaba las
tácticas del jugador.

## Decisión

Monorepo gestionado con **pub workspaces nativos** (Dart ≥ 3.6) y un
`Makefile` como runner de tareas, con paquetes Dart separados:

- `packages/domain` — entidades e invariantes; sin dependencias.
- `packages/engine` — lógica de juego; depende solo de `domain`.
- `packages/persistence` — Drift/SQLite; depende solo de `domain`.
- `packages/application` — casos de uso; orquesta engine + persistence.
- `apps/mobile` — Flutter; depende de `application` y `domain`.

La regla de dependencias (flechas solo hacia abajo) se verifica en CI con un
script de allowlist de imports, no por convención.

## Alternativas consideradas

1. **Proyecto Flutter único con carpetas** — descartada: las fronteras por
   carpeta no se pueden hacer cumplir; es el camino que degeneró en el
   proyecto anterior.
2. **Repos separados por paquete** — descartada: fricción de versionado
   enorme para un equipo pequeño; el workspace da la separación sin el coste.
3. **melos** — descartada tras probarlo: sus dependencias transitivas
   (`cli_util`) entraban en conflicto con `freezed`/`drift_dev` en el grafo
   del workspace; los pub workspaces nativos cubren el enlazado y un Makefile
   cubre los scripts sin añadir dependencias.

## Consecuencias

- (+) El motor se testea sin emulador, en milisegundos.
- (+) Las violaciones de capas rompen el build, no se descubren en auditorías.
- (−) Overhead inicial de configuración (workspace, pubspecs cruzados). Asumido.
