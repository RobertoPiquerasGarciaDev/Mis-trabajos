# ADR 0002 — Motor de simulación determinista y puro

- Estado: **Aceptada** (2026-07-05)
- Decisores: Dirección técnica

## Contexto

Un simulador de gestión vive o muere por la credibilidad de su simulación. El
proyecto anterior tenía un motor con `Random()` implícito y ratings derivados
de un hash MD5 del id del club, desconectado de los jugadores. Era imposible
razonar sobre balance, reproducir bugs o validar la justicia del sistema.

## Decisión

Todo el código de `packages/engine` cumple:

1. **Pureza**: sin I/O, sin `DateTime.now()`, sin estado global, sin imports de
   Flutter/red/disco. Funciones `(estado, config, rng) → resultado`.
2. **Determinismo**: la única fuente de aleatoriedad es un `Rng` inyectado
   (xoshiro256** en producción). Mismo input + semilla → mismo output.
3. **Los eventos referencian entidades reales**: un gol tiene un goleador que
   existe en la plantilla, con efectos sobre su forma, moral y estadísticas.

## Alternativas consideradas

1. **Motor con aleatoriedad libre** — descartada: imposibilita replays, tests
   de regresión y depuración de saves de usuarios.
2. **Simulación en servidor** — descartada para v1: el juego es offline-first
   (ADR 0003); un motor puro en Dart puede moverse a servidor después sin
   reescritura si hiciera falta.

## Consecuencias

- (+) Tests de balance estadístico en CI (10.000 partidos reproducibles).
- (+) Replays y highlights gratis (re-simular con la misma semilla).
- (+) Un save + semilla reproducen cualquier bug reportado.
- (−) Disciplina extra: nada de atajos con `Random()`. Verificado por lint.
