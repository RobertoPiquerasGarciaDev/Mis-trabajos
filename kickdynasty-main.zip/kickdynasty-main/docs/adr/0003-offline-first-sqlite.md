# ADR 0003 — Offline-first con SQLite (Drift)

- Estado: **Aceptada** (2026-07-05)
- Decisores: Dirección técnica; producto confirmó single-player para v1

## Contexto

Producto decidió: single-player en v1, multijugador después. Un juego de
gestión móvil se juega en desplazamientos, sin conectividad garantizada. El
proyecto anterior era online-only y la UI mostraba datos mock cuando el
backend no acompañaba.

## Decisión

- La partida vive **íntegramente en el dispositivo**, en SQLite gestionado con
  **Drift** (consultas tipadas, migraciones versionadas, soporte de isolates).
- Estado **normalizado en tablas** (no blob JSON): permite consultas sobre
  historiales y estadísticas sin cargar la partida entera en memoria.
- Snapshots por jornada con retención limitada (deshacer / continuidad).
- La nube, cuando llegue, será **sincronización de saves**, nunca requisito
  para jugar.

## Alternativas consideradas

1. **Isar / Hive (NoSQL)** — descartada: las consultas relacionales
   (clasificaciones históricas, agregados de temporada, mercado) son el pan de
   cada día de un juego de gestión; SQLite las resuelve de forma natural.
   Además, el estado de mantenimiento de Isar es incierto.
2. **JSON serializado a disco** — descartada: sin migraciones fiables ni
   consultas parciales; los saves crecerían sin control.
3. **Backend como fuente de verdad** — descartada para v1 por decisión de
   producto y por la lección del proyecto anterior.

## Consecuencias

- (+) Jugable en avión; cero dependencia de infraestructura.
- (+) Migraciones de esquema de save testeables en CI.
- (−) La sincronización multi-dispositivo futura exigirá resolución de
  conflictos (last-write-wins por partida es aceptable para single-player).
