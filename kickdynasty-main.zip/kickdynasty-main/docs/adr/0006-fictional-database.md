# ADR 0006 — Base de datos ficticia generada proceduralmente

- Estado: **Aceptada** (2026-07-05)
- Decisores: Dirección técnica; pendiente de ratificación por legal/producto

## Contexto

Los nombres reales de jugadores, clubes y competiciones están protegidos por
derechos de imagen y marcas (FIFPro, ligas). Usarlos sin licencia expone a
retiradas de las tiendas y demandas. Las licencias reales cuestan cifras fuera
del alcance de un estudio independiente.

## Decisión

- Todo el contenido (jugadores, clubes, ligas, nombres, escudos) es **ficticio
  y generado proceduralmente** por el motor, de forma determinista por semilla
  de partida.
- Generadores de nombres por locale (es, en, pt, de, fr, it…) con
  distribuciones realistas de nacionalidad por liga.
- Distribución de atributos por posición, edad y nivel de liga calibrada en
  `GameConfig` (ADR 0005).
- Arquitectura preparada para **packs de contenido del usuario** (importar
  nombres/escudos propios en su dispositivo), que es legalmente su
  responsabilidad y práctica estándar del género.

## Alternativas consideradas

1. **Scraping de datos reales** — descartada: riesgo legal directo.
2. **Base ficticia escrita a mano** — descartada: no escala (necesitamos
   ~10.000 jugadores por mundo y regeneración cada temporada).

## Consecuencias

- (+) Riesgo legal eliminado por diseño; publicable en ambas tiendas.
- (+) Rejugabilidad: cada partida genera un mundo distinto.
- (−) Menor atractivo inicial que los nombres reales. Mitigación: packs de
  usuario + calidad de la generación (nombres creíbles, historias emergentes).
