# ADR 0005 — Balance del juego como datos versionados con tests estadísticos

- Estado: **Aceptada** (2026-07-05)
- Decisores: Dirección técnica

## Contexto

En el proyecto anterior las constantes de juego (probabilidades, fórmulas
financieras) estaban dispersas en el código. Ajustar el balance significaba
tocar el motor, y no había forma objetiva de saber si un cambio "rompía" el
juego (p. ej. inflación descontrolada o ligas donde siempre gana el mismo).

## Decisión

- Todas las constantes de balance viven en `GameConfig`, un árbol de datos
  versionado dentro de `packages/engine/lib/src/config/`.
- El motor recibe `GameConfig` como parámetro; no hay números mágicos en la
  lógica.
- Una suite `balance_test` (etiquetada, corre en CI) valida **propiedades
  estadísticas** sobre miles de simulaciones con semillas fijas:
  - Distribución de goles por partido dentro de rango histórico real.
  - Correlación fuerza-resultados dentro de banda (ni determinista ni lotería).
  - Economía estable a 5 temporadas con IA por defecto.
  - Progresión/retiro de jugadores mantiene la población de las ligas.

## Alternativas consideradas

1. **Constantes en código con tests unitarios puntuales** — descartada: los
   tests puntuales no detectan efectos sistémicos (inflación, dominancia).
2. **Balance remoto (remote config)** — pospuesta: útil para live-ops futura,
   pero v1 offline no lo necesita; la estructura lo permite después.

## Consecuencias

- (+) Un diseñador puede proponer un cambio de balance como diff de datos.
- (+) CI rechaza cambios que rompan la salud sistémica del juego.
- (−) La suite estadística añade minutos al CI. Se ejecuta como job separado.
