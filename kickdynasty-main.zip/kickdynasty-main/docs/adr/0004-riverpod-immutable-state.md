# ADR 0004 — Estado con Riverpod y entidades inmutables (freezed)

- Estado: **Aceptada** (2026-07-05)
- Decisores: Dirección técnica

## Contexto

Necesitamos inyección de dependencias testeable y un flujo de estado
predecible en Flutter para un juego con estado grande y muy interconectado
(un traspaso afecta a plantilla, finanzas, moral y mercado a la vez).

## Decisión

- **Riverpod** (providers compilables, sin `BuildContext` para lógica) como
  contenedor de estado y DI en `application` y `apps/mobile`.
- Entidades y estados **inmutables con freezed**; los casos de uso devuelven
  nuevos estados, nunca mutan.
- Los widgets consumen providers selectivos (`select`) para reconstrucciones
  mínimas.

## Alternativas consideradas

1. **BLoC** — válida, pero más ceremonia por caso de uso; Riverpod cubre
   lo mismo con menos código y mejor composición de dependencias.
2. **GetX** — descartada: fomenta estado global mutable y service locators
   opacos; contraria a la testabilidad que exigimos.
3. **setState / InheritedWidget artesanal** — descartada: no escala a un
   estado del tamaño de una partida de gestión.

## Consecuencias

- (+) Cualquier caso de uso se testea instanciándolo con fakes de repositorio.
- (+) El estado de la partida tiene un único flujo de actualización.
- (−) Curva de aprendizaje de Riverpod 2.x. Asumida y documentada en el
  README de `application`.
